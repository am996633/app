$(function(){ 
	var yuming = document.location.hostname;  
	if(yuming == 'tuijian.blogcore.cn'){ 
		var BLOBAL_CMS_STATIC = "http://tuijian.blogcore.cn/www/static/"; 
	}else if(yuming == 'tuijian.blogchina.com'){ 
		var BLOBAL_CMS_STATIC = "http://tuijian.blogchina.com/www/static/"; 
	}else{ 
		var BLOBAL_CMS_STATIC = "http://tuijian.blogchina.com/www/static/"; 
	}



	var url = window.location.href;
	var url1 = url.split('//');
	var url2 = url1[1].split('/');
	var params = url2[2]; 
	
	if(params == 'wzdw'){
		var s = BLOBAL_CMS_STATIC +"images/location_up.png";
		$('.selected_a a').css("background-image","url("+s+")");
	}
	
	if(params == 'lsyl'){
		var s = BLOBAL_CMS_STATIC +"images/history_up.png";
		$('.selected_b a').css("background-image","url("+s+")");
	}	
	
	if(params == 'fzlc'){
		var s = BLOBAL_CMS_STATIC +"images/develop_up.png";
		$('.selected_c a').css("background-image","url("+s+")");
	}	
	
 	if(params == 'lxzb'){
		var s = BLOBAL_CMS_STATIC +"images/lxzb_up.png";
		$('.selected_d a').css("background-image","url("+s+")");
	}
	
	if(params == 'lxwm'){
		var s = BLOBAL_CMS_STATIC +"images/contact_up.png";
		$('.selected_e a').css("background-image","url("+s+")");
	}
	
	if(params == 'ggfw'){
		var s = BLOBAL_CMS_STATIC +"images/ad_up.png";
		$('.selected_f a').css("background-image","url("+s+")");
	}			
 
 	if(params == 'cpjy'){
		var s = BLOBAL_CMS_STATIC +"images/cpjy_up.png";
		$('.selected_g a').css("background-image","url("+s+")");
	}
 
});
