$(function() { 
	
	// //加载精彩图文
	// $.ajax({
	// 	url:GLOBAL_CMS_APP+'home/graphics',
	// 	dataType : "json",
	// 	type:'get',
	// 	async: false,
	// 	beforeSend:function(){$('#graphics_pic').attr('src',BLOBAL_CMS_STATIC+'images/top_jd.jpg');},
	// 	success:function(data){
	//
	// 		if(data.data.list.length != 0){
	// 			$('#graphics_title').text(data.data.list[0].article_title);
	// 			$('#graphics_title').attr('target','_blank');
	// 			$('#graphics_link').attr('target','_blank');
	// 			$('#graphics_title').attr('href',data.data.list[0].link);
	// 			$('#graphics_pic').attr('src',data.data.list[0].article_pic);
	// 			$('#graphics_link').attr('href',data.data.list[0].link);
	//   			$('.graphics_href').attr('href',data.data.list[0].link).attr('target','_blank');
	// 			$('.graphics_comment_num').attr('href',data.data.list[0].link+'#show_discuss').attr('target','_blank');
	// 			var content = '';
	//
	// 			for(i=0;i<data.data.list[0].article_related.length;i++){
	// 				var myurltou = /^(https?|ftp|http):\/\/[a-zA-Z0-9_]{1,}\.blogchina.com\/\d{1,}\.html$/i;
	// 				if(!myurltou.test(data.data.list[0].article_related[i].article_link)){
	// 					content+="<li><h2 class='tit'><a target='_blank' href='"+data.data.list[0].article_related[i].article_link+"'>"+data.data.list[0].article_related[i].article_title+"</a></h2><p class='article' style='word-wrap:break-word'><a target='_blank' href='"+data.data.list[0].article_related[i].article_link+"'>"+data.data.list[0].article_related[i].article_summary+"</a></p></li>";
	// 				}else{
	// 					var articleurl = data.data.list[0].article_related[i].article_link;
	//  					var articleurl1 = articleurl.split('//');
	//  					var articleurl2 = articleurl1[1].split('/');
	//  					var articleurl3 = articleurl2[1].split('.');
	//  					var aritcle_id = articleurl3[0];
	// 					content+="<li class='articlenumber' bid='"+aritcle_id+"'><h2 class='tit'><a target='_blank' href='"+data.data.list[0].article_related[i].article_link+"'>"+data.data.list[0].article_related[i].article_title+"</a></h2><p class='article' style='word-wrap:break-word'><a target='_blank' href='"+data.data.list[0].article_related[i].article_link+"'>"+data.data.list[0].article_related[i].article_summary+"</a></p><p class='ins right'><a target='_blank' href='"+data.data.list[0].article_related[i].article_link+"'>参与 <span class='first_comment_article_num_"+aritcle_id+"'>0</span></a><a target='_blank' href='"+data.data.list[0].article_related[i].article_link+"#show_discuss'>评论 ";
	//
	// 					content+="<span class='first_comment_num_"+aritcle_id+"'>0</span>";
	//
	// 					content+="</a><a target='_blank' href='"+data.data.list[0].article_related[i].article_link+"'>支持 <span class='first_support_num_"+aritcle_id+"'>0</span></a></p></li>";
	// 			   }
	// 			}
	//  			$('.news_rest').html(content);
	//
	//  			//获取文章的各数量 如果有外链  就不显示参与和评论
	// 			var article_ids = [];
	// 			article_ids[0] = data.data.list[0].article_id;
	// 			if(article_ids[0] == 10 || article_ids[0] == 11){
	// 				$('.pcshowhide').hide();
	// 			}else{
	// 				$.ajax({
	// 					url:GLOBAL_CMS_APP+'home/articlenumber',
	// 					data:{bids:article_ids},
	// 					dataType : "json",
	// 					type:'post',
	// 					success:function(msg){
	// 						$.each(msg,function(i,n){
	// 							$('#graphics_clicknum').text('['+n.click+']');
	// 							$('#graphics_commentnum').text('['+n.comment+']');
	// 						})
	// 					}
	// 				});
	// 			}
	//
	// 		};
	// 	},
	// });
	
	
	//加载各文章数量
	var bids = [];   
	var i = 0;
	$('.articlenumber').each(function(){
		bids[i]=$(this).attr("bid");
	    i++;
	});  
	 
	$.ajax({
		url:GLOBAL_CMS_APP+'home/articlenumber',
		data:{bids:bids},
		dataType : "json",
		type:'post',
		success:function(msg){
			$.each(msg,function(i,n){ 
				$(".comment_article_num_"+n.aid).text(n.click);
				$(".comment_num_"+n.aid).text(n.comment);
				$(".support_num_"+n.aid).text(n.support); 
				$(".focus_comment_article_num_"+n.aid).text(n.click);
				$(".focus_comment_num_"+n.aid).text(n.comment);
				$(".focus_support_num_"+n.aid).text(n.support);  
				
				
				$(".first_comment_article_num_"+n.aid).text(n.click); 
				$(".first_comment_num_"+n.aid).text(n.comment);
				$(".first_support_num_"+n.aid).text(n.support);  
			}) 
		},
		error:function(){ 
		}
	});
	
	
	
  //专栏作家排行
  // $.ajax({
	// 	url:GLOBAL_CMS_APP+'home/userauthor',
	// 	dataType : "json",
	// 	type:'get',
	// 	success:function(msg){
	//
	//
	// 		if(msg.code == "A0200"){
	// 			var content = "";
	// 			for(i=0;i<msg.data.list.length;i++){
	// 				if(i<3){
	// 					content+="<li class='usernames' usernameid='"+msg.data.list[i].user_id+"'><a target='_blank' href='http://"+msg.data.list[i].user_name+".blogchina.com' class='avatar'><img src='"+msg.data.list[i].user_pic+"' onerror=\"this.src='"+BLOBAL_CMS_STATIC+"images/pl_tx_kong.jpg'\"></a><div class='rt'><p class='writer'><a target='_blank' href='http://"+msg.data.list[i].user_name+".blogchina.com'><img src='"+BLOBAL_CMS_STATIC+"images/h_culli"+(i+1)+".png'/>"+msg.data.list[i].user_nick+"</a></p><p class='writer'><a target='_blank' href='http://"+msg.data.list[i].user_name+".blogchina.com'><img src='"+BLOBAL_CMS_STATIC+"images/h_cullicik.png'/> <em id='click_num_"+msg.data.list[i].user_id+"'>"+msg.data.list[i].click+"</em></a><a target='_blank' href='http://"+msg.data.list[i].user_name+".blogchina.com'><img src='"+BLOBAL_CMS_STATIC+"images/h_culliread.png'/> <em id='article_num_"+msg.data.list[i].user_id+"'>"+msg.data.list[i].article+"</em></a></p><dl class='rest'>";
  //
	// 				}else{
 	// 					content+="<li class='usernames' usernameid='"+msg.data.list[i].user_id+"'><a target='_blank' href='http://"+msg.data.list[i].user_name+".blogchina.com' class='avatar'><img src='"+msg.data.list[i].user_pic+"' onerror=\"this.src='"+BLOBAL_CMS_STATIC+"images/pl_tx_kong.jpg'\"></a><div class='rt'><p class='writer'><a target='_blank' href='http://"+msg.data.list[i].user_name+".blogchina.com'><img src='"+BLOBAL_CMS_STATIC+"images/h_culli.png'/>"+msg.data.list[i].user_nick+"</a></p><p class='writer'><a target='_blank' href='http://"+msg.data.list[i].user_name+".blogchina.com'><img src='"+BLOBAL_CMS_STATIC+"images/h_cullicik.png'/> <em id='click_num_"+msg.data.list[i].user_id+"'>"+msg.data.list[i].click+"</em></a><a target='_blank' href='http://"+msg.data.list[i].user_name+".blogchina.com'><img src='"+BLOBAL_CMS_STATIC+"images/h_culliread.png'/> <em id='article_num_"+msg.data.list[i].user_id+"'>"+msg.data.list[i].article+"</em></a></p><dl class='rest'>";
 	// 				}
 	// 				if(msg.data.list[i].top_article != ''){
	// 					for(j=0;j<msg.data.list[i].top_article.length;j++){
	// 						content+="<dd><a target='_blank' href='"+msg.data.list[i].top_article[j].article_link+"'><span></span>"+msg.data.list[i].top_article[j].article_title+"</a></dd>";
	// 					} ;
	// 				};
	//
	// 				content+="</dl></div></li>";
	// 			};
	// 			$('#userauthor').html(content);
	// 		}
	// 	} ,
	// });
   
  	//加载话题
    // $.ajax({
	// 	url:GLOBAL_CMS_APP+'home/subject',
	// 	dataType : "json",
	// 	type:'get',
	// 	beforeSend:function(){$('#topicslink > img').attr('src',BLOBAL_CMS_STATIC+'images/right.jpg');},
	// 	success:function(msg){
	//
	//
	// 		if(msg.data.list.length != 0){
	// 			$("#huatititle").html(msg.data.list[0].subject_name);
	// 			$("#topicslink").attr('target','_blank');
	// 			$('#topicslink').attr('href',msg.data.list[0].article_link);
	// 			$('#topicslink > img').attr('src',msg.data.list[0].article_pic);
	// 			$('#toptitlelink').attr('target','_blank');
	// 			$('#toptitlelink').attr('href',msg.data.list[0].article_link);
	// 			$('#toptitlelink').text(msg.data.list[0].article_title);
	// 			$('#toptitlelink').parents('.talk_list').find('.article').children('a').attr('href',msg.data.list[0].article_link).html(msg.data.list[0].article_summary);
	// 			$('#toptitlelink').parents('.talk_list').find('.article').children('a').attr('target','_blank');
	// 			var content = "";
	// 			for(i=0;i<msg.data.list[0].article_subtitle.length;i++){
	// 				content+="<dd><a target='_blank' href='"+msg.data.list[0].article_subtitle[i].article_link+"'><span></span>"+msg.data.list[0].article_subtitle[i].article_title+"</a></dd>";
	// 			}
	// 				$('#correlatetitle').html(content);
	// 		}
	// 	},
	// 	error:function(){
    //
	// 	}
	// });
   

  
   
  //最新专题
  // $.ajax({
	// 	url:GLOBAL_CMS_APP+'home/newspecial',
	// 	dataType : "json",
	// 	type:'get',
	// 	success:function(msg){
	// 		if(msg.code == 'A0200'){
	// 			if(msg.data.list.length>0){
	// 				var content = '';
	// 				for(i=0;i<msg.data.list.length;i++){
	// 					content+="<li> <a target='_blank' href='"+msg.data.list[i].article_link+"' class='avatar'><img src='"+msg.data.list[i].article_pic+"' onerror=\"this.src='"+BLOBAL_CMS_STATIC+"images/right.jpg'\"><span class='n_pictures_t'></span><span class='n_pictures_b'></span></a><h2 class='title'><a target='_blank' href='"+msg.data.list[i].article_link+"'>"+msg.data.list[i].article_title+"</a></h2><p class='article'><a target='_blank' href='"+msg.data.list[i].article_link+"'>"+msg.data.list[i].article_summary+"</a></p></li>";
	// 				};
	// 		 		$('#newspecial').html(content);
	// 			}else if(msg.data.list.length == 0){
	// 				$('#newspecial').html('暂无数据');
	// 			}
	// 		}else{
	// 			console.log('服务器内部错误');return false;
	// 		}
	// 	}
	// });
  
	
	//热门文章2天
	$('#hotarticle1').mouseover(function(){
		$('#articles_fadetab >dd').removeClass('cur');
		$(this).addClass('cur');
	 	$('#articles_fadecon ul').eq(0).show();
 		$('#articles_fadecon ul').eq(1).hide();
		$('#articles_fadecon ul').eq(2).hide();
	})
  	
  	//热门文章7天
	$('#hotarticle2').mouseover(function(){
		$('#articles_fadetab >dd').removeClass('cur');
		$(this).addClass('cur');
 		$('#articles_fadecon ul').eq(0).hide();
 		$('#articles_fadecon ul').eq(1).show();
 		$('#articles_fadecon ul').eq(2).hide();
	})
	
	//热门文章30天
	$('#hotarticle3').mouseover(function(){
		$('#articles_fadetab >dd').removeClass('cur');
		$(this).addClass('cur');
		$('#articles_fadecon ul').eq(0).hide();
 		$('#articles_fadecon ul').eq(1).hide();
 		$('#articles_fadecon ul').eq(2).show();
		
		
	})
	
	
	
	
	
	//热门评论2天
	$('#hotcomment1').mouseover(function(){
		$('#comments_fadetab >dd').removeClass('cur');
		$(this).addClass('cur');
	 	$('#comments_fadecon ul').eq(0).show();
 		$('#comments_fadecon ul').eq(1).hide();
 		$('#comments_fadecon ul').eq(2).hide();
		
		});
 
	//热门评论7天
	$('#hotcomment2').mouseover(function(){
		$('#comments_fadetab >dd').removeClass('cur');
		$(this).addClass('cur');
 		$('#comments_fadecon ul').eq(0).hide();
 		$('#comments_fadecon ul').eq(1).show();
 		$('#comments_fadecon ul').eq(2).hide();

	})
	
	
	//热门30天
	$('#hotcomment3').mouseover(function(){
		$('#comments_fadetab >dd').removeClass('cur');
		$(this).addClass('cur');
		$('#comments_fadecon ul').eq(0).hide();
 		$('#comments_fadecon ul').eq(1).hide();
 		$('#comments_fadecon ul').eq(2).show();

	})
	

	
	
	//热门支持2天
	$('#hotsupport1').mouseover(function(){
		$('#supportrate_fadetab >dd').removeClass('cur');
		$(this).addClass('cur');
	 	$('#supportrate_fadecon ul').eq(0).show();
 		$('#supportrate_fadecon ul').eq(1).hide();
		$('#supportrate_fadecon ul').eq(2).hide();
	
	

	})
	
	
	//热门支持7天
	$('#hotsupport2').mouseover(function(){
		$('#supportrate_fadetab >dd').removeClass('cur');
		$(this).addClass('cur');
	 	$('#supportrate_fadecon ul').eq(0).hide();
 		$('#supportrate_fadecon ul').eq(1).show();
 		$('#supportrate_fadecon ul').eq(2).hide();
		
	

	})
	
	
	
	//热门支持30天
	$('#hotsupport3').mouseover(function(){
		$('#supportrate_fadetab >dd').removeClass('cur');
		$(this).addClass('cur');
	 	$('#supportrate_fadecon ul').eq(0).hide();
 		$('#supportrate_fadecon ul').eq(1).hide();
 		$('#supportrate_fadecon ul').eq(2).show();
	

		
	})
	
	
	//右侧标签专栏作家 author tangqiyin 2015-2-15
	//  $.ajax({
	// 	url:GLOBAL_CMS_APP+'home/usermarkauthor',
	// 	dataType : "json",
	// 	//data:{'user_category':1},
	// 	type:'get',
	// 	success:function(msg){
	// 		if(msg.code == 'A0200'){
	// 			if(msg.data.list.length>0){
	// 				var content = "";
	// 				for(i=0;i<msg.data.list.length;i++){
	// 				 content+= "<dd><a target='_blank' href='http://"+msg.data.list[i].user_name+".blogchina.com' class='avatar'><img src='"+msg.data.list[i].user_pic+"' onerror=\"this.src='"+BLOBAL_CMS_STATIC+"images/pl_tx_kong.jpg'\"></a><p class='writer'><a target='_blank' href='http://"+msg.data.list[i].user_name+".blogchina.com'>"+msg.data.list[i].user_nick+"</a></p></dd> ";
	// 				}
	// 		 		 $('#usermarkauthor').html(content);
	// 			}else if(msg.data.list.length == 0){
	// 					$('#usermarkauthor').html('<dd>暂无数据</dd>');
	// 				}
	// 		}else if(msg.code == 'A0204'){
	// 			$('#usermarkauthor').html('<dd>暂无数据</dd>');
	// 		}
	// 	}
	// });
	//
	// //时政
	// $('#politics').mouseover(function(){
	// 	$('.columnist_category > ul >li').removeClass('cur');
	// 	$(this).addClass('cur');
	// 	var tagname = '时政';
	// 	$.ajax({
	// 		url:GLOBAL_CMS_APP+'home/usermarkauthor',
	// 		dataType : "json",
	// 		data:{'user_category':tagname},
	// 		type:'get',
	// 		success:function(msg){
 	// 			if(msg.code == 'A0200'){
	// 				if(msg.data.list.length>0){
	// 					var content = "";
	// 					for(i=0;i<msg.data.list.length;i++){
	// 					 content+= "<dd><a target='_blank' href='http://"+msg.data.list[i].user_name+".blogchina.com' class='avatar'><img src='"+msg.data.list[i].user_pic+"' onerror=\"this.src='"+BLOBAL_CMS_STATIC+"images/pl_tx_kong.jpg'\"></a><p class='writer'><a href='http://"+msg.data.list[i].user_name+".blogchina.com'>"+msg.data.list[i].user_nick+"</a></p></dd> ";
	// 					}
	// 			 		$('#usermarkauthor').html(content);
	// 				}else if(msg.data.list.length == 0){
	// 						$('#usermarkauthor').html('<dd>暂无数据</dd>');
	// 					}
	// 			}else if(msg.code == 'A0204'){
	// 				$('#usermarkauthor').html('<dd>暂无数据</dd>');
	// 			}
	// 		}
	// 	});
	//
	// })
	//
	// //科技
	// $('#tech').mouseover(function(){
	// 	$('.columnist_category > ul >li').removeClass('cur');
	// 	$(this).addClass('cur');
	// 	var tagname = '科技';
	// 	$.ajax({
	// 		url:GLOBAL_CMS_APP+'home/usermarkauthor',
	// 		dataType : "json",
	// 		data:{'user_category':tagname},
	// 		type:'get',
	// 		success:function(msg){
	// 			if(msg.code == 'A0200'){
	// 				if(msg.data.list.length>0){
	// 					var content = "";
	// 					for(i=0;i<msg.data.list.length;i++){
	// 					 content+= "<dd><a target='_blank' href='http://"+msg.data.list[i].user_name+".blogchina.com' class='avatar'><img src='"+msg.data.list[i].user_pic+"' onerror=\"this.src='"+BLOBAL_CMS_STATIC+"images/pl_tx_kong.jpg'\"></a><p class='writer'><a href='http://"+msg.data.list[i].user_name+".blogchina.com'>"+msg.data.list[i].user_nick+"</a></p></dd> ";
	// 					}
	// 			 		$('#usermarkauthor').html(content);
	// 				}else if(msg.data.list.length == 0){
	// 						$('#usermarkauthor').html('<dd>暂无数据</dd>');
	// 					}
	// 			}else if(msg.code == 'A0204'){
	// 				$('#usermarkauthor').html('<dd>暂无数据</dd>');
	// 			}
	// 		}
	// 	});
	// })
	//
	//
	// //财经
	// $('#finance').mouseover(function(){
	// 	$('.columnist_category > ul >li').removeClass('cur');
	// 	$(this).addClass('cur');
	// 	var tagname = '财经';
	// 	$.ajax({
	// 		url:GLOBAL_CMS_APP+'home/usermarkauthor',
	// 		dataType : "json",
	// 		data:{'user_category':tagname},
	// 		type:'get',
	// 		success:function(msg){
	// 			if(msg.code == 'A0200'){
	// 				if(msg.data.list.length>0){
	// 					var content = "";
	// 					for(i=0;i<msg.data.list.length;i++){
	// 					 content+= "<dd><a target='_blank' href='http://"+msg.data.list[i].user_name+".blogchina.com' class='avatar'><img src='"+msg.data.list[i].user_pic+"' onerror=\"this.src='"+BLOBAL_CMS_STATIC+"images/pl_tx_kong.jpg'\"></a><p class='writer'><a href='http://"+msg.data.list[i].user_name+".blogchina.com'>"+msg.data.list[i].user_nick+"</a></p></dd> ";
	// 					}
	// 			 		$('#usermarkauthor').html(content);
	// 				}else if(msg.data.list.length == 0){
	// 						$('#usermarkauthor').html('<dd>暂无数据</dd>');
	// 					}
	// 			}else if(msg.code == 'A0204'){
	// 				$('#usermarkauthor').html('<dd>暂无数据</dd>');
	// 			}
	// 		}
	// 	});
	// })
	//
	// //娱乐
	// $('#entertain').mouseover(function(){
	// 	$('.columnist_category > ul >li').removeClass('cur');
	// 	$(this).addClass('cur');
	// 	var tagname = '娱乐';
	// 	$.ajax({
	// 		url:GLOBAL_CMS_APP+'home/usermarkauthor',
	// 		dataType : "json",
	// 		data:{'user_category':tagname},
	// 		type:'get',
	// 		success:function(msg){
	// 			if(msg.code == 'A0200'){
	// 				if(msg.data.list.length>0){
	// 					var content = "";
	// 					for(i=0;i<msg.data.list.length;i++){
	// 					 content+= "<dd><a target='_blank' href='http://"+msg.data.list[i].user_name+".blogchina.com' class='avatar'><img src='"+msg.data.list[i].user_pic+"' onerror=\"this.src='"+BLOBAL_CMS_STATIC+"images/pl_tx_kong.jpg'\"></a><p class='writer'><a href='http://"+msg.data.list[i].user_name+".blogchina.com'>"+msg.data.list[i].user_nick+"</a></p></dd> ";
	// 					}
	// 			 		$('#usermarkauthor').html(content);
	// 				}else if(msg.data.list.length == 0){
	// 						$('#usermarkauthor').html('<dd>暂无数据</dd>');
	// 					}
	// 			}else if(msg.code == 'A0204'){
	// 				$('#usermarkauthor').html('<dd>暂无数据</dd>');
	// 			}
	// 		}
	// 	});
	// })
	//
	//
	// //传媒
	// $('#media').mouseover(function(){
	// 	$('.columnist_category > ul >li').removeClass('cur');
	// 	$(this).addClass('cur');
	// 	var tagname = '传媒';
	// 	$.ajax({
	// 		url:GLOBAL_CMS_APP+'home/usermarkauthor',
	// 		dataType : "json",
	// 		data:{'user_category':tagname},
	// 		type:'get',
	// 		success:function(msg){
	// 			if(msg.code == 'A0200'){
	// 				if(msg.data.list.length>0){
	// 					var content = "";
	// 					for(i=0;i<msg.data.list.length;i++){
	// 					 content+= "<dd><a target='_blank' href='http://"+msg.data.list[i].user_name+".blogchina.com' class='avatar'><img src='"+msg.data.list[i].user_pic+"' onerror=\"this.src='"+BLOBAL_CMS_STATIC+"images/pl_tx_kong.jpg'\"></a><p class='writer'><a href='http://"+msg.data.list[i].user_name+".blogchina.com'>"+msg.data.list[i].user_nick+"</a></p></dd> ";
	// 					}
	// 			 		$('#usermarkauthor').html(content);
	// 				}else if(msg.data.list.length == 0){
	// 						$('#usermarkauthor').html('<dd>暂无数据</dd>');
	// 					}
	// 			}else if(msg.code == 'A0204'){
	// 				$('#usermarkauthor').html('<dd>暂无数据</dd>');
	// 			}
	// 		}
	// 	});
	// })
	//
	//
	// //文史
	// $('#chistory').mouseover(function(){
	// 	$('.columnist_category > ul >li').removeClass('cur');
	// 	$(this).addClass('cur');
	// 	var tagname = '文史';
	// 	$.ajax({
	// 		url:GLOBAL_CMS_APP+'home/usermarkauthor',
	// 		dataType : "json",
	// 		data:{'user_category':tagname},
	// 		type:'get',
	// 		success:function(msg){
	// 			if(msg.code == 'A0200'){
	// 				if(msg.data.list.length>0){
	// 					var content = "";
	// 					for(i=0;i<msg.data.list.length;i++){
	// 					 content+= "<dd><a target='_blank' href='http://"+msg.data.list[i].user_name+".blogchina.com' class='avatar'><img src='"+msg.data.list[i].user_pic+"' onerror=\"this.src='"+BLOBAL_CMS_STATIC+"images/pl_tx_kong.jpg'\"></a><p class='writer'><a href='http://"+msg.data.list[i].user_name+".blogchina.com'>"+msg.data.list[i].user_nick+"</a></p></dd> ";
	// 					}
	// 			 		$('#usermarkauthor').html(content);
	// 				}else if(msg.data.list.length == 0){
	// 						$('#usermarkauthor').html('<dd>暂无数据</dd>');
	// 					}
	// 			}else if(msg.code == 'A0204'){
	// 				$('#usermarkauthor').html('<dd>暂无数据</dd>');
	// 			}
	// 		}
	// 	});
	// })
	

	
  //加载最新文章  
  //加载第一块内容
  // $.ajax({
	// 	url:GLOBAL_CMS_APP+'home/lists',
	// 	dataType : "json",
	// 	type:'get',
	// 	data:{page:1, limit: 80},
	// 	success:function(d){
	// 		if(d.code == 'A0200'){
	// 			var content1 = '';
	// 			for(i=0;i<10;i++){
	// 				content1+="<li><a target='_blank' href='http://"+d.data.list[i].user_name+".blogchina.com/"+d.data.list[i].article_id+".html'>"+d.data.list[i].article_title+" </a><a target='_blank' href='http://"+d.data.list[i].user_name+".blogchina.com'><strong>"+d.data.list[i].user_nick+"</strong></a></li>";
	// 	 		};
	// 	 		$('#listdiv1').html(content1);
	// 	 		var content2 = '';
	// 			for(i=10;i<20;i++){
	// 				content2+="<li><a target='_blank' href='http://"+d.data.list[i].user_name+".blogchina.com/"+d.data.list[i].article_id+".html'>"+d.data.list[i].article_title+" </a><a target='_blank' href='http://"+d.data.list[i].user_name+".blogchina.com'><strong>"+d.data.list[i].user_nick+"</strong></a></li>";
	// 	 		};
	// 	 		$('#listdiv2').html(content2);
	// 	 		var content3 = '';
	// 			for(i=20;i<30;i++){
	// 				content3+="<li><a target='_blank' href='http://"+d.data.list[i].user_name+".blogchina.com/"+d.data.list[i].article_id+".html'>"+d.data.list[i].article_title+" </a><a target='_blank' href='http://"+d.data.list[i].user_name+".blogchina.com'><strong>"+d.data.list[i].user_nick+"</strong></a></li>";
	// 	 		};
	// 	 		$('#listdiv3').html(content3);
	// 	 		var content4 = '';
	// 			for(i=30;i<40;i++){
	// 				content4+="<li><a target='_blank' href='http://"+d.data.list[i].user_name+".blogchina.com/"+d.data.list[i].article_id+".html'>"+d.data.list[i].article_title+" </a><a target='_blank' href='http://"+d.data.list[i].user_name+".blogchina.com'><strong>"+d.data.list[i].user_nick+"</strong></a></li>";
	// 	 		};
	// 	 		$('#listdiv4').html(content4);
	// 	 		var content5 = '';
	// 			for(i=40;i<50;i++){
	// 				content5+="<li><a target='_blank' href='http://"+d.data.list[i].user_name+".blogchina.com/"+d.data.list[i].article_id+".html'>"+d.data.list[i].article_title+" </a><a target='_blank' href='http://"+d.data.list[i].user_name+".blogchina.com'><strong>"+d.data.list[i].user_nick+"</strong></a></li>";
	// 	 		};
	// 	 		$('#listdiv5').html(content5);
	// 	 		var content6 = '';
	// 			for(i=50;i<60;i++){
	// 				content6+="<li><a target='_blank' href='http://"+d.data.list[i].user_name+".blogchina.com/"+d.data.list[i].article_id+".html'>"+d.data.list[i].article_title+" </a><a target='_blank' href='http://"+d.data.list[i].user_name+".blogchina.com'><strong>"+d.data.list[i].user_nick+"</strong></a></li>";
	// 	 		};
	// 	 		$('#listdiv6').html(content6);
	// 	 		var content7 = '';
	// 			for(i=60;i<70;i++){
	// 				content7+="<li><a target='_blank' href='http://"+d.data.list[i].user_name+".blogchina.com/"+d.data.list[i].article_id+".html'>"+d.data.list[i].article_title+" </a><a target='_blank' href='http://"+d.data.list[i].user_name+".blogchina.com'><strong>"+d.data.list[i].user_nick+"</strong></a></li>";
	// 	 		};
	// 	 		$('#listdiv7').html(content7);
	// 	 		var content8 = '';
	// 			for(i=70;i<80;i++){
	// 				content8+="<li><a target='_blank' href='http://"+d.data.list[i].user_name+".blogchina.com/"+d.data.list[i].article_id+".html'>"+d.data.list[i].article_title+" </a><a target='_blank' href='http://"+d.data.list[i].user_name+".blogchina.com'><strong>"+d.data.list[i].user_nick+"</strong></a></li>";
	// 	 		};
	// 	 		$('#listdiv8').html(content8);
	// 		}else{
	// 			$('#listdiv1').html('暂无文章');
	// 		}
	// 	}
	// });
  //加载第二块内容
 //  $.ajax({
	// 	url:GLOBAL_CMS_APP+'home/lists',
	// 	dataType : "json", 
	// 	type:'get',
	// 	data:{page:2},
	// 	async:false,
	// 	success:function(d){
			
			
	// 		if(d.code == 'A0200'){
	// 			var content = ''; 
	// 			for(i=0;i<d.data.list.length;i++){  
	// 				//content+="<li><span><a target='_blank' href='http://pindao.blogchina.com/blog/lists/channel/"+data.data.list[i].article_channel_name+"'>【"+data.data.list[i].article_channel_name+"】</a></span><a target='_blank' href='http://"+data.data.list[i].user_name+".blogchina.com/"+data.data.list[i].article_id+".html'>"+data.data.list[i].article_title+" <strong>"+data.data.list[i].user_nick+"</strong></a></li>";
	// 				content+="<li><a target='_blank' href='http://"+d.data.list[i].user_name+".blogchina.com/"+d.data.list[i].article_id+".html'>"+d.data.list[i].article_title+" </a><a target='_blank' href='http://"+d.data.list[i].user_name+".blogchina.com'><strong>"+d.data.list[i].user_nick+"</strong></a></li>";
	// 	 		};
	// 	 		$('#listdiv2').html(content);
	// 		}else{
	// 			$('#listdiv2').html('暂无文章');
	// 		}  
	// 	}
	// });
 //  //加载第三块内容
 //  $.ajax({
	// 	url:GLOBAL_CMS_APP+'home/lists',
	// 	dataType : "json", 
	// 	type:'get',
	// 	data:{page:3},
	// 	async:false,
	// 	success:function(data){
	// 		if(data.code == 'A0200'){
	// 			var content = ''; 
	// 			for(i=0;i<data.data.list.length;i++){  
	// 				content+="<li><a target='_blank' href='http://"+data.data.list[i].user_name+".blogchina.com/"+data.data.list[i].article_id+".html'>"+data.data.list[i].article_title+" </a><a target='_blank' href='http://"+data.data.list[i].user_name+".blogchina.com'><strong>"+data.data.list[i].user_nick+"</strong></a></li>";
	// 	 		};
	// 	 		$('#listdiv3').html(content);
	// 		}else{
	// 			$('#listdiv3').html('暂无文章');
	// 		} 
			 
	// 	}
	// });
	// //加载第四块
 //    $.ajax({
	// 	url:GLOBAL_CMS_APP+'home/lists',
	// 	dataType : "json", 
	// 	type:'get',
	// 	data:{page:4},
	// 	async:false,
	// 	success:function(data){
	// 		if(data.code == 'A0200'){
	// 			var content = ''; 
	// 			for(i=0;i<data.data.list.length;i++){  
	// 				content+="<li><a target='_blank' href='http://"+data.data.list[i].user_name+".blogchina.com/"+data.data.list[i].article_id+".html'>"+data.data.list[i].article_title+" </a><a target='_blank' href='http://"+data.data.list[i].user_name+".blogchina.com'><strong>"+data.data.list[i].user_nick+"</strong></a></li>";
	// 	 		};
	// 	 		$('#listdiv4').html(content);
	// 		}else{
	// 			$('#listdiv4').html('暂无文章');
	// 		} 
			 
	// 	}
	// });
	// /*author:wangpeng time:2015-04-15 */
	// //加载第五块
 //    $.ajax({
	// 	url:GLOBAL_CMS_APP+'home/lists',
	// 	dataType : "json", 
	// 	type:'get',
	// 	data:{page:5},
	// 	async:false,
	// 	success:function(data){
			
			
	// 		if(data.code == 'A0200'){
	// 			var content = ''; 
	// 			for(i=0;i<data.data.list.length;i++){  
	// 				content+="<li><a target='_blank' href='http://"+data.data.list[i].user_name+".blogchina.com/"+data.data.list[i].article_id+".html'>"+data.data.list[i].article_title+" </a><a target='_blank' href='http://"+data.data.list[i].user_name+".blogchina.com'><strong>"+data.data.list[i].user_nick+"</strong></a></li>";
	// 	 		};
	// 	 		$('#listdiv5').html(content);
	// 		}else{
	// 			$('#listdiv5').html('暂无文章');
	// 		} 
			 
	// 	}
	// });
	
	// //加载第六块
 //    $.ajax({
	// 	url:GLOBAL_CMS_APP+'home/lists',
	// 	dataType : "json", 
	// 	type:'get',
	// 	data:{page:6},
	// 	async:false,
	// 	success:function(data){
	// 		if(data.code == 'A0200'){
	// 			var content = ''; 
	// 			for(i=0;i<data.data.list.length;i++){  
	// 				content+="<li><a target='_blank' href='http://"+data.data.list[i].user_name+".blogchina.com/"+data.data.list[i].article_id+".html'>"+data.data.list[i].article_title+" </a><a target='_blank' href='http://"+data.data.list[i].user_name+".blogchina.com'><strong>"+data.data.list[i].user_nick+"</strong></a></li>";
	// 	 		};
	// 	 		$('#listdiv6').html(content);
	// 		}else{
	// 			$('#listdiv6').html('暂无文章');
	// 		} 
			 
	// 	}
	// });
	// //加载第七块
 //    $.ajax({
	// 	url:GLOBAL_CMS_APP+'home/lists',
	// 	dataType : "json", 
	// 	type:'get',
	// 	data:{page:7},
	// 	async:false,
	// 	success:function(data){
	// 		if(data.code == 'A0200'){
	// 			var content = ''; 
	// 			for(i=0;i<data.data.list.length;i++){  
	// 				content+="<li><a target='_blank' href='http://"+data.data.list[i].user_name+".blogchina.com/"+data.data.list[i].article_id+".html'>"+data.data.list[i].article_title+" </a><a target='_blank' href='http://"+data.data.list[i].user_name+".blogchina.com'><strong>"+data.data.list[i].user_nick+"</strong></a></li>";
	// 	 		};
	// 	 		$('#listdiv7').html(content);
	// 		}else{
	// 			$('#listdiv7').html('暂无文章');
	// 		} 
			 
	// 	}
	// });
 //  //加载第八块内容
 //  $.ajax({
	// 	url:GLOBAL_CMS_APP+'home/lists',
	// 	dataType : "json", 
	// 	type:'get',
	// 	data:{page:8},
	// 	async:false,
	// 	success:function(data){
	// 		if(data.code == 'A0200'){
	// 			var content = ''; 
	// 			for(i=0;i<data.data.list.length;i++){  
	// 				content+="<li><a target='_blank' href='http://"+data.data.list[i].user_name+".blogchina.com/"+data.data.list[i].article_id+".html'>"+data.data.list[i].article_title+" </a><a target='_blank' href='http://"+data.data.list[i].user_name+".blogchina.com'><strong>"+data.data.list[i].user_nick+"</strong></a></li>";
	// 	 		};
	// 	 		$('#listdiv8').html(content);
	// 		}else{
	// 			$('#listdiv8').html('暂无文章');
	// 		}  
	// 	}
	// }); 
	
	
	
	

	
	//加载评论列表
	// $.ajax({
	// 	url:GLOBAL_CMS_APP+'home/comment',
	// 	dataType : "json",
	// 	type:'get',
	// 	//data:{flag:1,type:1},
	// 	success:function(data){
	// 		if(data.code == 'A0200'){
	// 			var content = '';
	// 			for(i=0;i<data.data.length;i++){
	// 			 content+="<li class='articlebid' bid='"+data.data[i].article_id+"'><div class='comments'>";
	// 			 if(data.data[i].is_login == 1){
	// 				content+="<a target='_blank' href='"+data.data[i].user_info.user_link+"'  class='avatar'>";
	// 				if(data.data[i].user_info.user_pic === ''){
	// 					content += "<span class='s color_'"+data.data[i].user_info.user_pic_color+">"+data.data[i].user_info.user_nick.substring(0, 1)+"</span>";
	// 				}else{
	// 					content += "<img src='"+data.data[i].user_info.user_pic+"' onerror=\"this.src='"+BLOBAL_CMS_STATIC+"images/fail.jpg'\">";
	// 				}
	// 				content += "</a>";
	// 			 }else{
	// 				content+="<a target='_blank' href='javascript:;'  class='avatar'><span class='s color_"+data.data[i].user_info.user_pic_color+"'>"+data.data[i].user_nick.substring(0, 1)+"</span></a>";
	// 			 }
	//
	// 			      content+="<p class='article' ><a target='_blank' href='http://"+data.data[i].user_name+".blogchina.com/"+data.data[i].article_id+".html'>"+data.data[i].comment_content+"</a></p></div><div class='rest'><a target='_blank' href='http://"+data.data[i].user_name+".blogchina.com/"+data.data[i].article_id+".html'><span></span>"+data.data[i].comment_title+"</a></div><div class='ins'><a target='_blank' href='http://"+data.data[i].user_name+".blogchina.com/"+data.data[i].article_id+".html'>参与 <span class='comment_participation_"+data.data[i].article_id+"'>["+data.data[i].click+"]</span></a> </div></li>";
	// 			}
	// 			//| <a target='_blank' href='http://"+data.data[i].user_name+".blogchina.com/"+data.data[i].article_id+".html'> 评论 <span class='comment_comment_"+data.data[i].article_id+"'>[0]</span></a>
	// 			$('#commentdata').html(content);
	//
	// 		}else{
	// 			$('#commentdata').html('暂无文章');
	// 		}
	//
	// 	},
	// 	error:function(){
    //
	// 	}
	// });
	
	
	
	$.ajax({
		url:GLOBAL_CMS_APP+'home/getusernamecookie/callback/?',
		type:'get',
		dataType : "jsonp",
		jsonpCallback: 'callback',
		success:function(msg){
			if(msg.meta.code == 200){
				$('#userislocallogin').html("<div class='user_login'><a class='avatar' id='user_app' href='javascript:void(0)'><span> <img alt='100' src='"+msg.data.avatar+"!middle'></span><em id='loginnick'>"+msg.data.nickname+"</em><b class='arrow_down'></b></a><ul class='dropdown_menu' id='user_app_menu' style='display: none;'><li> <a target='_blank' href='http://"+msg.data.name+".blogchina.com'>我的专栏</a> </li><li> <a target='_blank' href='http://post.blogchina.com/writer/create'>撰写文章</a> </li><li> <a target='_blank' href='http://post.blogchina.com/post/public'>专栏管理</a> </li><li> <a target='_blank' href='http://post.blogchina.com/notification?unread=y'>通知</a> </li><li> <a target='_blank' href='http://post.blogchina.com/setting/index'>设置</a> </li><li class='btbor'> <a id='userloginout' href='javascript:;'> 退出 </a> </li></ul></div>");
			}else{
				$('#userislocallogin').html("<div class='user_login_no'><a class='txt userindexlogin' href='javascript:;' >登录<i  style='font-style:normal;font-size:14px'>/&nbsp;专栏申请</i></a></div>");
			}
		}
	});
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
});