/**
 * 定义公共常量
 */
var yuming = document.location.hostname;  
if(yuming == 'tuijian5.blogcore.cn'){
	var GLOBAL_CMS_APP = "http://tuijian5.blogcore.cn/";
	var BLOBAL_CMS_JS_URL = "http://tuijian5.blogcore.cn/www.php?"
	var BLOBAL_CMS_STATIC = "http://tuijian5.blogcore.cn/www/static/";
	var BLOBAL_CMS_LOGIN = "http://UC5.blogcore.cn/";
}else if(yuming == 'tuijian.blogchina.com'){
	var GLOBAL_CMS_APP = "http://tuijian.blogchina.com/";
	var BLOBAL_CMS_JS_URL = "http://tuijian.blogchina.com/www.php?"
	var BLOBAL_CMS_STATIC = "http://tuijian.blogchina.com/www/static/";
	var BLOBAL_CMS_LOGIN = "http://post.blogchina.com/";
}else{
	var GLOBAL_CMS_APP = "http://tuijian.blogchina.com/";
	var BLOBAL_CMS_JS_URL = "http://tuijian.blogchina.com/www.php?"
	var BLOBAL_CMS_STATIC = "http://tuijian.blogchina.com/www/static/";
	var BLOBAL_CMS_LOGIN = "http://post.blogchina.com/";
}




	//登录
	$(document).on('click','#blogchinauserlogin',function(){
		publicpart();
	});
	
	//event事件登录
	$(document).keydown(function(event){ 
		if(event.keyCode == 13){  
			publicpart(); 
		} 
	}); 
	
	function publicpart(){
		var	user_name = $("#userName").val(),user_pass = $("#passWord").val(),hash_form = $("#hash_form").val();
 		if(user_name == '' || user_pass == ''){
			return false;
		}
		$.ajax({
			type: 'get',
			url: GLOBAL_CMS_APP+'list/toLogin/accout/'+user_name+'/password/'+user_pass+'/callback/?',
			dataType: 'jsonp',
			jsonp: 'callback',
			async:false,
			beforeSend: function(){
				$('.edit_pic_pr').html('登陆中..');
			},
			success:function(data){
				if(data.meta.code == 200){
					$('#userlogin').hide();
		 			$('#userislocallogin').html("<div class='user_login'><a class='avatar' id='user_app' href='javascript:void(0)'><span> <img alt='100' src='"+data.data.userinfo.data.avatar+"!middle'></span><em id='loginnick'>"+data.data.nickname+"</em><b class='arrow_down'></b></a><ul class='dropdown_menu' id='user_app_menu' style='display: none;'><li> <a target='_blank' href='http://"+data.data.name+".blogchina.com'>我的专栏</a> </li><li> <a target='_blank' href='http://post.blogchina.com/writer/create'>撰写文章</a> </li><li> <a target='_blank' href='http://post.blogchina.com/post/public'>专栏管理</a> </li><li> <a target='_blank' href='http://post.blogchina.com/notification?unread=y'>通知</a> </li><li> <a target='_blank' href='http://post.blogchina.com/setting/index'>设置</a> </li><li class='btbor'> <a id='userloginout' href='javascript:;'> 退出 </a> </li></ul></div>");
				}else{
					alert('登录失败！');
				}
			},
			complete:function(){
				$('.edit_pic_pr').html('登陆');
			}
		});
	}
	
	
	//关闭
	$(document).on('click','.close',function(){
		$('#userlogin').hide();
	});
	
	
	//打开登录窗口
	$(document).on('click','.userindexlogin',function(){
		$('#userlogin').show();
	});

 

	//用户登出
	$(document).on('click','#userloginout',function(){
		$.ajax({
			url:BLOBAL_CMS_LOGIN+'sign/out',
			type:'get',
			dataType : "jsonp",
			jsonpCallback: 'callback',
			success:function(msg){
				if(msg.meta.code  == 200){
					$('#userName').val('');
					$('#passWord').val('');
					$('#blogchinauserlogin').html('登陆');
					$('#userislocallogin').html("<div class='user_login_no'><a class='txt userindexlogin' href='javascript:;' >登录<i  style='font-style:normal;font-size:14px'>/&nbsp;专栏申请</i></a></div>"); 
 				}
			}
		});	
	});


	$(document).on('click', '#user_app', function(){ 
  		$("#user_app_menu").slideToggle("slow",function(){
			if($(".arrow_up").length > 0) {
				$(".arrow_up").removeClass("arrow_up").addClass("arrow_down");
			}else {
				$(".arrow_down").removeClass("arrow_down").addClass("arrow_up");
			}
	    });
	});