<?php //decode by 小猪php解密 QQ:2338208446 http://www.xzjiemi.com/ ?>

<link rel="stylesheet" type="text/css" href="css/public.css" />

	<!-- 头部 -->
	<div class="head">
		<div class="headL">
			<h1><img src="img/logo.png"></h1>
		</div>

	</div>
	<div id="nav">
		<ul class="navmain">
			<li>
				<a href="index.php">首页</a>
			</li>
			<li>
				基础
				<ul>
					<li>
						<a href="info.php?act=url">索引池管理</a>
					</li>
					<li>
						<a href="info.php?act=qurl">权重池管理</a>
					</li>
					<li>
						<a href="info.php?act=keywords">关键词管理</a>
					</li>
					<li>
						<a href="info.php?act=domains">域名管理</a>
					</li>
					<li>
						<a href="info.php?act=juzi2">句子管理</a>
					</li>
					<li>
						<a href="info.php?act=juzi">段子管理</a>
					</li>
					<li>
						<a href="info.php?act=shipin">视频管理</a>
					</li>
				</ul>
			</li>
			<li>
					蜘蛛
				<ul>
					<li>
						<a href="spider.php">蜘蛛日志</a>
					</li>
					<li>
						<a href="spiderset.php">蜘蛛开关</a>
					</li>
				</ul>
			</li>
			<li>
					外推
				<ul>
					<li>
						<a href="waituilog.php">外推日志</a>
					</li>
					<li>
						<a href="info.php?act=waiurl">外推管理</a>
					</li>
				</ul>
			</li>
			<li>
					模板
				<ul>
					<li>
						<a href="info.php?act=m_title">网站标题</a>
					</li>
					<li>
						<a href="info.php?act=m_key">网站关键词</a>
					</li>
					<li>
						<a href="info.php?act=m_des">网站描述</a>
					</li>
					<li>
						<a href="info.php?act=m_url">URL样式</a>
					</li>
					<li>
						<a href="info.php?act=a_title">文章标题</a>
					</li>
					<li>
						<a href="info.php?act=a_content">文章内容</a>
					</li>
					<li>
						<a href="unicode.php">关键词转码</a>
					</li>
					<li>
						<a href="cache.php">页面缓存</a>
					</li>
					<li>
						<a href="templates.php">模板管理</a>
					</li>
				</ul>
			</li>
			<li>
					跳转
				<ul>
					<li>
						<a href="jump.php">全局跳转</a>
					</li>
					<li>
						<a href="info.php?act=key_jump">关键词跳转</a>
					</li>
				</ul>
			</li>
			<li>
					采集
				<ul>
					<li>
						<a href="caiji.php">新闻采集</a>
					</li>
					<li>
						<a href="info.php?act=weiyuanchuang">采集伪原创</a>
					</li>
					<li>
						<a href="mycaiji.php">自定义采集</a>
					</li>
				</ul>
			</li>
			<li>
					平台
				<ul>
					<li>
						<a href="cloud_user.php">用户管理</a>
					</li>
					<li>
						<a href="cloud_link.php">用户外链</a>
					</li>
				</ul>
			</li>
			<li>
					系统
				<ul>
					<li>
						<a href="jstongji.php">流量统计</a>
					</li>
					<li>
						<a href="api.php">API接口</a>
					</li>
					<li>
						<a href="changepwd.php">修改密码</a>
					</li>
					<li>
						<a href="log.php?act=out">退出</a>
					</li>
				</ul>
			</li>
			<li>
				<a href="http://www.youzkm.com/#products" target="_blank">帮助中心</a>
			</li>
			<div style="clear:both"></div>
		</ul>
	</div>
