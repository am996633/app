<?php
return array (
	'default' => array (
		'hostname' => 'localhost',
		'username' => 'iye22',
		'password' => 'iye22',
        'database' => 'iye22',
		)
)
?>