<?php
return array (
  'maxnum' => '2000',
  'cachetime' => '30',
  'path_type' => 'index',
  'makexml' => '1',
  'makehtml' => '1',
);
?>