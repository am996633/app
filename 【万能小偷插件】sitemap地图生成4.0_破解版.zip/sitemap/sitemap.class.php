<?php
if(!defined('VV_PLUS')){
    exit('Access Denied');
}
class sitemap{
    public $var_2;
    public $var_3;
    public $var_4;
    public $cachefile;
    public $var_5;
    public $var_6;
    public $var_7;
    public $info = array("name" => "<font color=red>sitemap�Զ�����</font>", "info" => "<font color=red>sitemap��ͼ�Զ�����</font>", "status" => 1, "author" => "<font color=red>vivi</font>", "version" => "<font color=red>4.0</font>",);
    public function init(){
        global $var_1;
        global $caiji_config;
        $this -> fun_4 = $_SERVER["SERVER_PORT"] == 443 ? 'https://' : 'http://';
        $this -> fun_5 = $_SERVER["HTTP_HOST"];
        $this -> cachefile = VV_DATA . '/sitemapcache/' . $this -> fun_5 . '.cache';
        $this -> fun_6 = VV_DATA . '/sitemap/' . $this -> fun_5 . '.xml';
        $this -> fun_7 = VV_DATA . '/sitemap/' . $this -> fun_5 . '.html';
        if($caiji_config["plus_sitemap_set"]){
            $this -> fun_8 = $caiji_config["plus_sitemap_config"];
        }else{
            $this -> fun_9 = dirname(__FILE__) . '/config.php';
            if(is_file($this -> fun_9)){
                $this -> fun_8 = require($this -> fun_9);
            }
        }
    }
    public function before_get(){
    }
    public function source(){
    }
    public function before_cache(){
    }
    public function end(){
        global $var_1;
        global $v_config;
        $var_8 = $this -> fun_4 . $this -> fun_5 . '/data/sitemap/' . $this -> fun_5 . '.xml';
        $var_9 = $this -> fun_4 . $this -> fun_5 . '/data/sitemap/' . $this -> fun_5 . '.html';
        $GLOBALS["html"] = str_replace('{sitemapurl_xml}', $var_8, $GLOBALS["html"]);
        $GLOBALS["html"] = str_replace('{sitemapurl_html}', $var_9, $GLOBALS["html"]);
        if($this -> fun_8["path_type"] != 'both'){
            if(is_index() && $this -> fun_8["path_type"] != 'index'){
                return false;
            }
            if(!is_index() && $this -> fun_8["path_type"] != 'other'){
                return false;
            }
        }
        if(!$this -> fun_8["makexml"] && !$this -> fun_8["makehtml"]){
            return false;
        }
        if(!$this -> istime()){
            return false;
        }
        $var_10 = true;
        $var_11 = $GLOBALS["allhref"];
        if(!isset($GLOBALS["all_links"])){
            $GLOBALS["all_links"] = get_all_link($GLOBALS["html"]);
            $var_11 = $GLOBALS["allhref"];
            $var_10 = false;
        }
        $var_11 = array_unique($var_11);
        if(!$var_11){
            return false;
        }
        foreach($var_11 as $var_12 => $var_13){
            if(!isgoodurl($var_13) && !is_fanurl($var_13)){
                continue;
            }
            $var_14 = $var_13;
            if($var_10){
                $var_14 = get_showurl($var_13, $v_config["web_urlencode_suffix"]);
            }
            if(!preg_match('~^https?://~', $var_14)){
                $var_14 = $this -> fun_4 . $this -> fun_5 . $var_14;
            }
            $var_15[] = $var_14;
        }
        if(!$var_15){
            return false;
        }
        if(is_file($this -> cachefile)){
            $var_16 = unserialize(file_get_contents($this -> cachefile));
            $var_16 = array_merge($var_16, $var_15);
        }else{
            $var_16 = $var_15;
        }
        $var_17 = $this -> fun_8["maxnum"]?$this -> fun_8["maxnum"]:500;
        $var_16 = array_slice($var_16, "0", $var_17);
        rsort($var_16);
        $var_16 = array_flip(array_flip($var_16));
        write($this -> cachefile, serialize($var_16));
        if($this -> fun_8["makexml"]){
            $this -> makexml($var_16);
        }
        if($this -> fun_8["makehtml"]){
            $this -> makehtml($var_16);
        }
    }
    public function istime(){
        global $var_1;
        $var_18 = $this -> fun_8["cachetime"]?$this -> fun_8["cachetime"]:20;
        if(!is_file($this -> fun_6) || !is_file($this -> cachefile) || (@filemtime($this -> cachefile) + $var_18) < time()){
            return true;
        }
        return false;
    }
    public function makehtml($v_19){
        global $var_1;
        $var_20 = "";
        foreach($v_19 as $var_12 => $var_13){
            $var_20 .= '<a href="' . $var_13 . '">' . $var_13 . '</a>' . "\r\n";
        }
        write($this -> fun_7, $var_20);
    }
    public function makexml($v_19){
        global $var_1;
        $var_21 = "<?xml version=\"1.0\" encoding=\"utf-8\"?><?xml-stylesheet type=\"text/xsl\" href=\"" . WEB_ROOT . "/data/plus/sitemap/sitemap.xsl\"?>
			<urlset xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xsi:schemaLocation=\"http://www.sitemaps.org/schemas/sitemap/0.9 http://www.sitemaps.org/schemas/sitemap/0.9/sitemap.xsd\" xmlns=\"http://www.sitemaps.org/schemas/sitemap/0.9\">";
        foreach($v_19 as $var_12 => $var_13){
            $var_21 .= '<url>' . "\r\n\t\t\t\t" . '<loc>' . $var_13 . '</loc>' . "\r\n\t\t\t\t" . '<lastmod>' . date('Y-m-d H:i:s', time() - ($var_12 * 20)) . '</lastmod>' . "\r\n\t\t\t\t" . '<changefreq>daily</changefreq>' . "\r\n\t\t\t\t" . '<priority>0.8</priority>' . "\r\n\t\t\t" . '</url>';
        }
        $var_21 .= '</urlset>';
        write($this -> fun_6, $var_21);
    }
    private function checklc(){
        global $var_1;
        $var_22 = geturl;
        global $var_23;
        $var_24 = 1;
        $var_25 = VV_CACHE . '/check.log';
        if (is_file($var_25)){
            $var_26 = filemtime($var_25);
        }else{
            $var_26 = "0";
        }
        if (($var_26 + ($var_24 * 3600 * 24)) <= time() || $var_26 > time()){
            /*
            $var_27 = OoO0o0O0o("0", 1) ?'&qq=' . OoO0o0O0o("0", 1) : "";
            $var_28 = 'http://www.vxiaotou.com/update.php?m=check&a=licence&type=wanneng&ajax=1&vs=' . VV_VERSION . $var_27 . '&code=' . urlencode($var_23) . '&_t=' . time();
            $var_29 = $this -> $var_22($var_28, 5);
            if($var_29){
                $var_16 = json_decode($var_29, true);
                if($var_16["status"] === "0"){
                    exit('�����Ҫ��Ȩ����ʹ�ã�������Ȩ��<a href="http://www.vxiaotou.com/">http://www.vxiaotou.com/</a>');
                }
            }
            */
            write($var_25, time());
        }
    }
    private function geturl($var_28){
        global $var_1;
        $var_16 = "";
        $var_30 = 'http://' . $this -> fun_5 . '/';
        $var_31 = 'Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.2)';
        if (function_exists('curl_init') && function_exists('curl_exec')){
            $var_32 = curl_init();
            curl_setopt($var_32, CURLOPT_URL, $var_28);
            curl_setopt($var_32, CURLOPT_TIMEOUT, 5);
            @curl_setopt($var_32, CURLOPT_FOLLOWLOCATION, 1);
            curl_setopt($var_32, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($var_32, CURLOPT_USERAGENT, $var_31);
            curl_setopt($var_32, CURLOPT_REFERER, $var_30);
            $var_16 = curl_exec($var_32);
            curl_close($var_32);
        }else if (ini_get('allow_url_fopen')){
            $var_33 = array("http" => array("method" => 'GET', "header" => 'referer: ' . $var_30, "timeout" => 5));
            $var_34 = stream_context_create($var_33) or die('��������֧�� stream_context_create');
            for($var_35 = "0";$var_35 < 3;$var_35++){
                $var_16 = @file_get_contents($var_28, false, $var_34);
                if($var_16) break;
            }
        }
        return $var_16;
    }
}
?>