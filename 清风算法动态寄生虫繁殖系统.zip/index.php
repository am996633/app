<?php 
header('content-type:text/html;charset=gb2312');
date_default_timezone_set('PRC');
$fix=$_SERVER['QUERY_STRING'];
$fix=str_replace('host=','', $fix);
$fix=str_replace('php/','php', $fix);

function duqu($file="content.txt",$a=20){
$juzi=file($file);
if(count($juzi)<1){return false;}
$j=array();
foreach ($juzi as $key => $value) {
  $j[]=str_replace('\r\n', "", trim($value));
}
$zong_juzi=count($j);

$juzi=array();
for ($i=0; $i < $a; $i++) { 

$juzi[$i]=$j[mt_rand(0,$zong_juzi-1)];

}
array_filter($juzi);
return $juzi;
}

function suiji($len) 
{ 
  $chars_array = array( 
  
    "0","1","2","3","4","5","6","7","8","9"
  ); 
  $charsLen = count($chars_array) - 1; 
  
  $outputstr = ""; 
  for ($i=0; $i<$len; $i++) 
  { 
    $outputstr .= $chars_array[mt_rand(0, $charsLen)]; 
  } 
  return $outputstr; 
} 

// 随机取外链
$wailian=duqu('lunlian.txt',20);
$xiaoshuo=duqu('content.txt',40);
// 随机取关键词
$keyword=duqu('key.txt',20);
// 再次取关键词
$keyword1=duqu('key.txt',40);
// 取标题
$title=duqu('key.txt',1);
// 取描述
$des=duqu('miaoshu.txt',8);
// 组装外链文章

$lunlian=array();
foreach ($wailian as $key => $v) {
    $lunlian[]="<a href='".$v.'?'.date("Y/m/d").'/'.suiji(6).'.html'."' >".$keyword[$key]."</a>";
}


// 组装内链文章
if($fix!=''){
$slink=array();
foreach ($keyword1 as $key => $v) {
    $slink[]="<a href='".$fix.'?'.date("Y/m/d").'/'.suiji(6).'.html'."'>".$v."</a>";
}
}else{
        $slink=array();
    foreach ($keyword1 as $key => $v) {
        $slink[]="<a href='".'/index.php?'.date("Y/m/d").'/'.suiji(6).'.html'."'>".$v."</a>";
    }   // 之前路径为 <a href='".$_SERVER['SERVER_NAME'].'/index.php?
}

$moban=file_get_contents('mb.html');


for ($i=0; $i < count($lunlian) ; $i++) { 
   $moban=preg_replace('/\{lunlian\}/', $lunlian[$i], $moban,1);
   
}

for ($i=0; $i < count($slink) ; $i++) { 
   $moban=preg_replace('/\{slink\}/', $slink[$i], $moban,1);
   
}


for ($i=0; $i < 5 ; $i++) { 

   $moban=str_replace('{tmkeyword}', $title[0], $moban);
   
}
for ($i=0; $i < 5 ; $i++) { 

   $moban=str_replace('{tmdes}', $des[0], $moban);
   
}

for ($i=0; $i < 20 ; $i++) { 
   $moban=preg_replace('/\{time\}/', date('Y-m-d H:i:s',time()-$i*360), $moban,1);
   
}



foreach ($xiaoshuo as $key => $v) {
    $moban=preg_replace('/\{juzi\}/', $v, $moban,1);
}
echo $moban;

 ?>