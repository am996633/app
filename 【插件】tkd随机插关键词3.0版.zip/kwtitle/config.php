<?php
return array (
  'gailv' => '100',
  'title_rule' => '{title}_{word1}',
  'keywords_rule' => '{keywords},{word1}',
  'description_rule' => '{description_rule}{word1}',
  'iscache' => '0',
  'insert_keywords' => '1',
  'insert_description' => '1',
  'file_path' => 'data/randkw.txt',
  'insert_h1' => '1',
  'urlregx' => '',
);
?>