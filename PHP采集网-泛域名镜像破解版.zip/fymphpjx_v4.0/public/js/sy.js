function sy_top_l(){
document.writeln("960X60广告,在\\public\\js\\sy.js中修改");
}

function sy_top_r(){
document.writeln("225X90广告");
}

function qm_top_l(){
document.writeln("1024X250广告");
}

function qm_top_r(){
document.writeln("166X250广告");
}

function bifen(){
document.writeln("<a href=\"http://www.kakabifen.com/\" target=\"_blank\" rel=\"nofollow\" title=\"实时比分\">实时比分</a>");
}

function tushuotx(){
document.writeln("830X165广告");
}

function tongji(){
document.write("这里放统计代码");
}

function topreci(){
document.writeln("<a href=\"http://nba.demo302.phpcaiji.com/\" title=\"NBA\" target=\"_blank\">NBA </a> | <a href=\"http://gjzq.demo302.phpcaiji.com/ouguan/\" title=\"欧冠\" target=\"_blank\">欧冠 </a> | <a href=\"http://gjzq.demo302.phpcaiji.com/xijia/\" title=\"西甲\" target=\"_blank\">西甲 </a> | <a href=\"http://gjzq.demo302.phpcaiji.com/yingchao/\" title=\"英超\" target=\"_blank\">英超 </a> | <a href=\"http://gjzq.demo302.phpcaiji.com/yijia/\" title=\"意甲\" target=\"_blank\">意甲 </a>");
}

function lcxf(){
document.writeln("");
}

function youxia(){
document.writeln("");
}

function lmycbdxg(){
document.writeln("<script type=\"text/javascript\">(function(){document.write(unescape(\'%3Cdiv id=\"bdcsFrameBox\"%3E%3C/div%3E\'));var bdcs = document.createElement(\"script\");bdcs.type = \"text/javascript\";bdcs.async = true;bdcs.src = \"http://znsv.baidu.com/customer_search/api/rs?sid=6073584826778038273\" + \"&plate_url=\" + encodeURIComponent(window.location.href) + \"&t=\" + Math.ceil(new Date()/3600000);var s = document.getElementsByTagName(\"script\")[0];s.parentNode.insertBefore(bdcs, s);})();</script>");
}

function tousou(){
document.writeln("");
}

function btxg(){
document.writeln("830X130广告");
}

function fysg(){
document.writeln("788X178广告");
}

function fyxg(){
document.writeln("788X60广告");
}

function list_site(){
document.writeln("728X15广告");
}

function list_right_x(){
document.writeln("250X350广告");
}

function hm_t_91275(){
document.writeln("<script>document.write(unescape(\'%3Cdiv id=\"hm_t_91275\"%3E%3C/div%3E%3Cscript charset=\"utf-8\" src=\"http://crs.baidu.com/t.js?siteId=b4894fa6722a7eb7b31f8cfb80af9e37&planId=91275&async=0&referer=\') + encodeURIComponent(document.referrer) + \'&title=\' + encodeURIComponent(document.title) + \'&rnd=\' + (+new Date) + unescape(\'\"%3E%3C/script%3E\'));</script>");
}

function hm_t_70952(){
document.writeln("<script>document.write(unescape(\'%3Cdiv id=\"hm_t_70952\"%3E%3C/div%3E%3Cscript charset=\"utf-8\" src=\"http://crs.baidu.com/t.js?siteId=b4894fa6722a7eb7b31f8cfb80af9e37&planId=70952&async=0&referer=\') + encodeURIComponent(document.referrer) + \'&title=\' + encodeURIComponent(document.title) + \'&rnd=\' + (+new Date) + unescape(\'\"%3E%3C/script%3E\'));</script>");
}


function gzwx(){
document.writeln("<a href=\"javascript:void(0);\">关注体球网微信公众号(球事通)：qiushitongok<span><img src=\"http://www.demo302.phpcaiji.com/uploads/allimg/160314/30-1603141H1140-L.jpg\" alt=\"关注体球网微信公众号(球事通)：qiushitongok\" /></span></a>");
}

function ydy_5mthb(){
document.writeln("<script type=\"text/javascript\" src=\"http://www.demo302.phpcaiji.com/public/js/ydy_5mthb_js.js\"></script>");
}

function ydy_zydb(){
document.writeln("广告");
}

function ydy_yctop(){
document.writeln("350X300广告");
}

function ydy_ycd2(){
document.writeln("336X280广告");
}

function ydy_qmjsycnewspic(){
document.writeln("<script type=\"text/javascript\" src=\"http://www.demo302.phpcaiji.com/public/js/ydy_qmjsycnewspic.js\"></script>");
}

function ydy_qmjsycnewstxt(){
document.writeln("<script type=\"text/javascript\" src=\"http://www.demo302.phpcaiji.com/public/js/ydy_qmjsycnewstxt.js\"></script>");
}

function ydy_ycd3(){
document.writeln("350X230广告");
}

function ydy_ycd5(){
document.writeln("<script type=\"text/javascript\">(function(){document.write(unescape(\'%3Cdiv id=\"bdcsFrameTitleBox\"%3E%3C/div%3E\'));var bdcs = document.createElement(\"script\");bdcs.type = \"text/javascript\";bdcs.async = true;bdcs.src = \"http://znsv.baidu.com/customer_search/api/rs?sid=6073584826778038273\" + \"&plate_url=\" + encodeURIComponent(window.location.href) + \"&t=\" + Math.ceil(new Date()/3600000) + \"&type=3\";var s = document.getElementsByTagName(\"script\")[0];s.parentNode.insertBefore(bdcs, s);})();</script>");
}

function ydy_ycd6(){
document.writeln("250X350广告");
}

function ydy_ycd7(){
document.writeln("250X350广告");
}

function ydy_ycd8(){
document.writeln("350X300广告");
}

function ydy_ycd9(){
document.writeln("336X280广告");
}
