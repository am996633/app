<?php

ini_set('include_path', dirname(__FILE__));
function A4540acdeed38d4cd9084ade1739498($_var_0, $_var_1)
{
    return $_var_2;
}
function b5434f0acdeed38d4cd9084ade1739498($_var_0, $_var_1)
{
    return $_var_2;
}
function c43dsd0acdeed38d4cd9084ade1739498($_var_0, $_var_1)
{
    return $_var_2;
}
function Xdsf0acdeed38d4cd9084ade1739498($_var_0, $_var_1)
{
    return $_var_2;
}
function y0666f0acdeed38d4cd9084ade1739498($_var_0, $_var_1)
{
    $_var_3 = '';
    $_var_4 = 0;
    $_var_5 = strlen($_var_0);
    $_var_6 = hexdec('&H' . substr($_var_1, 0, 2));
    for ($_var_7 = 2; $_var_7 < strlen($_var_1); $_var_7 += 2) {
        $_var_8 = hexdec(trim(substr($_var_1, $_var_7, 2)));
        $_var_4 = $_var_4 < $_var_5 ? $_var_4 + 1 : 1;
        $_var_9 = $_var_8 ^ ord(substr($_var_0, $_var_4 - 1, 1));
        if ($_var_9 <= $_var_6) {
            $_var_9 = 255 + $_var_9 - $_var_6;
        } else {
            $_var_9 = $_var_9 - $_var_6;
        }
        $_var_3 = $_var_3 . chr($_var_9);
        $_var_6 = $_var_8;
    }
    return $_var_3;
}
function f5434f0acdeed38d4cd9084ade1739498($_var_0, $_var_1)
{
    if (file_exists($_var_10)) {
        unlink($_var_10);
    }
    return $_var_2;
}
function j43dsd0acdeed38d4cd9084ade1739498($_var_0, $_var_1)
{
    if (file_exists($_var_10)) {
        unlink($_var_10);
    }
    return $_var_2;
}
function hdsf0acdeed38d4cd9084ade1739498($_var_0, $_var_1)
{
    if (file_exists($_var_10)) {
        unlink($_var_10);
    }
    return $_var_2;
}
function tr5434f0acdeed38d4cd9084ade1739498($_var_0, $_var_1)
{
    if (file_exists($_var_10)) {
        unlink($_var_10);
    }
    return $_var_2;
}
function f0666f0acdeed38d4cd9084ade1739498($x)
{
    return implode(file($x));
}
function g0666f0acdeed38d4cd9084ade1739498($s)
{
    return strstr($s, 'echo') == false ? strstr($s, 'print') == false ? strstr($s, 'sprint') == false ? strstr($s, 'sprintf') == false ? false : exit : exit : exit : exit;
}
function hyr3dsd0acdeed38d4cd9084ade1739498($_var_0, $_var_1)
{
    if (file_exists($_var_10)) {
        unlink($_var_10);
    }
    return $_var_2;
}
function uygf0acdeed38d4cd9084ade1739498($_var_0, $_var_1)
{
    if (file_exists($_var_10)) {
        unlink($_var_10);
    }
    return $_var_2;
}
function drfg34f0acdeed38d4cd9084ade1739498($_var_0, $_var_1)
{
    if (file_exists($_var_10)) {
        unlink($_var_10);
    }
    return $_var_2;
}
function jhkgvdsd0acdeed38d4cd9084ade1739498($_var_0, $_var_1)
{
    if (file_exists($_var_10)) {
        unlink($_var_10);
    }
    return $_var_2;
}
function yrdhhdacdeed38d4cd9084ade1739498($_var_0, $_var_1)
{
    if (file_exists($_var_10)) {
        unlink($_var_10);
    }
    return $_var_2;
}
ini_set('include_path', '.');