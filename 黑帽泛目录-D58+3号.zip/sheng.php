﻿<?php 
error_reporting(0);
set_time_limit(0);
header("Content-Type:text/html; charset=UTF-8");
?>
<html>
<head>
<meta charset="utf-8">
<title>黑帽泛目录- PHP泛目录生成版</title>

</head>
<style>
body{padding:0px;margin:0 auto;background-color:#000;font-family: Century Gothic, 微软雅黑E\8F6F\96C5\9ED1, 幼圆E7C\5706, Arial, Verdana;font: 12px/1.5 Microsoft YaHei, Helvitica, Verdana, Arial, san-serif; background: url(images/bj.jpg);color:#ffffff;}
.main{margin:0 auto;width:800px; padding-left:100px; padding-right:100px; padding-top:30px;padding-bottom:30px;margin-top:4%;border-radius:5px; background: rgba(0,0,0,0.6);box-shadow:4px 4px 10px #000000; }
.softname{text-align:left;font-size:14px;color:#FFF;height:34px;line-height:34px;font-family: Century Gothic, 微软雅黑E\8F6F\96C5\9ED1, 幼圆E7C\5706, Arial, Verdana;font: 14px/1.5 Microsoft YaHei, Helvitica, Verdana, Arial, san-serif;position:relative;top:3px;}

.geshi1{text-align:left;font-size:18px;color:#FFF;line-height:100%;font-family: Century Gothic, 微软雅黑E\8F6F\96C5\9ED1, 幼圆E7C\5706, Arial, Verdana;font: 14px/1.5 Microsoft YaHei, Helvitica, Verdana, Arial, san-serif;}

a {text-decoration: none;color:red}
a:hover {color:#FFF;text-decoration: none;}

.form-control {display:inline-block;height: 32px;padding: 6px 12px;font-size: 14px;line-height: 1.42857143;color: #555;background-color: #fff;background-image: none;border: 1px solid #ccc;border-radius: 4px;-webkit-box-shadow: inset 0 1px 1px rgba(0,0,0,.075);box-shadow: inset 0 1px 1px rgba(0,0,0,.075);-webkit-transition: border-color ease-in-out .15s,-webkit-box-shadow ease-in-out .15s;-o-transition: border-color ease-in-out .15s,box-shadow ease-in-out .15s;transition: border-color ease-in-out .15s,box-shadow ease-in-out .15s;}
.form-control:focus {
    border-color: #66afe9;
    outline: 0;
    -webkit-box-shadow: inset 0 1px 1px rgba(0,0,0,.075),0 0 8px rgba(102,175,233,.6);
    box-shadow: inset 0 1px 1px rgba(0,0,0,.075),0 0 8px rgba(102,175,233,.6);
}
.btn {display: inline-block;padding: 6px 12px;margin-bottom: 0;font-size: 14px;font-weight: 400;line-height: 1.42857143;text-align: center;white-space: nowrap;vertical-align: middle;-ms-touch-action: manipulation;touch-action: manipulation;cursor: pointer;-webkit-user-select: none;-moz-user-select: none;-ms-user-select: none;user-select: none;background-image: none;border: 1px solid transparent;border-radius: 4px;}
.btn-default { color: #333; background-color: #fff; border-color: #ccc;}
.btn-default:hover {color: #333;background-color: #e6e6e6;border-color: #adadad;}

.btn1{ margin-top: 5px;}
.zw{ width: 100%; height: 20px; }
</style>
<body>

<div class="main">
<div class="softname"><center>&nbsp;黑帽泛目录 QQ：8776979 网址：www.966seo.com</center></div>
<?php 
function sjzm0($length)
{
    $str = 'abcdefghijklmnopqrstuvwxyz';
    $strlen = 26;
    while ($length > $strlen) {
        $str .= $str;
        $strlen += 26;
    }
    $str = str_shuffle($str);
    return substr($str, 0, $length);
}
function sjsz0($length)
{
    $str = '0123456789';
    $strlen = 10;
    while ($length > $strlen) {
        $str .= $str;
        $strlen += 10;
    }
    $str = str_shuffle($str);
    return substr($str, 0, $length);
}
$yuming = $_SERVER['HTTP_HOST'];
function getdomain($url)
{
    $host = strtolower($url);
    if (strpos($host, '/') !== false) {
        $parse = @parse_url($host);
        $host = $parse['host'];
    }
    $topleveldomaindb = array('net.cn', 'com.cn', 'load', 'pw', 'xyz', 'win', 'cn', 'top', 'com', 'edu', 'gov', 'int', 'mil', 'net', 'org', 'biz', 'info', 'pro', 'name', 'museum', 'coop', 'aero', 'xxx', 'idv', 'mobi', 'cc', 'me');
    $str = '';
    foreach ($topleveldomaindb as $v) {
        $str .= ($str ? '|' : '') . $v;
    }
    $matchstr = "[^\\.]+\\.(?:(" . $str . ")|\\w{2}|((" . $str . ")\\.\\w{2}))\$";
    if (preg_match("/" . $matchstr . "/ies", $host, $matchs)) {
        $domain = $matchs['0'];
    } else {
        $domain = $host;
    }
    return $domain;
}
$top_url = getdomain($yuming);
?>
 <div class="geshi1"><form action="" method="post">
网站名称: <br><input name="webname" type="text" value="<?php 
echo @file_get_contents(dirname(__FILE__) . '/inc/webname.txt');
?>" size="20" class="form-control">
<font color=#fe0000 style="font-size: 12px;">&nbsp;*设置网站名称后,模板的所有<网站名称>标签都会调用本名称。</font>
<br>
<input type="submit" class="btn btn-default btn1" name="submit" value="确定">
</div>
 <div class="geshi1">
<?php 
header("Content-type: text/html;charset=utf-8");
if (@$_POST["webname"] > -1) {
    //$tiao="http://".$_SERVER['HTTP_HOST'].$_SERVER['PHP_SELF'];
    file_put_contents(dirname(__FILE__) . '/inc/webname.txt', @$_POST["webname"]);
    echo "温馨提示:修改成功,点击下面打开新页面即可见！";
}
?>
</form>
 </div>
<div class="zw"></div>

<div class="geshi1">
<form action="" method="get">
生成新闻页面：<font color=#fe0000 style="font-size: 12px;">&nbsp;( *本次最多可生成<?php 
$txt = file('inc/title.txt');
echo count($txt);
?>个新闻页面 ）</font><br>页面数量:<input name="Total" type="text" value="" size="6" class="form-control">
<?php 
function sjmulu($length)
{
    $str = 'abcdef';
    $strlen = 6;
    while ($length > $strlen) {
        $str .= $str;
        $strlen += 6;
    }
    $str = str_shuffle($str);
    return substr($str, 0, $length);
}
?>
保存目录: <input name="mulu" type="text" value="<?php 
$ml = sjmulu(mt_rand(3, 5));
echo $ml;
?>" size="11" class="form-control">
<br>
<input type="submit" class="btn btn-default btn1" value="生成新闻页面"><font color=#fe0000 style="font-size: 12px;">&nbsp;*新闻页面可以一次性生成几百上千个页面，一周更新1次即可，不需要每次都生成。以后直接执行生成关键词页面生成就可以</font>
</form>
</div>

</hr>
<div class="geshi1">

</div>
<div class="zw"></div>

<div class="geshi1">
生成关键词页面：
<font color=#fe0000 style="font-size: 12px;">&nbsp;（ *本次最多可生成:<?php 
$txt = file('inc/keywords.txt');
echo count($txt);
?>个关键词页面 ）</font>
 </div>
<div class="geshi1">

<form action="" method="get">
页面数量:<input name="keyTotal" type="text" value="" size="6" class="form-control"><font color=#fe0000 style="font-size: 12px;">&nbsp;*建议每次最多生成100个</font>

 </br>


<div class="geshi1">

 </div>

 <div class="geshi1">
目录保存格式：<br>
<label><input name="mulu"  type="radio" value="1" checked>随机数字( 多目录 )</label>&nbsp;&nbsp;
<label><input type="radio" name="mulu" value="2">随机字母( 多目录 )</label>&nbsp;&nbsp;
<label><input type="radio" name="mulu" value="3">自定义目录( 单目录 )</label>&nbsp;&nbsp;<input name="keymulu" type="text" value="<?php 
$ml = sjsz0(mt_rand(2, 5));
echo $ml;
?>" size="5" class="form-control">


</div>
<div class="geshi1">

</div>
 
<div class="geshi1">
页面生成格式：<br>
<label style="margin-right: 70px;"><input name="fengge"  type="radio"value="1" checked>随机数字 如：287693.html</label>
<label style="margin-right: 69px;"><input type="radio" name="fengge" value="2">随机字符 如：2e87fc.html</label><label>
<label style="margin-right: 10px;"><input type="radio" name="fengge" value="3">字母数字 如：bdfec-9863.html</label><br>
<label style="margin-right: 15px;"><input type="radio" name="fengge" value="4">字符字符 如：cd29f678-9fdac.html</label>
<label style="margin-right: 32px;"><input type="radio" name="fengge" value="5">十位数字 如：6785432134.html</label>
<label style="margin-right: 10px;"><input type="radio" name="fengge" value="6">随机字母 如：afcbee.html</label><br>
<label style="margin-right: 9px;"><input type="radio" name="fengge" value="7">字母数字 如：c79652-8639134.html </label>
<label><input type="radio" name="fengge" value="8">年数字 如：<?php 
echo date("Ymd");
?>3218845.html</label>

</div>

<div class="geshi1">

</div>
<div class="geshi1">
<input type="submit"  value="生成关键词页面" class="btn btn-default btn1"><font color=#fe0000 style="font-size: 12px;">&nbsp;（ *不要一次性把全部关键词放进来生成,要定期更新一部分关键词发布，建议每周发布3次『熟练者可自我安排』 ）</font><br>
<button onClick="window.open('<?php 
function php_self()
{
    $php_self = substr($_SERVER['PHP_SELF'], strrpos($_SERVER['PHP_SELF'], '/') + 1);
    return $php_self;
}
$phpself = php_self();
echo $phpself;
?>')" class="btn btn-default btn1">打开新页面</button>
 </div>

</form>

</div>

<div class="zhuangtai"><?php 
set_time_limit(0);
@ini_set('max_execution_time', '0');
if (@$_GET["Total"] > -1 and @$_GET["Total"] <= count(file('inc/title.txt'))) {
    function rdomain($d)
    {
        $provace = array();
        return str_replace("*", dechex(date("s") . mt_rand(1111, 9999)) . $provace[rarray_rand($provace)], $d);
    }
    function rarray_rand($arr)
    {
        return mt_rand(0, count($arr) - 1);
    }
    function varray_rand($arr)
    {
        return $arr[rarray_rand($arr)];
    }
    function get_folder_files($folder)
    {
        $fp = @opendir($folder);
        while (false != ($file = readdir($fp))) {
            if ($file != '.' && $file != '..') {
                $file = "{$file}";
                $arr_file[] = $file;
            }
        }
        @closedir($fp);
        return @$arr_file;
    }
    function sjzf($length)
    {
        $str = '0123456789abcdefghijklmnopqrstuvwxyz';
        $strlen = 36;
        while ($length > $strlen) {
            $str .= $str;
            $strlen += 36;
        }
        $str = str_shuffle($str);
        return substr($str, 0, $length);
    }
    function sjsz($length)
    {
        $str = '0123456789';
        $strlen = 10;
        while ($length > $strlen) {
            $str .= $str;
            $strlen += 10;
        }
        $str = str_shuffle($str);
        return substr($str, 0, $length);
    }
    function sjzm($length)
    {
        $str = 'abcdef';
        $strlen = 6;
        while ($length > $strlen) {
            $str .= $str;
            $strlen += 6;
        }
        $str = str_shuffle($str);
        return substr($str, 0, $length);
    }
    if (file_exists("inc/cache.txt")) {
        unlink("inc/cache.txt");
    }
    if (file_exists("inc/list.txt")) {
        unlink("inc/list.txt");
    }
    if (file_exists("inc/url.txt")) {
        unlink("inc/url.txt");
    }
    $open = file_get_contents("inc/title.txt");
    $arr = explode("\r\n", $open);
    shuffle($arr);
    //打乱数组
    for ($i = 0; $i < $_GET["Total"]; $i++) {
        //循环，这回是输出$arr2的10条
        $aa = sjsz(mt_rand(4, 6));
        //链接长度
        $che = trim($arr[$i]) . '@' . $aa . "\r\n";
        file_put_contents('inc/cache.txt', $che, FILE_APPEND);
    }
    if (file_exists("inc/grm.txt")) {
        unlink("inc/grm.txt");
    }
    define("DIR", dirname(__FILE__));
    $fan = @file(DIR . '/inc/fan.txt');
    $sitedomain = $_SERVER['HTTP_HOST'];
    $siteurl = $_SERVER["REQUEST_URI"];
    $topdomain = getdomain($_SERVER['HTTP_HOST']);
    $lujing = dirname('http://' . $sitedomain . $siteurl) . "/";
    $mulu = @$_GET["mulu"];
    $webname = @file_get_contents(DIR . '/inc/webname.txt');
    $a = file('inc/cache.txt');
    foreach ($a as $url) {
        $url = trim($url);
        $moban = @file_get_contents(DIR . '/inc/rw1.html');
        $bianliang = @file(DIR . '/inc/bianliang.txt');
        $juzi = @file(DIR . '/inc/content.txt');
        $keywords = @file(DIR . '/inc/cache.txt');
        if (file_exists("inc/grm.txt")) {
            //unlink("inc/grm.txt");
        } else {
            $grm = @file_get_contents(DIR . '/inc/grm.html');
            $grm1 = str_ireplace('<grm>', sjzm(mt_rand(4, 6)), $grm);
            file_put_contents('inc/grm.txt', $grm1);
        }
        $grmcopy = @file_get_contents(DIR . '/inc/grm.txt');
        $gjc1 = trim(varray_rand($keywords));
        $gjc2 = trim(varray_rand($keywords));
        $gjc3 = trim(varray_rand($keywords));
        $gjc4 = trim(varray_rand($keywords));
        $gjc5 = trim(varray_rand($keywords));
        $gjc6 = trim(varray_rand($keywords));
        $gjc7 = trim(varray_rand($keywords));
        $gjc8 = trim(varray_rand($keywords));
        $gjc9 = trim(varray_rand($keywords));
        $gjc10 = trim(varray_rand($keywords));
        $gjc11 = trim(varray_rand($keywords));
        $gjc12 = trim(varray_rand($keywords));
        $gjc13 = trim(varray_rand($keywords));
        $gjc14 = trim(varray_rand($keywords));
        $gjc15 = trim(varray_rand($keywords));
        $gjc16 = trim(varray_rand($keywords));
        $gjc17 = trim(varray_rand($keywords));
        $gjc18 = trim(varray_rand($keywords));
        $gjc19 = trim(varray_rand($keywords));
        $gjc20 = trim(varray_rand($keywords));
        $gjc21 = trim(varray_rand($keywords));
        $gjc22 = trim(varray_rand($keywords));
        $gjc23 = trim(varray_rand($keywords));
        $gjc24 = trim(varray_rand($keywords));
        $gjc25 = trim(varray_rand($keywords));
        $gjc26 = trim(varray_rand($keywords));
        $gjc27 = trim(varray_rand($keywords));
        $gjc28 = trim(varray_rand($keywords));
        $gjc29 = trim(varray_rand($keywords));
        $gjc30 = trim(varray_rand($keywords));
        $gjc31 = trim(varray_rand($keywords));
        $gjc32 = trim(varray_rand($keywords));
        $gjc33 = trim(varray_rand($keywords));
        $gjc34 = trim(varray_rand($keywords));
        $gjc35 = trim(varray_rand($keywords));
        $gjc36 = trim(varray_rand($keywords));
        $gjc37 = trim(varray_rand($keywords));
        $gjc38 = trim(varray_rand($keywords));
        $gjc39 = trim(varray_rand($keywords));
        $gjc40 = trim(varray_rand($keywords));
        $gjc41 = trim(varray_rand($keywords));
        $gjc42 = trim(varray_rand($keywords));
        $gjc43 = trim(varray_rand($keywords));
        $gjc44 = trim(varray_rand($keywords));
        $gjc45 = trim(varray_rand($keywords));
        $gjc46 = trim(varray_rand($keywords));
        $gjc47 = trim(varray_rand($keywords));
        $gjc48 = trim(varray_rand($keywords));
        $gjc49 = trim(varray_rand($keywords));
        $gjc50 = trim(varray_rand($keywords));
        $gjc51 = trim(varray_rand($keywords));
        $gjc52 = trim(varray_rand($keywords));
        $gjc53 = trim(varray_rand($keywords));
        $gjc54 = trim(varray_rand($keywords));
        $gjc55 = trim(varray_rand($keywords));
        $gjc56 = trim(varray_rand($keywords));
        $gjc57 = trim(varray_rand($keywords));
        $gjc58 = trim(varray_rand($keywords));
        $gjc59 = trim(varray_rand($keywords));
        $gjc60 = trim(varray_rand($keywords));
        $gjc61 = trim(varray_rand($keywords));
        $gjc62 = trim(varray_rand($keywords));
        $gjc63 = trim(varray_rand($keywords));
        $gjc64 = trim(varray_rand($keywords));
        $gjc65 = trim(varray_rand($keywords));
        $gjc66 = trim(varray_rand($keywords));
        $gjc67 = trim(varray_rand($keywords));
        $gjc68 = trim(varray_rand($keywords));
        $gjc69 = trim(varray_rand($keywords));
        $gjc70 = trim(varray_rand($keywords));
        $gjc71 = trim(varray_rand($keywords));
        $gjc72 = trim(varray_rand($keywords));
        $gjc73 = trim(varray_rand($keywords));
        $gjc74 = trim(varray_rand($keywords));
        $gjc75 = trim(varray_rand($keywords));
        $gjc76 = trim(varray_rand($keywords));
        $gjc77 = trim(varray_rand($keywords));
        $gjc78 = trim(varray_rand($keywords));
        $gjc79 = trim(varray_rand($keywords));
        $gjc80 = trim(varray_rand($keywords));
        $gjc81 = trim(varray_rand($keywords));
        $gjc82 = trim(varray_rand($keywords));
        $gjc83 = trim(varray_rand($keywords));
        $gjc84 = trim(varray_rand($keywords));
        $gjc85 = trim(varray_rand($keywords));
        $gjc86 = trim(varray_rand($keywords));
        $gjc87 = trim(varray_rand($keywords));
        $gjc88 = trim(varray_rand($keywords));
        $gjc89 = trim(varray_rand($keywords));
        $gjc90 = trim(varray_rand($keywords));
        $gjc91 = trim(varray_rand($keywords));
        $gjc92 = trim(varray_rand($keywords));
        $gjc93 = trim(varray_rand($keywords));
        $gjc94 = trim(varray_rand($keywords));
        $gjc95 = trim(varray_rand($keywords));
        $gjc96 = trim(varray_rand($keywords));
        $gjc97 = trim(varray_rand($keywords));
        $gjc98 = trim(varray_rand($keywords));
        $gjc99 = trim(varray_rand($keywords));
        $gjc100 = trim(varray_rand($keywords));
        $moban = str_replace('<随机链接1>', "<a href=\"" . dirname('http://' . trim(varray_rand($fan)) . $topdomain . $siteurl) . "/" . $mulu . "/" . str_replace("@", "", strtolower(strstr($gjc1, '@'))) . ".html" . "\" target=" . "\"_blank" . "\">" . strtolower(substr($gjc1, 0, strrpos($gjc1, '@'))) . "</a>", $moban);
        $moban = str_replace('<随机链接2>', "<a href=\"" . dirname('http://' . trim(varray_rand($fan)) . $topdomain . $siteurl) . "/" . $mulu . "/" . str_replace("@", "", strtolower(strstr($gjc2, '@'))) . ".html" . "\" target=" . "\"_blank" . "\">" . strtolower(substr($gjc2, 0, strrpos($gjc2, '@'))) . "</a>", $moban);
        $moban = str_replace('<随机链接3>', "<a href=\"" . dirname('http://' . trim(varray_rand($fan)) . $topdomain . $siteurl) . "/" . $mulu . "/" . str_replace("@", "", strtolower(strstr($gjc3, '@'))) . ".html" . "\" target=" . "\"_blank" . "\">" . strtolower(substr($gjc3, 0, strrpos($gjc3, '@'))) . "</a>", $moban);
        $moban = str_replace('<随机链接4>', "<a href=\"" . dirname('http://' . trim(varray_rand($fan)) . $topdomain . $siteurl) . "/" . $mulu . "/" . str_replace("@", "", strtolower(strstr($gjc4, '@'))) . ".html" . "\" target=" . "\"_blank" . "\">" . strtolower(substr($gjc4, 0, strrpos($gjc4, '@'))) . "</a>", $moban);
        $moban = str_replace('<随机链接5>', "<a href=\"" . dirname('http://' . trim(varray_rand($fan)) . $topdomain . $siteurl) . "/" . $mulu . "/" . str_replace("@", "", strtolower(strstr($gjc5, '@'))) . ".html" . "\" target=" . "\"_blank" . "\">" . strtolower(substr($gjc5, 0, strrpos($gjc5, '@'))) . "</a>", $moban);
        $moban = str_replace('<随机链接6>', "<a href=\"" . dirname('http://' . trim(varray_rand($fan)) . $topdomain . $siteurl) . "/" . $mulu . "/" . str_replace("@", "", strtolower(strstr($gjc6, '@'))) . ".html" . "\" target=" . "\"_blank" . "\">" . strtolower(substr($gjc6, 0, strrpos($gjc6, '@'))) . "</a>", $moban);
        $moban = str_replace('<随机链接7>', "<a href=\"" . dirname('http://' . trim(varray_rand($fan)) . $topdomain . $siteurl) . "/" . $mulu . "/" . str_replace("@", "", strtolower(strstr($gjc7, '@'))) . ".html" . "\" target=" . "\"_blank" . "\">" . strtolower(substr($gjc7, 0, strrpos($gjc7, '@'))) . "</a>", $moban);
        $moban = str_replace('<随机链接8>', "<a href=\"" . dirname('http://' . trim(varray_rand($fan)) . $topdomain . $siteurl) . "/" . $mulu . "/" . str_replace("@", "", strtolower(strstr($gjc8, '@'))) . ".html" . "\" target=" . "\"_blank" . "\">" . strtolower(substr($gjc8, 0, strrpos($gjc8, '@'))) . "</a>", $moban);
        $moban = str_replace('<随机链接9>', "<a href=\"" . dirname('http://' . trim(varray_rand($fan)) . $topdomain . $siteurl) . "/" . $mulu . "/" . str_replace("@", "", strtolower(strstr($gjc9, '@'))) . ".html" . "\" target=" . "\"_blank" . "\">" . strtolower(substr($gjc9, 0, strrpos($gjc9, '@'))) . "</a>", $moban);
        $moban = str_replace('<随机链接10>', "<a href=\"" . dirname('http://' . trim(varray_rand($fan)) . $topdomain . $siteurl) . "/" . $mulu . "/" . str_replace("@", "", strtolower(strstr($gjc10, '@'))) . ".html" . "\" target=" . "\"_blank" . "\">" . strtolower(substr($gjc10, 0, strrpos($gjc10, '@'))) . "</a>", $moban);
        $moban = str_replace('<随机链接11>', "<a href=\"" . dirname('http://' . trim(varray_rand($fan)) . $topdomain . $siteurl) . "/" . $mulu . "/" . str_replace("@", "", strtolower(strstr($gjc11, '@'))) . ".html" . "\" target=" . "\"_blank" . "\">" . strtolower(substr($gjc11, 0, strrpos($gjc11, '@'))) . "</a>", $moban);
        $moban = str_replace('<随机链接12>', "<a href=\"" . dirname('http://' . trim(varray_rand($fan)) . $topdomain . $siteurl) . "/" . $mulu . "/" . str_replace("@", "", strtolower(strstr($gjc12, '@'))) . ".html" . "\" target=" . "\"_blank" . "\">" . strtolower(substr($gjc12, 0, strrpos($gjc12, '@'))) . "</a>", $moban);
        $moban = str_replace('<随机链接13>', "<a href=\"" . dirname('http://' . trim(varray_rand($fan)) . $topdomain . $siteurl) . "/" . $mulu . "/" . str_replace("@", "", strtolower(strstr($gjc13, '@'))) . ".html" . "\" target=" . "\"_blank" . "\">" . strtolower(substr($gjc13, 0, strrpos($gjc13, '@'))) . "</a>", $moban);
        $moban = str_replace('<随机链接14>', "<a href=\"" . dirname('http://' . trim(varray_rand($fan)) . $topdomain . $siteurl) . "/" . $mulu . "/" . str_replace("@", "", strtolower(strstr($gjc14, '@'))) . ".html" . "\" target=" . "\"_blank" . "\">" . strtolower(substr($gjc14, 0, strrpos($gjc14, '@'))) . "</a>", $moban);
        $moban = str_replace('<随机链接15>', "<a href=\"" . dirname('http://' . trim(varray_rand($fan)) . $topdomain . $siteurl) . "/" . $mulu . "/" . str_replace("@", "", strtolower(strstr($gjc15, '@'))) . ".html" . "\" target=" . "\"_blank" . "\">" . strtolower(substr($gjc15, 0, strrpos($gjc15, '@'))) . "</a>", $moban);
        $moban = str_replace('<随机链接16>', "<a href=\"" . dirname('http://' . trim(varray_rand($fan)) . $topdomain . $siteurl) . "/" . $mulu . "/" . str_replace("@", "", strtolower(strstr($gjc16, '@'))) . ".html" . "\" target=" . "\"_blank" . "\">" . strtolower(substr($gjc16, 0, strrpos($gjc16, '@'))) . "</a>", $moban);
        $moban = str_replace('<随机链接17>', "<a href=\"" . dirname('http://' . trim(varray_rand($fan)) . $topdomain . $siteurl) . "/" . $mulu . "/" . str_replace("@", "", strtolower(strstr($gjc17, '@'))) . ".html" . "\" target=" . "\"_blank" . "\">" . strtolower(substr($gjc17, 0, strrpos($gjc17, '@'))) . "</a>", $moban);
        $moban = str_replace('<随机链接18>', "<a href=\"" . dirname('http://' . trim(varray_rand($fan)) . $topdomain . $siteurl) . "/" . $mulu . "/" . str_replace("@", "", strtolower(strstr($gjc18, '@'))) . ".html" . "\" target=" . "\"_blank" . "\">" . strtolower(substr($gjc18, 0, strrpos($gjc18, '@'))) . "</a>", $moban);
        $moban = str_replace('<随机链接19>', "<a href=\"" . dirname('http://' . trim(varray_rand($fan)) . $topdomain . $siteurl) . "/" . $mulu . "/" . str_replace("@", "", strtolower(strstr($gjc19, '@'))) . ".html" . "\" target=" . "\"_blank" . "\">" . strtolower(substr($gjc19, 0, strrpos($gjc19, '@'))) . "</a>", $moban);
        $moban = str_replace('<随机链接20>', "<a href=\"" . dirname('http://' . trim(varray_rand($fan)) . $topdomain . $siteurl) . "/" . $mulu . "/" . str_replace("@", "", strtolower(strstr($gjc20, '@'))) . ".html" . "\" target=" . "\"_blank" . "\">" . strtolower(substr($gjc20, 0, strrpos($gjc20, '@'))) . "</a>", $moban);
        $moban = str_replace('<随机链接21>', "<a href=\"" . dirname('http://' . trim(varray_rand($fan)) . $topdomain . $siteurl) . "/" . $mulu . "/" . str_replace("@", "", strtolower(strstr($gjc21, '@'))) . ".html" . "\" target=" . "\"_blank" . "\">" . strtolower(substr($gjc21, 0, strrpos($gjc21, '@'))) . "</a>", $moban);
        $moban = str_replace('<随机链接22>', "<a href=\"" . dirname('http://' . trim(varray_rand($fan)) . $topdomain . $siteurl) . "/" . $mulu . "/" . str_replace("@", "", strtolower(strstr($gjc22, '@'))) . ".html" . "\" target=" . "\"_blank" . "\">" . strtolower(substr($gjc22, 0, strrpos($gjc22, '@'))) . "</a>", $moban);
        $moban = str_replace('<随机链接23>', "<a href=\"" . dirname('http://' . trim(varray_rand($fan)) . $topdomain . $siteurl) . "/" . $mulu . "/" . str_replace("@", "", strtolower(strstr($gjc23, '@'))) . ".html" . "\" target=" . "\"_blank" . "\">" . strtolower(substr($gjc23, 0, strrpos($gjc23, '@'))) . "</a>", $moban);
        $moban = str_replace('<随机链接24>', "<a href=\"" . dirname('http://' . trim(varray_rand($fan)) . $topdomain . $siteurl) . "/" . $mulu . "/" . str_replace("@", "", strtolower(strstr($gjc24, '@'))) . ".html" . "\" target=" . "\"_blank" . "\">" . strtolower(substr($gjc24, 0, strrpos($gjc24, '@'))) . "</a>", $moban);
        $moban = str_replace('<随机链接25>', "<a href=\"" . dirname('http://' . trim(varray_rand($fan)) . $topdomain . $siteurl) . "/" . $mulu . "/" . str_replace("@", "", strtolower(strstr($gjc25, '@'))) . ".html" . "\" target=" . "\"_blank" . "\">" . strtolower(substr($gjc25, 0, strrpos($gjc25, '@'))) . "</a>", $moban);
        $moban = str_replace('<随机链接26>', "<a href=\"" . dirname('http://' . trim(varray_rand($fan)) . $topdomain . $siteurl) . "/" . $mulu . "/" . str_replace("@", "", strtolower(strstr($gjc26, '@'))) . ".html" . "\" target=" . "\"_blank" . "\">" . strtolower(substr($gjc26, 0, strrpos($gjc26, '@'))) . "</a>", $moban);
        $moban = str_replace('<随机链接27>', "<a href=\"" . dirname('http://' . trim(varray_rand($fan)) . $topdomain . $siteurl) . "/" . $mulu . "/" . str_replace("@", "", strtolower(strstr($gjc27, '@'))) . ".html" . "\" target=" . "\"_blank" . "\">" . strtolower(substr($gjc27, 0, strrpos($gjc27, '@'))) . "</a>", $moban);
        $moban = str_replace('<随机链接28>', "<a href=\"" . dirname('http://' . trim(varray_rand($fan)) . $topdomain . $siteurl) . "/" . $mulu . "/" . str_replace("@", "", strtolower(strstr($gjc28, '@'))) . ".html" . "\" target=" . "\"_blank" . "\">" . strtolower(substr($gjc28, 0, strrpos($gjc28, '@'))) . "</a>", $moban);
        $moban = str_replace('<随机链接29>', "<a href=\"" . dirname('http://' . trim(varray_rand($fan)) . $topdomain . $siteurl) . "/" . $mulu . "/" . str_replace("@", "", strtolower(strstr($gjc29, '@'))) . ".html" . "\" target=" . "\"_blank" . "\">" . strtolower(substr($gjc29, 0, strrpos($gjc29, '@'))) . "</a>", $moban);
        $moban = str_replace('<随机链接30>', "<a href=\"" . dirname('http://' . trim(varray_rand($fan)) . $topdomain . $siteurl) . "/" . $mulu . "/" . str_replace("@", "", strtolower(strstr($gjc30, '@'))) . ".html" . "\" target=" . "\"_blank" . "\">" . strtolower(substr($gjc30, 0, strrpos($gjc30, '@'))) . "</a>", $moban);
        $moban = str_replace('<随机链接31>', "<a href=\"" . dirname('http://' . trim(varray_rand($fan)) . $topdomain . $siteurl) . "/" . $mulu . "/" . str_replace("@", "", strtolower(strstr($gjc31, '@'))) . ".html" . "\" target=" . "\"_blank" . "\">" . strtolower(substr($gjc31, 0, strrpos($gjc31, '@'))) . "</a>", $moban);
        $moban = str_replace('<随机链接32>', "<a href=\"" . dirname('http://' . trim(varray_rand($fan)) . $topdomain . $siteurl) . "/" . $mulu . "/" . str_replace("@", "", strtolower(strstr($gjc32, '@'))) . ".html" . "\" target=" . "\"_blank" . "\">" . strtolower(substr($gjc32, 0, strrpos($gjc32, '@'))) . "</a>", $moban);
        $moban = str_replace('<随机链接33>', "<a href=\"" . dirname('http://' . trim(varray_rand($fan)) . $topdomain . $siteurl) . "/" . $mulu . "/" . str_replace("@", "", strtolower(strstr($gjc33, '@'))) . ".html" . "\" target=" . "\"_blank" . "\">" . strtolower(substr($gjc33, 0, strrpos($gjc33, '@'))) . "</a>", $moban);
        $moban = str_replace('<随机链接34>', "<a href=\"" . dirname('http://' . trim(varray_rand($fan)) . $topdomain . $siteurl) . "/" . $mulu . "/" . str_replace("@", "", strtolower(strstr($gjc34, '@'))) . ".html" . "\" target=" . "\"_blank" . "\">" . strtolower(substr($gjc34, 0, strrpos($gjc34, '@'))) . "</a>", $moban);
        $moban = str_replace('<随机链接35>', "<a href=\"" . dirname('http://' . trim(varray_rand($fan)) . $topdomain . $siteurl) . "/" . $mulu . "/" . str_replace("@", "", strtolower(strstr($gjc35, '@'))) . ".html" . "\" target=" . "\"_blank" . "\">" . strtolower(substr($gjc35, 0, strrpos($gjc35, '@'))) . "</a>", $moban);
        $moban = str_replace('<随机链接36>', "<a href=\"" . dirname('http://' . trim(varray_rand($fan)) . $topdomain . $siteurl) . "/" . $mulu . "/" . str_replace("@", "", strtolower(strstr($gjc36, '@'))) . ".html" . "\" target=" . "\"_blank" . "\">" . strtolower(substr($gjc36, 0, strrpos($gjc36, '@'))) . "</a>", $moban);
        $moban = str_replace('<随机链接37>', "<a href=\"" . dirname('http://' . trim(varray_rand($fan)) . $topdomain . $siteurl) . "/" . $mulu . "/" . str_replace("@", "", strtolower(strstr($gjc37, '@'))) . ".html" . "\" target=" . "\"_blank" . "\">" . strtolower(substr($gjc37, 0, strrpos($gjc37, '@'))) . "</a>", $moban);
        $moban = str_replace('<随机链接38>', "<a href=\"" . dirname('http://' . trim(varray_rand($fan)) . $topdomain . $siteurl) . "/" . $mulu . "/" . str_replace("@", "", strtolower(strstr($gjc38, '@'))) . ".html" . "\" target=" . "\"_blank" . "\">" . strtolower(substr($gjc38, 0, strrpos($gjc38, '@'))) . "</a>", $moban);
        $moban = str_replace('<随机链接39>', "<a href=\"" . dirname('http://' . trim(varray_rand($fan)) . $topdomain . $siteurl) . "/" . $mulu . "/" . str_replace("@", "", strtolower(strstr($gjc39, '@'))) . ".html" . "\" target=" . "\"_blank" . "\">" . strtolower(substr($gjc39, 0, strrpos($gjc39, '@'))) . "</a>", $moban);
        $moban = str_replace('<随机链接40>', "<a href=\"" . dirname('http://' . trim(varray_rand($fan)) . $topdomain . $siteurl) . "/" . $mulu . "/" . str_replace("@", "", strtolower(strstr($gjc40, '@'))) . ".html" . "\" target=" . "\"_blank" . "\">" . strtolower(substr($gjc40, 0, strrpos($gjc40, '@'))) . "</a>", $moban);
        $moban = str_replace('<随机链接41>', "<a href=\"" . dirname('http://' . trim(varray_rand($fan)) . $topdomain . $siteurl) . "/" . $mulu . "/" . str_replace("@", "", strtolower(strstr($gjc41, '@'))) . ".html" . "\" target=" . "\"_blank" . "\">" . strtolower(substr($gjc41, 0, strrpos($gjc41, '@'))) . "</a>", $moban);
        $moban = str_replace('<随机链接42>', "<a href=\"" . dirname('http://' . trim(varray_rand($fan)) . $topdomain . $siteurl) . "/" . $mulu . "/" . str_replace("@", "", strtolower(strstr($gjc42, '@'))) . ".html" . "\" target=" . "\"_blank" . "\">" . strtolower(substr($gjc42, 0, strrpos($gjc42, '@'))) . "</a>", $moban);
        $moban = str_replace('<随机链接43>', "<a href=\"" . dirname('http://' . trim(varray_rand($fan)) . $topdomain . $siteurl) . "/" . $mulu . "/" . str_replace("@", "", strtolower(strstr($gjc43, '@'))) . ".html" . "\" target=" . "\"_blank" . "\">" . strtolower(substr($gjc43, 0, strrpos($gjc43, '@'))) . "</a>", $moban);
        $moban = str_replace('<随机链接44>', "<a href=\"" . dirname('http://' . trim(varray_rand($fan)) . $topdomain . $siteurl) . "/" . $mulu . "/" . str_replace("@", "", strtolower(strstr($gjc44, '@'))) . ".html" . "\" target=" . "\"_blank" . "\">" . strtolower(substr($gjc44, 0, strrpos($gjc44, '@'))) . "</a>", $moban);
        $moban = str_replace('<随机链接45>', "<a href=\"" . dirname('http://' . trim(varray_rand($fan)) . $topdomain . $siteurl) . "/" . $mulu . "/" . str_replace("@", "", strtolower(strstr($gjc45, '@'))) . ".html" . "\" target=" . "\"_blank" . "\">" . strtolower(substr($gjc45, 0, strrpos($gjc45, '@'))) . "</a>", $moban);
        $moban = str_replace('<随机链接46>', "<a href=\"" . dirname('http://' . trim(varray_rand($fan)) . $topdomain . $siteurl) . "/" . $mulu . "/" . str_replace("@", "", strtolower(strstr($gjc46, '@'))) . ".html" . "\" target=" . "\"_blank" . "\">" . strtolower(substr($gjc46, 0, strrpos($gjc46, '@'))) . "</a>", $moban);
        $moban = str_replace('<随机链接47>', "<a href=\"" . dirname('http://' . trim(varray_rand($fan)) . $topdomain . $siteurl) . "/" . $mulu . "/" . str_replace("@", "", strtolower(strstr($gjc47, '@'))) . ".html" . "\" target=" . "\"_blank" . "\">" . strtolower(substr($gjc47, 0, strrpos($gjc47, '@'))) . "</a>", $moban);
        $moban = str_replace('<随机链接48>', "<a href=\"" . dirname('http://' . trim(varray_rand($fan)) . $topdomain . $siteurl) . "/" . $mulu . "/" . str_replace("@", "", strtolower(strstr($gjc48, '@'))) . ".html" . "\" target=" . "\"_blank" . "\">" . strtolower(substr($gjc48, 0, strrpos($gjc48, '@'))) . "</a>", $moban);
        $moban = str_replace('<随机链接49>', "<a href=\"" . dirname('http://' . trim(varray_rand($fan)) . $topdomain . $siteurl) . "/" . $mulu . "/" . str_replace("@", "", strtolower(strstr($gjc49, '@'))) . ".html" . "\" target=" . "\"_blank" . "\">" . strtolower(substr($gjc49, 0, strrpos($gjc49, '@'))) . "</a>", $moban);
        $moban = str_replace('<随机链接50>', "<a href=\"" . dirname('http://' . trim(varray_rand($fan)) . $topdomain . $siteurl) . "/" . $mulu . "/" . str_replace("@", "", strtolower(strstr($gjc50, '@'))) . ".html" . "\" target=" . "\"_blank" . "\">" . strtolower(substr($gjc50, 0, strrpos($gjc50, '@'))) . "</a>", $moban);
        $moban = str_replace('<随机链接51>', "<a href=\"" . dirname('http://' . trim(varray_rand($fan)) . $topdomain . $siteurl) . "/" . $mulu . "/" . str_replace("@", "", strtolower(strstr($gjc51, '@'))) . ".html" . "\" target=" . "\"_blank" . "\">" . strtolower(substr($gjc51, 0, strrpos($gjc51, '@'))) . "</a>", $moban);
        $moban = str_replace('<随机链接52>', "<a href=\"" . dirname('http://' . trim(varray_rand($fan)) . $topdomain . $siteurl) . "/" . $mulu . "/" . str_replace("@", "", strtolower(strstr($gjc52, '@'))) . ".html" . "\" target=" . "\"_blank" . "\">" . strtolower(substr($gjc52, 0, strrpos($gjc52, '@'))) . "</a>", $moban);
        $moban = str_replace('<随机链接53>', "<a href=\"" . dirname('http://' . trim(varray_rand($fan)) . $topdomain . $siteurl) . "/" . $mulu . "/" . str_replace("@", "", strtolower(strstr($gjc53, '@'))) . ".html" . "\" target=" . "\"_blank" . "\">" . strtolower(substr($gjc53, 0, strrpos($gjc53, '@'))) . "</a>", $moban);
        $moban = str_replace('<随机链接54>', "<a href=\"" . dirname('http://' . trim(varray_rand($fan)) . $topdomain . $siteurl) . "/" . $mulu . "/" . str_replace("@", "", strtolower(strstr($gjc54, '@'))) . ".html" . "\" target=" . "\"_blank" . "\">" . strtolower(substr($gjc54, 0, strrpos($gjc54, '@'))) . "</a>", $moban);
        $moban = str_replace('<随机链接55>', "<a href=\"" . dirname('http://' . trim(varray_rand($fan)) . $topdomain . $siteurl) . "/" . $mulu . "/" . str_replace("@", "", strtolower(strstr($gjc55, '@'))) . ".html" . "\" target=" . "\"_blank" . "\">" . strtolower(substr($gjc55, 0, strrpos($gjc55, '@'))) . "</a>", $moban);
        $moban = str_replace('<随机链接56>', "<a href=\"" . dirname('http://' . trim(varray_rand($fan)) . $topdomain . $siteurl) . "/" . $mulu . "/" . str_replace("@", "", strtolower(strstr($gjc56, '@'))) . ".html" . "\" target=" . "\"_blank" . "\">" . strtolower(substr($gjc56, 0, strrpos($gjc56, '@'))) . "</a>", $moban);
        $moban = str_replace('<随机链接57>', "<a href=\"" . dirname('http://' . trim(varray_rand($fan)) . $topdomain . $siteurl) . "/" . $mulu . "/" . str_replace("@", "", strtolower(strstr($gjc57, '@'))) . ".html" . "\" target=" . "\"_blank" . "\">" . strtolower(substr($gjc57, 0, strrpos($gjc57, '@'))) . "</a>", $moban);
        $moban = str_replace('<随机链接58>', "<a href=\"" . dirname('http://' . trim(varray_rand($fan)) . $topdomain . $siteurl) . "/" . $mulu . "/" . str_replace("@", "", strtolower(strstr($gjc58, '@'))) . ".html" . "\" target=" . "\"_blank" . "\">" . strtolower(substr($gjc58, 0, strrpos($gjc58, '@'))) . "</a>", $moban);
        $moban = str_replace('<随机链接59>', "<a href=\"" . dirname('http://' . trim(varray_rand($fan)) . $topdomain . $siteurl) . "/" . $mulu . "/" . str_replace("@", "", strtolower(strstr($gjc59, '@'))) . ".html" . "\" target=" . "\"_blank" . "\">" . strtolower(substr($gjc59, 0, strrpos($gjc59, '@'))) . "</a>", $moban);
        $moban = str_replace('<随机链接60>', "<a href=\"" . dirname('http://' . trim(varray_rand($fan)) . $topdomain . $siteurl) . "/" . $mulu . "/" . str_replace("@", "", strtolower(strstr($gjc60, '@'))) . ".html" . "\" target=" . "\"_blank" . "\">" . strtolower(substr($gjc60, 0, strrpos($gjc60, '@'))) . "</a>", $moban);
        $moban = str_replace('<随机链接61>', "<a href=\"" . dirname('http://' . trim(varray_rand($fan)) . $topdomain . $siteurl) . "/" . $mulu . "/" . str_replace("@", "", strtolower(strstr($gjc61, '@'))) . ".html" . "\" target=" . "\"_blank" . "\">" . strtolower(substr($gjc61, 0, strrpos($gjc61, '@'))) . "</a>", $moban);
        $moban = str_replace('<随机链接62>', "<a href=\"" . dirname('http://' . trim(varray_rand($fan)) . $topdomain . $siteurl) . "/" . $mulu . "/" . str_replace("@", "", strtolower(strstr($gjc62, '@'))) . ".html" . "\" target=" . "\"_blank" . "\">" . strtolower(substr($gjc62, 0, strrpos($gjc62, '@'))) . "</a>", $moban);
        $moban = str_replace('<随机链接63>', "<a href=\"" . dirname('http://' . trim(varray_rand($fan)) . $topdomain . $siteurl) . "/" . $mulu . "/" . str_replace("@", "", strtolower(strstr($gjc63, '@'))) . ".html" . "\" target=" . "\"_blank" . "\">" . strtolower(substr($gjc63, 0, strrpos($gjc63, '@'))) . "</a>", $moban);
        $moban = str_replace('<随机链接64>', "<a href=\"" . dirname('http://' . trim(varray_rand($fan)) . $topdomain . $siteurl) . "/" . $mulu . "/" . str_replace("@", "", strtolower(strstr($gjc64, '@'))) . ".html" . "\" target=" . "\"_blank" . "\">" . strtolower(substr($gjc64, 0, strrpos($gjc64, '@'))) . "</a>", $moban);
        $moban = str_replace('<随机链接65>', "<a href=\"" . dirname('http://' . trim(varray_rand($fan)) . $topdomain . $siteurl) . "/" . $mulu . "/" . str_replace("@", "", strtolower(strstr($gjc65, '@'))) . ".html" . "\" target=" . "\"_blank" . "\">" . strtolower(substr($gjc65, 0, strrpos($gjc65, '@'))) . "</a>", $moban);
        $moban = str_replace('<随机链接66>', "<a href=\"" . dirname('http://' . trim(varray_rand($fan)) . $topdomain . $siteurl) . "/" . $mulu . "/" . str_replace("@", "", strtolower(strstr($gjc66, '@'))) . ".html" . "\" target=" . "\"_blank" . "\">" . strtolower(substr($gjc66, 0, strrpos($gjc66, '@'))) . "</a>", $moban);
        $moban = str_replace('<随机链接67>', "<a href=\"" . dirname('http://' . trim(varray_rand($fan)) . $topdomain . $siteurl) . "/" . $mulu . "/" . str_replace("@", "", strtolower(strstr($gjc67, '@'))) . ".html" . "\" target=" . "\"_blank" . "\">" . strtolower(substr($gjc67, 0, strrpos($gjc67, '@'))) . "</a>", $moban);
        $moban = str_replace('<随机链接68>', "<a href=\"" . dirname('http://' . trim(varray_rand($fan)) . $topdomain . $siteurl) . "/" . $mulu . "/" . str_replace("@", "", strtolower(strstr($gjc68, '@'))) . ".html" . "\" target=" . "\"_blank" . "\">" . strtolower(substr($gjc68, 0, strrpos($gjc68, '@'))) . "</a>", $moban);
        $moban = str_replace('<随机链接69>', "<a href=\"" . dirname('http://' . trim(varray_rand($fan)) . $topdomain . $siteurl) . "/" . $mulu . "/" . str_replace("@", "", strtolower(strstr($gjc69, '@'))) . ".html" . "\" target=" . "\"_blank" . "\">" . strtolower(substr($gjc69, 0, strrpos($gjc69, '@'))) . "</a>", $moban);
        $moban = str_replace('<随机链接70>', "<a href=\"" . dirname('http://' . trim(varray_rand($fan)) . $topdomain . $siteurl) . "/" . $mulu . "/" . str_replace("@", "", strtolower(strstr($gjc70, '@'))) . ".html" . "\" target=" . "\"_blank" . "\">" . strtolower(substr($gjc70, 0, strrpos($gjc70, '@'))) . "</a>", $moban);
        $moban = str_replace('<随机链接71>', "<a href=\"" . dirname('http://' . trim(varray_rand($fan)) . $topdomain . $siteurl) . "/" . $mulu . "/" . str_replace("@", "", strtolower(strstr($gjc71, '@'))) . ".html" . "\" target=" . "\"_blank" . "\">" . strtolower(substr($gjc71, 0, strrpos($gjc71, '@'))) . "</a>", $moban);
        $moban = str_replace('<随机链接72>', "<a href=\"" . dirname('http://' . trim(varray_rand($fan)) . $topdomain . $siteurl) . "/" . $mulu . "/" . str_replace("@", "", strtolower(strstr($gjc72, '@'))) . ".html" . "\" target=" . "\"_blank" . "\">" . strtolower(substr($gjc72, 0, strrpos($gjc72, '@'))) . "</a>", $moban);
        $moban = str_replace('<随机链接73>', "<a href=\"" . dirname('http://' . trim(varray_rand($fan)) . $topdomain . $siteurl) . "/" . $mulu . "/" . str_replace("@", "", strtolower(strstr($gjc73, '@'))) . ".html" . "\" target=" . "\"_blank" . "\">" . strtolower(substr($gjc73, 0, strrpos($gjc73, '@'))) . "</a>", $moban);
        $moban = str_replace('<随机链接74>', "<a href=\"" . dirname('http://' . trim(varray_rand($fan)) . $topdomain . $siteurl) . "/" . $mulu . "/" . str_replace("@", "", strtolower(strstr($gjc74, '@'))) . ".html" . "\" target=" . "\"_blank" . "\">" . strtolower(substr($gjc74, 0, strrpos($gjc74, '@'))) . "</a>", $moban);
        $moban = str_replace('<随机链接75>', "<a href=\"" . dirname('http://' . trim(varray_rand($fan)) . $topdomain . $siteurl) . "/" . $mulu . "/" . str_replace("@", "", strtolower(strstr($gjc75, '@'))) . ".html" . "\" target=" . "\"_blank" . "\">" . strtolower(substr($gjc75, 0, strrpos($gjc75, '@'))) . "</a>", $moban);
        $moban = str_replace('<随机链接76>', "<a href=\"" . dirname('http://' . trim(varray_rand($fan)) . $topdomain . $siteurl) . "/" . $mulu . "/" . str_replace("@", "", strtolower(strstr($gjc76, '@'))) . ".html" . "\" target=" . "\"_blank" . "\">" . strtolower(substr($gjc76, 0, strrpos($gjc76, '@'))) . "</a>", $moban);
        $moban = str_replace('<随机链接77>', "<a href=\"" . dirname('http://' . trim(varray_rand($fan)) . $topdomain . $siteurl) . "/" . $mulu . "/" . str_replace("@", "", strtolower(strstr($gjc77, '@'))) . ".html" . "\" target=" . "\"_blank" . "\">" . strtolower(substr($gjc77, 0, strrpos($gjc77, '@'))) . "</a>", $moban);
        $moban = str_replace('<随机链接78>', "<a href=\"" . dirname('http://' . trim(varray_rand($fan)) . $topdomain . $siteurl) . "/" . $mulu . "/" . str_replace("@", "", strtolower(strstr($gjc78, '@'))) . ".html" . "\" target=" . "\"_blank" . "\">" . strtolower(substr($gjc78, 0, strrpos($gjc78, '@'))) . "</a>", $moban);
        $moban = str_replace('<随机链接79>', "<a href=\"" . dirname('http://' . trim(varray_rand($fan)) . $topdomain . $siteurl) . "/" . $mulu . "/" . str_replace("@", "", strtolower(strstr($gjc79, '@'))) . ".html" . "\" target=" . "\"_blank" . "\">" . strtolower(substr($gjc79, 0, strrpos($gjc79, '@'))) . "</a>", $moban);
        $moban = str_replace('<随机链接80>', "<a href=\"" . dirname('http://' . trim(varray_rand($fan)) . $topdomain . $siteurl) . "/" . $mulu . "/" . str_replace("@", "", strtolower(strstr($gjc80, '@'))) . ".html" . "\" target=" . "\"_blank" . "\">" . strtolower(substr($gjc80, 0, strrpos($gjc80, '@'))) . "</a>", $moban);
        $moban = str_replace('<随机链接81>', "<a href=\"" . dirname('http://' . trim(varray_rand($fan)) . $topdomain . $siteurl) . "/" . $mulu . "/" . str_replace("@", "", strtolower(strstr($gjc81, '@'))) . ".html" . "\" target=" . "\"_blank" . "\">" . strtolower(substr($gjc81, 0, strrpos($gjc81, '@'))) . "</a>", $moban);
        $moban = str_replace('<随机链接82>', "<a href=\"" . dirname('http://' . trim(varray_rand($fan)) . $topdomain . $siteurl) . "/" . $mulu . "/" . str_replace("@", "", strtolower(strstr($gjc82, '@'))) . ".html" . "\" target=" . "\"_blank" . "\">" . strtolower(substr($gjc82, 0, strrpos($gjc82, '@'))) . "</a>", $moban);
        $moban = str_replace('<随机链接83>', "<a href=\"" . dirname('http://' . trim(varray_rand($fan)) . $topdomain . $siteurl) . "/" . $mulu . "/" . str_replace("@", "", strtolower(strstr($gjc83, '@'))) . ".html" . "\" target=" . "\"_blank" . "\">" . strtolower(substr($gjc83, 0, strrpos($gjc83, '@'))) . "</a>", $moban);
        $moban = str_replace('<随机链接84>', "<a href=\"" . dirname('http://' . trim(varray_rand($fan)) . $topdomain . $siteurl) . "/" . $mulu . "/" . str_replace("@", "", strtolower(strstr($gjc84, '@'))) . ".html" . "\" target=" . "\"_blank" . "\">" . strtolower(substr($gjc84, 0, strrpos($gjc84, '@'))) . "</a>", $moban);
        $moban = str_replace('<随机链接85>', "<a href=\"" . dirname('http://' . trim(varray_rand($fan)) . $topdomain . $siteurl) . "/" . $mulu . "/" . str_replace("@", "", strtolower(strstr($gjc85, '@'))) . ".html" . "\" target=" . "\"_blank" . "\">" . strtolower(substr($gjc85, 0, strrpos($gjc85, '@'))) . "</a>", $moban);
        $moban = str_replace('<随机链接86>', "<a href=\"" . dirname('http://' . trim(varray_rand($fan)) . $topdomain . $siteurl) . "/" . $mulu . "/" . str_replace("@", "", strtolower(strstr($gjc86, '@'))) . ".html" . "\" target=" . "\"_blank" . "\">" . strtolower(substr($gjc86, 0, strrpos($gjc86, '@'))) . "</a>", $moban);
        $moban = str_replace('<随机链接87>', "<a href=\"" . dirname('http://' . trim(varray_rand($fan)) . $topdomain . $siteurl) . "/" . $mulu . "/" . str_replace("@", "", strtolower(strstr($gjc87, '@'))) . ".html" . "\" target=" . "\"_blank" . "\">" . strtolower(substr($gjc87, 0, strrpos($gjc87, '@'))) . "</a>", $moban);
        $moban = str_replace('<随机链接88>', "<a href=\"" . dirname('http://' . trim(varray_rand($fan)) . $topdomain . $siteurl) . "/" . $mulu . "/" . str_replace("@", "", strtolower(strstr($gjc88, '@'))) . ".html" . "\" target=" . "\"_blank" . "\">" . strtolower(substr($gjc88, 0, strrpos($gjc88, '@'))) . "</a>", $moban);
        $moban = str_replace('<随机链接89>', "<a href=\"" . dirname('http://' . trim(varray_rand($fan)) . $topdomain . $siteurl) . "/" . $mulu . "/" . str_replace("@", "", strtolower(strstr($gjc89, '@'))) . ".html" . "\" target=" . "\"_blank" . "\">" . strtolower(substr($gjc89, 0, strrpos($gjc89, '@'))) . "</a>", $moban);
        $moban = str_replace('<随机链接90>', "<a href=\"" . dirname('http://' . trim(varray_rand($fan)) . $topdomain . $siteurl) . "/" . $mulu . "/" . str_replace("@", "", strtolower(strstr($gjc90, '@'))) . ".html" . "\" target=" . "\"_blank" . "\">" . strtolower(substr($gjc90, 0, strrpos($gjc90, '@'))) . "</a>", $moban);
        $moban = str_replace('<随机链接91>', "<a href=\"" . dirname('http://' . trim(varray_rand($fan)) . $topdomain . $siteurl) . "/" . $mulu . "/" . str_replace("@", "", strtolower(strstr($gjc91, '@'))) . ".html" . "\" target=" . "\"_blank" . "\">" . strtolower(substr($gjc91, 0, strrpos($gjc91, '@'))) . "</a>", $moban);
        $moban = str_replace('<随机链接92>', "<a href=\"" . dirname('http://' . trim(varray_rand($fan)) . $topdomain . $siteurl) . "/" . $mulu . "/" . str_replace("@", "", strtolower(strstr($gjc92, '@'))) . ".html" . "\" target=" . "\"_blank" . "\">" . strtolower(substr($gjc92, 0, strrpos($gjc92, '@'))) . "</a>", $moban);
        $moban = str_replace('<随机链接93>', "<a href=\"" . dirname('http://' . trim(varray_rand($fan)) . $topdomain . $siteurl) . "/" . $mulu . "/" . str_replace("@", "", strtolower(strstr($gjc93, '@'))) . ".html" . "\" target=" . "\"_blank" . "\">" . strtolower(substr($gjc93, 0, strrpos($gjc93, '@'))) . "</a>", $moban);
        $moban = str_replace('<随机链接94>', "<a href=\"" . dirname('http://' . trim(varray_rand($fan)) . $topdomain . $siteurl) . "/" . $mulu . "/" . str_replace("@", "", strtolower(strstr($gjc94, '@'))) . ".html" . "\" target=" . "\"_blank" . "\">" . strtolower(substr($gjc94, 0, strrpos($gjc94, '@'))) . "</a>", $moban);
        $moban = str_replace('<随机链接95>', "<a href=\"" . dirname('http://' . trim(varray_rand($fan)) . $topdomain . $siteurl) . "/" . $mulu . "/" . str_replace("@", "", strtolower(strstr($gjc95, '@'))) . ".html" . "\" target=" . "\"_blank" . "\">" . strtolower(substr($gjc95, 0, strrpos($gjc95, '@'))) . "</a>", $moban);
        $moban = str_replace('<随机链接96>', "<a href=\"" . dirname('http://' . trim(varray_rand($fan)) . $topdomain . $siteurl) . "/" . $mulu . "/" . str_replace("@", "", strtolower(strstr($gjc96, '@'))) . ".html" . "\" target=" . "\"_blank" . "\">" . strtolower(substr($gjc96, 0, strrpos($gjc96, '@'))) . "</a>", $moban);
        $moban = str_replace('<随机链接97>', "<a href=\"" . dirname('http://' . trim(varray_rand($fan)) . $topdomain . $siteurl) . "/" . $mulu . "/" . str_replace("@", "", strtolower(strstr($gjc97, '@'))) . ".html" . "\" target=" . "\"_blank" . "\">" . strtolower(substr($gjc97, 0, strrpos($gjc97, '@'))) . "</a>", $moban);
        $moban = str_replace('<随机链接98>', "<a href=\"" . dirname('http://' . trim(varray_rand($fan)) . $topdomain . $siteurl) . "/" . $mulu . "/" . str_replace("@", "", strtolower(strstr($gjc98, '@'))) . ".html" . "\" target=" . "\"_blank" . "\">" . strtolower(substr($gjc98, 0, strrpos($gjc98, '@'))) . "</a>", $moban);
        $moban = str_replace('<随机链接99>', "<a href=\"" . dirname('http://' . trim(varray_rand($fan)) . $topdomain . $siteurl) . "/" . $mulu . "/" . str_replace("@", "", strtolower(strstr($gjc99, '@'))) . ".html" . "\" target=" . "\"_blank" . "\">" . strtolower(substr($gjc99, 0, strrpos($gjc99, '@'))) . "</a>", $moban);
        $moban = str_replace('<随机链接100>', "<a href=\"" . dirname('http://' . trim(varray_rand($fan)) . $topdomain . $siteurl) . "/" . $mulu . "/" . str_replace("@", "", strtolower(strstr($gjc100, '@'))) . ".html" . "\" target=" . "\"_blank" . "\">" . strtolower(substr($gjc100, 0, strrpos($gjc100, '@'))) . "</a>", $moban);
        $moban = str_replace('<纯链接1>', dirname('http://' . trim(varray_rand($fan)) . $topdomain . $siteurl) . "/" . $mulu . "/" . str_replace("@", "", strtolower(strstr($gjc1, '@'))) . ".html", $moban);
        $moban = str_replace('<纯链接2>', dirname('http://' . trim(varray_rand($fan)) . $topdomain . $siteurl) . "/" . $mulu . "/" . str_replace("@", "", strtolower(strstr($gjc2, '@'))) . ".html", $moban);
        $moban = str_replace('<纯链接3>', dirname('http://' . trim(varray_rand($fan)) . $topdomain . $siteurl) . "/" . $mulu . "/" . str_replace("@", "", strtolower(strstr($gjc3, '@'))) . ".html", $moban);
        $moban = str_replace('<纯链接4>', dirname('http://' . trim(varray_rand($fan)) . $topdomain . $siteurl) . "/" . $mulu . "/" . str_replace("@", "", strtolower(strstr($gjc4, '@'))) . ".html", $moban);
        $moban = str_replace('<纯链接5>', dirname('http://' . trim(varray_rand($fan)) . $topdomain . $siteurl) . "/" . $mulu . "/" . str_replace("@", "", strtolower(strstr($gjc5, '@'))) . ".html", $moban);
        $moban = str_replace('<纯链接6>', dirname('http://' . trim(varray_rand($fan)) . $topdomain . $siteurl) . "/" . $mulu . "/" . str_replace("@", "", strtolower(strstr($gjc6, '@'))) . ".html", $moban);
        $moban = str_replace('<纯链接7>', dirname('http://' . trim(varray_rand($fan)) . $topdomain . $siteurl) . "/" . $mulu . "/" . str_replace("@", "", strtolower(strstr($gjc7, '@'))) . ".html", $moban);
        $moban = str_replace('<纯链接8>', dirname('http://' . trim(varray_rand($fan)) . $topdomain . $siteurl) . "/" . $mulu . "/" . str_replace("@", "", strtolower(strstr($gjc8, '@'))) . ".html", $moban);
        $moban = str_replace('<纯链接9>', dirname('http://' . trim(varray_rand($fan)) . $topdomain . $siteurl) . "/" . $mulu . "/" . str_replace("@", "", strtolower(strstr($gjc9, '@'))) . ".html", $moban);
        $moban = str_replace('<纯链接10>', dirname('http://' . trim(varray_rand($fan)) . $topdomain . $siteurl) . "/" . $mulu . "/" . str_replace("@", "", strtolower(strstr($gjc10, '@'))) . ".html", $moban);
        $moban = str_replace('<纯链接11>', dirname('http://' . trim(varray_rand($fan)) . $topdomain . $siteurl) . "/" . $mulu . "/" . str_replace("@", "", strtolower(strstr($gjc11, '@'))) . ".html", $moban);
        $moban = str_replace('<纯链接12>', dirname('http://' . trim(varray_rand($fan)) . $topdomain . $siteurl) . "/" . $mulu . "/" . str_replace("@", "", strtolower(strstr($gjc12, '@'))) . ".html", $moban);
        $moban = str_replace('<纯链接13>', dirname('http://' . trim(varray_rand($fan)) . $topdomain . $siteurl) . "/" . $mulu . "/" . str_replace("@", "", strtolower(strstr($gjc13, '@'))) . ".html", $moban);
        $moban = str_replace('<纯链接14>', dirname('http://' . trim(varray_rand($fan)) . $topdomain . $siteurl) . "/" . $mulu . "/" . str_replace("@", "", strtolower(strstr($gjc14, '@'))) . ".html", $moban);
        $moban = str_replace('<纯链接15>', dirname('http://' . trim(varray_rand($fan)) . $topdomain . $siteurl) . "/" . $mulu . "/" . str_replace("@", "", strtolower(strstr($gjc15, '@'))) . ".html", $moban);
        $moban = str_replace('<纯链接16>', dirname('http://' . trim(varray_rand($fan)) . $topdomain . $siteurl) . "/" . $mulu . "/" . str_replace("@", "", strtolower(strstr($gjc16, '@'))) . ".html", $moban);
        $moban = str_replace('<纯链接17>', dirname('http://' . trim(varray_rand($fan)) . $topdomain . $siteurl) . "/" . $mulu . "/" . str_replace("@", "", strtolower(strstr($gjc17, '@'))) . ".html", $moban);
        $moban = str_replace('<纯链接18>', dirname('http://' . trim(varray_rand($fan)) . $topdomain . $siteurl) . "/" . $mulu . "/" . str_replace("@", "", strtolower(strstr($gjc18, '@'))) . ".html", $moban);
        $moban = str_replace('<纯链接19>', dirname('http://' . trim(varray_rand($fan)) . $topdomain . $siteurl) . "/" . $mulu . "/" . str_replace("@", "", strtolower(strstr($gjc19, '@'))) . ".html", $moban);
        $moban = str_replace('<纯链接20>', dirname('http://' . trim(varray_rand($fan)) . $topdomain . $siteurl) . "/" . $mulu . "/" . str_replace("@", "", strtolower(strstr($gjc20, '@'))) . ".html", $moban);
        $moban = str_replace('<纯链接21>', dirname('http://' . trim(varray_rand($fan)) . $topdomain . $siteurl) . "/" . $mulu . "/" . str_replace("@", "", strtolower(strstr($gjc21, '@'))) . ".html", $moban);
        $moban = str_replace('<纯链接22>', dirname('http://' . trim(varray_rand($fan)) . $topdomain . $siteurl) . "/" . $mulu . "/" . str_replace("@", "", strtolower(strstr($gjc22, '@'))) . ".html", $moban);
        $moban = str_replace('<纯链接23>', dirname('http://' . trim(varray_rand($fan)) . $topdomain . $siteurl) . "/" . $mulu . "/" . str_replace("@", "", strtolower(strstr($gjc23, '@'))) . ".html", $moban);
        $moban = str_replace('<纯链接24>', dirname('http://' . trim(varray_rand($fan)) . $topdomain . $siteurl) . "/" . $mulu . "/" . str_replace("@", "", strtolower(strstr($gjc24, '@'))) . ".html", $moban);
        $moban = str_replace('<纯链接25>', dirname('http://' . trim(varray_rand($fan)) . $topdomain . $siteurl) . "/" . $mulu . "/" . str_replace("@", "", strtolower(strstr($gjc25, '@'))) . ".html", $moban);
        $moban = str_replace('<纯链接26>', dirname('http://' . trim(varray_rand($fan)) . $topdomain . $siteurl) . "/" . $mulu . "/" . str_replace("@", "", strtolower(strstr($gjc26, '@'))) . ".html", $moban);
        $moban = str_replace('<纯链接27>', dirname('http://' . trim(varray_rand($fan)) . $topdomain . $siteurl) . "/" . $mulu . "/" . str_replace("@", "", strtolower(strstr($gjc27, '@'))) . ".html", $moban);
        $moban = str_replace('<纯链接28>', dirname('http://' . trim(varray_rand($fan)) . $topdomain . $siteurl) . "/" . $mulu . "/" . str_replace("@", "", strtolower(strstr($gjc28, '@'))) . ".html", $moban);
        $moban = str_replace('<纯链接29>', dirname('http://' . trim(varray_rand($fan)) . $topdomain . $siteurl) . "/" . $mulu . "/" . str_replace("@", "", strtolower(strstr($gjc29, '@'))) . ".html", $moban);
        $moban = str_replace('<纯链接30>', dirname('http://' . trim(varray_rand($fan)) . $topdomain . $siteurl) . "/" . $mulu . "/" . str_replace("@", "", strtolower(strstr($gjc30, '@'))) . ".html", $moban);
        $moban = str_replace('<纯链接31>', dirname('http://' . trim(varray_rand($fan)) . $topdomain . $siteurl) . "/" . $mulu . "/" . str_replace("@", "", strtolower(strstr($gjc31, '@'))) . ".html", $moban);
        $moban = str_replace('<纯链接32>', dirname('http://' . trim(varray_rand($fan)) . $topdomain . $siteurl) . "/" . $mulu . "/" . str_replace("@", "", strtolower(strstr($gjc32, '@'))) . ".html", $moban);
        $moban = str_replace('<纯链接33>', dirname('http://' . trim(varray_rand($fan)) . $topdomain . $siteurl) . "/" . $mulu . "/" . str_replace("@", "", strtolower(strstr($gjc33, '@'))) . ".html", $moban);
        $moban = str_replace('<纯链接34>', dirname('http://' . trim(varray_rand($fan)) . $topdomain . $siteurl) . "/" . $mulu . "/" . str_replace("@", "", strtolower(strstr($gjc34, '@'))) . ".html", $moban);
        $moban = str_replace('<纯链接35>', dirname('http://' . trim(varray_rand($fan)) . $topdomain . $siteurl) . "/" . $mulu . "/" . str_replace("@", "", strtolower(strstr($gjc35, '@'))) . ".html", $moban);
        $moban = str_replace('<纯链接36>', dirname('http://' . trim(varray_rand($fan)) . $topdomain . $siteurl) . "/" . $mulu . "/" . str_replace("@", "", strtolower(strstr($gjc36, '@'))) . ".html", $moban);
        $moban = str_replace('<纯链接37>', dirname('http://' . trim(varray_rand($fan)) . $topdomain . $siteurl) . "/" . $mulu . "/" . str_replace("@", "", strtolower(strstr($gjc37, '@'))) . ".html", $moban);
        $moban = str_replace('<纯链接38>', dirname('http://' . trim(varray_rand($fan)) . $topdomain . $siteurl) . "/" . $mulu . "/" . str_replace("@", "", strtolower(strstr($gjc38, '@'))) . ".html", $moban);
        $moban = str_replace('<纯链接39>', dirname('http://' . trim(varray_rand($fan)) . $topdomain . $siteurl) . "/" . $mulu . "/" . str_replace("@", "", strtolower(strstr($gjc39, '@'))) . ".html", $moban);
        $moban = str_replace('<纯链接40>', dirname('http://' . trim(varray_rand($fan)) . $topdomain . $siteurl) . "/" . $mulu . "/" . str_replace("@", "", strtolower(strstr($gjc40, '@'))) . ".html", $moban);
        $moban = str_replace('<纯链接41>', dirname('http://' . trim(varray_rand($fan)) . $topdomain . $siteurl) . "/" . $mulu . "/" . str_replace("@", "", strtolower(strstr($gjc41, '@'))) . ".html", $moban);
        $moban = str_replace('<纯链接42>', dirname('http://' . trim(varray_rand($fan)) . $topdomain . $siteurl) . "/" . $mulu . "/" . str_replace("@", "", strtolower(strstr($gjc42, '@'))) . ".html", $moban);
        $moban = str_replace('<纯链接43>', dirname('http://' . trim(varray_rand($fan)) . $topdomain . $siteurl) . "/" . $mulu . "/" . str_replace("@", "", strtolower(strstr($gjc43, '@'))) . ".html", $moban);
        $moban = str_replace('<纯链接44>', dirname('http://' . trim(varray_rand($fan)) . $topdomain . $siteurl) . "/" . $mulu . "/" . str_replace("@", "", strtolower(strstr($gjc44, '@'))) . ".html", $moban);
        $moban = str_replace('<纯链接45>', dirname('http://' . trim(varray_rand($fan)) . $topdomain . $siteurl) . "/" . $mulu . "/" . str_replace("@", "", strtolower(strstr($gjc45, '@'))) . ".html", $moban);
        $moban = str_replace('<纯链接46>', dirname('http://' . trim(varray_rand($fan)) . $topdomain . $siteurl) . "/" . $mulu . "/" . str_replace("@", "", strtolower(strstr($gjc46, '@'))) . ".html", $moban);
        $moban = str_replace('<纯链接47>', dirname('http://' . trim(varray_rand($fan)) . $topdomain . $siteurl) . "/" . $mulu . "/" . str_replace("@", "", strtolower(strstr($gjc47, '@'))) . ".html", $moban);
        $moban = str_replace('<纯链接48>', dirname('http://' . trim(varray_rand($fan)) . $topdomain . $siteurl) . "/" . $mulu . "/" . str_replace("@", "", strtolower(strstr($gjc48, '@'))) . ".html", $moban);
        $moban = str_replace('<纯链接49>', dirname('http://' . trim(varray_rand($fan)) . $topdomain . $siteurl) . "/" . $mulu . "/" . str_replace("@", "", strtolower(strstr($gjc49, '@'))) . ".html", $moban);
        $moban = str_replace('<纯链接50>', dirname('http://' . trim(varray_rand($fan)) . $topdomain . $siteurl) . "/" . $mulu . "/" . str_replace("@", "", strtolower(strstr($gjc50, '@'))) . ".html", $moban);
        $moban = str_replace('<纯链接51>', dirname('http://' . trim(varray_rand($fan)) . $topdomain . $siteurl) . "/" . $mulu . "/" . str_replace("@", "", strtolower(strstr($gjc51, '@'))) . ".html", $moban);
        $moban = str_replace('<纯链接52>', dirname('http://' . trim(varray_rand($fan)) . $topdomain . $siteurl) . "/" . $mulu . "/" . str_replace("@", "", strtolower(strstr($gjc52, '@'))) . ".html", $moban);
        $moban = str_replace('<纯链接53>', dirname('http://' . trim(varray_rand($fan)) . $topdomain . $siteurl) . "/" . $mulu . "/" . str_replace("@", "", strtolower(strstr($gjc53, '@'))) . ".html", $moban);
        $moban = str_replace('<纯链接54>', dirname('http://' . trim(varray_rand($fan)) . $topdomain . $siteurl) . "/" . $mulu . "/" . str_replace("@", "", strtolower(strstr($gjc54, '@'))) . ".html", $moban);
        $moban = str_replace('<纯链接55>', dirname('http://' . trim(varray_rand($fan)) . $topdomain . $siteurl) . "/" . $mulu . "/" . str_replace("@", "", strtolower(strstr($gjc55, '@'))) . ".html", $moban);
        $moban = str_replace('<纯链接56>', dirname('http://' . trim(varray_rand($fan)) . $topdomain . $siteurl) . "/" . $mulu . "/" . str_replace("@", "", strtolower(strstr($gjc56, '@'))) . ".html", $moban);
        $moban = str_replace('<纯链接57>', dirname('http://' . trim(varray_rand($fan)) . $topdomain . $siteurl) . "/" . $mulu . "/" . str_replace("@", "", strtolower(strstr($gjc57, '@'))) . ".html", $moban);
        $moban = str_replace('<纯链接58>', dirname('http://' . trim(varray_rand($fan)) . $topdomain . $siteurl) . "/" . $mulu . "/" . str_replace("@", "", strtolower(strstr($gjc58, '@'))) . ".html", $moban);
        $moban = str_replace('<纯链接59>', dirname('http://' . trim(varray_rand($fan)) . $topdomain . $siteurl) . "/" . $mulu . "/" . str_replace("@", "", strtolower(strstr($gjc59, '@'))) . ".html", $moban);
        $moban = str_replace('<纯链接60>', dirname('http://' . trim(varray_rand($fan)) . $topdomain . $siteurl) . "/" . $mulu . "/" . str_replace("@", "", strtolower(strstr($gjc60, '@'))) . ".html", $moban);
        $moban = str_replace('<纯链接61>', dirname('http://' . trim(varray_rand($fan)) . $topdomain . $siteurl) . "/" . $mulu . "/" . str_replace("@", "", strtolower(strstr($gjc61, '@'))) . ".html", $moban);
        $moban = str_replace('<纯链接62>', dirname('http://' . trim(varray_rand($fan)) . $topdomain . $siteurl) . "/" . $mulu . "/" . str_replace("@", "", strtolower(strstr($gjc62, '@'))) . ".html", $moban);
        $moban = str_replace('<纯链接63>', dirname('http://' . trim(varray_rand($fan)) . $topdomain . $siteurl) . "/" . $mulu . "/" . str_replace("@", "", strtolower(strstr($gjc63, '@'))) . ".html", $moban);
        $moban = str_replace('<纯链接64>', dirname('http://' . trim(varray_rand($fan)) . $topdomain . $siteurl) . "/" . $mulu . "/" . str_replace("@", "", strtolower(strstr($gjc64, '@'))) . ".html", $moban);
        $moban = str_replace('<纯链接65>', dirname('http://' . trim(varray_rand($fan)) . $topdomain . $siteurl) . "/" . $mulu . "/" . str_replace("@", "", strtolower(strstr($gjc65, '@'))) . ".html", $moban);
        $moban = str_replace('<纯链接66>', dirname('http://' . trim(varray_rand($fan)) . $topdomain . $siteurl) . "/" . $mulu . "/" . str_replace("@", "", strtolower(strstr($gjc66, '@'))) . ".html", $moban);
        $moban = str_replace('<纯链接67>', dirname('http://' . trim(varray_rand($fan)) . $topdomain . $siteurl) . "/" . $mulu . "/" . str_replace("@", "", strtolower(strstr($gjc67, '@'))) . ".html", $moban);
        $moban = str_replace('<纯链接68>', dirname('http://' . trim(varray_rand($fan)) . $topdomain . $siteurl) . "/" . $mulu . "/" . str_replace("@", "", strtolower(strstr($gjc68, '@'))) . ".html", $moban);
        $moban = str_replace('<纯链接69>', dirname('http://' . trim(varray_rand($fan)) . $topdomain . $siteurl) . "/" . $mulu . "/" . str_replace("@", "", strtolower(strstr($gjc69, '@'))) . ".html", $moban);
        $moban = str_replace('<纯链接70>', dirname('http://' . trim(varray_rand($fan)) . $topdomain . $siteurl) . "/" . $mulu . "/" . str_replace("@", "", strtolower(strstr($gjc70, '@'))) . ".html", $moban);
        $moban = str_replace('<纯链接71>', dirname('http://' . trim(varray_rand($fan)) . $topdomain . $siteurl) . "/" . $mulu . "/" . str_replace("@", "", strtolower(strstr($gjc71, '@'))) . ".html", $moban);
        $moban = str_replace('<纯链接72>', dirname('http://' . trim(varray_rand($fan)) . $topdomain . $siteurl) . "/" . $mulu . "/" . str_replace("@", "", strtolower(strstr($gjc72, '@'))) . ".html", $moban);
        $moban = str_replace('<纯链接73>', dirname('http://' . trim(varray_rand($fan)) . $topdomain . $siteurl) . "/" . $mulu . "/" . str_replace("@", "", strtolower(strstr($gjc73, '@'))) . ".html", $moban);
        $moban = str_replace('<纯链接74>', dirname('http://' . trim(varray_rand($fan)) . $topdomain . $siteurl) . "/" . $mulu . "/" . str_replace("@", "", strtolower(strstr($gjc74, '@'))) . ".html", $moban);
        $moban = str_replace('<纯链接75>', dirname('http://' . trim(varray_rand($fan)) . $topdomain . $siteurl) . "/" . $mulu . "/" . str_replace("@", "", strtolower(strstr($gjc75, '@'))) . ".html", $moban);
        $moban = str_replace('<纯链接76>', dirname('http://' . trim(varray_rand($fan)) . $topdomain . $siteurl) . "/" . $mulu . "/" . str_replace("@", "", strtolower(strstr($gjc76, '@'))) . ".html", $moban);
        $moban = str_replace('<纯链接77>', dirname('http://' . trim(varray_rand($fan)) . $topdomain . $siteurl) . "/" . $mulu . "/" . str_replace("@", "", strtolower(strstr($gjc77, '@'))) . ".html", $moban);
        $moban = str_replace('<纯链接78>', dirname('http://' . trim(varray_rand($fan)) . $topdomain . $siteurl) . "/" . $mulu . "/" . str_replace("@", "", strtolower(strstr($gjc78, '@'))) . ".html", $moban);
        $moban = str_replace('<纯链接79>', dirname('http://' . trim(varray_rand($fan)) . $topdomain . $siteurl) . "/" . $mulu . "/" . str_replace("@", "", strtolower(strstr($gjc79, '@'))) . ".html", $moban);
        $moban = str_replace('<纯链接80>', dirname('http://' . trim(varray_rand($fan)) . $topdomain . $siteurl) . "/" . $mulu . "/" . str_replace("@", "", strtolower(strstr($gjc80, '@'))) . ".html", $moban);
        $moban = str_replace('<纯链接81>', dirname('http://' . trim(varray_rand($fan)) . $topdomain . $siteurl) . "/" . $mulu . "/" . str_replace("@", "", strtolower(strstr($gjc81, '@'))) . ".html", $moban);
        $moban = str_replace('<纯链接82>', dirname('http://' . trim(varray_rand($fan)) . $topdomain . $siteurl) . "/" . $mulu . "/" . str_replace("@", "", strtolower(strstr($gjc82, '@'))) . ".html", $moban);
        $moban = str_replace('<纯链接83>', dirname('http://' . trim(varray_rand($fan)) . $topdomain . $siteurl) . "/" . $mulu . "/" . str_replace("@", "", strtolower(strstr($gjc83, '@'))) . ".html", $moban);
        $moban = str_replace('<纯链接84>', dirname('http://' . trim(varray_rand($fan)) . $topdomain . $siteurl) . "/" . $mulu . "/" . str_replace("@", "", strtolower(strstr($gjc84, '@'))) . ".html", $moban);
        $moban = str_replace('<纯链接85>', dirname('http://' . trim(varray_rand($fan)) . $topdomain . $siteurl) . "/" . $mulu . "/" . str_replace("@", "", strtolower(strstr($gjc85, '@'))) . ".html", $moban);
        $moban = str_replace('<纯链接86>', dirname('http://' . trim(varray_rand($fan)) . $topdomain . $siteurl) . "/" . $mulu . "/" . str_replace("@", "", strtolower(strstr($gjc86, '@'))) . ".html", $moban);
        $moban = str_replace('<纯链接87>', dirname('http://' . trim(varray_rand($fan)) . $topdomain . $siteurl) . "/" . $mulu . "/" . str_replace("@", "", strtolower(strstr($gjc87, '@'))) . ".html", $moban);
        $moban = str_replace('<纯链接88>', dirname('http://' . trim(varray_rand($fan)) . $topdomain . $siteurl) . "/" . $mulu . "/" . str_replace("@", "", strtolower(strstr($gjc88, '@'))) . ".html", $moban);
        $moban = str_replace('<纯链接89>', dirname('http://' . trim(varray_rand($fan)) . $topdomain . $siteurl) . "/" . $mulu . "/" . str_replace("@", "", strtolower(strstr($gjc89, '@'))) . ".html", $moban);
        $moban = str_replace('<纯链接90>', dirname('http://' . trim(varray_rand($fan)) . $topdomain . $siteurl) . "/" . $mulu . "/" . str_replace("@", "", strtolower(strstr($gjc90, '@'))) . ".html", $moban);
        $moban = str_replace('<纯链接91>', dirname('http://' . trim(varray_rand($fan)) . $topdomain . $siteurl) . "/" . $mulu . "/" . str_replace("@", "", strtolower(strstr($gjc91, '@'))) . ".html", $moban);
        $moban = str_replace('<纯链接92>', dirname('http://' . trim(varray_rand($fan)) . $topdomain . $siteurl) . "/" . $mulu . "/" . str_replace("@", "", strtolower(strstr($gjc92, '@'))) . ".html", $moban);
        $moban = str_replace('<纯链接93>', dirname('http://' . trim(varray_rand($fan)) . $topdomain . $siteurl) . "/" . $mulu . "/" . str_replace("@", "", strtolower(strstr($gjc93, '@'))) . ".html", $moban);
        $moban = str_replace('<纯链接94>', dirname('http://' . trim(varray_rand($fan)) . $topdomain . $siteurl) . "/" . $mulu . "/" . str_replace("@", "", strtolower(strstr($gjc94, '@'))) . ".html", $moban);
        $moban = str_replace('<纯链接95>', dirname('http://' . trim(varray_rand($fan)) . $topdomain . $siteurl) . "/" . $mulu . "/" . str_replace("@", "", strtolower(strstr($gjc95, '@'))) . ".html", $moban);
        $moban = str_replace('<纯链接96>', dirname('http://' . trim(varray_rand($fan)) . $topdomain . $siteurl) . "/" . $mulu . "/" . str_replace("@", "", strtolower(strstr($gjc96, '@'))) . ".html", $moban);
        $moban = str_replace('<纯链接97>', dirname('http://' . trim(varray_rand($fan)) . $topdomain . $siteurl) . "/" . $mulu . "/" . str_replace("@", "", strtolower(strstr($gjc97, '@'))) . ".html", $moban);
        $moban = str_replace('<纯链接98>', dirname('http://' . trim(varray_rand($fan)) . $topdomain . $siteurl) . "/" . $mulu . "/" . str_replace("@", "", strtolower(strstr($gjc98, '@'))) . ".html", $moban);
        $moban = str_replace('<纯链接99>', dirname('http://' . trim(varray_rand($fan)) . $topdomain . $siteurl) . "/" . $mulu . "/" . str_replace("@", "", strtolower(strstr($gjc99, '@'))) . ".html", $moban);
        $moban = str_replace('<纯链接100>', dirname('http://' . trim(varray_rand($fan)) . $topdomain . $siteurl) . "/" . $mulu . "/" . str_replace("@", "", strtolower(strstr($gjc100, '@'))) . ".html", $moban);
        $moban = str_replace('<标题1>', strtolower(substr($gjc1, 0, strrpos($gjc1, '@'))), $moban);
        $moban = str_replace('<标题2>', strtolower(substr($gjc2, 0, strrpos($gjc2, '@'))), $moban);
        $moban = str_replace('<标题3>', strtolower(substr($gjc3, 0, strrpos($gjc3, '@'))), $moban);
        $moban = str_replace('<标题4>', strtolower(substr($gjc4, 0, strrpos($gjc4, '@'))), $moban);
        $moban = str_replace('<标题5>', strtolower(substr($gjc5, 0, strrpos($gjc5, '@'))), $moban);
        $moban = str_replace('<标题6>', strtolower(substr($gjc6, 0, strrpos($gjc6, '@'))), $moban);
        $moban = str_replace('<标题7>', strtolower(substr($gjc7, 0, strrpos($gjc7, '@'))), $moban);
        $moban = str_replace('<标题8>', strtolower(substr($gjc8, 0, strrpos($gjc8, '@'))), $moban);
        $moban = str_replace('<标题9>', strtolower(substr($gjc9, 0, strrpos($gjc9, '@'))), $moban);
        $moban = str_replace('<标题10>', strtolower(substr($gjc10, 0, strrpos($gjc10, '@'))), $moban);
        $moban = str_replace('<标题11>', strtolower(substr($gjc11, 0, strrpos($gjc11, '@'))), $moban);
        $moban = str_replace('<标题12>', strtolower(substr($gjc12, 0, strrpos($gjc12, '@'))), $moban);
        $moban = str_replace('<标题13>', strtolower(substr($gjc13, 0, strrpos($gjc13, '@'))), $moban);
        $moban = str_replace('<标题14>', strtolower(substr($gjc14, 0, strrpos($gjc14, '@'))), $moban);
        $moban = str_replace('<标题15>', strtolower(substr($gjc15, 0, strrpos($gjc15, '@'))), $moban);
        $moban = str_replace('<标题16>', strtolower(substr($gjc16, 0, strrpos($gjc16, '@'))), $moban);
        $moban = str_replace('<标题17>', strtolower(substr($gjc17, 0, strrpos($gjc17, '@'))), $moban);
        $moban = str_replace('<标题18>', strtolower(substr($gjc18, 0, strrpos($gjc18, '@'))), $moban);
        $moban = str_replace('<标题19>', strtolower(substr($gjc19, 0, strrpos($gjc19, '@'))), $moban);
        $moban = str_replace('<标题20>', strtolower(substr($gjc20, 0, strrpos($gjc20, '@'))), $moban);
        $moban = str_replace('<标题21>', strtolower(substr($gjc21, 0, strrpos($gjc21, '@'))), $moban);
        $moban = str_replace('<标题22>', strtolower(substr($gjc22, 0, strrpos($gjc22, '@'))), $moban);
        $moban = str_replace('<标题23>', strtolower(substr($gjc23, 0, strrpos($gjc23, '@'))), $moban);
        $moban = str_replace('<标题24>', strtolower(substr($gjc24, 0, strrpos($gjc24, '@'))), $moban);
        $moban = str_replace('<标题25>', strtolower(substr($gjc25, 0, strrpos($gjc25, '@'))), $moban);
        $moban = str_replace('<标题26>', strtolower(substr($gjc26, 0, strrpos($gjc26, '@'))), $moban);
        $moban = str_replace('<标题27>', strtolower(substr($gjc27, 0, strrpos($gjc27, '@'))), $moban);
        $moban = str_replace('<标题28>', strtolower(substr($gjc28, 0, strrpos($gjc28, '@'))), $moban);
        $moban = str_replace('<标题29>', strtolower(substr($gjc29, 0, strrpos($gjc29, '@'))), $moban);
        $moban = str_replace('<标题30>', strtolower(substr($gjc30, 0, strrpos($gjc30, '@'))), $moban);
        $moban = str_replace('<标题31>', strtolower(substr($gjc31, 0, strrpos($gjc31, '@'))), $moban);
        $moban = str_replace('<标题32>', strtolower(substr($gjc32, 0, strrpos($gjc32, '@'))), $moban);
        $moban = str_replace('<标题33>', strtolower(substr($gjc33, 0, strrpos($gjc33, '@'))), $moban);
        $moban = str_replace('<标题34>', strtolower(substr($gjc34, 0, strrpos($gjc34, '@'))), $moban);
        $moban = str_replace('<标题35>', strtolower(substr($gjc35, 0, strrpos($gjc35, '@'))), $moban);
        $moban = str_replace('<标题36>', strtolower(substr($gjc36, 0, strrpos($gjc36, '@'))), $moban);
        $moban = str_replace('<标题37>', strtolower(substr($gjc37, 0, strrpos($gjc37, '@'))), $moban);
        $moban = str_replace('<标题38>', strtolower(substr($gjc38, 0, strrpos($gjc38, '@'))), $moban);
        $moban = str_replace('<标题39>', strtolower(substr($gjc39, 0, strrpos($gjc39, '@'))), $moban);
        $moban = str_replace('<标题40>', strtolower(substr($gjc40, 0, strrpos($gjc40, '@'))), $moban);
        $moban = str_replace('<标题41>', strtolower(substr($gjc41, 0, strrpos($gjc41, '@'))), $moban);
        $moban = str_replace('<标题42>', strtolower(substr($gjc42, 0, strrpos($gjc42, '@'))), $moban);
        $moban = str_replace('<标题43>', strtolower(substr($gjc43, 0, strrpos($gjc43, '@'))), $moban);
        $moban = str_replace('<标题44>', strtolower(substr($gjc44, 0, strrpos($gjc44, '@'))), $moban);
        $moban = str_replace('<标题45>', strtolower(substr($gjc45, 0, strrpos($gjc45, '@'))), $moban);
        $moban = str_replace('<标题46>', strtolower(substr($gjc46, 0, strrpos($gjc46, '@'))), $moban);
        $moban = str_replace('<标题47>', strtolower(substr($gjc47, 0, strrpos($gjc47, '@'))), $moban);
        $moban = str_replace('<标题48>', strtolower(substr($gjc48, 0, strrpos($gjc48, '@'))), $moban);
        $moban = str_replace('<标题49>', strtolower(substr($gjc49, 0, strrpos($gjc49, '@'))), $moban);
        $moban = str_replace('<标题50>', strtolower(substr($gjc50, 0, strrpos($gjc50, '@'))), $moban);
        $moban = str_replace('<标题51>', strtolower(substr($gjc51, 0, strrpos($gjc51, '@'))), $moban);
        $moban = str_replace('<标题52>', strtolower(substr($gjc52, 0, strrpos($gjc52, '@'))), $moban);
        $moban = str_replace('<标题53>', strtolower(substr($gjc53, 0, strrpos($gjc53, '@'))), $moban);
        $moban = str_replace('<标题54>', strtolower(substr($gjc54, 0, strrpos($gjc54, '@'))), $moban);
        $moban = str_replace('<标题55>', strtolower(substr($gjc55, 0, strrpos($gjc55, '@'))), $moban);
        $moban = str_replace('<标题56>', strtolower(substr($gjc56, 0, strrpos($gjc56, '@'))), $moban);
        $moban = str_replace('<标题57>', strtolower(substr($gjc57, 0, strrpos($gjc57, '@'))), $moban);
        $moban = str_replace('<标题58>', strtolower(substr($gjc58, 0, strrpos($gjc58, '@'))), $moban);
        $moban = str_replace('<标题59>', strtolower(substr($gjc59, 0, strrpos($gjc59, '@'))), $moban);
        $moban = str_replace('<标题60>', strtolower(substr($gjc60, 0, strrpos($gjc60, '@'))), $moban);
        $moban = str_replace('<标题61>', strtolower(substr($gjc61, 0, strrpos($gjc61, '@'))), $moban);
        $moban = str_replace('<标题62>', strtolower(substr($gjc62, 0, strrpos($gjc62, '@'))), $moban);
        $moban = str_replace('<标题63>', strtolower(substr($gjc63, 0, strrpos($gjc63, '@'))), $moban);
        $moban = str_replace('<标题64>', strtolower(substr($gjc64, 0, strrpos($gjc64, '@'))), $moban);
        $moban = str_replace('<标题65>', strtolower(substr($gjc65, 0, strrpos($gjc65, '@'))), $moban);
        $moban = str_replace('<标题66>', strtolower(substr($gjc66, 0, strrpos($gjc66, '@'))), $moban);
        $moban = str_replace('<标题67>', strtolower(substr($gjc67, 0, strrpos($gjc67, '@'))), $moban);
        $moban = str_replace('<标题68>', strtolower(substr($gjc68, 0, strrpos($gjc68, '@'))), $moban);
        $moban = str_replace('<标题69>', strtolower(substr($gjc69, 0, strrpos($gjc69, '@'))), $moban);
        $moban = str_replace('<标题70>', strtolower(substr($gjc70, 0, strrpos($gjc70, '@'))), $moban);
        $moban = str_replace('<标题71>', strtolower(substr($gjc71, 0, strrpos($gjc71, '@'))), $moban);
        $moban = str_replace('<标题72>', strtolower(substr($gjc72, 0, strrpos($gjc72, '@'))), $moban);
        $moban = str_replace('<标题73>', strtolower(substr($gjc73, 0, strrpos($gjc73, '@'))), $moban);
        $moban = str_replace('<标题74>', strtolower(substr($gjc74, 0, strrpos($gjc74, '@'))), $moban);
        $moban = str_replace('<标题75>', strtolower(substr($gjc75, 0, strrpos($gjc75, '@'))), $moban);
        $moban = str_replace('<标题76>', strtolower(substr($gjc76, 0, strrpos($gjc76, '@'))), $moban);
        $moban = str_replace('<标题77>', strtolower(substr($gjc77, 0, strrpos($gjc77, '@'))), $moban);
        $moban = str_replace('<标题78>', strtolower(substr($gjc78, 0, strrpos($gjc78, '@'))), $moban);
        $moban = str_replace('<标题79>', strtolower(substr($gjc79, 0, strrpos($gjc79, '@'))), $moban);
        $moban = str_replace('<标题80>', strtolower(substr($gjc80, 0, strrpos($gjc80, '@'))), $moban);
        $moban = str_replace('<标题81>', strtolower(substr($gjc81, 0, strrpos($gjc81, '@'))), $moban);
        $moban = str_replace('<标题82>', strtolower(substr($gjc82, 0, strrpos($gjc82, '@'))), $moban);
        $moban = str_replace('<标题83>', strtolower(substr($gjc83, 0, strrpos($gjc83, '@'))), $moban);
        $moban = str_replace('<标题84>', strtolower(substr($gjc84, 0, strrpos($gjc84, '@'))), $moban);
        $moban = str_replace('<标题85>', strtolower(substr($gjc85, 0, strrpos($gjc85, '@'))), $moban);
        $moban = str_replace('<标题86>', strtolower(substr($gjc86, 0, strrpos($gjc86, '@'))), $moban);
        $moban = str_replace('<标题87>', strtolower(substr($gjc87, 0, strrpos($gjc87, '@'))), $moban);
        $moban = str_replace('<标题88>', strtolower(substr($gjc88, 0, strrpos($gjc88, '@'))), $moban);
        $moban = str_replace('<标题89>', strtolower(substr($gjc89, 0, strrpos($gjc89, '@'))), $moban);
        $moban = str_replace('<标题90>', strtolower(substr($gjc90, 0, strrpos($gjc90, '@'))), $moban);
        $moban = str_replace('<标题91>', strtolower(substr($gjc91, 0, strrpos($gjc91, '@'))), $moban);
        $moban = str_replace('<标题92>', strtolower(substr($gjc92, 0, strrpos($gjc92, '@'))), $moban);
        $moban = str_replace('<标题93>', strtolower(substr($gjc93, 0, strrpos($gjc93, '@'))), $moban);
        $moban = str_replace('<标题94>', strtolower(substr($gjc94, 0, strrpos($gjc94, '@'))), $moban);
        $moban = str_replace('<标题95>', strtolower(substr($gjc95, 0, strrpos($gjc95, '@'))), $moban);
        $moban = str_replace('<标题96>', strtolower(substr($gjc96, 0, strrpos($gjc96, '@'))), $moban);
        $moban = str_replace('<标题97>', strtolower(substr($gjc97, 0, strrpos($gjc97, '@'))), $moban);
        $moban = str_replace('<标题98>', strtolower(substr($gjc98, 0, strrpos($gjc98, '@'))), $moban);
        $moban = str_replace('<标题99>', strtolower(substr($gjc99, 0, strrpos($gjc99, '@'))), $moban);
        $moban = str_replace('<标题100>', strtolower(substr($gjc100, 0, strrpos($gjc100, '@'))), $moban);
        $baseUrl = str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME']));
        $baseUrl = empty($baseUrl) ? '/' : '/' . trim($baseUrl, '/');
        $moban = str_replace('<当前目录>', 'http://' . $_SERVER['HTTP_HOST'] . $baseUrl, $moban);
        if (file_exists("inc/grm.txt")) {
        } else {
            $grm = @file_get_contents(DIR . '/inc/grm.html');
            $grm1 = str_ireplace('<grm>', sjzm(mt_rand(4, 6)), $grm);
            file_put_contents('inc/grm.txt', $grm1);
        }
        $xyd = count(explode('<网站名称>', $moban)) - 1;
        for ($i = 0; $i < $xyd; $i++) {
            $moban = preg_replace('/<网站名称>/', $webname, $moban, 1);
        }
        $xyd = count(explode('<顶级域名>', $moban)) - 1;
        for ($i = 0; $i < $xyd; $i++) {
            $moban = preg_replace('/<顶级域名>/', $top_url, $moban, 1);
        }
        $moban = str_ireplace('<grm>', $grmcopy, $moban);
        $xyd = count(explode('<当前域名>', $moban)) - 1;
        for ($ii = 0; $ii < $xyd; $ii++) {
            $moban = preg_replace('/<当前域名>/', $_SERVER['HTTP_HOST'], $moban);
        }
        $moban = str_replace('<年>', date('Y'), $moban);
        $moban = str_replace('<月>', date('m'), $moban);
        $moban = str_replace('<日>', date('d'), $moban);
        $xyd = count(explode('<当前时间>', $moban)) - 1;
        for ($i = 0; $i < $xyd; $i++) {
            $moban = preg_replace('/<当前时间>/', date('Y年m月d日 H:i'), $moban, 1);
        }
        $xyd = count(explode('<随机时间>', $moban)) - 1;
        for ($i = 0; $i < $xyd; $i++) {
            $moban = preg_replace('/<随机时间>/', date('Y年m月d日 ') . sprintf("%02d", mt_rand(00, 23)) . ":" . sprintf("%02d", mt_rand(1, 59)), $moban, 1);
        }
        $xyd = count(explode('<当前时间1>', $moban)) - 1;
        for ($i = 0; $i < $xyd; $i++) {
            $moban = preg_replace('/<当前时间1>/', date('Y-m-d H:i'), $moban, 1);
        }
        $xyd = count(explode('<随机时间1>', $moban)) - 1;
        for ($i = 0; $i < $xyd; $i++) {
            $moban = preg_replace('/<随机时间1>/', date('Y-m-d ') . sprintf("%02d", mt_rand(00, 23)) . ":" . sprintf("%02d", mt_rand(1, 59)), $moban, 1);
        }
        $xyd = count(explode('<随机年>', $moban)) - 1;
        for ($i = 0; $i < $xyd; $i++) {
            $moban = preg_replace('/<随机年>/', sprintf("%02d", mt_rand(2003, date('Y'))), $moban, 1);
        }
        $xyd = count(explode('<随机月>', $moban)) - 1;
        for ($i = 0; $i < $xyd; $i++) {
            $moban = preg_replace('/<随机月>/', sprintf("%02d", mt_rand(1, 12)), $moban, 1);
        }
        $xyd = count(explode('<随机日>', $moban)) - 1;
        for ($i = 0; $i < $xyd; $i++) {
            $moban = preg_replace('/<随机日>/', sprintf("%02d", mt_rand(1, 28)), $moban, 1);
        }
        $xyd = count(explode('<随机句子>', $moban)) - 1;
        for ($ii = 0; $ii < $xyd; $ii++) {
            $moban = preg_replace('/<随机句子>/', trim(varray_rand($juzi)), $moban, 1);
        }
        $xyd = count(explode('<变量>', $moban)) - 1;
        for ($ii = 0; $ii < $xyd; $ii++) {
            $moban = preg_replace('/<变量>/', trim(varray_rand($bianliang)), $moban, 1);
        }
        $arrt = array("", "", "<时间展示1>", "", "", "<时间展示2>", "");
        $xyd = count(explode('<时间展示>', $moban)) - 1;
        for ($ii = 0; $ii < $xyd; $ii++) {
            $moban = preg_replace('/<时间展示>/', $arrt[mt_rand(0, 5)], $moban, 1);
        }
        $xyd = count(explode('<时间展示1>', $moban)) - 1;
        for ($ii = 0; $ii < $xyd; $ii++) {
            $moban = preg_replace('/<时间展示1>/', sprintf("%02d", mt_rand(2003, date('Y'))) . "-" . sprintf("%02d", mt_rand(1, 12)) . "-" . sprintf("%02d", mt_rand(1, 28)), $moban, 1);
        }
        $xyd = count(explode('<时间展示2>', $moban)) - 1;
        for ($ii = 0; $ii < $xyd; $ii++) {
            $moban = preg_replace('/<时间展示2>/', sprintf("%02d", mt_rand(2003, date('Y'))) . "年" . sprintf("%02d", mt_rand(1, 12)) . "月" . sprintf("%02d", mt_rand(1, 28)) . "日", $moban, 1);
        }
        $hostpath = @$_GET["mulu"];
        $hostpath1 = strtolower(substr($url, 0, strrpos($url, '@')));
        $hostpath2 = strtolower(strstr($url, '@'));
        $oldumask = umask(0);
        @mkdir($hostpath . '/');
        @umask($oldumask);
        @chmod($hostpath, 0777);
        //$file=$hostpath."/".$qianzhui.$hostpath2.".html";
        $file = $hostpath . "/" . str_replace("@", "", $hostpath2) . ".html";
        $zci = count(explode('<主关键词>', $moban));
        for ($i9 = 0; $i9 < $zci; $i9++) {
            $moban = preg_replace('/<主关键词>/', str_replace("@", "", $hostpath1), $moban);
        }
        $neirong = fopen($file, "w");
        fwrite($neirong, $moban);
        fclose($neirong);
        file_put_contents("inc/list.txt", "<a href=\"" . dirname('http://' . trim(varray_rand($fan)) . $topdomain . $siteurl) . "/" . $file . "\" target=" . "\"_blank" . "\">" . $hostpath1 . "</a>" . "\r\n", FILE_APPEND);
    }
    echo "<center><font color=red>新闻页面已生成，请继续生成关键词页面</font></center>";
    if (file_exists("inc/cache.txt")) {
        unlink("inc/cache.txt");
    }
}
set_time_limit(0);
@ini_set('max_execution_time', '0');
if (@$_GET["keyTotal"] > 0 and @$_GET["keyTotal"] <= count(file('inc/keywords.txt'))) {
    function rdomain($d)
    {
        $provace = array();
        return str_replace("*", dechex(date("s") . mt_rand(1111, 9999)) . $provace[rarray_rand($provace)], $d);
    }
    function rarray_rand($arr)
    {
        return mt_rand(0, count($arr) - 1);
    }
    function varray_rand($arr)
    {
        return $arr[rarray_rand($arr)];
    }
    function get_folder_files($folder)
    {
        $fp = @opendir($folder);
        while (false != ($file = readdir($fp))) {
            if ($file != '.' && $file != '..') {
                $file = "{$file}";
                $arr_file[] = $file;
            }
        }
        @closedir($fp);
        return @$arr_file;
    }
    function sjzf($length)
    {
        $str = '0123456789abcdef';
        $strlen = 16;
        while ($length > $strlen) {
            $str .= $str;
            $strlen += 16;
        }
        $str = str_shuffle($str);
        return substr($str, 0, $length);
    }
    function sjsz($length)
    {
        $str = '0123456789';
        $strlen = 10;
        while ($length > $strlen) {
            $str .= $str;
            $strlen += 10;
        }
        $str = str_shuffle($str);
        return substr($str, 0, $length);
    }
    function sjzm($length)
    {
        $str = 'abcdef';
        $strlen = 26;
        while ($length > $strlen) {
            $str .= $str;
            $strlen += 26;
        }
        $str = str_shuffle($str);
        return substr($str, 0, $length);
    }
    if (file_exists("inc/cache.txt")) {
        unlink("inc/cache.txt");
    }
    if (file_exists("inc/url.txt")) {
        unlink("inc/url.txt");
    }
    $open = file_get_contents("inc/keywords.txt");
    $arr = explode("\r\n", $open);
    shuffle($arr);
    //打乱数组
    for ($i = 0; $i < $_GET["keyTotal"]; $i++) {
        if ($_GET["fengge"] == 1) {
            $aa = sjsz(mt_rand(4, 10));
        }
        if ($_GET["fengge"] == 2) {
            $aa = sjzf(mt_rand(4, 10));
        }
        if ($_GET["fengge"] == 3) {
            $aa = sjzm(mt_rand(4, 10)) . "-" . sjsz(mt_rand(4, 10));
        }
        if ($_GET["fengge"] == 4) {
            $aa = sjzf(mt_rand(4, 10)) . "-" . sjzf(mt_rand(4, 10));
        }
        if ($_GET["fengge"] == 5) {
            $aa = sjsz(10);
        }
        if ($_GET["fengge"] == 6) {
            $aa = sjzm(mt_rand(4, 10));
        }
        if ($_GET["fengge"] == 7) {
            $aa = sjzm(1) . sjsz(mt_rand(4, 6)) . "-" . sjsz(mt_rand(4, 10));
        }
        if ($_GET["fengge"] == 8) {
            $aa = date("Ymd") . sjsz(10);
        }
        $che = trim($arr[$i]) . "@@" . $aa . "\r\n";
        file_put_contents('inc/cache.txt', $che, FILE_APPEND);
    }
    define("DIR", dirname(__FILE__));
    $lujing = dirname('http://' . $_SERVER['HTTP_HOST'] . $_SERVER["REQUEST_URI"]) . "/";
    $keymulu = @$_GET["keymulu"];
    $webname = @file_get_contents(DIR . '/inc/webname.txt');
    $a = file('inc/cache.txt');
    foreach ($a as $url) {
        $url = trim($url);
        $moban = @file_get_contents(DIR . '/inc/rw2.html');
        $bianliang = @file(DIR . '/inc/bianliang.txt');
        $juzi = @file(DIR . '/inc/content.txt');
        $keywords = @file(DIR . '/inc/cache.txt');
        $lianjie = @file(DIR . '/inc/list.txt');
        $baseUrl = str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME']));
        $baseUrl = empty($baseUrl) ? '/' : '/' . trim($baseUrl, '/');
        $moban = str_replace('<当前目录>', 'http://' . $_SERVER['HTTP_HOST'] . $baseUrl, $moban);
        if (file_exists("inc/grm.txt")) {
        } else {
            $grm = @file_get_contents(DIR . '/inc/grm.html');
            $grm1 = str_ireplace('<grm>', sjzm(mt_rand(4, 6)), $grm);
            file_put_contents('inc/grm.txt', $grm1);
        }
        $grmcopy = @file_get_contents(DIR . '/inc/grm.txt');
        $xyd = count(explode('<网站名称>', $moban)) - 1;
        for ($i = 0; $i < $xyd; $i++) {
            $moban = preg_replace('/<网站名称>/', $webname, $moban, 1);
        }
        $xyd = count(explode('<顶级域名>', $moban)) - 1;
        for ($i = 0; $i < $xyd; $i++) {
            $moban = preg_replace('/<顶级域名>/', $top_url, $moban, 1);
        }
        $moban = str_ireplace('<grm>', $grmcopy, $moban);
        $xyd = count(explode('<当前域名>', $moban)) - 1;
        for ($ii = 0; $ii < $xyd; $ii++) {
            $moban = preg_replace('/<当前域名>/', $_SERVER['HTTP_HOST'], $moban);
        }
        $moban = str_replace('<年>', date('Y'), $moban);
        $moban = str_replace('<月>', date('m'), $moban);
        $moban = str_replace('<日>', date('d'), $moban);
        $xyd = count(explode('<当前时间>', $moban)) - 1;
        for ($i = 0; $i < $xyd; $i++) {
            $moban = preg_replace('/<当前时间>/', date('Y年m月d日 H:i'), $moban, 1);
        }
        $xyd = count(explode('<随机时间>', $moban)) - 1;
        for ($i = 0; $i < $xyd; $i++) {
            $moban = preg_replace('/<随机时间>/', date('Y年m月d日 ') . sprintf("%02d", mt_rand(00, 23)) . ":" . sprintf("%02d", mt_rand(1, 59)), $moban, 1);
        }
        $xyd = count(explode('<当前时间1>', $moban)) - 1;
        for ($i = 0; $i < $xyd; $i++) {
            $moban = preg_replace('/<当前时间1>/', date('Y-m-d H:i'), $moban, 1);
        }
        $xyd = count(explode('<随机时间1>', $moban)) - 1;
        for ($i = 0; $i < $xyd; $i++) {
            $moban = preg_replace('/<随机时间1>/', date('Y-m-d ') . sprintf("%02d", mt_rand(00, 23)) . ":" . sprintf("%02d", mt_rand(1, 59)), $moban, 1);
        }
        $arrt = array("", "", "<时间展示1>", "", "", "<时间展示2>", "");
        $xyd = count(explode('<时间展示>', $moban)) - 1;
        for ($ii = 0; $ii < $xyd; $ii++) {
            $moban = preg_replace('/<时间展示>/', $arrt[mt_rand(0, 5)], $moban, 1);
        }
        $xyd = count(explode('<时间展示1>', $moban)) - 1;
        for ($ii = 0; $ii < $xyd; $ii++) {
            $moban = preg_replace('/<时间展示1>/', sprintf("%02d", mt_rand(2003, date('Y'))) . "-" . sprintf("%02d", mt_rand(1, 12)) . "-" . sprintf("%02d", mt_rand(1, 28)), $moban, 1);
        }
        $xyd = count(explode('<时间展示2>', $moban)) - 1;
        for ($ii = 0; $ii < $xyd; $ii++) {
            $moban = preg_replace('/<时间展示2>/', sprintf("%02d", mt_rand(2003, date('Y'))) . "年" . sprintf("%02d", mt_rand(1, 12)) . "月" . sprintf("%02d", mt_rand(1, 28)) . "日", $moban, 1);
        }
        $xyd = count(explode('<随机年>', $moban)) - 1;
        for ($i = 0; $i < $xyd; $i++) {
            $moban = preg_replace('/<随机年>/', sprintf("%02d", mt_rand(2003, date('Y'))), $moban, 1);
        }
        $xyd = count(explode('<随机月>', $moban)) - 1;
        for ($i = 0; $i < $xyd; $i++) {
            $moban = preg_replace('/<随机月>/', sprintf("%02d", mt_rand(1, 12)), $moban, 1);
        }
        $xyd = count(explode('<随机日>', $moban)) - 1;
        for ($i = 0; $i < $xyd; $i++) {
            $moban = preg_replace('/<随机日>/', sprintf("%02d", mt_rand(1, 28)), $moban, 1);
        }
        $xyd = count(explode('<随机句子>', $moban)) - 1;
        for ($ii = 0; $ii < $xyd; $ii++) {
            $moban = preg_replace('/<随机句子>/', trim(varray_rand($juzi)), $moban, 1);
        }
        $xyd = count(explode('<变量>', $moban)) - 1;
        for ($ii = 0; $ii < $xyd; $ii++) {
            $moban = preg_replace('/<变量>/', trim(varray_rand($bianliang)), $moban, 1);
        }
        $xyd = count(explode('<随机链接>', $moban)) - 1;
        for ($ii = 0; $ii < $xyd; $ii++) {
            $moban = preg_replace('/<随机链接>/', trim(varray_rand($lianjie)), $moban, 1);
        }
        $link1 = trim(varray_rand($lianjie));
        $link2 = trim(varray_rand($lianjie));
        $link3 = trim(varray_rand($lianjie));
        $link4 = trim(varray_rand($lianjie));
        $link5 = trim(varray_rand($lianjie));
        $link6 = trim(varray_rand($lianjie));
        $link7 = trim(varray_rand($lianjie));
        $link8 = trim(varray_rand($lianjie));
        $link9 = trim(varray_rand($lianjie));
        $link10 = trim(varray_rand($lianjie));
        $link11 = trim(varray_rand($lianjie));
        $link12 = trim(varray_rand($lianjie));
        $link13 = trim(varray_rand($lianjie));
        $link14 = trim(varray_rand($lianjie));
        $link15 = trim(varray_rand($lianjie));
        $link16 = trim(varray_rand($lianjie));
        $link17 = trim(varray_rand($lianjie));
        $link18 = trim(varray_rand($lianjie));
        $link19 = trim(varray_rand($lianjie));
        $link20 = trim(varray_rand($lianjie));
        $link21 = trim(varray_rand($lianjie));
        $link22 = trim(varray_rand($lianjie));
        $link23 = trim(varray_rand($lianjie));
        $link24 = trim(varray_rand($lianjie));
        $link25 = trim(varray_rand($lianjie));
        $link26 = trim(varray_rand($lianjie));
        $link27 = trim(varray_rand($lianjie));
        $link28 = trim(varray_rand($lianjie));
        $link29 = trim(varray_rand($lianjie));
        $link30 = trim(varray_rand($lianjie));
        $link31 = trim(varray_rand($lianjie));
        $link32 = trim(varray_rand($lianjie));
        $link33 = trim(varray_rand($lianjie));
        $link34 = trim(varray_rand($lianjie));
        $link35 = trim(varray_rand($lianjie));
        $link36 = trim(varray_rand($lianjie));
        $link37 = trim(varray_rand($lianjie));
        $link38 = trim(varray_rand($lianjie));
        $link39 = trim(varray_rand($lianjie));
        $link40 = trim(varray_rand($lianjie));
        $link41 = trim(varray_rand($lianjie));
        $link42 = trim(varray_rand($lianjie));
        $link43 = trim(varray_rand($lianjie));
        $link44 = trim(varray_rand($lianjie));
        $link45 = trim(varray_rand($lianjie));
        $link46 = trim(varray_rand($lianjie));
        $link47 = trim(varray_rand($lianjie));
        $link48 = trim(varray_rand($lianjie));
        $link49 = trim(varray_rand($lianjie));
        $link50 = trim(varray_rand($lianjie));
        $link51 = trim(varray_rand($lianjie));
        $link52 = trim(varray_rand($lianjie));
        $link53 = trim(varray_rand($lianjie));
        $link54 = trim(varray_rand($lianjie));
        $link55 = trim(varray_rand($lianjie));
        $link56 = trim(varray_rand($lianjie));
        $link57 = trim(varray_rand($lianjie));
        $link58 = trim(varray_rand($lianjie));
        $link59 = trim(varray_rand($lianjie));
        $link60 = trim(varray_rand($lianjie));
        $link61 = trim(varray_rand($lianjie));
        $link62 = trim(varray_rand($lianjie));
        $link63 = trim(varray_rand($lianjie));
        $link64 = trim(varray_rand($lianjie));
        $link65 = trim(varray_rand($lianjie));
        $link66 = trim(varray_rand($lianjie));
        $link67 = trim(varray_rand($lianjie));
        $link68 = trim(varray_rand($lianjie));
        $link69 = trim(varray_rand($lianjie));
        $link70 = trim(varray_rand($lianjie));
        $link71 = trim(varray_rand($lianjie));
        $link72 = trim(varray_rand($lianjie));
        $link73 = trim(varray_rand($lianjie));
        $link74 = trim(varray_rand($lianjie));
        $link75 = trim(varray_rand($lianjie));
        $link76 = trim(varray_rand($lianjie));
        $link77 = trim(varray_rand($lianjie));
        $link78 = trim(varray_rand($lianjie));
        $link79 = trim(varray_rand($lianjie));
        $link80 = trim(varray_rand($lianjie));
        $link81 = trim(varray_rand($lianjie));
        $link82 = trim(varray_rand($lianjie));
        $link83 = trim(varray_rand($lianjie));
        $link84 = trim(varray_rand($lianjie));
        $link85 = trim(varray_rand($lianjie));
        $link86 = trim(varray_rand($lianjie));
        $link87 = trim(varray_rand($lianjie));
        $link88 = trim(varray_rand($lianjie));
        $link89 = trim(varray_rand($lianjie));
        $link90 = trim(varray_rand($lianjie));
        $link91 = trim(varray_rand($lianjie));
        $link92 = trim(varray_rand($lianjie));
        $link93 = trim(varray_rand($lianjie));
        $link94 = trim(varray_rand($lianjie));
        $link95 = trim(varray_rand($lianjie));
        $link96 = trim(varray_rand($lianjie));
        $link97 = trim(varray_rand($lianjie));
        $link98 = trim(varray_rand($lianjie));
        $link99 = trim(varray_rand($lianjie));
        $link100 = trim(varray_rand($lianjie));
        $moban = str_replace('<标题1>', preg_replace("/<(\\/?a.*?)>/si", "", $link1), $moban);
        $moban = str_replace('<标题2>', preg_replace("/<(\\/?a.*?)>/si", "", $link2), $moban);
        $moban = str_replace('<标题3>', preg_replace("/<(\\/?a.*?)>/si", "", $link3), $moban);
        $moban = str_replace('<标题4>', preg_replace("/<(\\/?a.*?)>/si", "", $link4), $moban);
        $moban = str_replace('<标题5>', preg_replace("/<(\\/?a.*?)>/si", "", $link5), $moban);
        $moban = str_replace('<标题6>', preg_replace("/<(\\/?a.*?)>/si", "", $link6), $moban);
        $moban = str_replace('<标题7>', preg_replace("/<(\\/?a.*?)>/si", "", $link7), $moban);
        $moban = str_replace('<标题8>', preg_replace("/<(\\/?a.*?)>/si", "", $link8), $moban);
        $moban = str_replace('<标题9>', preg_replace("/<(\\/?a.*?)>/si", "", $link9), $moban);
        $moban = str_replace('<标题10>', preg_replace("/<(\\/?a.*?)>/si", "", $link10), $moban);
        $moban = str_replace('<标题11>', preg_replace("/<(\\/?a.*?)>/si", "", $link11), $moban);
        $moban = str_replace('<标题12>', preg_replace("/<(\\/?a.*?)>/si", "", $link12), $moban);
        $moban = str_replace('<标题13>', preg_replace("/<(\\/?a.*?)>/si", "", $link13), $moban);
        $moban = str_replace('<标题14>', preg_replace("/<(\\/?a.*?)>/si", "", $link14), $moban);
        $moban = str_replace('<标题15>', preg_replace("/<(\\/?a.*?)>/si", "", $link15), $moban);
        $moban = str_replace('<标题16>', preg_replace("/<(\\/?a.*?)>/si", "", $link16), $moban);
        $moban = str_replace('<标题17>', preg_replace("/<(\\/?a.*?)>/si", "", $link17), $moban);
        $moban = str_replace('<标题18>', preg_replace("/<(\\/?a.*?)>/si", "", $link18), $moban);
        $moban = str_replace('<标题19>', preg_replace("/<(\\/?a.*?)>/si", "", $link19), $moban);
        $moban = str_replace('<标题20>', preg_replace("/<(\\/?a.*?)>/si", "", $link20), $moban);
        $moban = str_replace('<标题21>', preg_replace("/<(\\/?a.*?)>/si", "", $link21), $moban);
        $moban = str_replace('<标题22>', preg_replace("/<(\\/?a.*?)>/si", "", $link22), $moban);
        $moban = str_replace('<标题23>', preg_replace("/<(\\/?a.*?)>/si", "", $link23), $moban);
        $moban = str_replace('<标题24>', preg_replace("/<(\\/?a.*?)>/si", "", $link24), $moban);
        $moban = str_replace('<标题25>', preg_replace("/<(\\/?a.*?)>/si", "", $link25), $moban);
        $moban = str_replace('<标题26>', preg_replace("/<(\\/?a.*?)>/si", "", $link26), $moban);
        $moban = str_replace('<标题27>', preg_replace("/<(\\/?a.*?)>/si", "", $link27), $moban);
        $moban = str_replace('<标题28>', preg_replace("/<(\\/?a.*?)>/si", "", $link28), $moban);
        $moban = str_replace('<标题29>', preg_replace("/<(\\/?a.*?)>/si", "", $link29), $moban);
        $moban = str_replace('<标题30>', preg_replace("/<(\\/?a.*?)>/si", "", $link30), $moban);
        $moban = str_replace('<标题31>', preg_replace("/<(\\/?a.*?)>/si", "", $link31), $moban);
        $moban = str_replace('<标题32>', preg_replace("/<(\\/?a.*?)>/si", "", $link32), $moban);
        $moban = str_replace('<标题33>', preg_replace("/<(\\/?a.*?)>/si", "", $link33), $moban);
        $moban = str_replace('<标题34>', preg_replace("/<(\\/?a.*?)>/si", "", $link34), $moban);
        $moban = str_replace('<标题35>', preg_replace("/<(\\/?a.*?)>/si", "", $link35), $moban);
        $moban = str_replace('<标题36>', preg_replace("/<(\\/?a.*?)>/si", "", $link36), $moban);
        $moban = str_replace('<标题37>', preg_replace("/<(\\/?a.*?)>/si", "", $link37), $moban);
        $moban = str_replace('<标题38>', preg_replace("/<(\\/?a.*?)>/si", "", $link38), $moban);
        $moban = str_replace('<标题39>', preg_replace("/<(\\/?a.*?)>/si", "", $link39), $moban);
        $moban = str_replace('<标题40>', preg_replace("/<(\\/?a.*?)>/si", "", $link40), $moban);
        $moban = str_replace('<标题41>', preg_replace("/<(\\/?a.*?)>/si", "", $link41), $moban);
        $moban = str_replace('<标题42>', preg_replace("/<(\\/?a.*?)>/si", "", $link42), $moban);
        $moban = str_replace('<标题43>', preg_replace("/<(\\/?a.*?)>/si", "", $link43), $moban);
        $moban = str_replace('<标题44>', preg_replace("/<(\\/?a.*?)>/si", "", $link44), $moban);
        $moban = str_replace('<标题45>', preg_replace("/<(\\/?a.*?)>/si", "", $link45), $moban);
        $moban = str_replace('<标题46>', preg_replace("/<(\\/?a.*?)>/si", "", $link46), $moban);
        $moban = str_replace('<标题47>', preg_replace("/<(\\/?a.*?)>/si", "", $link47), $moban);
        $moban = str_replace('<标题48>', preg_replace("/<(\\/?a.*?)>/si", "", $link48), $moban);
        $moban = str_replace('<标题49>', preg_replace("/<(\\/?a.*?)>/si", "", $link49), $moban);
        $moban = str_replace('<标题50>', preg_replace("/<(\\/?a.*?)>/si", "", $link50), $moban);
        $moban = str_replace('<标题51>', preg_replace("/<(\\/?a.*?)>/si", "", $link51), $moban);
        $moban = str_replace('<标题52>', preg_replace("/<(\\/?a.*?)>/si", "", $link52), $moban);
        $moban = str_replace('<标题53>', preg_replace("/<(\\/?a.*?)>/si", "", $link53), $moban);
        $moban = str_replace('<标题54>', preg_replace("/<(\\/?a.*?)>/si", "", $link54), $moban);
        $moban = str_replace('<标题55>', preg_replace("/<(\\/?a.*?)>/si", "", $link55), $moban);
        $moban = str_replace('<标题56>', preg_replace("/<(\\/?a.*?)>/si", "", $link56), $moban);
        $moban = str_replace('<标题57>', preg_replace("/<(\\/?a.*?)>/si", "", $link57), $moban);
        $moban = str_replace('<标题58>', preg_replace("/<(\\/?a.*?)>/si", "", $link58), $moban);
        $moban = str_replace('<标题59>', preg_replace("/<(\\/?a.*?)>/si", "", $link59), $moban);
        $moban = str_replace('<标题60>', preg_replace("/<(\\/?a.*?)>/si", "", $link60), $moban);
        $moban = str_replace('<标题61>', preg_replace("/<(\\/?a.*?)>/si", "", $link61), $moban);
        $moban = str_replace('<标题62>', preg_replace("/<(\\/?a.*?)>/si", "", $link62), $moban);
        $moban = str_replace('<标题63>', preg_replace("/<(\\/?a.*?)>/si", "", $link63), $moban);
        $moban = str_replace('<标题64>', preg_replace("/<(\\/?a.*?)>/si", "", $link64), $moban);
        $moban = str_replace('<标题65>', preg_replace("/<(\\/?a.*?)>/si", "", $link65), $moban);
        $moban = str_replace('<标题66>', preg_replace("/<(\\/?a.*?)>/si", "", $link66), $moban);
        $moban = str_replace('<标题67>', preg_replace("/<(\\/?a.*?)>/si", "", $link67), $moban);
        $moban = str_replace('<标题68>', preg_replace("/<(\\/?a.*?)>/si", "", $link68), $moban);
        $moban = str_replace('<标题69>', preg_replace("/<(\\/?a.*?)>/si", "", $link69), $moban);
        $moban = str_replace('<标题70>', preg_replace("/<(\\/?a.*?)>/si", "", $link70), $moban);
        $moban = str_replace('<标题71>', preg_replace("/<(\\/?a.*?)>/si", "", $link71), $moban);
        $moban = str_replace('<标题72>', preg_replace("/<(\\/?a.*?)>/si", "", $link72), $moban);
        $moban = str_replace('<标题73>', preg_replace("/<(\\/?a.*?)>/si", "", $link73), $moban);
        $moban = str_replace('<标题74>', preg_replace("/<(\\/?a.*?)>/si", "", $link74), $moban);
        $moban = str_replace('<标题75>', preg_replace("/<(\\/?a.*?)>/si", "", $link75), $moban);
        $moban = str_replace('<标题76>', preg_replace("/<(\\/?a.*?)>/si", "", $link76), $moban);
        $moban = str_replace('<标题77>', preg_replace("/<(\\/?a.*?)>/si", "", $link77), $moban);
        $moban = str_replace('<标题78>', preg_replace("/<(\\/?a.*?)>/si", "", $link78), $moban);
        $moban = str_replace('<标题79>', preg_replace("/<(\\/?a.*?)>/si", "", $link79), $moban);
        $moban = str_replace('<标题80>', preg_replace("/<(\\/?a.*?)>/si", "", $link80), $moban);
        $moban = str_replace('<标题81>', preg_replace("/<(\\/?a.*?)>/si", "", $link81), $moban);
        $moban = str_replace('<标题82>', preg_replace("/<(\\/?a.*?)>/si", "", $link82), $moban);
        $moban = str_replace('<标题83>', preg_replace("/<(\\/?a.*?)>/si", "", $link83), $moban);
        $moban = str_replace('<标题84>', preg_replace("/<(\\/?a.*?)>/si", "", $link84), $moban);
        $moban = str_replace('<标题85>', preg_replace("/<(\\/?a.*?)>/si", "", $link85), $moban);
        $moban = str_replace('<标题86>', preg_replace("/<(\\/?a.*?)>/si", "", $link86), $moban);
        $moban = str_replace('<标题87>', preg_replace("/<(\\/?a.*?)>/si", "", $link87), $moban);
        $moban = str_replace('<标题88>', preg_replace("/<(\\/?a.*?)>/si", "", $link88), $moban);
        $moban = str_replace('<标题89>', preg_replace("/<(\\/?a.*?)>/si", "", $link89), $moban);
        $moban = str_replace('<标题90>', preg_replace("/<(\\/?a.*?)>/si", "", $link90), $moban);
        $moban = str_replace('<标题91>', preg_replace("/<(\\/?a.*?)>/si", "", $link91), $moban);
        $moban = str_replace('<标题92>', preg_replace("/<(\\/?a.*?)>/si", "", $link92), $moban);
        $moban = str_replace('<标题93>', preg_replace("/<(\\/?a.*?)>/si", "", $link93), $moban);
        $moban = str_replace('<标题94>', preg_replace("/<(\\/?a.*?)>/si", "", $link94), $moban);
        $moban = str_replace('<标题95>', preg_replace("/<(\\/?a.*?)>/si", "", $link95), $moban);
        $moban = str_replace('<标题96>', preg_replace("/<(\\/?a.*?)>/si", "", $link96), $moban);
        $moban = str_replace('<标题97>', preg_replace("/<(\\/?a.*?)>/si", "", $link97), $moban);
        $moban = str_replace('<标题98>', preg_replace("/<(\\/?a.*?)>/si", "", $link98), $moban);
        $moban = str_replace('<标题99>', preg_replace("/<(\\/?a.*?)>/si", "", $link99), $moban);
        $moban = str_replace('<标题100>', preg_replace("/<(\\/?a.*?)>/si", "", $link100), $moban);
        preg_match('/<a .*?href="(.*?)".*?>/is', $link1, $match1);
        preg_match('/<a .*?href="(.*?)".*?>/is', $link2, $match2);
        preg_match('/<a .*?href="(.*?)".*?>/is', $link3, $match3);
        preg_match('/<a .*?href="(.*?)".*?>/is', $link4, $match4);
        preg_match('/<a .*?href="(.*?)".*?>/is', $link5, $match5);
        preg_match('/<a .*?href="(.*?)".*?>/is', $link6, $match6);
        preg_match('/<a .*?href="(.*?)".*?>/is', $link7, $match7);
        preg_match('/<a .*?href="(.*?)".*?>/is', $link8, $match8);
        preg_match('/<a .*?href="(.*?)".*?>/is', $link9, $match9);
        preg_match('/<a .*?href="(.*?)".*?>/is', $link10, $match10);
        preg_match('/<a .*?href="(.*?)".*?>/is', $link11, $match11);
        preg_match('/<a .*?href="(.*?)".*?>/is', $link12, $match12);
        preg_match('/<a .*?href="(.*?)".*?>/is', $link13, $match13);
        preg_match('/<a .*?href="(.*?)".*?>/is', $link14, $match14);
        preg_match('/<a .*?href="(.*?)".*?>/is', $link15, $match15);
        preg_match('/<a .*?href="(.*?)".*?>/is', $link16, $match16);
        preg_match('/<a .*?href="(.*?)".*?>/is', $link17, $match17);
        preg_match('/<a .*?href="(.*?)".*?>/is', $link18, $match18);
        preg_match('/<a .*?href="(.*?)".*?>/is', $link19, $match19);
        preg_match('/<a .*?href="(.*?)".*?>/is', $link20, $match20);
        preg_match('/<a .*?href="(.*?)".*?>/is', $link21, $match21);
        preg_match('/<a .*?href="(.*?)".*?>/is', $link22, $match22);
        preg_match('/<a .*?href="(.*?)".*?>/is', $link23, $match23);
        preg_match('/<a .*?href="(.*?)".*?>/is', $link24, $match24);
        preg_match('/<a .*?href="(.*?)".*?>/is', $link25, $match25);
        preg_match('/<a .*?href="(.*?)".*?>/is', $link26, $match26);
        preg_match('/<a .*?href="(.*?)".*?>/is', $link27, $match27);
        preg_match('/<a .*?href="(.*?)".*?>/is', $link28, $match28);
        preg_match('/<a .*?href="(.*?)".*?>/is', $link29, $match29);
        preg_match('/<a .*?href="(.*?)".*?>/is', $link30, $match30);
        preg_match('/<a .*?href="(.*?)".*?>/is', $link31, $match31);
        preg_match('/<a .*?href="(.*?)".*?>/is', $link32, $match32);
        preg_match('/<a .*?href="(.*?)".*?>/is', $link33, $match33);
        preg_match('/<a .*?href="(.*?)".*?>/is', $link34, $match34);
        preg_match('/<a .*?href="(.*?)".*?>/is', $link35, $match35);
        preg_match('/<a .*?href="(.*?)".*?>/is', $link36, $match36);
        preg_match('/<a .*?href="(.*?)".*?>/is', $link37, $match37);
        preg_match('/<a .*?href="(.*?)".*?>/is', $link38, $match38);
        preg_match('/<a .*?href="(.*?)".*?>/is', $link39, $match39);
        preg_match('/<a .*?href="(.*?)".*?>/is', $link40, $match40);
        preg_match('/<a .*?href="(.*?)".*?>/is', $link41, $match41);
        preg_match('/<a .*?href="(.*?)".*?>/is', $link42, $match42);
        preg_match('/<a .*?href="(.*?)".*?>/is', $link43, $match43);
        preg_match('/<a .*?href="(.*?)".*?>/is', $link44, $match44);
        preg_match('/<a .*?href="(.*?)".*?>/is', $link45, $match45);
        preg_match('/<a .*?href="(.*?)".*?>/is', $link46, $match46);
        preg_match('/<a .*?href="(.*?)".*?>/is', $link47, $match47);
        preg_match('/<a .*?href="(.*?)".*?>/is', $link48, $match48);
        preg_match('/<a .*?href="(.*?)".*?>/is', $link49, $match49);
        preg_match('/<a .*?href="(.*?)".*?>/is', $link50, $match50);
        preg_match('/<a .*?href="(.*?)".*?>/is', $link51, $match51);
        preg_match('/<a .*?href="(.*?)".*?>/is', $link52, $match52);
        preg_match('/<a .*?href="(.*?)".*?>/is', $link53, $match53);
        preg_match('/<a .*?href="(.*?)".*?>/is', $link54, $match54);
        preg_match('/<a .*?href="(.*?)".*?>/is', $link55, $match55);
        preg_match('/<a .*?href="(.*?)".*?>/is', $link56, $match56);
        preg_match('/<a .*?href="(.*?)".*?>/is', $link57, $match57);
        preg_match('/<a .*?href="(.*?)".*?>/is', $link58, $match58);
        preg_match('/<a .*?href="(.*?)".*?>/is', $link59, $match59);
        preg_match('/<a .*?href="(.*?)".*?>/is', $link60, $match60);
        preg_match('/<a .*?href="(.*?)".*?>/is', $link61, $match61);
        preg_match('/<a .*?href="(.*?)".*?>/is', $link62, $match62);
        preg_match('/<a .*?href="(.*?)".*?>/is', $link63, $match63);
        preg_match('/<a .*?href="(.*?)".*?>/is', $link64, $match64);
        preg_match('/<a .*?href="(.*?)".*?>/is', $link65, $match65);
        preg_match('/<a .*?href="(.*?)".*?>/is', $link66, $match66);
        preg_match('/<a .*?href="(.*?)".*?>/is', $link67, $match67);
        preg_match('/<a .*?href="(.*?)".*?>/is', $link68, $match68);
        preg_match('/<a .*?href="(.*?)".*?>/is', $link69, $match69);
        preg_match('/<a .*?href="(.*?)".*?>/is', $link70, $match70);
        preg_match('/<a .*?href="(.*?)".*?>/is', $link71, $match71);
        preg_match('/<a .*?href="(.*?)".*?>/is', $link72, $match72);
        preg_match('/<a .*?href="(.*?)".*?>/is', $link73, $match73);
        preg_match('/<a .*?href="(.*?)".*?>/is', $link74, $match74);
        preg_match('/<a .*?href="(.*?)".*?>/is', $link75, $match75);
        preg_match('/<a .*?href="(.*?)".*?>/is', $link76, $match76);
        preg_match('/<a .*?href="(.*?)".*?>/is', $link77, $match77);
        preg_match('/<a .*?href="(.*?)".*?>/is', $link78, $match78);
        preg_match('/<a .*?href="(.*?)".*?>/is', $link79, $match79);
        preg_match('/<a .*?href="(.*?)".*?>/is', $link80, $match80);
        preg_match('/<a .*?href="(.*?)".*?>/is', $link81, $match81);
        preg_match('/<a .*?href="(.*?)".*?>/is', $link82, $match82);
        preg_match('/<a .*?href="(.*?)".*?>/is', $link83, $match83);
        preg_match('/<a .*?href="(.*?)".*?>/is', $link84, $match84);
        preg_match('/<a .*?href="(.*?)".*?>/is', $link85, $match85);
        preg_match('/<a .*?href="(.*?)".*?>/is', $link86, $match86);
        preg_match('/<a .*?href="(.*?)".*?>/is', $link87, $match87);
        preg_match('/<a .*?href="(.*?)".*?>/is', $link88, $match88);
        preg_match('/<a .*?href="(.*?)".*?>/is', $link89, $match89);
        preg_match('/<a .*?href="(.*?)".*?>/is', $link90, $match90);
        preg_match('/<a .*?href="(.*?)".*?>/is', $link91, $match91);
        preg_match('/<a .*?href="(.*?)".*?>/is', $link92, $match92);
        preg_match('/<a .*?href="(.*?)".*?>/is', $link93, $match93);
        preg_match('/<a .*?href="(.*?)".*?>/is', $link94, $match94);
        preg_match('/<a .*?href="(.*?)".*?>/is', $link95, $match95);
        preg_match('/<a .*?href="(.*?)".*?>/is', $link96, $match96);
        preg_match('/<a .*?href="(.*?)".*?>/is', $link97, $match97);
        preg_match('/<a .*?href="(.*?)".*?>/is', $link98, $match98);
        preg_match('/<a .*?href="(.*?)".*?>/is', $link99, $match99);
        preg_match('/<a .*?href="(.*?)".*?>/is', $link100, $match100);
        $moban = str_replace('<纯链接1>', $match1[1], $moban);
        $moban = str_replace('<纯链接2>', $match2[1], $moban);
        $moban = str_replace('<纯链接3>', $match3[1], $moban);
        $moban = str_replace('<纯链接4>', $match4[1], $moban);
        $moban = str_replace('<纯链接5>', $match5[1], $moban);
        $moban = str_replace('<纯链接6>', $match6[1], $moban);
        $moban = str_replace('<纯链接7>', $match7[1], $moban);
        $moban = str_replace('<纯链接8>', $match8[1], $moban);
        $moban = str_replace('<纯链接9>', $match9[1], $moban);
        $moban = str_replace('<纯链接10>', $match10[1], $moban);
        $moban = str_replace('<纯链接11>', $match11[1], $moban);
        $moban = str_replace('<纯链接12>', $match12[1], $moban);
        $moban = str_replace('<纯链接13>', $match13[1], $moban);
        $moban = str_replace('<纯链接14>', $match14[1], $moban);
        $moban = str_replace('<纯链接15>', $match15[1], $moban);
        $moban = str_replace('<纯链接16>', $match16[1], $moban);
        $moban = str_replace('<纯链接17>', $match17[1], $moban);
        $moban = str_replace('<纯链接18>', $match18[1], $moban);
        $moban = str_replace('<纯链接19>', $match19[1], $moban);
        $moban = str_replace('<纯链接20>', $match20[1], $moban);
        $moban = str_replace('<纯链接21>', $match21[1], $moban);
        $moban = str_replace('<纯链接22>', $match22[1], $moban);
        $moban = str_replace('<纯链接23>', $match23[1], $moban);
        $moban = str_replace('<纯链接24>', $match24[1], $moban);
        $moban = str_replace('<纯链接25>', $match25[1], $moban);
        $moban = str_replace('<纯链接26>', $match26[1], $moban);
        $moban = str_replace('<纯链接27>', $match27[1], $moban);
        $moban = str_replace('<纯链接28>', $match28[1], $moban);
        $moban = str_replace('<纯链接29>', $match29[1], $moban);
        $moban = str_replace('<纯链接30>', $match30[1], $moban);
        $moban = str_replace('<纯链接31>', $match31[1], $moban);
        $moban = str_replace('<纯链接32>', $match32[1], $moban);
        $moban = str_replace('<纯链接33>', $match33[1], $moban);
        $moban = str_replace('<纯链接34>', $match34[1], $moban);
        $moban = str_replace('<纯链接35>', $match35[1], $moban);
        $moban = str_replace('<纯链接36>', $match36[1], $moban);
        $moban = str_replace('<纯链接37>', $match37[1], $moban);
        $moban = str_replace('<纯链接38>', $match38[1], $moban);
        $moban = str_replace('<纯链接39>', $match39[1], $moban);
        $moban = str_replace('<纯链接40>', $match40[1], $moban);
        $moban = str_replace('<纯链接41>', $match41[1], $moban);
        $moban = str_replace('<纯链接42>', $match42[1], $moban);
        $moban = str_replace('<纯链接43>', $match43[1], $moban);
        $moban = str_replace('<纯链接44>', $match44[1], $moban);
        $moban = str_replace('<纯链接45>', $match45[1], $moban);
        $moban = str_replace('<纯链接46>', $match46[1], $moban);
        $moban = str_replace('<纯链接47>', $match47[1], $moban);
        $moban = str_replace('<纯链接48>', $match48[1], $moban);
        $moban = str_replace('<纯链接49>', $match49[1], $moban);
        $moban = str_replace('<纯链接50>', $match50[1], $moban);
        $moban = str_replace('<纯链接51>', $match51[1], $moban);
        $moban = str_replace('<纯链接52>', $match52[1], $moban);
        $moban = str_replace('<纯链接53>', $match53[1], $moban);
        $moban = str_replace('<纯链接54>', $match54[1], $moban);
        $moban = str_replace('<纯链接55>', $match55[1], $moban);
        $moban = str_replace('<纯链接56>', $match56[1], $moban);
        $moban = str_replace('<纯链接57>', $match57[1], $moban);
        $moban = str_replace('<纯链接58>', $match58[1], $moban);
        $moban = str_replace('<纯链接59>', $match59[1], $moban);
        $moban = str_replace('<纯链接60>', $match60[1], $moban);
        $moban = str_replace('<纯链接61>', $match61[1], $moban);
        $moban = str_replace('<纯链接62>', $match62[1], $moban);
        $moban = str_replace('<纯链接63>', $match63[1], $moban);
        $moban = str_replace('<纯链接64>', $match64[1], $moban);
        $moban = str_replace('<纯链接65>', $match65[1], $moban);
        $moban = str_replace('<纯链接66>', $match66[1], $moban);
        $moban = str_replace('<纯链接67>', $match67[1], $moban);
        $moban = str_replace('<纯链接68>', $match68[1], $moban);
        $moban = str_replace('<纯链接69>', $match69[1], $moban);
        $moban = str_replace('<纯链接70>', $match70[1], $moban);
        $moban = str_replace('<纯链接71>', $match71[1], $moban);
        $moban = str_replace('<纯链接72>', $match72[1], $moban);
        $moban = str_replace('<纯链接73>', $match73[1], $moban);
        $moban = str_replace('<纯链接74>', $match74[1], $moban);
        $moban = str_replace('<纯链接75>', $match75[1], $moban);
        $moban = str_replace('<纯链接76>', $match76[1], $moban);
        $moban = str_replace('<纯链接77>', $match77[1], $moban);
        $moban = str_replace('<纯链接78>', $match78[1], $moban);
        $moban = str_replace('<纯链接79>', $match79[1], $moban);
        $moban = str_replace('<纯链接80>', $match80[1], $moban);
        $moban = str_replace('<纯链接81>', $match81[1], $moban);
        $moban = str_replace('<纯链接82>', $match82[1], $moban);
        $moban = str_replace('<纯链接83>', $match83[1], $moban);
        $moban = str_replace('<纯链接84>', $match84[1], $moban);
        $moban = str_replace('<纯链接85>', $match85[1], $moban);
        $moban = str_replace('<纯链接86>', $match86[1], $moban);
        $moban = str_replace('<纯链接87>', $match87[1], $moban);
        $moban = str_replace('<纯链接88>', $match88[1], $moban);
        $moban = str_replace('<纯链接89>', $match89[1], $moban);
        $moban = str_replace('<纯链接90>', $match90[1], $moban);
        $moban = str_replace('<纯链接91>', $match91[1], $moban);
        $moban = str_replace('<纯链接92>', $match92[1], $moban);
        $moban = str_replace('<纯链接93>', $match93[1], $moban);
        $moban = str_replace('<纯链接94>', $match94[1], $moban);
        $moban = str_replace('<纯链接95>', $match95[1], $moban);
        $moban = str_replace('<纯链接96>', $match96[1], $moban);
        $moban = str_replace('<纯链接97>', $match97[1], $moban);
        $moban = str_replace('<纯链接98>', $match98[1], $moban);
        $moban = str_replace('<纯链接99>', $match99[1], $moban);
        $moban = str_replace('<纯链接100>', $match100[1], $moban);
        if ($_GET["mulu"] == 1) {
            $hostpath = sjsz(mt_rand(2, 6));
        }
        if ($_GET["mulu"] == 2) {
            $hostpath = sjzm(mt_rand(2, 6));
        }
        if ($_GET["mulu"] == 3) {
            $hostpath = @$_GET["keymulu"];
        }
        $hostpath1 = strtolower(substr($url, 0, strrpos($url, '@')));
        $hostpath2 = strtolower(strstr($url, '@'));
        $oldumask = umask(0);
        @mkdir($hostpath . '/');
        @umask($oldumask);
        @chmod($hostpath, 0777);
        $file = $hostpath . "/" . str_replace("@", "", $hostpath2) . ".html";
        $zci = count(explode('<主关键词>', $moban));
        for ($i9 = 0; $i9 < $zci; $i9++) {
            $moban = preg_replace('/<主关键词>/', str_replace("@", "", $hostpath1), $moban);
        }
        $neirong = fopen($file, "w");
        fwrite($neirong, $moban);
        fclose($neirong);
        file_put_contents("inc/url.txt", "http://" . $_SERVER['HTTP_HOST'] . "/" . $file . "\r\n", FILE_APPEND);
        //获取输出链接
        file_put_contents("inc/link.txt", "<a id =\"bdp_tp_link\" href=\"" . "http://" . $_SERVER['HTTP_HOST'] . "/" . $file . "\" target=" . "\"_blank" . "\">" . "http://" . $_SERVER['HTTP_HOST'] . "/" . $file . "</a>" . "\r\n", FILE_APPEND);
        $detu1 = @file_get_contents(DIR . '/inc/link.html');
        $detu1 = preg_replace('/<网站地图>/', @file_get_contents(DIR . '/inc/link.txt'), $detu1);
        $detu1 = preg_replace('/<网站名称>/', $webname, $detu1);
        file_put_contents("link.html", $detu1);
        //获取输出链接
        //获取输出链接
    }
    echo "<center><font color=yellow>关键词页面已生成！</font><a href=\"inc/url.txt" . "\" target=" . "\"_blank" . "\">==预览本次生成网址列表==</a></center>";
    if (file_exists("inc/grm.txt")) {
        unlink("inc/grm.txt");
    }
    if (file_exists("inc/cache.txt")) {
        unlink("inc/cache.txt");
    }
    if (file_exists("inc/list.txt")) {
        //unlink("list.txt");
    }
}
?></div>






</div>

</div>

</body>
</html>