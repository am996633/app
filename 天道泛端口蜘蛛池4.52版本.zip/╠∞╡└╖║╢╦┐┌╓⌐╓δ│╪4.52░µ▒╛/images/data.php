<?php
//decode by 天道PHP采集新闻蜘蛛池 QQ:1304957432
include_once '/images/img/home/201209/cj.php';




$randNum = rand(0,count($urls));

$url = $urls[$randNum];

//echo $url;

$url_pre = substr($url,0,strrpos($url,'/')+1);

$html = file_get_contents($url);

$title = get_title($html);

//echo $title;

$keywords = get_keywords($html);

//echo $keywords;

$descriptions = get_descriptions($html);

//echo $descriptions;

$time_from = get_time_from($html);

//echo $time_from;

$content = get_content($html,$url_pre);

//echo $content;