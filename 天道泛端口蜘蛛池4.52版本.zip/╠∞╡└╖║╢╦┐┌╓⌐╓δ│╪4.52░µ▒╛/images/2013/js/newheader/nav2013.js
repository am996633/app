// JavaScript Document Iuv 2012.9.7
// add remove class 2012.9.7 iuv: tcl(Selector,className)

// tab2013 2012.9.7 iuv: tab(Selector,Selector,ClassName,Number,Interval)
function tab2013(l,t,c,n,jg){l=$(l);t=$(t);var int;switch(n){case 0:default:l.hover(function(){qh($(this).index())},function(){t.removeClass(c);l.removeClass(c)});break;case 1:l.click(function(){qh($(this).index())});break;}if(jg){int=setInterval(jx,jg);l.mouseover(function(){clearInterval(int)}).mouseout(function(){int = setInterval(jx,jg);});t.mouseover(function(){clearInterval(int)}).mouseout(function(){int = setInterval(jx,jg);});}function jx(){var j=0;l.each(function(r){if($(this).hasClass(c)){j=r+1;if(j>l.size()-1){j=0;}}});qh(j);}function qh(i){l.removeClass(c).eq(i).addClass(c);t.removeClass(c).eq(i).addClass(c);}}
// tbc 2012.10.15 iuv: tbc(Selector,Selector,className,Number)
function tbc_weibo(bg,tc,cl,ts){bg=$(bg);tc=$(tc);bg.css({"height":function(){if($('body').height()<$(window).height()){return $(window).height();}else{return $('body').height();}}}).removeClass(cl);tc.css({"left":$(window).width()*0.5-tc.width()*0.5,"top":function(index, value) {if($(window).height()<tc.height()){return 0;}else{return $(window).height()*0.4-tc.height()*0.5 + $('html').scrollTop();}}});if(ts){tc.addClass(cl);}else{tc.removeClass(cl);}}
// gb 2012.10.15 iuv: gb(Selector,Selector,className,Number)
function gb_weibo(dj,mb,cl,ts){dj=$(dj);mb=$(mb);dj.click(function(){if(ts){mb.removeClass(cl);}else{mb.addClass(cl);}});}
function NVideo(a, b) {
    $(a).mousemove(function() {
        $(a).removeClass(b);$(this).addClass(b);}
	);
}

//搜索下拉框开始
var xl =function(id){ 
	var dom = document.getElementById(id);
	if(dom)	
		return dom;
	else 
	  return {
		style:{display:"",cursor:"",backgroundColor:""},
		innerHTML:""
	  };
} 
var flag=false; 
function shlist(){ 
	xl("selectList").style.display=xl("selectList").style.display=="block"?"none":"block"; 
} 
function changesever(ts){ 
	xl("text_selected").innerHTML=""+ts.innerHTML+""; 
	shlist(); 
} 
function setFlag(val){ 
	flag=val; 
} 
function hideList(){ 
	if(!flag)
	xl("selectList").style.display="none"; 
} 
setCss=function(p){ 
	p.style.cursor='hand'; 
	p.style.backgroundColor='#BABABA'; 
	tag_zn=1;
} 
removeCss=function(p){ 
	p.style.backgroundColor='white'; 
	tag_zn=0;
} 

//微博 新浪腾讯弹窗 tbc 2012.10.15 iuv: tbc(Selector,Selector,className,Number)
function tbc_weibo(bg, tc, cl, ts) {
    bg = $(bg);
    tc = $(tc);
    bg.css({
        "height": function() {
            if ($('body').height() < $(window).height()) {
                return $(window).height();
            } else {
                return $('body').height();
            }
        }
    }).removeClass(cl);
    tc.css({
        "left": $(window).width() * 0.5 - tc.width() * 0.5,
        "top": function(index, value) {
            if ($(window).height() < tc.height()) {
                return $('html').scrollTop();
            } else {
                return $(window).height() * 0.4 - tc.height() * 0.5 + $('html').scrollTop();
            }
        }
    });
    if (ts) {
        tc.addClass(cl);
    } else {
        tc.removeClass(cl);
    }
}


//桌面快捷方式
function toDesktop(sUrl,sName){ 
try{ 
var WshShell = new ActiveXObject("WScript.Shell"); 
var oUrlLink = WshShell.CreateShortcut(WshShell.SpecialFolders("Desktop") + "\\" + sName + ".url"); 
oUrlLink.TargetPath = sUrl; 
oUrlLink.Save(); 
}catch(e){ 
alert("当前浏览器安全级别不允许操作！"); 
} 
} 
//加入收藏
function AddFavorite(sURL, sTitle) {  
  try {  
  window.external.addFavorite(sURL, sTitle); 
  } 
  catch (e)  {  
  try {  
  window.sidebar.addPanel(sTitle, sURL, "");  
  } catch (e) {     
  alert("加入收藏失败，请使用Ctrl+D进行添加");   
  }
  }
  } 
  
 //设为首页
  function setHome(url)   
  
{   
  
if (document.all){   
  
document.body.style.behavior='url(#default#homepage)';   
  
document.body.setHomePage(url);   
  
}else if (window.sidebar){   
  
if(window.netscape){   
  
try{   
  
netscape.security.PrivilegeManager.enablePrivilege("UniversalXPConnect");   
  
}catch (e){   
  
alert( "该操作被浏览器拒绝，如果想启用该功能，请在地址栏内输入 about:config,然后将项 signed.applets.codebase_principal_support 值该为true" );   
  
}   
  
}   
  
if(window.confirm("你确定要设置"+url+"为首页吗？")==1){   
  
var prefs = Components.classes['@mozilla.org/preferences-service;1'].getService(Components.interfaces.nsIPrefBranch);   
  
prefs.setCharPref('browser.startup.homepage',url);   
  
}   
  
}   
  
}   


//登录层控制
 var tag_login=0;
 var tag_zn=0;
  document.onmousedown = function(event){
         event = event || window.event;
		 if (tag_login==0)
			xl("show_4").style.display="none";
		 if (tag_zn==0)
			xl("selectList").style.display="none";
	}  
  function onclick_show_login(){
	       xl("login_x").style.display="";
	}
	   
  function mouseover(tag){
		 if (tag == "4" ) tag_login=1;
	       xl("show_"+tag).style.display="";
	}
  function mouseout(tag){
	       if (tag != "4" )
	       xl("show_"+tag).style.display="none";
		   if (tag == "4" ) tag_login=0;
	   }
      





