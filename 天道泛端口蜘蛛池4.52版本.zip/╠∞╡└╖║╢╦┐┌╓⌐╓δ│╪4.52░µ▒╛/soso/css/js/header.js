//var WB_API = 'http://www.cmzj.net';

/**
 * 加入收藏夹
 * @param sURL
 * @param sTitle
 * @author lbf 2013-03-04
 */
function AddFavorite(sURL, sTitle) {
	try {
		window.external.addFavorite(sURL, sTitle);
    } catch (e) {
    	try {
    		window.sidebar.addPanel(sTitle, sURL, '');
        } catch (e) {
        	alert("加入收藏失败，请使用Ctrl+D进行添加！");
        }
    }
}

/**
 * 设为首页
 * @param obj
 * @param vrl
 * @author lbf 2013-03-04
 */
function setHomePage(obj, vrl) {
	try {
		obj.style.behavior = 'url(#default#homepage)';
		obj.setHomePage(vrl);
	} catch(e) {
		if (window.netscape) {
			try {
				netscape.security.PrivilegeManager.enablePrivilege("UniversalXPConnect");
			} catch (e) {
				alert("此操作被浏览器拒绝！\n请在浏览器地址栏输入“about:config”并回车\n然后将 [signed.applets.codebase_principal_support]的值设置为'true',双击即可。");
			}
			var prefs = Components.classes['@mozilla.org/preferences-service;1'].getService(Components.interfaces.nsIPrefBranch);
			prefs.setCharPref('browser.startup.homepage', vrl);
		}
	}
}

/**
 * 获取登陆状态
 * @author lbf 2013-03-04
 */
function check_login()  {
	$.ajax({
		type: 'POST',
		url: '/check_login.php',
		data: 'r=' + Math.random(),
		dataType: 'json',
		success: function(data) {
			if ($.isEmptyObject(data)||data == ''||data==null) {
				$('.dengLu').show();
				$('.dengLuH').hide();
			} else {
				$('.userNameF').text(data.username);
				$('.dengLu').hide();
				$('.dengLuH').show();
			}
		}
	});
}
//查询账户余额
function check_account(){
	$.ajax({
		type: 'POST',
		url: '/User/interface/getaccount.php',
		data: 'r=' + Math.random(),
		dataType: 'json',
		success: function(data) {
			if ($.isEmptyObject(data)) {
				$('.dengLu').show();
				$('.dengLuH').hide();
			} else {
				$('#account').text(data.actvalue);
				$('#giftaccount').text(data.giftvalue);
				$('.dengLu').hide();
				$('.dengLuH').show();
			}
		}
	});
}