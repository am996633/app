var WB_API = 'http://www.cmzj.net';


/**
 * 调用各个彩种的预测信息
 * @param lottery
 */
function lottery_yuce(lottery){
	if(lottery == 'ssq'){
		$('#lotter_name').html('双色球预测');
		var str_var = '<a href="' + WB_API + '/cunzi/article/index.php?action=lists&lottery=2&type=1&class_id=2" target="_blank">更多</a>';
		$('#lottery_link').html(str_var);
		info_yuce(2, 1, 2, 0, 10, 0);
		info_yuce(2, 1, 1, 0, 10, 0);
		info_yuce(2, 2, 0, 0, 10, 0);
	}else if(lottery == '3d'){
		$('#lotter_name').html('福彩3D预测');
		var str_var = '<a href="' + WB_API + '/cunzi/article/index.php?action=lists&lottery=1&type=1&class_id=2" target="_blank">更多</a>';
		$('#lottery_link').html(str_var);
		info_yuce(1, 1, 2, 0, 10, 0);
		info_yuce(1, 1, 1, 0, 10, 0);
		info_yuce(1, 2, 0, 0, 10, 0);
	}else if(lottery == 'p3'){
		$('#lotter_name').html('排列3预测');
		var str_var = '<a href="' + WB_API + '/cunzi/article/index.php?action=lists&lottery=3&type=1&class_id=2" target="_blank">更多</a>';
		$('#lottery_link').html(str_var);
		info_yuce(3, 1, 2, 0, 10, 0);
		info_yuce(3, 1, 1, 0, 10, 0);
		info_yuce(3, 2, 0, 0, 10, 0);
	}else if(lottery == 'dlt'){
		$('#lotter_name').html('大乐透预测');
		var str_var = '<a href="' + WB_API + '/cunzi/article/index.php?action=lists&lottery=4&type=1&class_id=2" target="_blank">更多</a>';
		$('#lottery_link').html(str_var);
		info_yuce(4, 1, 2, 0, 10, 0);
		info_yuce(4, 1, 1, 0, 10, 0);
		info_yuce(4, 2, 0, 0, 10, 0);
	}else{
		$('#lotter_name').html('双色球预测');
		var str_var = '<a href="' + WB_API + '/cunzi/article/index.php?action=lists&lottery=2&type=1&class_id=2" target="_blank">更多</a>';
		$('#lottery_link').html(str_var);
		info_yuce(2, 1, 2, 0, 10, 0);
		info_yuce(2, 1, 1, 0, 10, 0);
		info_yuce(2, 2, 0, 0, 10, 0);
	}
}

/**
 * 排行榜信息
 * @param lottery 彩种分类：3d:福彩3D；ssq:双色球；p3:排列3；
 */
function phb(lottery){
	if (lottery == 'ssq' || lottery == 'qlc' || lottery == 'qxc' || lottery == 'dlt' || lottery == 'dls') {
		$('#lotterytitle').html('双色球专家排行');
		var classtitle = '<tr><td onclick="rank(2,1,this)">金胆</td><td onclick="rank(2,2,this)" class="sep">红三胆</td>' +
						 '<td onclick="rank(2,4,this)">龙头</td><td onclick="rank(2,5,this)">凤尾</td></tr>' +
          				 '<tr><td onclick="rank(2,6,this)">红20码</td><td onclick="rank(2,7,this)">四码围蓝</td>' +
						 '<td onclick="rank(2,12,this)">胆拖</td><td onclick="rank(2,2,this)">红篮复式</td></tr>';
		$('#classtitle').empty().append(classtitle);
		expert_rank(2, 2, 1, 2, 0, 10);
		//双色球专家排行
		//本期
		expert_toprank(2, 2, 2, 1, 0, 10);
		//本周
		expert_toprank(2, 2, 2, 2, 0, 10);
		//本月
		expert_toprank(2, 2, 2, 3, 0, 10);
		//本年
		expert_toprank(2, 2, 2, 4, 0, 10);
	} else if (lottery == '3d') {
		$('#lotterytitle').html('福彩3D专家排行');
		var classtitle = '<tr><td onclick="rank(1,1,this)">独胆</td><td onclick="rank(1,2,this)" class="sep">双胆</td>' +
						 '<td onclick="rank(1,3,this)">三胆</td><td onclick="rank(1,456,this)">定位胆</td></tr>' +
          				 '<tr><td onclick="rank(1,7,this)">杀码</td><td onclick="rank(1,8,this)">和值</td>' +
						 '<td onclick="rank(1,167,this)">组选复式</td><td onclick="rank(1,18,this)">直选复式</td></tr>';
		$('#classtitle').empty().append(classtitle);
		expert_rank(1, 2, 1, 1, 0, 10);
		//福彩3D专家排行
		//本期
		expert_toprank(1, 2, 2, 1, 0, 10);
		//本周
		expert_toprank(1, 2, 2, 2, 0, 10);
		//本月
		expert_toprank(1, 2, 2, 3, 0, 10);
		//本月
		expert_toprank(1, 2, 2, 4, 0, 10);
	} else if (lottery == 'p3' || lottery == 'p5' || lottery == 'bls' || lottery == 'blw') {
		$('#lotterytitle').html('排列三专家排行');
		var classtitle = '<tr><td onclick="rank(3,1,this)">独胆</td><td onclick="rank(3,2,this)" class="sep">双胆</td>' +
		 				 '<td onclick="rank(3,3,this)">三胆</td><td onclick="rank(3,456,this)">定位胆</td></tr>' +
		 				 '<tr><td onclick="rank(3,7,this)">杀码</td><td onclick="rank(3,8,this)">和值</td>' +
		 				 '<td onclick="rank(3,167,this)">组选复式</td><td onclick="rank(3,18,this)">直选复式</td></tr>';
		$('#classtitle').empty().append(classtitle);
		expert_rank(3, 2, 1, 1, 0, 10);
		//排列三专家排行
		//本期
		expert_toprank(3, 2, 2, 1, 0, 10);
		//本周
		expert_toprank(3, 2, 2, 2, 0, 10);
		//本月
		expert_toprank(3, 2, 2, 3, 0, 10);
		//本月
		expert_toprank(3, 2, 2, 4, 0, 10);
	}
}

/**
 * 排行
 * @param lottery 彩种分类：3d:福彩3D；ssq:双色球；p3:排列3；
 * @param classid
 */
function rank(lottery,classid,obj){
	$('#classtitle td').removeClass();
	$(obj).addClass('sep');
	expert_rank(lottery, 2, 1, classid, 0, 10);
}

/**
 * 彩种预测信息
 * @param lottery 彩种分类：3d:福彩3D；ssq:双色球；p3:排列3；
 */
function article(lottery) {
	if (lottery == 'ssq' || lottery == 'qlc' || lottery == 'qxc' || lottery == 'dls') {
		expert_forecasts(2, 1, 2, 0, 8, 0);
	} else if (lottery == '3d') {
		expert_forecasts(1, 1, 2, 0, 8, 0);
	} else if (lottery == 'bls' || lottery == 'blw') {
		expert_forecasts(3, 1, 2, 0, 8, 0);
	}
}

/**
 * 短信排行
 * @param date
 */
function sms_rank(date){
	$.ajax({
		type: 'POST',
		url: '/index.php?do=ajax&ac=sms_month',
		data: 'sms_date=' + date,
		dataType: 'json',
		success: function(data) {
				var html = '';
				$.each(data,function(i,item){
					html += '<tr>' +
			            	'<td><span class="mingCi mingCi3">'+ (i+1) +'</span></td>' +
			            	'<td><a href="member/index.php?do=detail&sid='+ item.sid +'" target="_blank">'+ item.ftitle +'</a></td>' +
			            	'<td>'+ item.num +'</td>' +
			            	'<td><a href="member/index.php?do=order&sid='+ item.sid +'" target="_blank" class="Fblue">订阅</a></td></tr>';
				});
				$('#top_' + rang).empty().append(html);
			}
		});
}


/**
 * 专家排行
 * @param lottery 彩种分类：1:福彩3D；2:双色球；3:排列3；4:大乐透；5:足彩
 * @param classes 排行类型：1:普通专家；2:收费专家
 * @param stattype 统计方式：1:单项；2:汇总
 * @param classid 排行项目 汇总分类：1:当期；2:周；3:月；4:年；5:总
 * @param testmac 3D试机号：1:试机号前；2:试机号后
 * @param ranks 排行名次 默认10
 */
function expert_toprank(lottery, classes, stattype, classid, testmac, ranks) {
	$.ajax({
		type: 'POST',
		url: '/index.php?do=ajax&ac=expert_top',
		data: 'lottery=' + lottery + '&class=' + classes + '&stattype=' + stattype + '&classid=' + classid + '&testmac=' + testmac + '&ranks=' + ranks + '&r=' + Math.random(),
		dataType: 'json',
		success: function(data) {
			var info = data.info;
			var list = data.list;
			var html = '';
			var type = '';
			var rang = '';
			for (var i = 0; i < list.length; i++) {
				var item = list[i];
				var way = '';
				if (item.rank > item.rank_h) {
					way = 'sheng';
				} else if (item.rank == item.rank_h) {
					way = 'ping';
				} else if (item.rank < item.rank_h) {
					way = 'jiang';
				}
				html += '<tr'+ (i%2==0?'':' class="Snum"') +'>';
				html += '<td><span class="mingCi'+ (i<3?' mingCi3':'') +'">' + (i + 1) + '</span></td>';
				html += '<td><a href="' + WB_API + '/cunzi/article/expert.php?action=expert_info&expert_id=' + item.expertid + '" target="_blank">' + item.expertname + '</a></td>';
				html += '<td>' + item.score + '</td>';
				html += '<td><a href="' + WB_API + '/cunzi/article/index.php?action=record&expert_id=' + item.expertid + '&lottery=' + info.lottery + '" target="_blank"  class="Fblue">历史成绩</a></td>';
				html += '</tr>';
			}
			if (info.lottery == 1) {
				type = '3d';
			} else if (info.lottery == 2) {
				type = 'ssq';
			} else if (info.lottery == 3) {
				type = 'p3';
			} else if (info.lottery == 4) {
				type = 'dlt';
			} else if (info.lottery == 5) {
				type = 'zc';
			}
			if (info.classid == 1) {
				rang = 'current';
			} else if (info.classid == 2) {
				rang = 'week';
			} else if (info.classid == 3) {
				rang = 'month';
			} else if (info.classid == 4) {
				rang = 'year';
			} else if (info.classid == 5) {
				rang = 'total';
			}
			$('#top_' + rang).empty().append(html);
		}
	});
}

/**
 * 专家排行
 * @param lottery 彩种分类：1:福彩3D；2:双色球；3:排列3；4:大乐透；5:足彩
 * @param classes 排行类型：1:普通专家；2:收费专家
 * @param stattype 统计方式：1:单项；2:汇总
 * @param classid 排行项目 汇总分类：1:当期；2:周；3:月；4:年；5:总
 * @param testmac 3D试机号：1:试机号前；2:试机号后
 * @param ranks 排行名次 默认10
 */
function expert_rank(lottery, classes, stattype, classid, testmac, ranks) {
	$.ajax({
		type: 'POST',
		url: '/index.php?do=ajax&ac=expert_top',
		data: 'lottery=' + lottery + '&class=' + classes + '&stattype=' + stattype + '&classid=' + classid + '&testmac=' + testmac + '&ranks=' + ranks + '&r=' + Math.random(),
		dataType: 'json',
		success: function(data) {
			var info = data.info;
			var list = data.list;
			var html = '';
			var type = '';
			var rang = '';
			for (var i = 0; i < list.length; i++) {
				var item = list[i];
				html += '<tr'+ (i%2==0?'':' class="Snum"') +'>';
				html += '<td><span class="mingCi'+ (i<3?' mingCi3':'') +'">' + (i + 1) + '</span></td>';
				html += '<td><a href="' + WB_API + '/cunzi/article/expert.php?action=expert_info&expert_id=' + item.expertid + '" target="_blank">' + item.expertname + '</a></td>';
				html += '<td>' + item.score + '</td>';
				html += '<td><a href="' + WB_API + '/cunzi/article/index.php?action=record&expert_id=' + item.expertid + '&lottery=' + info.lottery + '" target="_blank"  class="Fblue">查看</a></td>';
				html += '</tr>';
			}
			$('#expert_rank').empty().append(html);
		}
	});
}

/**
 * 预测信息
 * @param lottery 彩种分类：1:福彩3D；2:双色球；3:排列3；4:大乐透；5:足彩
 * @param type 文章分类：1:预测文章；2:趋势分析；3:其他文章
 * @param classid 文章子分类：1:免费文章；2:收费
 * @param expertid 专家ID
 * @param nums 文章数量
 * @param testmac 试机号前后：1:前；2:后
 */ 
function expert_forecasts(lottery, type, classid, expertid, nums, testmac) {
	$
			.ajax({
				type : 'POST',
				url : '/index.php?do=ajax&ac=expert_forecast',
				data : 'lottery=' + lottery + '&type=' + type + '&classid='
						+ classid + '&expertid=' + expertid + '&nums=' + nums
						+ '&testmac=' + testmac + '&r=' + Math.random(),
				dataType : 'json',
				success : function(data) {
					var info = data.info;
					var list = data.list;
					var html = '';
					var type = '';
					var tag = '';
					if (info.lottery == 1) {
						// num = 4;
						type = '3d';
						if (info.type == 1 && info.classid == 1) {// 免费预测
							// tag = 'mf';
							tag = 'mianfei';
							for ( var i = 0; i < list.length; i++) {
								var item = list[i];
								html += '<li><span class="qianZhui" title="试机号'
										+ (item.test_mac == 1 ? '前' : '后')
										+ '预测">'
										+ (item.test_mac == 1 ? '前' : '后')
										+ '</span> <a href="' + WB_API + '/cunzi/article/index.php?action=show&bbx_id='
										+ item.bbxid + '" target="_blank">【'
										+ item.expertname + '】&nbsp;'
										+ item.title + '</a></li>';
							}
						} else if (info.type == 1 && info.classid == 2) {// 收费预测
							// tag = 'shf';
							tag = 'shoufei';
							for ( var i = 0; i < list.length; i++) {
								var item = list[i];
								html += '<tr'
										+ (i % 2 == 0 ? ' class="Snum"' : '')
										+ '>'
										+ '<td><span class="mingCi">'
										+ (i + 1)
										+ '</span></td>'
										+ '<td><a href="' + WB_API + '/cunzi/article/index.php?action=show&bbx_id='
										+ item.bbxid
										+ '" target="_blank">'
										+ item.expertname
										+ '</a></td>'
										+ '<td><a href="' + WB_API + '/cunzi/article/index.php?action=show&bbx_id='
										+ item.bbxid
										+ '" target="_blank">'
										+ item.title
										+ '</a></td>'
										+ '<td><span class="Fblue">'
										+ (item.money != 0 ? item.money + '元'
												: item.money1 + '豆')
										+ '</span></td>'
										+ '<td><a href="' + WB_API + '/cunzi/article/index.php?action=record&expert_id=' + item.expertid + '&lottery=' + info.lottery + '&classid=' + info.classid + '" target="_blank" class="Fblue">历史成绩</a></td>'
										+ '</tr>';
								// html += '<li><span class="qianZhui"
								// title="试机号' + (item.test_mac == 1 ? '前' :
								// '后') + '预测">' + (item.test_mac == 1 ? '前' :
								// '后') + '</span> <a
								// href="' + WB_API + '/cunzi/article/index.php?action=show&bbx_id='
								// + item.bbxid + '" target="_blank">【' +
								// item.expertname + '】&nbsp;' + item.title +
								// '</a><span class="jg">(' + (item.money != 0 ?
								// item.money + '元' : item.money1 + '豆') +
								// ')</span></li>';
							}
						} else if (info.type == 2) {// 趋势分析
							// tag = 'fx';
							tag = 'qushi';
							for ( var i = 0; i < list.length; i++) {
								var item = list[i];
								html += '<li>'
										+ (item.end_issue == '' ? ' '
												: '<span class="qianZhui" title="周期方案">周</span>')
										+ ' <a href="' + WB_API + '/cunzi/article/index.php?action=show&bbx_id='
										+ item.bbxid
										+ '" target="_blank">【'
										+ item.expertname
										+ '】&nbsp;'
										+ item.title
										+ '</a><span class="jg">('
										+ (item.money != 0 ? item.money + '元'
												: item.money1 + '豆')
										+ ')</span></li>';
							}
						}
					} else if (info.lottery == 2) {
						// num = 2;
						type = 'ssq';
						if (info.type == 1 && info.classid == 1) {// 免费预测
							// tag = 'mf';
							tag = 'mianfei';
							for ( var i = 0; i < list.length; i++) {
								var item = list[i];
								html += '<li>&gt; <a href="' + WB_API + '/cunzi/article/index.php?action=show&bbx_id='
										+ item.bbxid
										+ '" target="_blank">【'
										+ item.expertname
										+ '】&nbsp;'
										+ item.title + '</a></li>';
							}
						} else if (info.type == 1 && info.classid == 2) {// 收费预测
							// tag = 'shf';
							tag = 'shoufei';
							for ( var i = 0; i < list.length; i++) {
								var item = list[i];
								html += '<tr'
										+ (i % 2 == 0 ? ' class="Snum"' : '')
										+ '>'
										+ '<td><span class="mingCi">'
										+ (i + 1)
										+ '</span></td>'
										+ '<td><a href="' + WB_API + '/cunzi/article/index.php?action=show&bbx_id='
										+ item.bbxid
										+ '" target="_blank">'
										+ item.expertname
										+ '</a></td>'
										+ '<td><a href="' + WB_API + '/cunzi/article/index.php?action=show&bbx_id='
										+ item.bbxid
										+ '" target="_blank">'
										+ item.title
										+ '</a></td>'
										+ '<td><span class="Fblue">'
										+ (item.money != 0 ? item.money + '元'
												: item.money1 + '豆')
										+ '</span></td>'
										+ '<td><a href="' + WB_API + '/cunzi/article/index.php?action=record&expert_id=' + item.expertid + '&lottery=' + info.lottery + '&classid=' + info.classid + '" target="_blank" class="Fblue">历史成绩</a></td>'
										+ '</tr>';
								// html += '<li>&gt; <a
								// href="' + WB_API + '/cunzi/article/index.php?action=show&bbx_id='
								// + item.bbxid + '" target="_blank">【' +
								// item.expertname + '】&nbsp;' + item.title +
								// '</a><span class="jg">(' + (item.money != 0 ?
								// item.money + '元' : item.money1 + '豆') +
								// ')</span></li>';
							}
						} else if (info.type == 2) {// 趋势分析
							// tag = 'fx';
							tag = 'qushi';
							for ( var i = 0; i < list.length; i++) {
								var item = list[i];
								html += '<li>'
										+ (item.end_issue == '' ? ' '
												: '<span class="qianZhui" title="周期方案">周</span>')
										+ ' <a href="' + WB_API + '/cunzi/article/index.php?action=show&bbx_id='
										+ item.bbxid
										+ '" target="_blank">【'
										+ item.expertname
										+ '】&nbsp;'
										+ item.title
										+ '</a><span class="jg">('
										+ (item.money != 0 ? item.money + '元'
												: item.money1 + '豆')
										+ ')</span></li>';
							}
						}
					} else if (info.lottery == 3) {
						// num = 6;
						type = 'p3';
						if (info.type == 1 && info.classid == 1) {// 免费预测
							// tag = 'mf';
							tag = 'mianfei';
							for ( var i = 0; i < list.length; i++) {
								var item = list[i];
								html += '<li>&gt; <a href="' + WB_API + '/cunzi/article/index.php?action=show&bbx_id='
										+ item.bbxid
										+ '" target="_blank">【'
										+ item.expertname
										+ '】&nbsp;'
										+ item.title + '</a></li>';
							}
						} else if (info.type == 1 && info.classid == 2) {// 收费预测
							// tag = 'shf';
							tag = 'shoufei';
							for ( var i = 0; i < list.length; i++) {
								var item = list[i];
								html += '<tr'
										+ (i % 2 == 0 ? ' class="Snum"' : '')
										+ '>'
										+ '<td><span class="mingCi">'
										+ (i + 1)
										+ '</span></td>'
										+ '<td><a href="' + WB_API + '/cunzi/article/index.php?action=show&bbx_id='
										+ item.bbxid
										+ '" target="_blank">'
										+ item.expertname
										+ '</a></td>'
										+ '<td><a href="' + WB_API + '/cunzi/article/index.php?action=show&bbx_id='
										+ item.bbxid
										+ '" target="_blank">'
										+ item.title
										+ '</a></td>'
										+ '<td><span class="Fblue">'
										+ (item.money != 0 ? item.money + '元'
												: item.money1 + '豆')
										+ '</span></td>'
										+ '<td><a href="' + WB_API + '/cunzi/article/index.php?action=record&expert_id=' + item.expertid + '&lottery=' + info.lottery + '&classid=' + info.classid + '" target="_blank" class="Fblue">历史成绩</a></td>'
										+ '</tr>';
								// html += '<li>&gt; <a
								// href="' + WB_API + '/cunzi/article/index.php?action=show&bbx_id='
								// + item.bbxid + '" target="_blank">【' +
								// item.expertname + '】&nbsp;' + item.title +
								// '</a><span class="jg">(' + (item.money != 0 ?
								// item.money + '元' : item.money1 + '豆') +
								// ')</span></li>';
							}
						} else if (info.type == 2) {// 趋势分析
							// tag = 'fx';
							tag = 'qushi';
							for ( var i = 0; i < list.length; i++) {
								var item = list[i];
								html += '<li>'
										+ (item.end_issue == '' ? ' '
												: '<span class="qianZhui" title="周期方案">周</span>')
										+ ' <a href="' + WB_API + '/cunzi/article/index.php?action=show&bbx_id='
										+ item.bbxid
										+ '" target="_blank">【'
										+ item.expertname
										+ '】&nbsp;'
										+ item.title
										+ '</a><span class="jg">('
										+ (item.money != 0 ? item.money + '元'
												: item.money1 + '豆')
										+ ')</span></li>';
							}
						}
					} else if (info.lottery == 4) {
						// num = 8;
						type = 'dlt';
						if (info.type == 1 && info.classid == 1) {// 免费预测
							// tag = 'mf';
							tag = 'mianfei';
							for ( var i = 0; i < list.length; i++) {
								var item = list[i];
								html += '<li><span class="qianZhui">大</span> <a href="' + WB_API + '/cunzi/article/index.php?action=show&bbx_id='
										+ item.bbxid
										+ '" target="_blank">【'
										+ item.expertname
										+ '】&nbsp;'
										+ item.title + '</a></li>';
							}
						} else if (info.type == 1 && info.classid == 2) {// 收费预测
							// tag = 'shf';
							tag = 'shoufei';
							for ( var i = 0; i < list.length; i++) {
								var item = list[i];
								html += '<tr'
										+ (i % 2 == 0 ? ' class="Snum"' : '')
										+ '>'
										+ '<td><span class="mingCi">'
										+ (i + 1)
										+ '</span></td>'
										+ '<td><a href="' + WB_API + '/cunzi/article/index.php?action=show&bbx_id='
										+ item.bbxid
										+ '" target="_blank">'
										+ item.expertname
										+ '</a></td>'
										+ '<td><a href="' + WB_API + '/cunzi/article/index.php?action=show&bbx_id='
										+ item.bbxid
										+ '" target="_blank">'
										+ item.title
										+ '</a></td>'
										+ '<td><span class="Fblue">'
										+ (item.money != 0 ? item.money + '元'
												: item.money1 + '豆')
										+ '</span></td>'
										+ '<td><a href="' + WB_API + '/cunzi/article/index.php?action=record&expert_id=' + item.expertid + '&lottery=' + info.lottery + '&classid=' + info.classid + '" target="_blank" class="Fblue">历史成绩</a></td>'
										+ '</tr>';
								// html += '<li><span class="qianZhui">大</span>
								// <a
								// href="' + WB_API + '/cunzi/article/index.php?action=show&bbx_id='
								// + item.bbxid + '" target="_blank">【' +
								// item.expertname + '】&nbsp;' + item.title +
								// '</a><span class="jg">(' + (item.money != 0 ?
								// item.money + '元' : item.money1 + '豆') +
								// ')</span></li>';
							}
						}
					} else if (info.lottery == 5) {
						// num = 10;
						type = 'zc';
						if (info.type == 1 && info.classid == 1) {// 免费预测
							// tag = 'mf';
							tag = 'mianfei';
							for ( var i = 0; i < list.length; i++) {
								var item = list[i];
								html += '<li><span class="qianZhui">足</span> <a href="' + WB_API + '/cunzi/article/index.php?action=show&bbx_id='
										+ item.bbxid
										+ '" target="_blank">【'
										+ item.expertname
										+ '】&nbsp;'
										+ item.title + '</a></li>';
							}
						} else if (info.type == 1 && info.classid == 2) {// 收费预测
							// tag = 'shf';
							tag = 'shoufei';
							for ( var i = 0; i < list.length; i++) {
								var item = list[i];
								html += '<tr'
										+ (i % 2 == 0 ? ' class="Snum"' : '')
										+ '>'
										+ '<td><span class="mingCi">'
										+ (i + 1)
										+ '</span></td>'
										+ '<td><a href="' + WB_API + '/cunzi/article/index.php?action=show&bbx_id='
										+ item.bbxid
										+ '" target="_blank">'
										+ item.expertname
										+ '</a></td>'
										+ '<td><a href="' + WB_API + '/cunzi/article/index.php?action=show&bbx_id='
										+ item.bbxid
										+ '" target="_blank">'
										+ item.title
										+ '</a></td>'
										+ '<td><span class="Fblue">'
										+ (item.money != 0 ? item.money + '元'
												: item.money1 + '豆')
										+ '</span></td>'
										+ '<td><a href="' + WB_API + '/cunzi/article/index.php?action=record&expert_id=' + item.expertid + '&lottery=' + info.lottery + '&classid=' + info.classid + '" target="_blank" class="Fblue">历史成绩</a></td>'
										+ '</tr>';
								// html += '<li><span class="qianZhui">足</span>
								// <a
								// href="' + WB_API + '/cunzi/article/index.php?action=show&bbx_id='
								// + item.bbxid + '" target="_blank">【' +
								// item.expertname + '】&nbsp;' + item.title +
								// '</a><span class="jg">(' + (item.money != 0 ?
								// item.money + '元' : item.money1 + '豆') +
								// ')</span></li>';
							}
						}
					}
					// $('.tbox' + num + ' .' + tag + '
					// ul').empty().append(html);
					html = '<tr><th>序号</th><th>作者</th><th>标题</th><th>收费</th><th>查看</th></tr>'
							+ html;
					$('#datetj').empty().append(html);
				}
			});
}


/**
 * 开奖详情页预测信息
 * @param lottery 彩种分类：1:福彩3D；2:双色球；3:排列3；4:大乐透；5:足彩
 * @param type 文章分类：1:预测文章；2:趋势分析；3:其他文章
 * @param classid 文章子分类：1:免费文章；2:收费
 * @param expertid 专家ID
 * @param nums 文章数量
 * @param testmac 试机号前后：1:前；2:后
 */ 
function info_yuce(lottery, type, classid, expertid, nums, testmac) {
	$
			.ajax({
				type : 'POST',
				url : '/index.php?do=ajax&ac=expert_forecast',
				data : 'lottery=' + lottery + '&type=' + type + '&classid='
						+ classid + '&expertid=' + expertid + '&nums=' + nums
						+ '&testmac=' + testmac + '&cut=30&r=' + Math.random(),
				dataType : 'json',
				success : function(data) {
					var info = data.info;
					var list = data.list;
					var html = '';
					var type = '';
					var tag = '';
					if (info.lottery == 1) {
						// num = 4;
						type = '3d';
						if (info.type == 1 && info.classid == 1) {// 免费预测
							// tag = 'mf';
							tag = 'mianfei';
							for ( var i = 0; i < list.length; i++) {
								var item = list[i];
								html += '<tr'
										+ (i % 2 == 0 ? ' class="Snum"' : '')
										+ '>'
										+ '<td><span class="mingCi">'
										+ (i + 1)
										+ '</span></td>'
										+ '<td><a href="' + WB_API + '/cunzi/article/index.php?action=show&bbx_id='
										+ item.bbxid
										+ '" target="_blank">'
										+ item.expertname
										+ '</a></td>'
										+ '<td style="text-align:left"><a href="' + WB_API + '/cunzi/article/index.php?action=show&bbx_id='
										+ item.bbxid
										+ '" target="_blank">'
										+ item.title
										+ '</a></td>'
										+ '<td><span class="Fblue">'
										+ (item.money != 0 ? item.money + '元'
												: item.money1 + '豆')
										+ '</span></td>'
										+ '<td><a href="' + WB_API + '/cunzi/article/index.php?action=record&expert_id=' + item.expertid + '&lottery=' + info.lottery + '&classid=' + info.classid + '" target="_blank" class="Fblue">历史成绩</a></td>'
										+ '</tr>';
							}
						} else if (info.type == 1 && info.classid == 2) {// 收费预测
							// tag = 'shf';
							tag = 'shoufei';
							for ( var i = 0; i < list.length; i++) {
								var item = list[i];
								html += '<tr'
										+ (i % 2 == 0 ? ' class="Snum"' : '')
										+ '>'
										+ '<td><span class="mingCi">'
										+ (i + 1)
										+ '</span></td>'
										+ '<td><a href="' + WB_API + '/cunzi/article/index.php?action=show&bbx_id='
										+ item.bbxid
										+ '" target="_blank">'
										+ item.expertname
										+ '</a></td>'
										+ '<td style="text-align:left"><a href="' + WB_API + '/cunzi/article/index.php?action=show&bbx_id='
										+ item.bbxid
										+ '" target="_blank">'
										+ item.title
										+ '</a></td>'
										+ '<td><span class="Fblue">'
										+ (item.money != 0 ? item.money + '元'
												: item.money1 + '豆')
										+ '</span></td>'
										+ '<td><a href="' + WB_API + '/cunzi/article/index.php?action=record&expert_id=' + item.expertid + '&lottery=' + info.lottery + '&classid=' + info.classid + '" target="_blank" class="Fblue">历史成绩</a></td>'
										+ '</tr>';
								// html += '<li><span class="qianZhui"
								// title="试机号' + (item.test_mac == 1 ? '前' :
								// '后') + '预测">' + (item.test_mac == 1 ? '前' :
								// '后') + '</span> <a
								// href="' + WB_API + '/cunzi/article/index.php?action=show&bbx_id='
								// + item.bbxid + '" target="_blank">【' +
								// item.expertname + '】&nbsp;' + item.title +
								// '</a><span class="jg">(' + (item.money != 0 ?
								// item.money + '元' : item.money1 + '豆') +
								// ')</span></li>';
							}
						} else if (info.type == 2) {// 趋势分析
							// tag = 'fx';
							tag = 'qushi';
							for ( var i = 0; i < list.length; i++) {
								var item = list[i];
								html += '<tr'
										+ (i % 2 == 0 ? ' class="Snum"' : '')
										+ '>'
										+ '<td><span class="mingCi">'
										+ (i + 1)
										+ '</span></td>'
										+ '<td><a href="' + WB_API + '/cunzi/article/index.php?action=show&bbx_id='
										+ item.bbxid
										+ '" target="_blank">'
										+ item.expertname
										+ '</a></td>'
										+ '<td style="text-align:left"><a href="' + WB_API + '/cunzi/article/index.php?action=show&bbx_id='
										+ item.bbxid
										+ '" target="_blank">'
										+ item.title
										+ '</a></td>'
										+ '<td><span class="Fblue">'
										+ (item.money != 0 ? item.money + '元'
												: item.money1 + '豆')
										+ '</span></td>'
										+ '<td><a href="' + WB_API + '/cunzi/article/index.php?action=record&expert_id=' + item.expertid + '&lottery=' + info.lottery + '" target="_blank" class="Fblue">历史成绩</a></td>'
										+ '</tr>';
							}
						}
					} else if (info.lottery == 2) {
						// num = 2;
						type = 'ssq';
						if (info.type == 1 && info.classid == 1) {// 免费预测
							// tag = 'mf';
							tag = 'mianfei';
							for ( var i = 0; i < list.length; i++) {
								var item = list[i];
								html += '<tr'
										+ (i % 2 == 0 ? ' class="Snum"' : '')
										+ '>'
										+ '<td><span class="mingCi">'
										+ (i + 1)
										+ '</span></td>'
										+ '<td><a href="' + WB_API + '/cunzi/article/index.php?action=show&bbx_id='
										+ item.bbxid
										+ '" target="_blank">'
										+ item.expertname
										+ '</a></td>'
										+ '<td style="text-align:left"><a href="' + WB_API + '/cunzi/article/index.php?action=show&bbx_id='
										+ item.bbxid
										+ '" target="_blank">'
										+ item.title
										+ '</a></td>'
										+ '<td><span class="Fblue">'
										+ (item.money != 0 ? item.money + '元'
												: item.money1 + '豆')
										+ '</span></td>'
										+ '<td><a href="' + WB_API + '/cunzi/article/index.php?action=record&expert_id=' + item.expertid + '&lottery=' + info.lottery + '&classid=' + info.classid + '" target="_blank" class="Fblue">历史成绩</a></td>'
										+ '</tr>';
							}
						} else if (info.type == 1 && info.classid == 2) {// 收费预测
							// tag = 'shf';
							tag = 'shoufei';
							for ( var i = 0; i < list.length; i++) {
								var item = list[i];
								html += '<tr'
										+ (i % 2 == 0 ? ' class="Snum"' : '')
										+ '>'
										+ '<td><span class="mingCi">'
										+ (i + 1)
										+ '</span></td>'
										+ '<td><a href="' + WB_API + '/cunzi/article/index.php?action=show&bbx_id='
										+ item.bbxid
										+ '" target="_blank">'
										+ item.expertname
										+ '</a></td>'
										+ '<td style="text-align:left"><a href="' + WB_API + '/cunzi/article/index.php?action=show&bbx_id='
										+ item.bbxid
										+ '" target="_blank">'
										+ item.title
										+ '</a></td>'
										+ '<td><span class="Fblue">'
										+ (item.money != 0 ? item.money + '元'
												: item.money1 + '豆')
										+ '</span></td>'
										+ '<td><a href="' + WB_API + '/cunzi/article/index.php?action=record&expert_id=' + item.expertid + '&lottery=' + info.lottery + '&classid=' + info.classid + '" target="_blank" class="Fblue">历史成绩</a></td>'
										+ '</tr>';
								// html += '<li>&gt; <a
								// href="' + WB_API + '/cunzi/article/index.php?action=show&bbx_id='
								// + item.bbxid + '" target="_blank">【' +
								// item.expertname + '】&nbsp;' + item.title +
								// '</a><span class="jg">(' + (item.money != 0 ?
								// item.money + '元' : item.money1 + '豆') +
								// ')</span></li>';
							}
						} else if (info.type == 2) {// 趋势分析
							// tag = 'fx';
							tag = 'qushi';
							for ( var i = 0; i < list.length; i++) {
								var item = list[i];
								html += '<tr'
										+ (i % 2 == 0 ? ' class="Snum"' : '')
										+ '>'
										+ '<td><span class="mingCi">'
										+ (i + 1)
										+ '</span></td>'
										+ '<td><a href="' + WB_API + '/cunzi/article/index.php?action=show&bbx_id='
										+ item.bbxid
										+ '" target="_blank">'
										+ item.expertname
										+ '</a></td>'
										+ '<td style="text-align:left"><a href="' + WB_API + '/cunzi/article/index.php?action=show&bbx_id='
										+ item.bbxid
										+ '" target="_blank">'
										+ item.title
										+ '</a></td>'
										+ '<td><span class="Fblue">'
										+ (item.money != 0 ? item.money + '元'
												: item.money1 + '豆')
										+ '</span></td>'
										+ '<td><a href="' + WB_API + '/cunzi/article/index.php?action=record&expert_id=' + item.expertid + '&lottery=' + info.lottery + '" target="_blank" class="Fblue">历史成绩</a></td>'
										+ '</tr>';
							}
						}
					} else if (info.lottery == 3) {
						// num = 6;
						type = 'p3';
						if (info.type == 1 && info.classid == 1) {// 免费预测
							// tag = 'mf';
							tag = 'mianfei';
							for ( var i = 0; i < list.length; i++) {
								var item = list[i];
								html += '<tr'
										+ (i % 2 == 0 ? ' class="Snum"' : '')
										+ '>'
										+ '<td><span class="mingCi">'
										+ (i + 1)
										+ '</span></td>'
										+ '<td><a href="' + WB_API + '/cunzi/article/index.php?action=show&bbx_id='
										+ item.bbxid
										+ '" target="_blank">'
										+ item.expertname
										+ '</a></td>'
										+ '<td style="text-align:left"><a href="' + WB_API + '/cunzi/article/index.php?action=show&bbx_id='
										+ item.bbxid
										+ '" target="_blank">'
										+ item.title
										+ '</a></td>'
										+ '<td><span class="Fblue">'
										+ (item.money != 0 ? item.money + '元'
												: item.money1 + '豆')
										+ '</span></td>'
										+ '<td><a href="' + WB_API + '/cunzi/article/index.php?action=record&expert_id=' + item.expertid + '&lottery=' + info.lottery + '&classid=' + info.classid + '" target="_blank" class="Fblue">历史成绩</a></td>'
										+ '</tr>';
							}
						} else if (info.type == 1 && info.classid == 2) {// 收费预测
							// tag = 'shf';
							tag = 'shoufei';
							for ( var i = 0; i < list.length; i++) {
								var item = list[i];
								html += '<tr'
										+ (i % 2 == 0 ? ' class="Snum"' : '')
										+ '>'
										+ '<td><span class="mingCi">'
										+ (i + 1)
										+ '</span></td>'
										+ '<td><a href="' + WB_API + '/cunzi/article/index.php?action=show&bbx_id='
										+ item.bbxid
										+ '" target="_blank">'
										+ item.expertname
										+ '</a></td>'
										+ '<td style="text-align:left"><a href="' + WB_API + '/cunzi/article/index.php?action=show&bbx_id='
										+ item.bbxid
										+ '" target="_blank">'
										+ item.title
										+ '</a></td>'
										+ '<td><span class="Fblue">'
										+ (item.money != 0 ? item.money + '元'
												: item.money1 + '豆')
										+ '</span></td>'
										+ '<td><a href="' + WB_API + '/cunzi/article/index.php?action=record&expert_id=' + item.expertid + '&lottery=' + info.lottery + '&classid=' + info.classid + '" target="_blank" class="Fblue">历史成绩</a></td>'
										+ '</tr>';
								// html += '<li>&gt; <a
								// href="' + WB_API + '/cunzi/article/index.php?action=show&bbx_id='
								// + item.bbxid + '" target="_blank">【' +
								// item.expertname + '】&nbsp;' + item.title +
								// '</a><span class="jg">(' + (item.money != 0 ?
								// item.money + '元' : item.money1 + '豆') +
								// ')</span></li>';
							}
						} else if (info.type == 2) {// 趋势分析
							// tag = 'fx';
							tag = 'qushi';
							for ( var i = 0; i < list.length; i++) {
								var item = list[i];
								html += '<tr'
										+ (i % 2 == 0 ? ' class="Snum"' : '')
										+ '>'
										+ '<td><span class="mingCi">'
										+ (i + 1)
										+ '</span></td>'
										+ '<td><a href="' + WB_API + '/cunzi/article/index.php?action=show&bbx_id='
										+ item.bbxid
										+ '" target="_blank">'
										+ item.expertname
										+ '</a></td>'
										+ '<td style="text-align:left"><a href="' + WB_API + '/cunzi/article/index.php?action=show&bbx_id='
										+ item.bbxid
										+ '" target="_blank">'
										+ item.title
										+ '</a></td>'
										+ '<td><span class="Fblue">'
										+ (item.money != 0 ? item.money + '元'
												: item.money1 + '豆')
										+ '</span></td>'
										+ '<td><a href="' + WB_API + '/cunzi/article/index.php?action=record&expert_id=' + item.expertid + '&lottery=' + info.lottery + '" target="_blank" class="Fblue">历史成绩</a></td>'
										+ '</tr>';
							}
						}
					} else if (info.lottery == 4) {
						// num = 8;
						type = 'dlt';
						if (info.type == 1 && info.classid == 1) {// 免费预测
							// tag = 'mf';
							tag = 'mianfei';
							for ( var i = 0; i < list.length; i++) {
								var item = list[i];
								html += '<tr'
										+ (i % 2 == 0 ? ' class="Snum"' : '')
										+ '>'
										+ '<td><span class="mingCi">'
										+ (i + 1)
										+ '</span></td>'
										+ '<td><a href="' + WB_API + '/cunzi/article/index.php?action=show&bbx_id='
										+ item.bbxid
										+ '" target="_blank">'
										+ item.expertname
										+ '</a></td>'
										+ '<td style="text-align:left"><a href="' + WB_API + '/cunzi/article/index.php?action=show&bbx_id='
										+ item.bbxid
										+ '" target="_blank">'
										+ item.title
										+ '</a></td>'
										+ '<td><span class="Fblue">'
										+ (item.money != 0 ? item.money + '元'
												: item.money1 + '豆')
										+ '</span></td>'
										+ '<td><a href="' + WB_API + '/cunzi/article/index.php?action=record&expert_id=' + item.expertid + '&lottery=' + info.lottery + '&classid=' + info.classid + '" target="_blank" class="Fblue">历史成绩</a></td>'
										+ '</tr>';
							}
						} else if (info.type == 1 && info.classid == 2) {// 收费预测
							// tag = 'shf';
							tag = 'shoufei';
							for ( var i = 0; i < list.length; i++) {
								var item = list[i];
								html += '<tr'
										+ (i % 2 == 0 ? ' class="Snum"' : '')
										+ '>'
										+ '<td><span class="mingCi">'
										+ (i + 1)
										+ '</span></td>'
										+ '<td><a href="' + WB_API + '/cunzi/article/index.php?action=show&bbx_id='
										+ item.bbxid
										+ '" target="_blank">'
										+ item.expertname
										+ '</a></td>'
										+ '<td style="text-align:left"><a href="' + WB_API + '/cunzi/article/index.php?action=show&bbx_id='
										+ item.bbxid
										+ '" target="_blank">'
										+ item.title
										+ '</a></td>'
										+ '<td><span class="Fblue">'
										+ (item.money != 0 ? item.money + '元'
												: item.money1 + '豆')
										+ '</span></td>'
										+ '<td><a href="' + WB_API + '/cunzi/article/index.php?action=record&expert_id=' + item.expertid + '&lottery=' + info.lottery + '&classid=' + info.classid + '" target="_blank" class="Fblue">历史成绩</a></td>'
										+ '</tr>';
								// html += '<li><span class="qianZhui">大</span>
								// <a
								// href="' + WB_API + '/cunzi/article/index.php?action=show&bbx_id='
								// + item.bbxid + '" target="_blank">【' +
								// item.expertname + '】&nbsp;' + item.title +
								// '</a><span class="jg">(' + (item.money != 0 ?
								// item.money + '元' : item.money1 + '豆') +
								// ')</span></li>';
							}
						}
					} else if (info.lottery == 5) {
						// num = 10;
						type = 'zc';
						if (info.type == 1 && info.classid == 1) {// 免费预测
							// tag = 'mf';
							tag = 'mianfei';
							for ( var i = 0; i < list.length; i++) {
								var item = list[i];
								html += '<tr'
										+ (i % 2 == 0 ? ' class="Snum"' : '')
										+ '>'
										+ '<td><span class="mingCi">'
										+ (i + 1)
										+ '</span></td>'
										+ '<td><a href="' + WB_API + '/cunzi/article/index.php?action=show&bbx_id='
										+ item.bbxid
										+ '" target="_blank">'
										+ item.expertname
										+ '</a></td>'
										+ '<td style="text-align:left"><a href="' + WB_API + '/cunzi/article/index.php?action=show&bbx_id='
										+ item.bbxid
										+ '" target="_blank">'
										+ item.title
										+ '</a></td>'
										+ '<td><span class="Fblue">'
										+ (item.money != 0 ? item.money + '元'
												: item.money1 + '豆')
										+ '</span></td>'
										+ '<td><a href="' + WB_API + '/cunzi/article/index.php?action=record&expert_id=' + item.expertid + '&lottery=' + info.lottery + '&classid=' + info.classid + '" target="_blank" class="Fblue">历史成绩</a></td>'
										+ '</tr>';
							}
						} else if (info.type == 1 && info.classid == 2) {// 收费预测
							// tag = 'shf';
							tag = 'shoufei';
							for ( var i = 0; i < list.length; i++) {
								var item = list[i];
								html += '<tr'
										+ (i % 2 == 0 ? ' class="Snum"' : '')
										+ '>'
										+ '<td><span class="mingCi">'
										+ (i + 1)
										+ '</span></td>'
										+ '<td><a href="' + WB_API + '/cunzi/article/index.php?action=show&bbx_id='
										+ item.bbxid
										+ '" target="_blank">'
										+ item.expertname
										+ '</a></td>'
										+ '<td style="text-align:left"><a href="' + WB_API + '/cunzi/article/index.php?action=show&bbx_id='
										+ item.bbxid
										+ '" target="_blank">'
										+ item.title
										+ '</a></td>'
										+ '<td><span class="Fblue">'
										+ (item.money != 0 ? item.money + '元'
												: item.money1 + '豆')
										+ '</span></td>'
										+ '<td><a href="' + WB_API + '/cunzi/article/index.php?action=record&expert_id=' + item.expertid + '&lottery=' + info.lottery + '&classid=' + info.classid + '" target="_blank" class="Fblue">历史成绩</a></td>'
										+ '</tr>';
								// html += '<li><span class="qianZhui">足</span>
								// <a
								// href="' + WB_API + '/cunzi/article/index.php?action=show&bbx_id='
								// + item.bbxid + '" target="_blank">【' +
								// item.expertname + '】&nbsp;' + item.title +
								// '</a><span class="jg">(' + (item.money != 0 ?
								// item.money + '元' : item.money1 + '豆') +
								// ')</span></li>';
							}
						}
					}
					// $('.tbox' + num + ' .' + tag + '
					// ul').empty().append(html);
					html = '<tr><th>序号</th><th>作者</th><th>标题</th><th>收费</th><th>查看</th></tr>'
							+ html;
					$('#info_'+tag).empty().append(html);
				}
			});
}

