// JavaScript Document Iuv 2012.9.7
//��������˵�
jQuery(
function($){
	$("a").click(function(){
		$("a").removeClass("hoverIuv");
		$('dt').removeClass('hover2Iuv');
		$(this).addClass("hoverIuv");
		$(this).parent().parent().parent().prev().addClass("hover2Iuv");
		$(this).parent("dt").addClass("hover2Iuv");
	});

	$('dt').click(function(){
		if(!$(this).next('dd').html()==""){
			$(this).toggleClass("hoverIuv");
			$(this).next('dd').toggleClass("noneIuv");
		}
	});

 /*cursor:pointer;*/
$('dt').addClass(function(){if($(this).next('dd').html()==""){$(this).addClass("hover3Iuv");}});
$('dt').css({cursor:function(index, value){if(!$(this).next('dd').html()==""){return "pointer";}}});
/*$("a").attr("href",function(){if($(this).attr("href")=="#"){$(this).css({color:"#f00"});}});*/
//$(".kA").hover(function(){$(this).toggleClass("noneIuv")});
});

// add remove class 2012.9.7 iuv: tcl(Selector,className)
function tcl(a,b){$(a).hover(function(){$(a).removeClass(b);$(this).addClass(b);});}
// tab 2012.9.7 iuv: tab(Selector,Selector,ClassName,Number,Interval)
function tab(l,t,c,n,jg){l=$(l);t=$(t);var int;switch(n){case 0:default:l.hover(function(){qh($(this).index())});break;case 1:l.click(function(){qh($(this).index())});break;}if(jg){int=setInterval(jx,jg);l.mouseover(function(){clearInterval(int)}).mouseout(function(){int = setInterval(jx,jg);});t.mouseover(function(){clearInterval(int)}).mouseout(function(){int = setInterval(jx,jg);});}function jx(){var j=0;l.each(function(r){if($(this).hasClass(c)){j=r+1;if(j>l.size()-1){j=0;}}});qh(j);}function qh(i){l.removeClass(c).eq(i).addClass(c);t.removeClass(c).eq(i).addClass(c);}}
function tbc(bg,tc,cl,ts){bg=$(bg);tc=$(tc);bg.css({"height":function(){if($('body').height()<$(window).height()){return $(window).height();}else{return $('body').height();}}}).removeClass(cl);tc.css({"left":$(window).width()*0.5-tc.width()*0.5,"top":function(index, value) {if($(window).height() < tc.height()){return 0;}else{return $(window).height()*0.4-tc.height()*0.4 + $('html').scrollTop();}}});if(ts){tc.addClass(cl);}else{tc.removeClass(cl);}}
// gb 2012.10.15 iuv: gb(Selector,Selector,className,Number)
function gb(dj,mb,cl,ts){dj=$(dj);mb=$(mb);dj.click(function(){if(ts){mb.removeClass(cl);}else{mb.addClass(cl);}});}



//iframe ����Ӧ�߶�
function iFrameHeight() { 
var ifm= document.getElementById("user_iframe"); 
var subWeb = document.frames ? document.frames["user_iframe"].document : ifm.contentDocument; 
if(ifm != null && subWeb != null) { 
ifm.height = subWeb.body.scrollHeight; 
} 
} 