//复选框全选
//var IN_CP = 'http://www.cmzj.net/cunzi/';
//var M_DOMAIN = 'http://www.cmzj.net/';
var IN_CP = '/cunzi/';
var M_DOMAIN = '/';
function check_all(form){
  	for (var i=0;i<form.elements.length;i++){
		var e = form.elements[i];
		if (e.Name != "chk_all" && e.disabled==false)
		e.checked = form.chk_all.checked;
  	}
}
function forward_url(href) {
	location.href=href;
}
//删除确定框
function is_del(str,href){
	if(confirm(str)){
		forward_url(href);
	}
}
$(function() {
	var typ=$('#the_charge_type').val();
	if(typ==3){
		$('#money').hide();
		$('#max_money_tips').html($('#max_money').val()+'元');
		$('#money_tips').html('');
	}
	$('#go_page').click(function(){ //跳转到当前页面
		href = window.location.href;
		if(href.indexOf('?') >= 0) {
			href += '&page='+$('#page').val();
		} else {
			href += '?page='+$('#page').val();
		}
		forward_url(href);	   
	});  
	$('#a_edit_avatar').click(function(){
		$('#avatar').show();
		$('#a_edit_avatar').hide();
	});
	$("input[name ^= 'top']").click(function(){
		var top = 0;
		if($(this).attr('checked') == 'checked') {
			top = 1;
		}
		var postData = "action=top&id="+$(this).val()+"&top="+top;
		$.ajax({
			type:'POST',
			url:IN_CP+'admin/expert/index.php',
			data:postData,
			success:function(msg){
			}
		});	   
	});
	$('#btn_action').click(function(){
		var action = $('#action').val();
		$('#action_form').attr('action', IN_CP+'admin/expert/index.php');
		if(action == 'delete' && confirm('确定删除所选内容？')) {
			$('#action_form').submit();
		} 
		if(action != 'delete') {
			$('#action_form').submit();
		}
	});
	$('#keyword').focus(function(){
		if($(this).val() == '输入专家名' || $(this).val() == '输入关键词') {
			$(this).val('');
		}
	});
	$('.pbtabRT td').click(function(){
		$(this).parents('tr').children('td').removeClass('sep');
		$(this).parents('tr').siblings().children('td').removeClass('sep');
		$(this).addClass('sep');
		var paras = $(this).attr('id').split('_');
		var postData = "action=ajax_rank_info&lottery="+paras[1]+"&stat_type="+paras[3]+"&class_id="+paras[4]+"&class="+paras[2];
		ajax_rank_info(postData, paras[0]);
	});
	$('.mbox li').click(function(){
		$(this).siblings().removeClass('hover2');
		$(this).addClass('hover2');
		var paras = $(this).attr('id').split('_');
		var postData = "action=ajax_rank_info&lottery="+paras[1]+"&stat_type="+paras[3]+"&class_id="+paras[4]+"&class="+paras[2];
		ajax_rank_info(postData, paras[0]);
	});
	$("input[name = 'charge_type']").click(function(){
		if($(this).val() == 1 && $(this).attr('checked') == 'checked') {
			$('#money').hide();
			$('#max_money_tips').html('');
			$('#money_tips').html('');
		} else {
			$('#money').show();
			$('#money_tips').html('');
			if($(this).val() == 2) {
				if($('#the_charge_type').val() == 3 && $('#max_money1').val() > 0) {
					$('#max_money_tips').html('( '+$('#max_money1').val()+'豆'+' )');
				} else if($('#the_charge_type').val() == 2 && $('#max_money').val() > 0) {
					$('#max_money_tips').html('( '+$('#max_money').val()+'豆'+' )');
				}
			}
			if($(this).val() == 3) {
				$('#money').hide();
				$('#max_money_tips').html($('#max_money').val()+'元');
				$('#money_tips').html('');
			}
		}
	});
	$("#money").keyup(function () {
		var reg = /\D|^0/g;
		if (reg.test(this.value)) {
			alert('请您输入整数');
            this.value = "";
			return false;
        }
	});
})
function del_select(form) {
	if(confirm('确定删除所选内容？')){
		form.submit();
	}
}
function is_mobile(s){
	var reg=/^1[3|4|5|8][0-9]\d{4,8}$/;
	//var reg=/^1\d{10}$/;
	if (!reg.exec(s)) {
	 	return false;
	}
	return true;
}
function is_num(n){
	var reg=/^([0-9]*)$/;
	if (!reg.exec(n)) {
	 	return false;
	}
	return true;
}
function get_str_len(str){
	var len = 0;
	var cnstrCount = 0; 
	for(var i = 0 ; i < str.length ; i++){
	  if(str.charCodeAt(i)>255)
	   cnstrCount = cnstrCount + 1 ;
	}
	len = str.length + cnstrCount;
	return len;
}
function set_content(obj) {
	obj=obj.replace(/<\/?[^>]*>/g,''); //去除HTML tag
	obj= obj.replace(/[ | ]*\n/g,'\n'); //去除行尾空白  
	return obj;
}
function attend_expert(expertId, userId, attend) {
	var postData = "action=expert_attend&expert_id="+expertId+"&user_id="+userId+"&attend="+attend;
	$.ajax({
		type:'POST',
		url:IN_CP+'article/expert.php',
		data:postData,
		success:function(json){
			var returnInfo = eval("("+json+")");
			if(returnInfo.state == 1) {
				if($('#attend_'+expertId)) {
					if(attend == 1) {
						$('#attend_'+expertId).text(returnInfo.msg);
					}
					if(attend == 2) {
						$('#expert_'+expertId).remove();
					}
				} else {
					alert(returnInfo.msg);
				}
			} else if(returnInfo.state == 2) {
				forward_url(M_DOMAIN+'User/do.php?ac=login');
			} else {
				alert(returnInfo.msg);
			}
		}
	});
}
function user_collect(userId, lottery, sid) {
	var postData = "action=user_collect&sid="+sid+"&user_id="+userId+"&lottery="+lottery;
	$.ajax({
		type:'POST',
		url:IN_CP+'article/expert.php',
		data:postData,
		success:function(json){
			var returnInfo = eval("("+json+")");
			if(returnInfo.errorcode == '0') {
				if($('#collect_'+sid)) {
					$('#collect_'+sid).text('收藏成功');
				} else {
					alert(returnInfo.errormsg);
				}
			} else if(returnInfo.errorcode == 2) {
				forward_url(M_DOMAIN+'User/do.php?ac=login');
			} else {
				alert(returnInfo.errormsg);
			}
		}
	});
}
function ajax_rank_info(postData, tab) {
	if(postData != '') {
		$.ajax({
			type:'POST',
			url:IN_CP+'article/rank.php',
			data:postData,
			success:function(msg){
				$('#'+tab).html(msg);
			}
		});
	}
}
function AddFavorite(sURL, sTitle) {
	try {
		window.external.addFavorite(sURL, sTitle);
    } catch (e) {
    	try {
    		window.sidebar.addPanel(sTitle, sURL, '');
        } catch (e) {
        	alert("加入收藏失败，请使用Ctrl+D进行添加！");
        }
    }
}
function setHomePage(obj, vrl) {
	try {
		obj.style.behavior = 'url(#default#homepage)';
		obj.setHomePage(vrl);
	} catch(e) {
		if (window.netscape) {
			try {
				netscape.security.PrivilegeManager.enablePrivilege("UniversalXPConnect");
			} catch (e) {
				alert("此操作被浏览器拒绝！\n请在浏览器地址栏输入“about:config”并回车\n然后将 [signed.applets.codebase_principal_support]的值设置为'true',双击即可。");
			}
			var prefs = Components.classes['@mozilla.org/preferences-service;1'].getService(Components.interfaces.nsIPrefBranch);
			prefs.setCharPref('browser.startup.homepage', vrl);
		}
	}
}