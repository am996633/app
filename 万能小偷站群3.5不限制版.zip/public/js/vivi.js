var a = 'undefined,body,,cache.php,replace.php,sift.php,GET,admin.php?lsaction=c1&_t=,1,,POST,admin.php?lsaction=c4,&qq=,http://www.vxiaotou.com/vip/?type=wanneng&u=,<tr class="firstalt"><td colspan="2" align="center"><input class="bginput" type="submit" name="submit" value=" �ύ ">&nbsp;&nbsp;<input class="bginput" type="reset" name="Input" value=" ���� "></td></tr>,sub,none,block,sub,none,none,contextmenu,<div class="keybox" style="line-height:30px;display:none"><font color=red>,</font><br> ��ҳ�湦������ҵ�湦�ܣ��蹺����Ȩ�󷽿�ʹ�á�<br>�ͷ�QQ��<a href="http://wpa.qq.com/msgrd?v=3&uin=2598315599&site=qq&menu=yes" target="_blank"><font color=red>2598315599</font></a> ������<a href="http://www.vxiaotou.com" target="_blank"><font color=red>vxiaotou.com</font></a></div>,div,.keybox,vivi��ʾ��,input,disabled,disabled,textarea,disabled,disabled,.keybox input:disabled,disabled,GET,admin.php,lsaction=c2&t=,#key,POST,admin.php?lsaction=c3,code=,1,��Ȩ�벻��ȷ��,��֤ʧ�ܣ�,contextmenu,<div class="keybox" style="line-height:30px;display:none">��������Ȩ��(<a href="http://www.vxiaotou.com/plugin.php?id=vivi_accr:accr" target="_blank"><font color=red>�������������Ȩ</font></a>) <br><textarea name="key" id="key" style="height: 50px; width: 304px" onFocus="this.style.borderColor=\'#00CC00\'" onBlur="this.style.borderColor=\'#dcdcdc\'" ></textarea> <p style="text-align:right">��ҳ�湦������ҵ�湦�ܣ��蹺����Ȩʹ��&nbsp;<button type="button" onclick="checkcode();"><span class="ui-button-text">ȷ��</span></button></p>�ͷ�QQ��<a href="http://wpa.qq.com/msgrd?v=3&uin=2598315599&site=qq&menu=yes" target="_blank"><font color=red>2598315599</font></a> �ٷ���վ��<a href="http://www.vxiaotou.com" target="_blank"><font color=red>vxiaotou.com</font></a></div>,div,.keybox,��������Ȩ�����ʹ��<span style=\'font-size: 11px;color: #FF9900;\'>(vivi����С͵վȺ��)</span>,input,disabled,disabled,textarea,disabled,disabled,.keybox textarea:disabled,disabled'.split(",");
window.onerror = function() {
	return !0
};
$(function() {
	typeof $.ui == a[0] && $(a[1]).html(a[2]);
	    $("#checkvip").html('<font color="green">��Ŀǰʹ�õ��Ѿ������°汾 QQ2598315599</font>');
	    return;
	0 < $("#checkvip").length && checkupdate();
	$.ajax({
		type: a[6],
		url: a[7] + Math.random(),
		success: function(g) {
			"0" == g ? l() : $.getScript("http://www.vxiaotou.com/update.php?m=check&a=licence&type=" + systype + "&vs=" + version + "&ajax=1&code=" + vipcode)
		}
	})
});
var b = 0,
	c = [],
	d = 1,
	e = a[14];

function f() {
	null == opener || opener.closed || (opener.window.g = null, opener.openbutton.disabled = !1, opener.closebutton.disabled = !0)
}
function h(g) {
	obj = eval(a[15] + g);
	if (obj.style.display == a[16]) if (obj.style.display = a[17], b < d) c[b] = g, b++;
	else {
		eval(a[18] + c[0]).style.display = a[19];
		for (i = 0; i < c.length - 1; i++) c[i] = c[i + 1];
		c[c.length - 1] = g
	} else {
		obj.style.display = a[20];
		var k;
		for (i = 0; i < c.length; i++) c[i] == g && (k = i);
		for (i = k; i < c.length - 1; i++) c[i] = c[i + 1];
		c[c.length - 1] = null;
		b--
	}
}
function i(g) {
	$(document).bind(a[21], function() {
		return !1
	});
	g = a[22] + g + a[23];
	var k = document.createElement(a[24]);
	k.innerHTML = g;
	document.body.appendChild(k);
	$(a[25]).dialog({
		width: 330,
		height: 180,
		modal: !0,
		title: a[26],
		closeOnEscape: !1
	});
	$(a[27]).attr(a[28], a[29]);
	$(a[30]).attr(a[31], a[32]);
	$(a[33]).attr(a[34], !1);
	j()
}
function j() {
	$.ajax({
		type: a[35],
		url: a[36],
		data: a[37] + Math.random()
	})
}
function checkcode() {
	var g = $.trim($(a[38]).val());
	$.ajax({
		type: a[39],
		url: a[40],
		data: a[41] + g,
		success: function(g) {
			g == a[42] ? top.location.reload() : alert(a[43])
		},
		error: function() {
			alert(a[44])
		}
	})
}
function l() {
	$(document).bind(a[45], function() {
		return !1
	});
	var g = a[46],
		k = document.createElement(a[47]);
	k.innerHTML = g;
	document.body.appendChild(k);
	$(a[48]).dialog({
		width: 330,
		height: 220,
		modal: !0,
		title: a[49],
		closeOnEscape: !1
	});
	$(a[50]).attr(a[51], a[52]);
	$(a[53]).attr(a[54], a[55]);
	$(a[56]).attr(a[57], !1);
	j()
}
function checkupdate() {
    $("#checkvip").html('<font color="green">��Ŀǰʹ�õ��Ѿ������°汾 QQ2598315599 </font>');
    return;
	$("#checkvip").html('<img src="../public/img/load.gif" />');
	$.ajax({
		url: "http://www.vxiaotou.com/update.php?m=check&a=update&type=" + systype + "&vs=" + version + "&ajax=1&code=" + vipcode,
		dataType: "jsonp",
		success: function(g) {
			g.status ? ($("#checkvip").html(g.title), g.msg && n(g.msg)) : "0" == g.status ? $("#checkvip").html(g.title) : $("#checkvip").html("����ʧ��")
		}
	})
}
function n(g) {
	$('<div class="keybox" style="line-height:30px;">' + g + '<p style="text-align:right"><button type="button" onclick="location.href=\'update.php?t=update\'"><span class="ui-button-text">ǰ������</span></button></p></div>').dialog({
		width: 400,
		height: 250,
		modal: !0,
		title: "������ʾ",
		closeOnEscape: !0
	});
	$(".ui-dialog-titlebar-close").show();
	$(".ui-dialog-titlebar-close .ui-icon").css({
		"text-indent": 0,
		"text-align": "center",
		color: "#416B01"
	}).html("X")
}
function o() {
	$('<div class="keybox" style="line-height:30px;">��������Ȩ��(<a href="http://www.vxiaotou.com/plugin.php?id=vivi_accr:accr" target="_blank"><font color=red>�������������Ȩ</font></a>) <br><textarea name="vipkey" id="vipkey" style="height: 100px; width: 370px" onFocus="this.style.borderColor=\'#00CC00\'" onBlur="this.style.borderColor=\'#dcdcdc\'" ></textarea><p style="text-align:right">��Ȩ�󽫿������й���&nbsp;<button type="button" onclick="checkvip();"><span class="ui-button-text" id="svipbtn">ȷ��</span></button></p></div>').dialog({
		width: 400,
		height: 250,
		modal: !0,
		title: "¼����Ȩ��",
		closeOnEscape: !0
	});
	$(".ui-dialog-titlebar-close").show();
	$(".ui-dialog-titlebar-close .ui-icon").css({
		"text-indent": 0,
		"text-align": "center",
		color: "#416B01"
	}).html("X")
}
function checkvip() {
	var g = $.trim($("#vipkey").val());
	$("#svipbtn").html("������֤...");
	$.ajax({
		type: "POST",
		url: "admin.php?lsaction=c3",
		data: "code=" + g,
		success: function(g) {
			$("#svipbtn").html("ȷ��");
			1 == g ? top.location.reload() : alert("��Ȩ���������")
		}
	})
}
var submit = '<tr class="firstalt"><td colspan="2" align="center"><input class="bginput" type="submit" name="submit" value=" �ύ ">&nbsp;&nbsp;<input class="bginput" type="reset" name="Input" value=" ���� "></td></tr>';