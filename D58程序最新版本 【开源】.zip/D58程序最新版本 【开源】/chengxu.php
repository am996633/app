<?php
error_reporting(E_ERROR);
set_time_limit(0);
function setarray(){
	return array('keyfile'=>'key.txt','txtfile'=>'txt/','linkfile'=>'link.txt','picfile'=>'pic.txt','btfile'=>'bt/','blfile'=>'bl.txt','templetefile'=>'mb.txt','isopenext'=>true);
	}
define('_sj_',date("Ymd", time()));
function getKeys()
{
$digits=9;
$chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
$max = 61;
$hash = '';
for($i = 0; $i < $digits; $i++) {
$hash .= $chars[mt_rand(0, $max)];
}
return $hash;
}
function getKey($digits=6,$s=1)
{
switch($s){
case"4":
$chars = 'abcdefghijklmnopqrstuvwxyz0123456789';
$max = 37;
break;
case"3":
$chars = 'bpmfdtnlgkhjqxrzcsyw';
$max = 19;
break;
case"2":
$chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
$max = 61;
break;
case"1":
$chars = 'abcdefghijklmnopqrstuvwxyz';
$max = 25;
break;
case"0":
$chars = '0123456789';
$max = 9;
break;
}
$hash = '';
for($i = 0; $i < $digits; $i++) {
$hash .= $chars[mt_rand(0, $max)];
}
return $hash;
}
function dy_sk($str, $split_len = 1)  
{  
    if (!preg_match('/^[0-9]+$/', $split_len) || $split_len < 1)  
        return FALSE;  
    $str=mb_convert_encoding($str,'utf-8','gbk');
    $len = mb_strlen($str, 'UTF-8');  
    if ($len <= $split_len) return $str;
    preg_match_all('/.{'.$split_len.'}|[^x00]{1,'.$split_len.'}$/us', $str, $ar);  
    return mb_convert_encoding(join(" ",$ar[0]),'gbk','utf-8');  
}
function Pinyin($_String, $_Code='0')
{
$_DataKey = "a|ai|an|ang|ao|ba|bai|ban|bang|bao|bei|ben|beng|bi|bian|biao|bie|bin|bing|bo|bu|ca|cai|can|cang|cao|ce|ceng|cha".
"|chai|chan|chang|chao|che|chen|cheng|chi|chong|chou|chu|chuai|chuan|chuang|chui|chun|chuo|ci|cong|cou|cu|".
"cuan|cui|cun|cuo|da|dai|dan|dang|dao|de|deng|di|dian|diao|die|ding|diu|dong|dou|du|duan|dui|dun|duo|e|en|er".
"|fa|fan|fang|fei|fen|feng|fo|fou|fu|ga|gai|gan|gang|gao|ge|gei|gen|geng|gong|gou|gu|gua|guai|guan|guang|gui".
"|gun|guo|ha|hai|han|hang|hao|he|hei|hen|heng|hong|hou|hu|hua|huai|huan|huang|hui|hun|huo|ji|jia|jian|jiang".
"|jiao|jie|jin|jing|jiong|jiu|ju|juan|jue|jun|ka|kai|kan|kang|kao|ke|ken|keng|kong|kou|ku|kua|kuai|kuan|kuang".
"|kui|kun|kuo|la|lai|lan|lang|lao|le|lei|leng|li|lia|lian|liang|liao|lie|lin|ling|liu|long|lou|lu|lv|luan|lue".
"|lun|luo|ma|mai|man|mang|mao|me|mei|men|meng|mi|mian|miao|mie|min|ming|miu|mo|mou|mu|na|nai|nan|nang|nao|ne".
"|nei|nen|neng|ni|nian|niang|niao|nie|nin|ning|niu|nong|nu|nv|nuan|nue|nuo|o|ou|pa|pai|pan|pang|pao|pei|pen".
"|peng|pi|pian|piao|pie|pin|ping|po|pu|qi|qia|qian|qiang|qiao|qie|qin|qing|qiong|qiu|qu|quan|que|qun|ran|rang".
"|rao|re|ren|reng|ri|rong|rou|ru|ruan|rui|run|ruo|sa|sai|san|sang|sao|se|sen|seng|sha|shai|shan|shang|shao|".
"she|shen|sheng|shi|shou|shu|shua|shuai|shuan|shuang|shui|shun|shuo|si|song|sou|su|suan|sui|sun|suo|ta|tai|".
"tan|tang|tao|te|teng|ti|tian|tiao|tie|ting|tong|tou|tu|tuan|tui|tun|tuo|wa|wai|wan|wang|wei|wen|weng|wo|wu".
"|xi|xia|xian|xiang|xiao|xie|xin|xing|xiong|xiu|xu|xuan|xue|xun|ya|yan|yang|yao|ye|yi|yin|ying|yo|yong|you".
"|yu|yuan|yue|yun|za|zai|zan|zang|zao|ze|zei|zen|zeng|zha|zhai|zhan|zhang|zhao|zhe|zhen|zheng|zhi|zhong|".
"zhou|zhu|zhua|zhuai|zhuan|zhuang|zhui|zhun|zhuo|zi|zong|zou|zu|zuan|zui|zun|zuo";
$_DataValue = "-20319|-20317|-20304|-20295|-20292|-20283|-20265|-20257|-20242|-20230|-20051|-20036|-20032|-20026|-20002|-19990".
"|-19986|-19982|-19976|-19805|-19784|-19775|-19774|-19763|-19756|-19751|-19746|-19741|-19739|-19728|-19725".
"|-19715|-19540|-19531|-19525|-19515|-19500|-19484|-19479|-19467|-19289|-19288|-19281|-19275|-19270|-19263".
"|-19261|-19249|-19243|-19242|-19238|-19235|-19227|-19224|-19218|-19212|-19038|-19023|-19018|-19006|-19003".
"|-18996|-18977|-18961|-18952|-18783|-18774|-18773|-18763|-18756|-18741|-18735|-18731|-18722|-18710|-18697".
"|-18696|-18526|-18518|-18501|-18490|-18478|-18463|-18448|-18447|-18446|-18239|-18237|-18231|-18220|-18211".
"|-18201|-18184|-18183|-18181|-18012|-17997|-17988|-17970|-17964|-17961|-17950|-17947|-17931|-17928|-17922".
"|-17759|-17752|-17733|-17730|-17721|-17703|-17701|-17697|-17692|-17683|-17676|-17496|-17487|-17482|-17468".
"|-17454|-17433|-17427|-17417|-17202|-17185|-16983|-16970|-16942|-16915|-16733|-16708|-16706|-16689|-16664".
"|-16657|-16647|-16474|-16470|-16465|-16459|-16452|-16448|-16433|-16429|-16427|-16423|-16419|-16412|-16407".
"|-16403|-16401|-16393|-16220|-16216|-16212|-16205|-16202|-16187|-16180|-16171|-16169|-16158|-16155|-15959".
"|-15958|-15944|-15933|-15920|-15915|-15903|-15889|-15878|-15707|-15701|-15681|-15667|-15661|-15659|-15652".
"|-15640|-15631|-15625|-15454|-15448|-15436|-15435|-15419|-15416|-15408|-15394|-15385|-15377|-15375|-15369".
"|-15363|-15362|-15183|-15180|-15165|-15158|-15153|-15150|-15149|-15144|-15143|-15141|-15140|-15139|-15128".
"|-15121|-15119|-15117|-15110|-15109|-14941|-14937|-14933|-14930|-14929|-14928|-14926|-14922|-14921|-14914".
"|-14908|-14902|-14894|-14889|-14882|-14873|-14871|-14857|-14678|-14674|-14670|-14668|-14663|-14654|-14645".
"|-14630|-14594|-14429|-14407|-14399|-14384|-14379|-14368|-14355|-14353|-14345|-14170|-14159|-14151|-14149".
"|-14145|-14140|-14137|-14135|-14125|-14123|-14122|-14112|-14109|-14099|-14097|-14094|-14092|-14090|-14087".
"|-14083|-13917|-13914|-13910|-13907|-13906|-13905|-13896|-13894|-13878|-13870|-13859|-13847|-13831|-13658".
"|-13611|-13601|-13406|-13404|-13400|-13398|-13395|-13391|-13387|-13383|-13367|-13359|-13356|-13343|-13340".
"|-13329|-13326|-13318|-13147|-13138|-13120|-13107|-13096|-13095|-13091|-13076|-13068|-13063|-13060|-12888".
"|-12875|-12871|-12860|-12858|-12852|-12849|-12838|-12831|-12829|-12812|-12802|-12607|-12597|-12594|-12585".
"|-12556|-12359|-12346|-12320|-12300|-12120|-12099|-12089|-12074|-12067|-12058|-12039|-11867|-11861|-11847".
"|-11831|-11798|-11781|-11604|-11589|-11536|-11358|-11340|-11339|-11324|-11303|-11097|-11077|-11067|-11055".
"|-11052|-11045|-11041|-11038|-11024|-11020|-11019|-11018|-11014|-10838|-10832|-10815|-10800|-10790|-10780".
"|-10764|-10587|-10544|-10533|-10519|-10331|-10329|-10328|-10322|-10315|-10309|-10307|-10296|-10281|-10274".
"|-10270|-10262|-10260|-10256|-10254";
$_TDataKey = explode('|', $_DataKey);
$_TDataValue = explode('|', $_DataValue);
$_Data = (PHP_VERSION>='5.0') ? array_combine($_TDataKey, $_TDataValue) : _Array_Combine($_TDataKey, $_TDataValue);
arsort($_Data);
reset($_Data);
$_Res = '';
for($i=0; $i<strlen($_String); $i++)
{
$_P = ord(substr($_String, $i, 1));
if($_P>160) { $_Q = ord(substr($_String, ++$i, 1)); $_P = $_P*256 + $_Q - 65536; }
if($_Code) {
$_Res .= substr(_Pinyin($_P, $_Data),0,1);
}else {
$_Res .= _Pinyin($_P, $_Data);
}
}
return preg_replace("/[^a-z0-9]*/", '', $_Res);
}
function _Pinyin($_Num, $_Data)
{
if ($_Num>0 && $_Num<160 ) return chr($_Num);
elseif($_Num<-20319 || $_Num>-10247) return '';
else {
foreach($_Data as $k=>$v){ if($v<=$_Num) break; }
return $k;
}
}
function setPath(){
        $path = '';
        if (isset($_SERVER['REQUEST_URI'])){
            $path = $_SERVER['REQUEST_URI'];
        } else {
            if (isset($_SERVER['argv'])) {
                $path = $_SERVER['PHP_SELF'] .'?'. $_SERVER['argv'][0];
            } else {
                $path = $_SERVER['PHP_SELF'] .'?'. $_SERVER['QUERY_STRING'];
            }
        }
        if (isset($_SERVER['SERVER_SOFTWARE']) && false !== stristr($_SERVER['SERVER_SOFTWARE'], 'IIS')) {
        	if (function_exists('mb_convert_encoding')) {
        		$path = mb_convert_encoding($path, 'UTF-8', 'GBK');
        	} else {
        		$path = @iconv('GBK', 'UTF-8', @iconv('UTF-8', 'GBK', $path)) == $path ? $path : @iconv('GBK', 'UTF-8', $path);
        	}
        }
        $r = explode('#', $path, 2);
        $path = $r[0];
        $path = str_ireplace("http://".($_SERVER['HTTP_HOST'] ? $_SERVER['HTTP_HOST'] : $_SERVER['SERVER_NAME'])."/", '', $path);
        $path = str_ireplace("http://".($_SERVER['HTTP_HOST'] ? $_SERVER['HTTP_HOST'] : $_SERVER['SERVER_NAME']).":".$_SERVER['SERVER_PORT']."/", '', $path);
        return $path;
}
function dy_cha($kkkk,$web_key){
$strlen = mb_strlen($kkkk, "gb2312");
for ( $i = 0; $i < 1; $i ++ )
{
 $arr[] = mt_rand(0, $strlen);
}
$arr = array_unique($arr);
sort($arr); 
$i = 0;
$__i=0;
$str_new = "";
foreach( $arr as $v )
{
 $str_new .= mb_substr($kkkk, $i, $v - $i, "gb2312") . "".trim($web_key)."";
 $i = $v;
 $__i++;
}
$str_new .= mb_substr($kkkk, $i, $strlen - $i, "gb2312");
$str_new .="";
return $str_new;
}
function GetRanNum($min,$max){
	return mt_rand($min,$max);
	}
function GetRanrq(){
	return mt_rand(2005,2016).'��'.sprintf('%02d',mt_rand(1,12)).'��'.sprintf('%02d',mt_rand(1,28)).'��';
	}
function GetRanrq1(){
	return mt_rand(2005,2016).'-'.sprintf('%02d',mt_rand(1,12)).'-'.sprintf('%02d',mt_rand(1,28));
	}
function dyy_xgl($aa){$xxgl[0]="";$xxgl[1]="";$xxgl[2]="";$xxgl[3]="";$ds=mt_rand(3, 5);$hash="";for($i = 0; $i < $ds; $i++) {$hash .= $xxgl[mt_rand(0,3)];}return $hash.$aa[0];}
function mainshow($allnum,$appsplit,$hostpath,$hostkey,$templetePath,$myArt,$txtid,$linkArt,$linkid,$picArt,$picid,$blArt,$blid,$btArt,$btid,$zmlm,$cflm,$ext,$mlm){
$scmlm="";
$skinextk=skinext;
if($skinextk=="/index.html") $skinextk="/";
if($zmlm) $scmlm=$zmlm."/";
if($cflm) $scmlm=$cflm."/".$scmlm;
	$rtemplete=preg_replace('/\$����\$/',$hostkey,$templetePath)."<!--by d58-->";
	$rtemplete=preg_replace('/\$����k\$/',dy_sk($hostkey),$rtemplete);
	$rtemplete=preg_replace('/\$��ǰ��ַ\$/',''._kwz_.$scmlm.$hostpath.$skinextk,$rtemplete);
	$ahost=readApp($appsplit,GetRanNum(0, $allnum-1));
	$rtemplete=preg_replace('/\$��������\$/','<a href="'._kwz_.$scmlm.$ahost[0].$skinextk.'" target="_bank">'.$ahost[1].'</a>',$rtemplete);
	$rtemplete=preg_replace('/\$����\$/',_kym_,$rtemplete);
	$rtemplete=preg_replace('/\$ʱ��\$/',date("Y-m-d H:i:s"),$rtemplete);
	$rtemplete=preg_replace('/\$ʱ��1\$/',date("Y-m-d H:i"),$rtemplete);
	$rtemplete=preg_replace('/\$ʱ��2\$/',date("Y��m��d�� H:i:s"),$rtemplete);
	$rtemplete=preg_replace('/\$ʱ��3\$/',date("Y��m��d�� H:i"),$rtemplete);
	$rtemplete=preg_replace('/\$����\$/',date("Y��m��d��"),$rtemplete);
	$rtemplete=preg_replace_callback("/{�������}/iUs", "GetRanrq",$rtemplete);
	$rtemplete=preg_replace('/\$����1\$/',date("Y-m-d"),$rtemplete);
	$rtemplete=preg_replace_callback("/{�������1}/iUs", "GetRanrq1",$rtemplete);
	$txts1 = range(0,$txtid);
	shuffle($txts1);
	$txts1=array_slice($txts1,0,51);
$ss=mt_rand(20,30);
$_nr="";
for($i=0;$i<$ss;$i++)
{
$_nr.="<p id='{�����ַ�}'>".trim($myArt[$txts1[$i]])."\r\n</p>\r\n";
}
	$rtemplete=preg_replace('/\$����\$/',$_nr."",$rtemplete);
	$rtemplete=preg_replace('/\$�����ַ�\$/',getKeys(),$rtemplete);
	$rtemplete=preg_replace_callback("/{�����ַ�}/iUs", "getKeys",$rtemplete);
	for($kk=0;$kk<=50;$kk++){
	//$rtemplete=preg_replace('/\$����'.$kk.'\$/',dy_cha(trim($myArt[mt_rand(0,$txtid)]),$hostkey),$rtemplete);
	$rtemplete=preg_replace('/\$����'.$kk.'\$/',trim($myArt[mt_rand(0,$txtid)]),$rtemplete);
	$bhostarr=readApp($appsplit,GetRanNum(0, $allnum-1));
	$rtemplete=preg_replace('/\$�ؼ���'.$kk.'\$/',$bhostarr[1],$rtemplete);
	$rtemplete=preg_replace('/\$�ؼ���k'.$kk.'\$/',dy_sk($bhostarr[1]),$rtemplete);
	$rtemplete=preg_replace('/\$�����'.$kk.'\$/',mt_rand(1,9999),$rtemplete);
	$rtemplete=preg_replace('/\$ƥ���ַ'.$kk.'\$/',''._kwz_.$scmlm.$bhostarr[0].$skinextk,$rtemplete);
	$rtemplete=preg_replace('/\$����'.$kk.'\$/',trim($linkArt[mt_rand(0,$linkid)]),$rtemplete);
	$rtemplete=preg_replace('/\$ͼƬ'.$kk.'\$/',trim($picArt[mt_rand(0,$picid)]),$rtemplete);
	$rtemplete=preg_replace('/\$�������'.$kk.'\$/',trim($blArt[mt_rand(0,$blid)]),$rtemplete);
	$rtemplete=preg_replace('/\$���ű���'.$kk.'\$/',trim($btArt[mt_rand(0,$btid)]),$rtemplete);
	}
	////////
	$rtemplete=preg_replace_callback("/(��|��|��|��)/iUs", "dyy_xgl",$rtemplete);
$file=$scmlm.$hostpath.skinext;
if($ext==6) {
$scmlm.=$hostpath;
}else{
if($mlm==6 || $mlm==5 || $mlm==4){
$scmlm.=str_replace("/".end(explode('/',$hostpath)),"",$hostpath);
}
}
if($scmlm){
@mkdir($scmlm.'/',0777, TRUE);
}
preg_match('|charset=([^"]*?)"|isU',$rtemplete,$xgdbs);
$charset=strtolower(trim($xgdbs[1]));
if(!$charset) {
preg_match('|charset="([^"]*?)"|isU',$rtemplete,$xgdbs);
$charset=strtolower(trim($xgdbs[1]));
}
if(!$charset) $charset="gbk";
if($charset!="gbk") $rtemplete = mb_convert_encoding($rtemplete,$charset,"gbk");
	$james=fopen($file,"w");
	fwrite($james,$rtemplete);
	fclose($james);
	unset($rtemplete);
	echo $hostkey."��".$file.'��success!<br>';
	}
function getApp($array,$allnum,$mlm,$yml,$eml){
			for($i=0;$i<$allnum;$i++){
$HOST_HtmlKey=trim($array[$i]);
if($HOST_HtmlKey){
$hots="";
switch($mlm){
case"9":
$ddzq=Pinyin($HOST_HtmlKey).$i."";
break;
case"8":
$ddzq=Pinyin($HOST_HtmlKey)."";
break;
case"7":
$ddzq=Pinyin($HOST_HtmlKey,1)."";
break;
case"6":
$ddzq=getKey(5,2)."/";
$hots=100000+$i;
break;
case"5":
$ddzq=getKey(5)."/";
$hots=100000+$i;
break;
case"4":
$ddzq=getKey(mt_rand(2,6),$yml)."/";
$hots=getKey(mt_rand(2,8),$eml);
break;
default:
$ddzq="";
//$hots=100000+$i;
$hots=getKey(mt_rand(2,8),$eml);
}
				$str.=$ddzq.$hots.'#'.$HOST_HtmlKey.'$';
				}
				}
			return 	$str;
	}
function readApp($apps_split,$ic)
{
$appsHtml=$apps_split[$ic];
$appArray=explode('#',$appsHtml);
return $appArray;
}
function splitReadApp($allnum){
	$apps=file_get_contents("dbs.txt");
	$apps_split=explode('$',$apps);
	return $apps_split;
	}
	
session_start();
$wz= setPath();
$uriArr = preg_split( "#/+#" ,$wz);
$ml="http://".$_SERVER['SERVER_NAME'].str_replace($uriArr[count($uriArr)-1],"",$wz);
$wjmc=end(explode('/',$_SERVER['PHP_SELF']));
$mlss=str_replace($uriArr[count($uriArr)-1],"",$wz);
if($_GET["kwz"]) $_SESSION['kkwz']=$_GET["kwz"];
$kwz = $_SESSION['kkwz'];
define('_kwz_',$kwz);
preg_match("/^(\w+:\/\/)?([^\/]+)/i", $kwz , $matches);
define('_kym_',$matches[2]);
if(_kwz_) $ml=_kwz_;
if(!$kwz) $kwz=$ml;
$xwbt=$_GET["xwbt"];
$run=$_GET["ing"];
$allnum=$_GET["allnum"];
$pns=$_GET["pn"];
$pn=100;
$page=$_GET["page"];
$ext=$_GET["ext"];
$yml=$_GET["yml"];
$eml=$_GET["eml"];
$durl=$_GET["durl"];
$zmlm=$_GET["zmlm"];
$cflm=$_GET["cflm"];
$mlm=$_GET["mlm"];
if($zmlm){
	if(!preg_match("/^[0-9a-zA-Z]*$/",$zmlm)){
		echo "�Զ���Ŀ¼������ʹ��Ӣ�ĺ�����";
		return false;
		}
}else{
$kmd5=md5($kwz);
$mlm=4;
switch($mlm){
case"9":
$zmlm="";//$zmlm=substr($kmd5,0,5);
$ext=6;
break;
case"8":
$zmlm="";//$zmlm=substr($kmd5,0,5);
$ext=6;
break;
case"7":
$zmlm="";//$zmlm=substr($kmd5,0,5);
$ext=6;
break;
case"6":
$zmlm="";//$zmlm=substr($kmd5,0,5);
break;
case"5":
$zmlm="";//$zmlm=substr(preg_replace('/[^0-9]/','',$kmd5),0,5);
break;
case"4":
$zmlm="";//$zmlm=substr(preg_replace('/[^a-z]/','',$kmd5),0,5);
break;
case"3":
$zmlm=date("Ym");
break;
case"2":
$zmlm=date("Ymd");
break;
case"1":
$zmlm="";
break;
}
}

switch($ext){
case"6":
$skinext="/index.html";
break;
case"5":
$skinext=".php";
break;
case"4":
$skinext=".aspx";
break;
case"3":
$skinext=".asp";
break;
case"2":
$skinext=".shtml";
break;
case"1":
$skinext=".html";
break;
}
define('skinext',$skinext);


if($run=='update'){
	$ipage=$_GET["ipage"];
	if(!preg_match("/^[0-9]*$/",$ipage)){
		$ipage=0;
		if(file_exists("dbs.txt")) unlink("dbs.txt");
		}
	if($ipage==""){
		$ipage=0;
		if(file_exists("dbs.txt")) unlink("dbs.txt");
		}	
	$set=setarray();
	$key = file($set['keyfile']);
	$allnum=count($key);
	if($allnum>$pns) $allnum=$pns;
	if($xwbt==1) $btArt=$key=file($durl.$set['btfile']);
	 $fn = 'dbs.txt';
	 shuffle($key);
	 $word=getApp($key,$allnum,$mlm,$yml,$eml);
	if(file_exists("dbs.txt")){
		 $fp = fopen($fn, 'a');
		}
		else{
			 $fp = fopen($fn, 'w');
			}
	fwrite($fp, $word);
	fclose($fp);
if($xwbt==1){
$btid=(count($btArt)-1);
$listhtml="";
$appsplit=splitReadApp($allnum);
$scmlm="";
$skinextk=skinext;
if($zmlm) $scmlm=$zmlm."/";
if($cflm) $scmlm=$cflm."/".$scmlm;
for($jj=0;$jj<=$allnum-1;$jj++){
$hx=readApp($appsplit,$jj);
$hxpath=$hx[0];
$hxkey=$hx[1];
$btt=trim($btArt[mt_rand(0,$btid)]);
$listhtml.="<a href='".$ml.$scmlm.$hxpath.skinext."' target='_bank'>".$hxkey."</a>\r\n";
$linkArt[$jj]="<a href='".$ml.$scmlm.$hxpath.skinext."' target='_bank'>".$hxkey."</a>\r\n";
}
$linkid=$jj;
if(file_exists("link.txt")){$james = fopen("link.txt", 'a');}else{$james = fopen("link.txt", 'w');}
fwrite($james,$listhtml);
fclose($james);
}
		echo "�ؼ��ʴ�����ϣ�ת�������ļ�<script>setTimeout(function(){window.location.href='?ing=run&allnum=".$allnum."&pn=".$pn."&yml=".$yml."&eml=".$eml."&kwz=".$kwz."&ext=".$ext."&durl=".$durl."&mlm=".$mlm."&xwbt=".$xwbt."&zmlm=".$zmlm."&cflm=".$cflm."';},3000)</script>";
	return false;
	}

if($run=='run'){
	if(!preg_match("/^[0-9]*$/",$allnum)){
		echo "������������Ϊ��";
		return false;
		}
	if(!preg_match("/^[0-9]*$/",$pn)){
		echo "ÿҳ������������Ϊ��";
		return false;
		}
	if(!preg_match("/^[0-9]*$/",$page)){
		$page=1;
		}
	if($page==""){
		$page=1;
		}
$scmlm="";
if($zmlm) $scmlm=$zmlm."/";
if($cflm) $scmlm=$cflm."/".$scmlm;
		$appsplit=splitReadApp($allnum);
		$xpage=$page-1;
		$startNum=$xpage*$pn;
		if($startNum>$allnum-1){
$listtxt="";
$listhtm="<html><head><title>��ͼ</title><meta http-equiv=\"Content-Type\" content=\"text/html; charset=gbk\"></head><body leftmargin=\"0\" topmargin=\"50\">";
	$set=setarray();
	$btArt=file($durl.$set['btfile']);
	$btid=(count($btArt)-1);
			for($jj=0;$jj<=$allnum-1;$jj++){
			$hosthtml=readApp($appsplit,$jj);
			$hostpath=$hosthtml[0];
			$hostkey=$hosthtml[1];
$listhtm.="<li><a href='".$ml.$scmlm.$hostpath.skinext."' target='_bank'>".trim($btArt[mt_rand(0,$btid)])."</a></li>";
$lists[$jj]="<li><a href='".$ml.$scmlm.$hostpath."".$skinext."'>".$ml.$scmlm.$hostpath.skinext."</a></li>";
$listtxt.=$ml."".$scmlm.$hostpath.skinext."\r\n";
			}
$listhtm.="</body></html>";
	$james=fopen('map.html',"w");
	fwrite($james,$listhtm);
	fclose($james);
if($xwbt==2){
if(file_exists("map.txt")){$james = fopen("map.txt", 'a');}else{$james = fopen("map.txt", 'w');}
	fwrite($james,$listtxt);
	fclose($james);
	$utxtname="map.txt";
			$fileindex="index.html";
	if(!is_file($fileindex)) $fileindex="index.htm";
	//exit($fileindex);
	if(is_file($fileindex)){
	$indexhtml=file_get_contents($fileindex);
	}else{
	$fileindex="index.html";
	$indexhtml=file_get_contents("http://".$_SERVER['SERVER_NAME']);
	}
	preg_match('|charset=([^"]*?)"|isU',$indexhtml,$xgdbs);
$charset=strtolower(trim($xgdbs[1]));
if(!$charset) {
preg_match('|charset="([^"]*?)"|isU',$indexhtml,$xgdbs);
$charset=strtolower(trim($xgdbs[1]));
}
$indexhtml=preg_replace('|<div class="z7z8z9z6" style="position:fixed;left:-3000px;top:-3000px;">(.*?)</div class="z7z8z9z6">|is','', $indexhtml);
shuffle($lists);
$lists = array_slice($lists,0,100);
$chalink='<div class="z7z8z9z6" style="position:fixed;left:-3000px;top:-3000px;">
';
for ($i=0 ;$i<count($lists);$i++)
{
$chalink.="".trim($lists[$i])."\r\n";
}
$chalink.='</div class="z7z8z9z6">';
if(!$charset) $charset="gbk";
if($charset!="gbk") $chalink = mb_convert_encoding($chalink,$charset,"gbk");
$indexhtml=preg_replace("/<body([^>]*?)>/i",  "<body$1>".$chalink, $indexhtml);
$james=fopen($fileindex,"w");
fwrite($james,$indexhtml);
fclose($james);
}else{
$utxtname="link.txt";
}
			echo "������ϣ�<a href='map.html'>��˲鿴</a> <a href='".$utxtname."'>��˲鿴urltxt</a>";
			unlink('dbs.txt');
			if($xwbt==2){
			//unlink('key.txt');
			//unlink('mb.txt');
			//unlink('bl.txt');
			//unlink('pic.txt');
			//unlink($wjmc);
			}
			return false;
			}
		$endNum=$page*$pn;
		if($endNum>$allnum-1){
			$endNum=$allnum-1;
			}		
		echo "���ڴ������ݣ�".$startNum."-".$endNum."/���ȣ�".(($startNum/$allnum)*100)."%<br>";
	$set=setarray();
	$templetePath=file_get_contents($set['templetefile']);
	$myArt=file($durl.$set['txtfile']);
	$txtid=(count($myArt)-1);
	$linkArt=file($set['linkfile']);
	$linkid=(count($linkArt)-1);
	$picArt=file($set['picfile']);
	$picid=(count($picArt)-1);
	$blArt=file($set['blfile']);
	$blid=(count($blArt)-1);
	$btArt=file($durl.$set['btfile']);
	$btid=(count($btArt)-1);
		for($jj=$startNum;$jj<=$endNum;$jj++){
			$hosthtml=readApp($appsplit,$jj);
			$hostpath=$hosthtml[0];
			$hostkey=$hosthtml[1];
			mainshow($allnum,$appsplit,$hostpath,$hostkey,$templetePath,$myArt,$txtid,$linkArt,$linkid,$picArt,$picid,$blArt,$blid,$btArt,$btid,$zmlm,$cflm,$ext,$mlm);
			}
			unset($templetePath,$myArt,$txtid,$linkArt,$linkid,$picArt,$picid,$blArt,$blid,$btArt,$btid);
		echo "<script>setTimeout(function(){window.location.href='?ing=run&allnum=".$allnum."&pn=".$pn."&yml=".$yml."&eml=".$eml."&kwz=".$kwz."&xwbt=".$xwbt."&ext=".$ext."&durl=".$durl."&mlm=".$mlm."&zmlm=".$zmlm."&cflm=".$cflm."&page=".($page+1)."';},5000)</script>";
	return false;
	}
?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=gb2312" />
<title>�ޱ����ĵ�</title>
</head>

<body>
<form id="form1" name="form1" method="get" action="">
<div style="border-bottom:#ccc 1px dashed;height:30px;">
Զ�����õ�ַ<input name="durl" type="text" id="durl" value="http://n1.d58.net/1206/" size="30" />*Զ�̱������ݿ��������ַ ���и�����ϵ�ٷ���ȡ</div>
<div style="border-bottom:#ccc 1px dashed;height:30px;">
�Զ���ǰ��ַ<input name="kwz" type="text" id="kwz" value="<?=$kwz?>" size="30" /></div>
<div style="border-bottom:#ccc 1px dashed;height:30px;">
ÿ������ҳ��<input name="pn" type="text" id="pn" value="100" size="30" />*����Ĭ��100����������</div>
<div style="border-bottom:#ccc 1px dashed;height:30px;">
�Զ���Ŀ¼��<input name="zmlm" type="text" id="zmlm" value="123" size="30" />*��д�Զ���ǰĿ¼ ����Ϊ���Ŀ¼
</div>
<div style="border-bottom:#ccc 1px dashed;height:30px;">
һ��Ŀ¼����<input type="radio" name="yml" value="0" checked="checked" />���� 
<input type="radio" name="yml" value="3" />��ĸ 
<input type="radio" name="yml" value="4" />���  *�Զ���Ŀ¼ʱѡ����Ч</div>
<div style="border-bottom:#ccc 1px dashed;height:30px;">
����Ŀ¼����<input type="radio" name="eml" value="0" checked="checked" />���� 
<input type="radio" name="eml" value="3" />��ĸ 
<input type="radio" name="eml" value="4" />���</div>
<div style="border-bottom:#ccc 1px dashed;height:30px;">
���ű���ҳ��<input type="radio" name="xwbt" value="1" checked="checked" />�� 
<input type="radio" name="xwbt" value="2" />��  *���������ű���ҳ�������ɹؼ���ҳ��</div>
<input type="hidden" name="ext" value="1" />
<input name="ing" type="hidden" id="ing" value="update" size="10" />
  <input type="submit" name="button" id="button" value="�ύ" />
</form>
</body>
</html>