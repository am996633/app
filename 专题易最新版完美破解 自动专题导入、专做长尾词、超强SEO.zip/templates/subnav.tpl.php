<div class="header cl">
	<div class="logo fl">
		<a href="/">
			<img src="/static/images/logo.png" title="{$conf[siteName]}">
		</a>
	</div>
	<div class="mainnav cl fl">
		<a href="/list/" {if isset($hd_nav) && $hd_nav=="list"} class="current"{/if}>最新专题</a>
		<a href="/article/" {if isset($hd_nav) && $hd_nav=="article"} class="current"{/if} >最新文章</a>
		<a href="/baike/" {if isset($hd_nav) && $hd_nav=="baike"} class="current"{/if} >百科知识</a>
		<a href="/question/" {if isset($hd_nav) && $hd_nav=="question"} class="current"{/if} >常见问题</a>
	</div>

	<div class="fr mar10 ">
		<form action="/article/search/" method="get">
			<input  type="text" name="keyword" {if isset($keyword)} value="{$keyword}" {/if}  placeholder="输入关键字" class="search" /><input class="btn" value="搜索" type="submit" />
		</form>
	</div>
	<div class="fr"><a href="http://<?php echo $this->conf['webHost']; ?>/sitemap.xml" class="sitemap" title="sitemap" target="_blank"></a></div>
</div>
