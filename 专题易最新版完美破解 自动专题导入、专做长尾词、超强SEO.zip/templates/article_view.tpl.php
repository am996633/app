<?php if(!defined('IN_SYS')) exit('Access Denied'); ?>
<!DOCTYPE html>
<html>
<head>
	<meta charset='utf-8' />
	<title>{$page['title']}_{$topic['title']}-{$conf[siteName]}</title>
	<meta name="keywords" content="{$page[keywords]}"/>
	<meta name="description" content="{$page[description]}"/>
	<link type="text/css" rel="stylesheet" href="/static/css/reset.css" />
	<link type="text/css" rel="stylesheet" href="/static/css/common.css" />
	<link type="text/css" rel="stylesheet" href="/static/css/style.css" />
	<script type="text/javascript" src="/static/js/jquery.js"></script>
	<script type="text/javascript" src="/static/js/common.js"></script>
	<script type="text/javascript" src="/static/js/share.js"></script>
	<script type="text/javascript" src="/static/js/plus.js"></script>
	<!-- include system/mobile_agent -->
</head>
<body>
	<!-- include header -->
	<div class="page wrap" >
		<div class="cl">
			<div  class="leftcon">
				<div class="breadcrumb">
					<a href="/" class="home_ico">{$conf[siteName]}</a> <a href="{$topic['pyurl']}">{$topic['title']}</a> {$page[title]}
				</div>
				<div class="title">
					<h1>{$page[title]}</h1>
				</div>
				<div class="cl">
					<!-- include system/section_share -->
					<span class="page_click"><b class="page_bold">{echo $page['click']}</b> 阅读</span>
				</div>
				<div class="mainbody">{$page[body]}</div>
				<div>
					<div align="right"><a href="/">[返回首页]</a></div>
					<div class="zeren">
						<span>版权声明</span>
						<div>1.本网站所转载的作品，目的在于传递更多信息，并不代表本网站赞同其观点和对其真实性负责。</div>
						<div>2.如因作品内容，版权和其他问题需要同本网站联系的，请邮件联系我们support@email.thinkincloud.cn</div>
					</div>

					<div class="comment">
						<!-- include system/section_comment -->
					</div>
					<div class="xiangguan cl">
						<div class="fl">
							<div class="xg_title">相关文章</div>
							<div class="xg_content">
								<ul>
									<!--foreach $xg_list-->
									<li><a href="{$url}" title="{$title}">{$title}</a></li>
									<!--/foreach-->
								</ul>
							</div>
						</div>
						<div class="fl mrl20">
							<div class="xg_title">延伸阅读</div>
							<div class="xg_content">
								<ul>
									<!--foreach $ys_list-->
									<li><a href="{$url}" title="{$title}">{$title}</a></li>
									<!--/foreach-->
								</ul>
							</div>
						</div>
					</div>
				</div>
			</div>
			<div class="rightcon index2">
				<div id="fix_top">
					<div class="r_title cl">
						<div class="fl div1 current tb_a ">热门文章</div>
						<div class="fr div1 tb_a border_left " >最新文章</div>
					</div>

					<div class="tbc_a">
						<!--foreach $list_hot -->
						{if $index==1}
						<div class="cl" >
							<div class="fl">
								<a href="{$url}" target="_blank" title="{$title}">
									<img src="{if empty($thumb)}/static/images/default.png{else}{fixsrc($thumb)}{/if}" width="120" height="90">
								</a>
							</div>
							<div class="fl mrl20" >
								<div><a href="{$url}" target="_blank" title="{$title}" >{cut($title,20,'...')}</a></div>
								<div class="w150">{cut($description,60,'...')}</div>
							</div>
						</div>
						{/if}
						<!--/foreach -->
						<div class="r_content">
							<ul>
								<!--foreach $list_hot -->
								{if $index>1}
								<li {if $index<=4}class="blue"{else}class="gray"{/if}><a href="{$url}" target="_blank">{$title}</a></li>
								{/if}
								<!--/foreach -->
							</ul>
						</div>
					</div>
					<div class="tbc_a" style="display:none;">
						<!--foreach $list_new -->
						{if $index==1}
						<div class="cl" >
							<div class="fl">
								<a href="{$url}" target="_blank" title="{$title}" >
									<img src="{if empty($thumb)}/static/images/default.png{else}{fixsrc($thumb)}{/if}" width="120" height="90">
								</a>
							</div>
							<div class="fl mrl20" >
								<div><a href="{$url}" target="_blank" title="{$title}" >{cut($title,20,'...')}</a></div>
								<div class="w150">{cut($description,60,'...')}</div>
							</div>
						</div>
						{/if}
						<!--/foreach -->
						<div class="r_content">
							<ul>
								<!--foreach $list_new -->
								{if $index>1}
								<li {if $index<=4}class="blue"{else}class="gray"{/if}><a href="{$url}" target="_blank">{$title}</a></li>
								{/if}
								<!--/foreach -->
							</ul>
						</div>
					</div>
				</div>

			</div>
		</div>
	</div>
	<!-- include footer -->
</body>
</html>
