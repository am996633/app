<?php if(!defined('IN_SYS')) exit('Access Denied'); ?>
<div class="adbox">
	<div class="wrap">
		<!-- tag::ad(1) -->
	</div>
</div>

<!-- include subnav -->
<div class="nav">
	<div class="wrap">
		<a href="/">首页</a>
		{if isset($topic)}
		<?php $turl = explode("/", $topic['pyurl']);
		$turl = $turl[1]; 
		?>
		<a href="{$topic['pyurl']}" {if $current==$turl} class="current" {/if} >{$topic['title']}</a>
		{/if}
		<!-- foreach $nav  -->
		<a href="{$pyurl}" {if $current==$pinyin} class="current" {/if}>{$title}</a>
		<!-- /foreach -->
	</div>
</div>
