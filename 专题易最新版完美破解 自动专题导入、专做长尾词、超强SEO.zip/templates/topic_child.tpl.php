<?php if(!defined('IN_SYS')) exit('Access Denied'); ?>
<!DOCTYPE html>
<html>
<head>
	<meta charset='utf-8' />
	<title>{$topic_child['title']}_{$topic['title']}专题 - {$conf[siteName]}</title>
	<meta name="keywords" content="{$topic_child['title']},{$topic['title']}"/>
	<meta name="description" content="关于{$topic['title']}的{$topic_child['title']}相关信息。"/>
	<link type="text/css" rel="stylesheet" href="/static/css/reset.css" />
	<link type="text/css" rel="stylesheet" href="/static/css/common.css" />
	<link type="text/css" rel="stylesheet" href="/static/css/style.css" />
	<script type="text/javascript" src="/static/js/jquery.js"></script>
	<script type="text/javascript" src="/static/js/common.js"></script>
	<script src="/static/js/jquery.SuperSlide.2.1.1.js"></script>
	<!-- include system/mobile_agent -->
</head>
<body>
	<!-- include header -->
	<div class="wrap topic_child cl">

		<div class="leftcon">
			<div class="top_con">
				<div class="topic_title"><h1>{$topic_child['title']}</h1></div>

				<div class="line_hg">
					<p>{cut($topic_body['desc'],150,'...')}</p>
					<!-- if $topic_body['body'] -->
					<p>{cut($topic_body['body'],190,'...')} <a href="/{$index_url}/{$current}/info_{$topic_body['id']}.html" >查看更多</a></p>
					<!-- /if -->
				</div>
			</div>

			<!--if !empty($list_baike)-->
			<div class="baike_box">
				<div class="tip_cap">百科</div>
				<div class="title"><h2><a href="baike_{$list_baike[0][id]}.html" target="_blank">{$list_baike[0][bk_title]}百科</a></h2></div>
				<div class="content">{cut($list_baike[0][bk_content],200,'...')}<a href="baike_{$list_baike[0][id]}.html" target="_blank">查看更多</a></div>

				<ul class="list_s">
					<!-- foreach $list_baike -->
					<!-- if $index>1 -->
					<li><a href="baike_{$id}.html" target="_blank">{$bk_title}</a></li>
					<!-- /if -->
					<!-- /foreach -->
				</ul>
			</div>
			<!-- /if -->

			<div class="arclist " >
				<div class="tip_cap">相关文章</div>
				<ul>
					<!-- foreach $list -->
					<li>
						<div class="ltitle">
							<a href="{$url}" target="_blank">{$title}</a>
						</div>
						<div class="ldesc">
							{cut($description, 120)}
						</div>
						<div class="lbar cl">
							<div class="v">{$click}</div>
							<div class="t">{date("Y-m-d H:i:s", $addtime)}</div>
						</div>
					</li>
					<!-- /foreach -->
				</ul>
			</div>

		</div>

		<div class="rightcon">
			<div class="ntopic_box">
				<div class="title">最新专题</div>
				<ul>
					<!-- sql select * from topic where flag = 1 AND status=1 order by id desc limit 5-->
					<li class="content"><a href="{$pyurl}">{$title}</a></li>
					<!--/sql -->
				</ul>
			</div>

			<!-- if !empty($list_wenwen) -->
			<div  class="block">
				<div class="caption">常见问题</div>
				<div class="conlist">
					<!-- foreach $list_wenwen -->
					<div  class="index_wenwen"><a href="/{$index_url}/{$current}/question_{$id}.html">{$ww_title}？</a></div>
					<!-- /foreach -->
				</div>
			</div>
			<!-- /if -->

			<!-- if !empty($list_weibo) -->
			<div  class="block">
				<div class="caption">微博讨论</div>
				<!-- foreach $list_weibo -->
				<div class="cl mrt10" >
					<div class="fl"><img src="{$face}" ></div>
					<div class="fl wb_name" >
						<div class="name_color">{$name}</div>
						<div class="hg_con">{$content}</div>
					</div>
				</div>
				<!--/foreach -->
			</div>
			<!-- /if -->
			
		</div>
	</div>
	<div class="lr_arrow">
		<!-- if $left_arrow -->
		<div class="post-prev"><a href="{$left_arrow[pyurl]}">&lt;</a></div>
		<!-- /if -->
		<!-- if $right_arrow -->
		<div class="post-next"><a href="{$right_arrow[pyurl]}">&gt;</a></div>
		<!-- /if -->
	</div>
	<!-- include footer -->
</body>
</html>