<?php if(!defined('IN_SYS')) exit('Access Denied'); ?>

<div id="top" class="footer_scroll">
	<a href="javascript:$('html, body').animate({scrollTop:0}, 'slow');"> </a>
</div>
<div class="footer">
	<div class="footer_nav">
		<ul class="cl">
			<li><a href="/">首页</a></li>
			<!--sql select * from page  -->
			<li><a href="/page/{$ename}.html">{$title}</a></li>
			<!--/sql -->
		</ul>
	</div>
	Copyright © 2015 {$conf[siteName]}  All rights reserved. {$conf[ipc]}
</div>
<div style="display:none;">
	{$conf[site_code]}
</div>
