<?php if(!defined('IN_SYS')) exit('Access Denied'); ?>
<!DOCTYPE html>
<html>
<head>
	<meta charset='utf-8' />
	<title>百科知识-{$conf[siteName]}</title>
	<link type="text/css" rel="stylesheet" href="/static/css/reset.css" />
	<link type="text/css" rel="stylesheet" href="/static/css/common.css" />
	<link type="text/css" rel="stylesheet" href="/static/css/style.css" />
	<script type="text/javascript" src="/static/js/jquery.js"></script>
	<script type="text/javascript" src="/static/js/common.js"></script>
	<script type="text/javascript" src="/static/js/plus.js"></script>
	<!-- include system/mobile_agent -->
</head>
<body>
	<!-- include header -->
	<div class="page wrap cl">
		<div class="leftcon bklist">
			<div class="breadcrumb">
				<a href="/">{$conf[siteName]}</a> 百科知识
			</div>
			<!--  foreach $list -->
			<div class="cl list_title" >
				<div class="fl">
					<img src="/static/images/baike.png" width="120" height="110" style="border:1px solid #ececec;">
					
				</div>
				<div class="fl bk_descr" >
					<div><a href='{$url}baike_{$id}.html' target="_blank" >{$bk_title}</a></div>
					<div class="info">{cut($bk_content,150,'...')}</div>
				</div>
			</div>
			<!-- /foreach -->
			<div class="page_link">{$page}</div>
		</div>
		<div class="rightcon index2">
			<div id="fix_top">
				<div class="r_title cl">
					<div class="fl div1 current tb_a ">热门百科</div>
					<div class="fr div1 tb_a border_left " >百科推荐</div>
				</div>
				<div class="tbc_a">
					<div class="r_content">
						<ul>
							<!--foreach $baike_hot -->
							<li {if $index<=4}class="blue"{else}class="gray"{/if}><a href="{$url}baike_{$id}.html" target="_blank">{cut($bk_title,30,'...')}</a></li>
							<!--/foreach -->
						</ul>
					</div>
				</div>
				<div class="tbc_a">
					<div class="r_content">
						<ul>
							<!--foreach $baike_rand -->
							<li {if $index<=4}class="blue"{else}class="gray"{/if}><a href="{$url}baike_{$id}.html" target="_blank">{cut($bk_title,30,'...')}</a></li>
							<!--/foreach -->
						</ul>
					</div>
				</div>
			</div>
		</div>
	</div>
	<!-- include footer -->
</body>
</html>