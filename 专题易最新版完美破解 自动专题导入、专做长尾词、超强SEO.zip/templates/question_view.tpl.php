<?php if(!defined('IN_SYS')) exit('Access Denied'); ?>
<!DOCTYPE html>
<html>
<head>
	<meta charset='utf-8' />
	<title>{$ww['ww_title']}-{$conf[siteName]}</title>
	<meta name="keywords" content="{$ww['ww_title']}"/>
	<meta name="description" content="{$ww['ww_title']}"/>
	<link type="text/css" rel="stylesheet" href="/static/css/reset.css" />
	<link type="text/css" rel="stylesheet" href="/static/css/common.css" />
	<link type="text/css" rel="stylesheet" href="/static/css/style.css" />
	<script type="text/javascript" src="/static/js/jquery.js"></script>
	<script type="text/javascript" src="/static/js/common.js"></script>
	<!-- include system/mobile_agent -->
</head>
<body>
	<!-- include header -->
	<div class="page wrap cl" >
		<div  class="leftcon">
			<div class="breadcrumb">
				<a href="/">{$conf[siteName]}</a> <a href="{$topic['pyurl']}">{$topic['title']}</a> {$ww['ww_title']}
			</div>
			<div class="title">
				<h1>{$ww['ww_title']}</h1>
			</div>
			<div class="share cl">
				<span></span>
			</div>
			<div class="mainbody">{$ww['ww_content']}</div>
			<div class="comment">
			</div>
			<div class="recommend">
			</div>
		</div>
		<div class="rightcon">
			<div  class="block hot_topic">
				<div class="caption">{$topic['title']} 常见问题</div>
				<div class="conlist">
					<!-- foreach $list_wenwen -->
					<div style="padding-top:5px;"><a href="question_{$id}.html">{$ww_title}？</a></div>
					<!-- /foreach -->
				</div>
			</div>
		</div>
	</div>
	<!-- include footer -->
</body>
</html>
