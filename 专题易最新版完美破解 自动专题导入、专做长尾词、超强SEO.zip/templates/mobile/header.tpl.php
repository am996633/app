<?php if(!defined('IN_SYS')) exit('Access Denied'); ?>
<div class="header_main">
	<div class="logobox cl">
		<div class="logo"><a href="/">{$conf[siteName]}</a></div>
		<div class="menu">
			<a href="javascript:void(0)" onclick="shownav()"></a>
		</div>
	</div>
	<div class="menubar">
		<a href="/list/" {if isset($hd_nav) && $hd_nav=="list"} class="current"{/if}>最新专题</a>
		<a href="/article/" {if isset($hd_nav) && $hd_nav=="article"} class="current"{/if} >最新文章</a>
		<a href="/baike/" {if isset($hd_nav) && $hd_nav=="baike"} class="current"{/if} >百科知识</a>
		<a href="/question/" {if isset($hd_nav) && $hd_nav=="question"} class="current"{/if} >常见问题</a>
	</div>
</div>

