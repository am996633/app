<?php if(!defined('IN_SYS')) exit('Access Denied'); ?>

<div class="wrap" style="display:none;">
	{$conf[site_code]}
</div>
<div class="footer">
	<div class="footer_nav">
		<ul class="cl">
			<li><a href="/">首页</a></li>
			<!--sql select * from page  -->
			<li><a href="/page/{$ename}.html">{$title}</a></li>
			<!--/sql -->
		</ul>
	</div>
	<div class="footer_txt">
		<p>Copyright © 2015 {$conf[siteName]} All rights reserved.</p>
		<p>{$conf[ipc]}</p>
	</div>
</div>
<script type="text/javascript">
	function shownav(){
		if($(".menubar").is(':visible')){
			$(".menubar").slideUp();
		}else{
			$(".menubar").slideDown();
		}
	}
</script>
