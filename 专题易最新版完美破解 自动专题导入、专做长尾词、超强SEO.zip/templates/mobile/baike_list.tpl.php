<?php if(!defined('IN_SYS')) exit('Access Denied'); ?>
<!DOCTYPE html>
<html>
<head>
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0, user-scalable=no" />
	<title>百科知识-{$conf[siteName]}</title>
	<meta name="keywords" content="{$conf[keywords]}"/>
	<meta name="description" content="{$conf[description]}"/>
	<link type="text/css" rel="stylesheet" href="/static/css/m_common.css" />
	<link type="text/css" rel="stylesheet" href="/static/css/m_style.css" />
	<script type="text/javascript" src="/static/js/jquery.js"></script>
	<script type="text/javascript" src="/static/js/iscroll.js"></script>
	<link rel="canonical" href="{$web_url}">

</head>
<body>
	<!-- include header -->
	<div class="m_wrap ">
		<div class="m_index_box baike_list">
			<div class="breadcrumb">
				<a href="/">{$conf[siteName]}</a> 百科知识
			</div>
			<!--  foreach $list -->
			<div class="list_title" >
				<div class=" descr" >
					<div><a href='{$url}baike_{$id}.html' target="_blank" >{$bk_title}</a></div>
					<div>{cut($bk_content,60,'...')}</div>
				</div>
				
			</div>
			<!-- /foreach -->
			<div class="page_link">{$page}</div>
		</div>
	</div>
	<!-- include footer -->
</body>
</html>