<?php if(!defined('IN_SYS')) exit('Access Denied'); ?>
<!DOCTYPE html>
<html>
<head>
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0, user-scalable=no" />
	<title>{$topic['title']}专题_{$topic['title']}的最新消息 - {$conf[siteName]}</title>
	<meta name="keywords" content="{$topic['title']}专题，{$topic['title']}的最新消息"/>
	<meta name="description" content="{$conf[siteName]}整理了有关{$topic['title']}的相关报道，收集{$topic['title']}的最新消息并持续追踪后续报道。"/>
	<link type="text/css" rel="stylesheet" href="/static/css/m_common.css" />
	<link type="text/css" rel="stylesheet" href="/static/css/m_style.css" />
	
	<script type="text/javascript" src="/static/js/jquery.js"></script>
	<script type="text/javascript" src="/static/js/TouchSlide.1.1.js"></script>
	<script type="text/javascript" src="/static/js/iscroll.js"></script>
	<link rel="canonical" href="{$web_url}">
</head>
<body>
	<!-- include header -->
	<div class="m_wrap " >
		<!-- include subnav -->
		<div class="m_index_box topic">
			<div class="breadcrumb">
				<a href="/">{$conf[siteName]}</a> {$topic['title']}
			</div>
			<div class="info">
				<div class="topictit"><h1>{$topic['title']}</h1></div>
				<!-- if $topic_body['body'] -->
				<div class="topicbody">
					<p>{cut($topic_body['desc'],150,'...')}</p>
					<p>{cut($topic_body['body'],190,'...')} <a href="/{$index_url}/{$current}/info_{$topic_body['id']}.html">查看更多</a></p>
				</div>
				<!-- /if -->
			</div>
			<div>
				<div id="focus" class="focus" >
					<div class="hd"><ul></ul></div>
					<div class="bd">
						<ul>
							<!-- foreach $list -->
							<li>
								<div><a href="{$url}" title="{$title}"><img src="{if empty($thumb)}/static/images/default.png{else}{fixsrc($thumb)}{/if}" ></a></div>
								<div class="title"><a href="{$url}" title="{$title}">{cut($title,30)}</a></div>
							</li>
							<!-- /foreach -->
						</ul>
					</div>
				</div>
				<script type="text/javascript">
					TouchSlide({
						slideCell: "#focus",
						titCell: ".hd ul",
						mainCell: ".bd ul",
						effect: "leftLoop",
						autoPlay: true,
						autoPage: "<li></li>",
						interTime: "3500",
					});
				</script>
			</div>
		</div>
		<div>
			{if !empty($list_baike)}
			<div class="index_baike">
				<div class="title">{$list_baike[0][bk_title]}百科</div>
				<div class="content">{cut($list_baike[0][bk_content],200,'...')}<a href="baike_{$list_baike[0][id]}.html" target="_blank">查看更多</a></div>
				<ul class="list_s cl">
					<!-- foreach $list_baike -->
					<!-- if $index>1 -->
					<li><a href="baike_{$id}.html" target="_blank">{$bk_title}</a></li>
					<!-- /if -->
					<!-- /foreach -->
				</ul>
			</div>
			{/if}
			<div class="article">
				<!-- foreach $topics -->
				<div class=" index_box ">
					<div class="title">
						<a href="{$pyurl}">{$title}</a>
						<div class="cl">
							<div class="fl red_border"></div><div class="fl gray_border"></div>
						</div>
					</div>
					<div >
						<ul >
							<!-- foreach $arclist -->
							<li>
								<a href="{$url}" target="_blank" title="{$title}">{$title}</a>
							</li>
							<!-- /foreach -->
						</ul>
					</div>
				</div>
				<!-- /foreach -->
			</div>
		</div>
		<div class="m_index_box" >
			<div class="block ">
				<div class="t_title">{$topic['title']} 常见问题</div>
				<div class="conlist">
					<!-- foreach $list_wenwen -->
					<div style="line-height:30px;overflow: hidden; height:30px;"><a href="question_{$id}.html">{$ww_title}？</a></div>
					<!-- /foreach -->
				</div>
			</div>
		</div>
		
	</div>
	<!-- include footer -->
</body>
</html>