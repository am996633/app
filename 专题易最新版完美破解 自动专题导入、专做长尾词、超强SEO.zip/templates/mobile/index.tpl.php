<?php if(!defined('IN_SYS')) exit('Access Denied'); ?>

<!DOCTYPE html>
<html>
<head>
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0, user-scalable=no" />
	<title>{$conf[siteName]}-{$conf[siteTitle]}手机版</title>
	<meta name="keywords" content="{$conf[keywords]}"/>
	<meta name="description" content="{$conf[description]}"/>
	<link type="text/css" rel="stylesheet" href="/static/css/m_common.css" />
	<link type="text/css" rel="stylesheet" href="/static/css/m_style.css" /> 
	<link rel="canonical" href="{$web_url}">
	<script type="text/javascript" src="/static/js/jquery.js"></script>
	<script type="text/javascript" src="/static/js/common.js"></script>
	<script type="text/javascript" src="/static/js/TouchSlide.1.1.js"></script>
	<script type="text/javascript" src="/static/js/plus.js"></script>
	<script type="text/javascript" src="/static/js/iscroll.js"></script>
</head>
<body>
	<!-- include header -->
	<div class="m_wrap" >
		<div id="focus" class="focus" >
			<div class="hd"><ul></ul></div>
			<div class="bd">
				<ul>
					<!-- foreach $list -->
					{if $index<=5}
					<li>
						<div><a href="{$url}" title="{$title}"><img src="{if empty($thumb)}/static/images/default.png{else}{fixsrc($thumb)}{/if}" ></a></div>
						<div class="title"><a href="{$url}" title="{$title}">{cut($title,30)}</a></div>
					</li>
					{/if}
					<!-- /foreach -->
				</ul>
			</div>
		</div>
		<script type="text/javascript">
			TouchSlide({
				slideCell: "#focus",
				titCell: ".hd ul",
				mainCell: ".bd ul",
				effect: "leftLoop",
				autoPlay: true,
				autoPage: "<li></li>",
				interTime: "3500",
			});
		</script>

		<div >
			<div class="m_index_box new_zt ">
				<div class="t_title">最新专题</div>
				<!--foreach $list_parent -->
				{if $index<=5}
				<div>
					<div class="mrt20">
						<div class="k_title">
							<div class=" m_title"><a href="{$pyurl}" >{$title}</a></div>
						</div>
					</div>
					<div class="cl">
						<div class="fl relative" >
							<!--foreach $list_article -->
							{if $index==1}
							<a href="{$pyurl}" target="_blank" title="{$title}"><img src="{if empty($thumb)}/static/images/default.png{else}{fixsrc($thumb)}{/if}" data-original="{fixsrc($thumb)}" width="150" height="110"></a>
							{/if}
							<!--/foreach -->
						</div>
						<div class="fl mrl20" >
							<div class="cl ">
								<!--foreach $list_topic -->
								<div class="index_child"><a href="{$pyurl}" target="_blank">{$title}</a></div>
								<!--/foreach -->
								
							</div>
						</div>
					</div>
				</div>
				{/if} 
				<!--/foreach -->
			</div>

			<div class="m_index_box new_zt ">
				<div class="t_title">百科知识</div>
				<div class="list_title2 cl">
					<ul>
						<!--  foreach $list_baike -->
						<li><a href='{$pyurl}baike_{$id}.html' target="_self">{$bk_title}</a></li>
						<!-- /foreach -->
					</ul>
				</div>
			</div>

			<div class="m_index_box new_zt ">
				<div class="r_title cl">
					<div class="fl div1 current tb_a ">热门文章</div>
					<div class="fr div1 tb_a border_left " >最新文章</div>
				</div>
				<div class="tbc_a">
					<div class="r_content">
						<ul>
							<!--foreach $list -->
							{if $index>10 && $index<=19}
							<li {if $index<=13}class="blue"{else}class="gray"{/if}><a href="{$url}" target="_blank">{$title}</a></li>
							{/if}
							<!--/foreach -->
						</ul>
					</div>
				</div>
				<div class="tbc_a">
					<div class="r_content">
						<ul>
							<!--foreach $list_new -->
							{if $index>1}
							<li {if $index<=4}class="blue"{else}class="gray"{/if}><a href="{$url}" target="_blank">{$title}</a></li>
							{/if}
							<!--/foreach -->
						</ul>
					</div>
				</div>
			</div>

			<div class="m_index_box new_zt ">
				<div class="t_title">友情链接</div>
				<div class="flink_con cl">
					<ul>
						<!-- foreach $flink  -->
						<li><a href="{$url}" target="_blank">{$sitename}</a></li>
						<!-- /foreach -->
					</ul>
				</div>
			</div>
		</div>
	</div>
	<!-- include footer -->
</body>
</html>