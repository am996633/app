<?php if(!defined('IN_SYS')) exit('Access Denied'); ?>

<!DOCTYPE html>
<html lang='zh-cn'>
<head>
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0, user-scalable=no" />
	<title>{$ww['ww_title']}-{$conf[siteName]}</title>
	<meta name="keywords" content="{$ww['ww_title']}"/>
	<meta name="description" content="{$ww['ww_title']}"/>
	<link type="text/css" rel="stylesheet" href="/static/css/m_common.css" />
	<link type="text/css" rel="stylesheet" href="/static/css/m_style.css" />
	<script type="text/javascript" src="/static/js/jquery.js"></script>
	<script type="text/javascript" src="/static/js/iscroll.js"></script>
	<link rel="canonical" href="{$web_url}">
</head>
<body>
	<!-- include header -->
	<div class="m_wrap" >
		<!-- include subnav -->
		<div  class="m_index_box">
			<div class="breadcrumb">
				<a href="/">{$conf[siteName]}</a> <a href="{$topic['pyurl']}">{$topic['title']}</a> {$ww['ww_title']}
			</div>
			<div class="fs_18">
				{$ww['ww_title']}
			</div>
		
			<div class="mainbody">{$ww['ww_content']}</div>
		</div>
		<div class="rightcon">
					<div  class="block hot_topic">
				<div class="caption"> 更多话题</div>
		</div>
	
		</div>
		<div style="clear: both;"></div>
	</div>
	<!-- include footer -->

</body>
</html>