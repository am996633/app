<?php if(!defined('IN_SYS')) exit('Access Denied'); ?>

<div class="nav cl" id="nav">
	<ul style="width:1000px;" class="cl">
		<li>
			{if isset($topic)}
			<?php $turl = explode("/", $topic['pyurl']);
			$turl = $turl[1]; 
			?>
			<a href="{$topic['pyurl']}" {if $current==$turl} class="current" {/if} >{$topic['title']}</a>
			{/if}
		</li>
		<!-- foreach $nav  -->
		<li><a href="{$pyurl}" {if $current==$pinyin} class="current" {/if}>{$title}</a></li>
		<!-- /foreach -->	
	</ul>
</div>

<script>
	$('.menubar').hide();
	$('.menu').show();
	$('.m_wrap').css('marginTop', $('.header_main').height() );
	var myscroll = new iScroll("nav", {snap:true, vScroll:false, hScroll: true, hScrollbar:false});
</script>
