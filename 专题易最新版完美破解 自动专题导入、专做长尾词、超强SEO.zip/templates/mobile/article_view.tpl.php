<?php if(!defined('IN_SYS')) exit('Access Denied'); ?>

<!DOCTYPE html>
<html>
<head>
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0, user-scalable=no" />
	<title>{$page['title']}-{$conf[siteName]}</title>
	<meta name="keywords" content="{$page[keywords]}"/>
	<meta name="description" content="{$page[description]}"/>
	<link type="text/css" rel="stylesheet" href="/static/css/m_common.css" />
	<link type="text/css" rel="stylesheet" href="/static/css/m_style.css" />
	<script type="text/javascript" src="/static/js/jquery.js"></script>
	<script type="text/javascript" src="/static/js/plus.js"></script>
	<script type="text/javascript" src="/static/js/iscroll.js"></script>
	<link rel="canonical" href="{$web_url}">
</head>
<body>
	<!-- include header -->
	<div class="m_wrap" >
		<!-- include subnav -->
		<div  class="m_index_box article_view">
			<div class="breadcrumb">
				<a href="/" class="home_ico">{$conf[siteName]}</a> <a href="{$topic['pyurl']}">{$topic['title']}</a> 文章正文
			</div>
			<div class="fs_18 arctitle">
				<h1>{$page['title']}</h1>
			</div>
			
			<div class="mainbody">{$page['body']}</div>

			<div class="zeren">
				<span>版权声明</span>
				<div>1.本网站所转载的作品，目的在于传递更多信息，并不代表本网站赞同其观点和对其真实性负责。</div>
				<div>2.如因作品内容，版权和其他问题需要同本网站联系的，请邮件联系我们support@email.thinkincloud.cn</div>
			</div>

		</div>
		<div class="m_index_box new_zt ">
			<div class="r_title cl">
				<div class="fl div1 current tb_a ">热门文章</div>
				<div class="fr div1 tb_a border_left " >最新文章</div>
			</div>
			<div class="tbc_a">
				<div class="r_content">
					<ul>
						<!--foreach $list_hot -->
						
						<li {if $index<=4}class="blue"{else}class="gray"{/if}><a href="{$url}" target="_blank">{cut($title,30,'...')}</a></li>
						
						<!--/foreach -->
					</ul>
				</div>
			</div>
			<div class="tbc_a">
				<div class="r_content">
					<ul>
						<!--foreach $list_new -->
						
						<li {if $index<=4}class="blue"{else}class="gray"{/if}><a href="{$url}" target="_blank">{cut($title,30,'...')}</a></li>
						
						<!--/foreach -->
					</ul>
				</div>
			</div>
		</div>
		
	</div>
	<!-- include footer -->

</body>
</html>