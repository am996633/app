<?php if(!defined('IN_SYS')) exit('Access Denied'); ?>
<!DOCTYPE html>
<html>
<head>
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0, user-scalable=no" />
	<title>{$topic_child['title']}_{$topic['title']}专题 - {$conf[siteName]}</title>
	<meta name="keywords" content="{$topic_child['title']},{$topic['title']}"/>
	<meta name="description" content="关于{$topic['title']}的{$topic_child['title']}相关信息。"/>
	<link type="text/css" rel="stylesheet" href="/static/css/m_common.css" />
	<link type="text/css" rel="stylesheet" href="/static/css/m_style.css" />
	<script type="text/javascript" src="/static/js/jquery.js"></script>
	<script type="text/javascript" src="/static/js/TouchSlide.1.1.js"></script>
	<script type="text/javascript" src="/static/js/iscroll.js"></script>
	<link rel="canonical" href="{$web_url}">
</head>
<body>
	<!-- include header -->
	<div class="m_wrap " >
		<!-- include subnav -->
		<div class="m_index_box topic">
			<div class="breadcrumb">
				<a href="/">{$conf[siteName]}</a> {$topic_child['title']}
			</div>
			<div class="info">
				<div class="topictit"><h1>{$topic['title']}</h1></div>
				<!-- if $topic_body['body'] -->
				<div class="topicbody">
					<p>{cut($topic_body['desc'],150,'...')}</p>
					<p>{cut($topic_body['body'],190,'...')} <a href="/{$index_url}/{$current}/info_{$topic_body['id']}.html">查看更多</a></p>
				</div>
				<!-- /if -->
			</div>
			<div id="focus" class="focus" >
				<div class="hd"><ul></ul></div>
				<div class="bd">
					<ul>
						<!-- foreach $list -->
						<li>
							<div><a href="{$url}" title="{$title}"><img src="{if empty($thumb)}/static/images/default.png{else}{fixsrc($thumb)}{/if}" ></a></div>
							<div class="title"><a href="{$url}" title="{$title}">{cut($title,30)}</a></div>
						</li>
						<!-- /foreach -->
					</ul>
				</div>
			</div>
			<script type="text/javascript">
				TouchSlide({
					slideCell: "#focus",
					titCell: ".hd ul",
					mainCell: ".bd ul",
					effect: "leftLoop",
					autoPlay: true,
					autoPage: "<li></li>",
					interTime: "3500",
				});
			</script>
		</div>

		{if !empty($list_baike)}
		<div class="index_baike">
			<div class="title">{$list_baike[0][bk_title]}百科</div>
			<div class="content">{cut($list_baike[0][bk_content],200,'...')}<a href="baike_{$list_baike[0][id]}.html" target="_blank">查看更多</a></div>
			<ul class="list_s cl">
				<!-- foreach $list_baike -->
				<!-- if $index>1 -->
				<li><a href="baike_{$id}.html" target="_blank">{$bk_title}</a></li>
				<!-- /if -->
				<!-- /foreach -->
			</ul>
		</div>
		{/if}
		
		<div  class="block  m_index_box">
			<div class="t_title">{$topic_child['title']} 常见问题</div>
			<div class="conlist">
				<!-- foreach $list_wenwen -->
				<div style="line-height:30px;overflow: hidden; height:30px;"><a href="/{$index_url}/{$current}/question_{$id}.html">{$ww_title}？</a></div>
				<!-- /foreach -->
			</div>
		</div>

	</div>

	<!-- include footer -->
</body>
</html>