<?php if(!defined('IN_SYS')) exit('Access Denied'); ?>
<!DOCTYPE html>
<html>
<head>
	<meta charset='utf-8' />
	<title>{$topic['title']}专题_{$topic['title']}的最新消息 - {$conf[siteName]}</title>
	<meta name="keywords" content="{$topic['title']}专题，{$topic['title']}的最新消息"/>
	<meta name="description" content="{$conf[siteName]}整理了有关{$topic['title']}的相关报道，收集{$topic['title']}的最新消息并持续追踪后续报道。"/>
	<link type="text/css" rel="stylesheet" href="/static/css/reset.css" />
	<link type="text/css" rel="stylesheet" href="/static/css/common.css" />
	<link type="text/css" rel="stylesheet" href="/static/css/style.css" />
	<script type="text/javascript" src="/static/js/jquery.js"></script>
	<script type="text/javascript" src="/static/js/common.js"></script>
	<script type="text/javascript" src="/static/js/plus.js"></script>
	<script src="/static/js/jquery.SuperSlide.2.1.1.js"></script>
	<!-- include system/mobile_agent -->
</head>
<body>
	<!-- include header -->
	<div class="wrap " >
		<div class="main_index cl">
			<div class="fl lf_con">
				<div class="topic_title"><h1>{$topic['title']}</h1></div>
				<!-- if $topic_body['body'] -->
				<div class="line_hg">{cut($topic_body['body'],210,'...')} <a href="info_{$topic_body['id']}.html" >查看更多</a></div>
				<!-- /if -->
				<div class="list_title1" >
					<ul>
						<!-- foreach $list -->
						<li {if $index==1}class="title"{/if} >
							<a href="{$url}" target="_blank">{$title}</a>
						</li>
						<!-- /foreach -->
					</ul>
				</div>
			</div>
			<div class="fl lm_con" >
				<div id="slideBox" class="slideBox">
					<div class="hd">
						<ul>
							<!--foreach $slidelist -->
							<li></li>
							<!--/foreach-->
						</ul>
					</div>
					<div class="bd">
						<ul>
							<!--foreach $slidelist -->
							<li>
								<div><a href="{$url}" title="{$title}"><img src="{fixsrc($thumb)}" height="260" width="390"></a></div>
								<div class="txt-bg"></div>
								<div class="txt"><a href="{$url}" title="{$title}">{cut($title,30)}</a></div>
							</li>
							<!--/foreach-->
						</ul>
					</div>
				</div>
				<script type="text/javascript">
					jQuery(".slideBox").slide({mainCell:".bd ul",effect: "leftLoop",interTime: "4000",autoPlay:true});
				</script>
				<div class="pdt5 desc">{cut($topic_body['desc'],150,'...')} </div>
			</div>
			<div  class="fr lr_con">
				<div class="title">网友评价</div>
				<div class="cl">
					<div class="fl"><img src="/static/images/zheng.png" align="middle">{$topic['positive']}%</div>
					<div class="fl"><img src="/static/images/fu.png" align="middle">{$topic['negative']}%</div>
				</div>
				<div class="title mrtt20">最新专题</div>
				<ul>
					<!-- sql select * from topic where flag = 1 AND status=1 order by id desc limit 5-->
					<li class="content"><a href="{$pyurl}">{$title}</a></li>
					<!--/sql -->
				</ul>
			</div>
		</div>
		<div class="cl">
			<div  class="leftcon">
				<!--if !empty($list_baike)-->
				<div class="index_baike">

					<div class="title">{$list_baike[0][bk_title]}百科知识</div>
					<div class="content">{cut($list_baike[0][bk_content],200,'...')}<a href="baike_{$list_baike[0][id]}.html" >查看更多</a></div>

					<ul class="list_s">
						<!-- foreach $list_baike -->
						<!-- if $index>1 -->
						<li><a href="baike_{$id}.html" >{$bk_title}</a></li>
						<!-- /if -->
						<!-- /foreach -->
					</ul>
				</div>
				<!-- /if -->
				<div class="article cl">
					<!-- foreach $topics -->
					<div class="{if $index%2==0}fr{else}fl{/if} index_box ">
						<div class="title">
							<a href="{$pyurl}" target="_blank">{$title}</a>
							<div class="cl">
								<div class="fl red_border"></div><div class="fr gray_border"></div>
							</div>
						</div>
						<ul>
							<!-- foreach $arclist -->
							{if $index==1}
							<li>
								<a href="{$url}" target="_blank" title="{$title}">{cut($title,40,'...')}</a>
								<div class="art_desc">{cut($description,60,'...')}</div>
							</li>
							{else}
							<li>
								<a href="{$url}" target="_blank" title="{$title}">{cut($title,38,'...')}</a>
							</li>
							{/if}
							<!-- /foreach -->
						</ul>
					</div>
					<!-- /foreach -->
				</div>
			</div>
			<div class="rightcon" >
				<div  class="block hot_topic">

					<!-- if !empty($list_wenwen) -->
					<div class="wenwen_box">
						<div class="caption">常见问题</div>
						<div class="conlist">
							<!-- foreach $list_wenwen -->
							<div class="index_wenwen"><a href="question_{$id}.html">{$ww_title}？</a></div>
							<!-- /foreach -->
						</div>
					</div>
					<!-- /if -->

					<!-- if !empty($list_weibo) -->
					<div class="weibo_box">
						<div class="caption">微博讨论</div>
						<!-- foreach $list_weibo -->
						<div class="cl mrt10" >
							<div class="fl"><img src="{$face}" ></div>
							<div class="fl wb_name" >
								<div class="name_color">{$name}</div>
								<div class="hg_con">{$content}</div>
							</div>
						</div>
						<!--/foreach -->
					</div>
					<!-- /if -->
					
				</div>
			</div>
		</div>
	</div>
	<div class="lr_arrow">
		<!-- if $left_arrow -->
		<div class="post-prev"><a href="{$left_arrow[pyurl]}">&lt;</a></div>
		<!-- /if -->
		<!-- if $right_arrow -->
		<div class="post-next"><a href="{$right_arrow[pyurl]}">&gt;</a></div>
		<!-- /if -->
	</div>
	<!-- include footer -->
</body>
</html>