<?php if(!defined('IN_SYS')) exit('Access Denied'); ?>

<!-- //社会化分享 -->
<div id="bdshare" class="bdsharebuttonbox" data-tag="share_2">
	<a href="#" class="bds bds_tsina" data-cmd="tsina" title="分享到新浪微博"></a>
	<a href="#" class="bds bds_tqq" data-cmd="tqq" title="分享到腾讯微博"></a>
	<a href="#" class="bds bds_renren" data-cmd="renren" title="分享到人人网"></a>
	<a href="#" class="bds bds_douban" data-cmd="douban" title="分享到豆瓣网"></a>
	<a href="#" class="bds bds_weixin" data-cmd="weixin" title="分享到微信"></a>
	<a href="#" class="bds bds_more" data-cmd="more"></a>
	<a class="bds_count" data-cmd="count"></a>
</div>
<script>
	window._bd_share_config={
		"common":{
			"bdSnsKey":{},
			"bdMini":"2",
			"bdMiniList":false,
			"bdStyle":"0",
			"bdText":"【{$page[title]}】（来自:{$conf[siteName]}）",
			"bdUrl": location.href
		},
		"share" : [{
			"tag" : "share_1",
			"bdSize" : "16"
		},{
			"tag" : "share_2",
			"bdSize" : "32"
		}]
	};
	with(document)0[(getElementsByTagName('head')[0]||body).appendChild(createElement('script')).src='http://bdimg.share.baidu.com/static/api/js/share.js?v=89860593.js?cdnversion='+~(-new Date()/36e5)];
</script>