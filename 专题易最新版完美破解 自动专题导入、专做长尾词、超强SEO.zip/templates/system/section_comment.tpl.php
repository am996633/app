<?php if(!defined('IN_SYS')) exit('Access Denied'); ?>

<!-- //在线评论 -->
<div id="uyan_frame"></div>
<!-- //猜你喜欢 -->
<div class="ujian-hook"></div>

<script type="text/javascript">var ujian_config = {num:10,showType:3,target:1,bgColor:'#',mouseoverColor:'#EFEFEF'};</script>
<script type="text/javascript" src="http://v2.uyan.cc/code/uyan.js?uid=1725651"></script>		
<script type="text/javascript" src="http://v1.ujian.cc/code/ujian.js?uid=1725651"></script>
