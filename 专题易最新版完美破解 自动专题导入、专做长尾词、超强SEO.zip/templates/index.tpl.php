<?php if(!defined('IN_SYS')) exit('Access Denied'); ?>
<!DOCTYPE html>
<html>
<head>
	<meta charset='utf-8' />
	<title>{$conf[siteName]}-{$conf[siteTitle]}</title>
	<meta name="keywords" content="{$conf[keywords]}"/>
	<meta name="description" content="{$conf[description]}"/>
	<link type="text/css" rel="stylesheet" href="/static/css/reset.css" />
	<link type="text/css" rel="stylesheet" href="/static/css/common.css" />
	<link type="text/css" rel="stylesheet" href="/static/css/style.css" />
	<script type="text/javascript" src="/static/js/jquery.js"></script>
	<script type="text/javascript" src="/static/js/common.js"></script>
	<script type="text/javascript" src="/static/js/jquery.SuperSlide.2.1.1.js"></script>
	<script type="text/javascript" src="/static/js/jquery.lazyload.min.js"></script>
	<script type="text/javascript" src="/static/js/plus.js"></script>
	<!-- include system/mobile_agent -->
</head>
<body>
	<div class="adbox">
		<div class="wrap">
			<!-- tag::ad(1) -->
		</div>
	</div> 
	<!-- include subnav -->
	<div class="adbox" style="padding-top:0;">
		<div class="wrap">
			<!-- tag::ad(3) -->
		</div>
	</div>
	<div class="wrap index_topic">
		<div  class="tpc2">
			<div class="cl">
				<div class="fl"><img src="/static/images/pic4.jpg" ></div>
				<div class="fl w1020" >
					<ul class="cl">
						<!-- foreach $list_parent -->
						<li ><a href="/{$pinyin}/" target="_blank">{$title}</a></li>
						<!--/foreach -->
					</ul>
				</div>
			</div>
		</div>
	</div>
	<div class="wrap">
		<div class="toutiao">
			<!--foreach $list -->
			{if $index==1}
			<a href="{$url}">{$title}</a>
			{/if}
			<!--/foreach-->
		</div>
	</div>
	<div class="wrap ">
		<div class="cl index1_1">
			<div class="fl">
				<div id="indexBox" class="indexBox">
					<div class="hd">
						<ul><li></li><li></li><li></li><li></li><li></li></ul>
					</div>
					<div class="bd">
						<ul>
							<!--foreach $list -->
							{if $index>1 && $index<=6}
							<li>
								<div><a href="{$url}" title="{$title}"><img src="{fixsrc($thumb)}" height="360" width="545"></a></div>
								<div class="txt-bg"></div>
								<div class="txt"><a href="{$url}" title="{$title}">{cut($title,30)}</a></div>
							</li>
							{/if}
							<!--/foreach-->
						</ul>
					</div>
				</div>
				<script type="text/javascript">
					jQuery(".indexBox").slide({mainCell:".bd ul",effect: "leftLoop",interTime: "4000",autoPlay:true});
				</script>
			</div>
			<div class="fl art3" >
				<!--foreach $list -->
				{if $index>6 && $index<=9}
				<div class="con_boder">
					<div class="title"><a href="{$url}" target="_blank">{$title}</a></div>
					<div class="content">{cut($description,180,'...')}</div>
				</div>
				{/if}
				<!--/foreach-->
			</div>
		</div>
	</div> 
	<div class="wrap cl index2">
		<div class="leftcon">
			<!--foreach $list_parent -->
			{if $index<=10}
			<div>
				<div class="mrt20">
					<div class="k_title">
						<div class=" m_title"><a href="{$pyurl}" >{$title}</a></div>
					</div>
				</div>
				<div class="cl">
					<div class="fl relative" >
						<!--foreach $list_article -->
						{if $index==1}
						<a href="{$pyurl}" target="_blank" title="{$title}"><img src="/static/images/deflogo.png" data-original="{if empty($thumb)}/static/images/default.png{else}{fixsrc($thumb)}{/if}" width="325" height="250"></a>
						{/if}
						<!--/foreach -->
					</div>
					<div class="fl art2" >
						<!--foreach $list_article -->
						{if $index==2}
						<div class="l_title"><a href="{$url}" target="_blank">{cut($title,40,'...')}</a></div>
						<div class="l_content">{cut($description,120,'...')}</div>
						{elseif $index>2}
						<div class="title_child"><a href="{$url}" target="_blank">.{cut($title,40,'...')}</a></div>
						{/if}
						<!--/foreach -->
						<div class="cl index_child">
							<!--foreach $list_topic -->
							{if $index%2==0}
							<div class="fr"><a href="{$pyurl}" target="_blank">{$title}</a></div>
							{else}
							<div class="fl"><a href="{$pyurl}" target="_blank">{$title}</a></div>
							{/if}
							<!--/foreach -->
						</div>
					</div>
				</div>
			</div>
			{/if} 
			<!--/foreach -->
		</div>
		<div class="rightcon">
			<div class="r_title cl">
				<div class="fl div1 current tb_a ">热门文章</div>
				<div class="fr div1 tb_a border_left " >最新文章</div>
			</div>
			<div class="tbc_a">
				<!--foreach $list -->
				{if $index==10}
				<div class="cl" >
					<div class="fl">
						<a href="{$url}" target="_blank" title="{$title}" >
							<img src="{if empty($thumb)}/static/images/default.png{else}{fixsrc($thumb)}{/if}" width="120" height="90">
						</a>
					</div>
					<div class="fl mrl20" >
						<div><a href="{$url}" target="_blank" title="{$title}" >{cut($title,20,'...')}</a></div>
						<div class="w150">{cut($description,60,'...')}</div>
					</div>
				</div>
				{/if}
				<!--/foreach -->
				<div class="r_content">
					<ul>
						<!--foreach $list -->
						{if $index>10 && $index<=19}
						<li {if $index<=13}class="blue"{else}class="gray"{/if}><a href="{$url}" target="_blank">{$title}</a></li>
						{/if}
						<!--/foreach -->
					</ul>
				</div>
			</div>
			<div class="tbc_a">
				<!--foreach $list_new -->
				{if $index==1}
				<div class="cl" >
					<div class="fl">
						<a href="{$url}" target="_blank" title="{$title}" >
							<img src="{if empty($thumb)}/static/images/default.png{else}{fixsrc($thumb)}{/if}" width="120" height="90">
						</a>
					</div>
					<div class="fl mrl20" >
						<div><a href="{$url}" target="_blank" title="{$title}" >{cut($title,20,'...')}</a></div>
						<div class="w150">{cut($description,60,'...')}</div>
					</div>
				</div>
				{/if}
				<!--/foreach -->
				<div class="r_content">
					<ul>
						<!--foreach $list_new -->
						{if $index>1}
						<li {if $index<=4}class="blue"{else}class="gray"{/if}><a href="{$url}" target="_blank">{$title}</a></li>
						{/if}
						<!--/foreach -->
					</ul>
				</div>
			</div>
			
			<div id="fix_top">
				<div class="cl">
					<div class="i_baike fl">百科知识</div>
					<div class="i_baike1 fl"></div>
				</div>
				<div class="bk_con"  >
					<!--foreach $list_baike -->
					<div><a href="{$pyurl}baike_{$id}.html"><span>{$index}</span>{$bk_title}</a></div>
					<!--/foreach -->
				</div>
			</div>

		</div>
	</div>
	<div class="wrap">
		<div class="flink">
			<div class="caption">友情链接</div>
			<div class="flink_con cl">
				<ul>
					<!-- foreach $flink  -->
					<li><a href="{$url}" target="_blank">{$sitename}</a></li>
					<!-- /foreach -->
				</ul>
			</div>
		</div>
	</div>
	<!-- include footer -->
	<script>
		$(function() {
			$("img").lazyload({
				effect: "fadeIn",
				threshold: 200,
				failure_limit : 6,
				skip_invisible : false,
				placeholder : '/static/images/loading.gif',
			});
		});
	</script>
</body>
</html>