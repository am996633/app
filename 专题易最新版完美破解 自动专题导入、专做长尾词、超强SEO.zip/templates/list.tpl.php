<?php if(!defined('IN_SYS')) exit('Access Denied'); ?>
<!DOCTYPE html>
<html>
<head>
	<meta charset='utf-8' />
	<title>最新专题-{$conf[siteName]}</title>
	<meta name="keywords" content="{$conf[keywords]}"/>
	<meta name="description" content="{$conf[description]}"/>
	<link type="text/css" rel="stylesheet" href="/static/css/reset.css" />
	<link type="text/css" rel="stylesheet" href="/static/css/common.css" />
	<link type="text/css" rel="stylesheet" href="/static/css/style.css" />
	<script type="text/javascript" src="/static/js/jquery.js"></script>
	<script type="text/javascript" src="/static/js/common.js"></script>
	<script type="text/javascript" src="/static/js/jquery.lazyload.min.js"></script>
	<script type="text/javascript" src="/static/js/plus.js"></script>
	<!-- include system/mobile_agent -->
</head>
<body>
	<!-- include header -->
	<div class="page wrap index2 cl" >
		<div  class="leftcon zt">
			<div class="breadcrumb">
				<a href="/" class="home_ico">{$conf[siteName]}</a> 最新专题
			</div>
			<!--foreach $list -->
			<div class="cl relative" >
				<div class="fl circle " >
					<span>{date('m月d日',$addtime)}</span>
					<label>{date('H:i:s',$addtime)}</label>
					<img src="/static/images/circle.png">
				</div>
				<div class="fl border_circle"  >
					<div class="mrb20" >
						<div class="k_title ">
							<div class=" m_title "><a href="{$pyurl}" >{$title}</a></div>
						</div>
					</div>
					<div class="cl"> 
						<div class="fl relative" >
							<!--foreach $list_article -->
							{if $index==1}
							<a href="{$pyurl}" target="_blank" title="{$title}"><img src="/static/images/deflogo.png" data-original="{fixsrc($thumb)}" width="209" height="158"></a>
							{/if}
							<!--/foreach -->
						</div>
						<div class="fl list_article" >
							<!--foreach $list_article -->
							{if $index==2}
							<div class="l_title"><a href="{$url}" target="_blank">{cut($title,40,'...')}</a></div>
							<div class="l_content">{cut($description,120,'...')}</div>
							{elseif $index>2}
							<div class="title_child"><a href="{$url}" target="_blank">.{cut($title,40,'...')}</a></div>
							{/if}
							<!--/foreach -->
						</div>
					</div>
				</div>
			</div>
			<!--/foreach -->
			<div class="page_link">{$page}</div>
		</div>
		<div class="rightcon">
			<div id="fix_top">
				<div class="r_title cl">
					<div class="fl div1 current tb_a ">热门专题</div>
					<div class="fr div1 tb_a border_left " >随机推荐</div>
				</div>
				<div class="tbc_a bg_a">
					<div class="cl">
						<!--foreach $list_hot -->
						<a href="{$pyurl}" title="{$title}">{$title}</a>
						<!--/foreach -->
					</div>
				</div>
				<div class="tbc_a bg_a" style="display:none;">
					<!--foreach $list_rand -->
					<a href="{$pyurl}" title="{$title}">{$title}</a>
					<!--/foreach -->
				</div>
			</div>
		</div>

	</div>
	<!-- include footer -->
	<script>
		$(function() {
			$("img").lazyload({
				effect: "fadeIn",
				threshold: 200,
				placeholder : '/static/images/loading.gif',
			});
		});
	</script>
</body>
</html>
