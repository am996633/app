<?php if(!defined('IN_SYS')) exit('Access Denied'); ?>
<!DOCTYPE html>
<html>
<head>
	<meta charset='utf-8' />
	<title>文章列表-{$conf[siteName]}</title>
	<link type="text/css" rel="stylesheet" href="/static/css/reset.css" />
	<link type="text/css" rel="stylesheet" href="/static/css/common.css" />
	<link type="text/css" rel="stylesheet" href="/static/css/style.css" />
	<script type="text/javascript" src="/static/js/jquery.js"></script>
	<script type="text/javascript" src="/static/js/common.js"></script>
	<script type="text/javascript" src="/static/js/jquery.lazyload.min.js"></script>
	<script type="text/javascript" src="/static/js/plus.js"></script>
	<!-- include system/mobile_agent -->
</head>
<body>
	<!-- include header -->
	<div class="page wrap cl">
		<div class="leftcon arclist">
			<div class="breadcrumb">
				<a href="/" class="home_ico">{$conf[siteName]}</a> 最新文章
			</div>
			<!--foreach $list -->
			<div class="cl list_title" >
				<div class="fl">
					<a href="{$url}" target="_blank"><img src="/static/images/deflogo.png" data-original="{fixsrc($thumb)}" width="201" height="160" /></a>
				</div>
				<div class="fl descr" >
					<div class="tit"><a href='{$url}' target="_blank" >{$title}</a></div>
					<div class="desc_txt">{cut($description,150,'...')}</div>
				</div>
				<div class="fr date_time" >
					<div class="zan_click"><span>{$click}</span></div>
					<div class="date_txt">{date('m-d H:i',$addtime)}</div>
				</div>
			</div>
			<!-- /foreach -->
			<div class="page_link">{$pagelink}</div>
		</div>
		<div class="rightcon index2">
			<div id="fix_top">
				<div class="r_title cl">
					<div class="fl div1 current tb_a ">热门文章</div>
					<div class="fr div1 tb_a border_left " >最新文章</div>
				</div>
				<div class="tbc_a">
					<!--foreach $list_hot -->
					{if $index==1}
					<div class="cl" >
						<div class="fl">
							<a href="{$url}" target="_blank" title="{$title}">
								<img src="{if empty($thumb)}/static/images/default.png{else}{fixsrc($thumb)}{/if}" width="120" height="90">
							</a>
						</div>
						<div class="fl mrl20" >
							<div><a href="{$url}" target="_blank" title="{$title}" >{cut($title,20,'...')}</a></div>
							<div class="w150">{cut($description,60,'...')}</div>
						</div>
					</div>
					{/if}
					<!--/foreach -->
					<div class="r_content">
						<ul>
							<!--foreach $list_hot -->
							{if $index>1}
							<li {if $index<=4}class="blue"{else}class="gray"{/if}><a href="{$url}" target="_blank">{$title}</a></li>
							{/if}
							<!--/foreach -->
						</ul>
					</div>
				</div>
				<div class="tbc_a">
					<!--foreach $list_new -->
					{if $index==1}
					<div class="cl" >
						<div class="fl">
							<a href="{$url}" target="_blank" title="{$title}" >
								<img src="{if empty($thumb)}/static/images/default.png{else}{fixsrc($thumb)}{/if}" width="120" height="90">
							</a>
						</div>
						<div class="fl mrl20" >
							<div><a href="{$url}" target="_blank" title="{$title}" >{cut($title,20,'...')}</a></div>
							<div class="w150">{cut($description,60,'...')}</div>
						</div>
					</div>
					{/if}
					<!--/foreach -->
					<div class="r_content">
						<ul>
							<!--foreach $list_new -->
							{if $index>1}
							<li {if $index<=4}class="blue"{else}class="gray"{/if}><a href="{$url}" target="_blank">{$title}</a></li>
							{/if}
							<!--/foreach -->
						</ul>
					</div>
				</div>
			</div>
		</div>
	</div>
	<!-- include footer -->
	<script>
		$(function() {
			$("img").lazyload({
				effect: "fadeIn",
				threshold: 200,
				placeholder : '/static/images/loading.gif',
			});
		});
	</script>
</body>
</html>