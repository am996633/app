<?php if(!defined('IN_SYS')) exit('Access Denied'); ?>
<!DOCTYPE html>
<html>
<head>
	<meta charset='utf-8' />
	<title>{$bk['bk_title']}-{$conf[siteName]}</title>
	<meta name="keywords" content="{$bk['bk_title']}"/>
	<meta name="description" content="{$bk['bk_title']}"/>
	<link type="text/css" rel="stylesheet" href="/static/css/reset.css" />
	<link type="text/css" rel="stylesheet" href="/static/css/common.css" />
	<link type="text/css" rel="stylesheet" href="/static/css/style.css" />
	<script type="text/javascript" src="/static/js/jquery.js"></script>
	<script type="text/javascript" src="/static/js/common.js"></script>
	<!-- include system/mobile_agent -->
</head>
<body>
	<!-- include header -->
	<div class="page wrap cl" >
		<div  class="leftcon">
			<div class="breadcrumb">
				<a href="/">{$conf[siteName]}</a> <a href="{$topic['pyurl']}">{$topic['title']}</a> {$bk['bk_title']}
			</div>

			<div class="title">
				<h1>{$bk['bk_title']}</h1>
			</div>
			<div class="share cl">
				<span></span>
			</div>
			<div class="mainbody">{$bk['bk_content']}</div>
		</div>
		<div class="rightcon">
			<div  class="block">
				<div class="caption">{$topic['title']} 百科知识</div>
				<div class="conlist">
					<!-- foreach $list_baike -->
					<div class="pdt5"><a href="baike_{$id}.html">{$bk_title}？</a></div>
					<!-- /foreach -->
				</div>
			</div>
		</div>
	</div>
	<!-- include footer -->
</body>
</html>
