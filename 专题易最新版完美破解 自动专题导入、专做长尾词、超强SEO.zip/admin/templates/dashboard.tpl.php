<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta name="renderer" content="webkit">
	<meta http-equiv="X-UA-Compatible" content="IE=edge" />
	<meta name="viewport" content="width=device-width, minimum-scale=1, maximum-scale=1, user-scalable=no">
	<title>专题易 © 2016 ThinkInCloud</title>
	<link rel="stylesheet" type="text/css" href="__APPROOT__/css/dashboard.css" />
	<script type="text/javascript" src="/static/js/jquery.js"></script>
	<script type="text/javascript" src="__APPROOT__/js/common.js"></script>
</head>
<body>
	<!-- include header -->
	<div class="cp-wrap dashboard">
		<div class="welcome">您好,{$user[username]} ,欢迎回来！</div>
		<!-- if empty($conf[appid]) -->
		<div class="hometip">
			<span>您的网站尚未完成配置，请先填写激活信息 <a href="?m=system&a=bind">点击这里完成激活</a></span>
		</div>
		<!-- /if -->
		<div class="tip-box rewritetip" style="display:none;">
			伪静态未设置完成，网站可能无法访问，请检查服务器是否配置正确。客服QQ：800190900
		</div>
		<div class="cl">
			<div class="box">
				<div class="box-title">系统信息</div>
				<div class="box-content">
					<p><span>服务器：</span>{php_uname('s')}</p>
					<p><span>内存限制：</span>{$memory_limit}</p>
					<p><span>剩余空间：</span>{$free_space}</p>
					<p><span>系统时间：</span>{date("Y-m-d H:i:s")}</p>
				</div>
			</div>
			<div class="box">
				<div class="caption"></div>
				<div class="box-title">最新通知</div>
				<div class="box-content">
					暂无通知
				</div>
			</div>
		</div>
		<div class="kefu"></div>
	</div>
	<!-- include footer -->
	<!-- 用于系统更新紧急安全提示等，建议不要删除 -->
	<script type="text/javascript" src="{echo REMOTEAPI}/service?host={$_SERVER[HTTP_HOST]}&softversion={$conf[softversion]}&server={urlencode(php_uname('s'))}&memory={$memory_limit}&space={urlencode($free_space)}&servertime={time()}"></script>
	<script>
		$.ajax({
			url:'../sitemap.xml',
			success:function(){

			},
			error:function(){
				$('.rewritetip').show();
			}
		});
	</script>
</body>
</html>