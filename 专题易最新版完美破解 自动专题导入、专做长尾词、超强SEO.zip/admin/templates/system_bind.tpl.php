<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta name="renderer" content="webkit">
	<meta http-equiv="X-UA-Compatible" content="IE=edge" />
	<meta name="viewport" content="width=device-width, minimum-scale=1, maximum-scale=1, user-scalable=no">
	<title>专题易 © 2016 ThinkInCloud</title>
	<link rel="stylesheet" type="text/css" href="__APPROOT__/css/dashboard.css" />
	<script type="text/javascript" src="/static/js/jquery.js"></script>
	<script type="text/javascript" src="__APPROOT__/js/common.js"></script>
</head>
<body>
	<!-- include header -->
	<div class="cp-wrap">
		<div class="crumb"></div>
		<div class="cp-form">
			<div class="box">
				<div class="box-title">站点激活</div>
				<form method="POST" action="?m=system&a=bind">
					<div class="tip" style="margin:10px 130px; padding:5px; width:500px;border:dotted 1px #ccc;">
						请登录授权绑定的账号，还没有购买授权<a href="http://www.liuliangshenqi.com.cn" target="_blank">点击这里购买</a>
					</div>
					<div class="control-group">
						<label class="control-label" for="name">授权账号：</label>
						<div class="controls">
							<input type="text" class="input-xlarge focused" name="username" style="width:450px;">
						</div>
					</div>
					<div class="control-group">
						<label class="control-label" for="name">密码：</label>
						<div class="controls">
							<input type="password" class="input-xlarge focused" name="password" style="width:450px;">
							<input type="password" style="position:fixed;bottom:-9999px;"> <!-- 用于禁止密码填充 -->
						</div>
					</div>
					<div class="form-actions">
						<input type="submit" class="btn" value="下一步" />
						<input type="button" class="btn btn-link" value="返回" onclick="history.back(-1)"/>
					</div>
				</form>	
			</div>
		</div>
	</div>
	<!-- include footer -->
	<script>

	</script>
</body>
</html>