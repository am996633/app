<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta name="renderer" content="webkit">
	<meta http-equiv="X-UA-Compatible" content="IE=edge" />
	<meta name="viewport" content="width=device-width, minimum-scale=1, maximum-scale=1, user-scalable=no">
	<title>专题易 © 2016 ThinkInCloud</title>
	<link rel="stylesheet" type="text/css" href="__APPROOT__/css/dashboard.css" />
	<script type="text/javascript" src="/static/js/jquery.js"></script>
	<script type="text/javascript" src="/static/js/jquery.json-2.2.min.js"></script>
	<script type="text/javascript" src="/static/js/web.js"></script>
	<script type="text/javascript" src="__APPROOT__/js/common.js"></script>
	<style type="text/css">
		.keyword_type{ display:inline-block; padding:1px 2px; width:80px; overflow: hidden; text-align: center; }
		.keyword_type a{ border:solid 1px #dfdfdf; display: block; height: 30px; line-height: 30px; }
		.keyword_type .sel{ display: block; border:solid 1px #0092DC; background: #0092DC; color:#fff !important; }
		.sub_keyword{ margin-top: 20px; }
	</style>
</head>
<body>
	<!-- include header -->
	<div class="cp-wrap">
		<div class="crumb"></div>
		<div class="cp-table-top">	
		</div>
		<div class="cp-table" >
			
			<div style="font-size:18px; padding-bottom:20px;">分类筛选：</div>
			<div class="keyword_type">
				<a href="javascript:void(0);" onclick="keywords('', 0)" class="" id="cate_id">全部</a>
			</div>
			<!-- foreach $list_type $v-->
			<div class="keyword_type">
				<a href="javascript:void(0);" onclick="keywords({$v['id']}, 0)" class="" id="cate_id_{$v['id']}">{$v['typename']}</a>
			</div>
			<!--/foreach -->
			<div id="keyword"></div>
		</div>
	</div>
	<!-- include footer -->
	<script type="text/javascript">
		function keywords(catecagory_id, page){
			$(".keyword_type a").removeClass();
			$.ajax({
				url: "?m=keyword&a=getKeywordList", 
				type:"POST",
				data: {step:"ajax",catecagory_id:catecagory_id,page:page},
				success: function(data){
					$("#keyword").html(data);
					$("#cate_id_"+catecagory_id).addClass("sel");
					if(catecagory_id==''){
						$("#cate_id").addClass("sel");
					}
				}
			});
		}

		function submitkeyword(){
			var flag = add_all();
			if(flag==true){
				var keywords = [];
				$("#keyword tr").each(function(){
					var obj = $("input", this);
					if(obj.attr("checked")){
						var newval = [obj.val(), obj.next().html()];
						keywords.push(newval);
					}
				});
				$.ajax({
					url: "?m=keyword&a=addKeyword", 
					type:"POST",
					data: {"data": $.toJSON(keywords)},
					dataType: "json",
					success: function(data){
						$(".checkboxed").attr("checked", false);
						$(".cp-pages b").click();
						if(data.status==1){
							cpAlert(data.msg);
						}else{
							cpAlert(data.errMsg);
						}
					}
				});
			}
		}

		keywords('', 0);
	</script>
</body>
</html>