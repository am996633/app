<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta name="renderer" content="webkit">
	<meta http-equiv="X-UA-Compatible" content="IE=edge" />
	<meta name="viewport" content="width=device-width, minimum-scale=1, maximum-scale=1, user-scalable=no">
	<title>专题易 © 2016 ThinkInCloud</title>
	<link rel="stylesheet" type="text/css" href="__APPROOT__/css/dashboard.css" />
	<script type="text/javascript" src="/static/js/jquery.js"></script>
	<script type="text/javascript" src="/static/ueditor/ueditor.all.min.js"></script>
	<script type="text/javascript" src="/static/ueditor/ueditor.config.js"></script>
	<script type="text/javascript" src="/static/js/plus.js"></script>
	<script type="text/javascript" src="__APPROOT__/js/common.js"></script>
	<script src="/static/uploadify/jquery.uploadify.min.js" type="text/javascript"></script>
	<link rel="stylesheet" type="text/css" href="/static/uploadify/uploadify.css">
	<style>
	.cp-form .controls span.uploadify-button-text{ padding-top:0; color: #FFF; }
	</style>
</head>
<body>
	<!-- include header -->
	<div class="cp-wrap">
		<div class="crumb"></div>
		<div class="cp-form">
			<div class="box">
				<div class="box-title">修改文章</div>
				<form method="POST" class="AjaxPost">
					
					<div class="control-group">
						<label class="control-label" for="name">标题：</label>
						<div class="controls">
							<input type="text" class="input-xlarge focused" name="title" style="width:450px;" value="{$r[title]}">
						</div>
					</div>
					
			
					<div class="control-group">
						<label class="control-label" for="name">缩略图：</label>
						<div class="controls cl">
							<div class="fl"><input type="text" class="input-xlarge focused" name="thumb" value="{$r[thumb]}"  style="width:300px;"></div>
							<div class="fl"><img src="{$r[thumb]}" id="imgsrc" width="100" /></div>
							<div class="fl" style="margin-left:5px;"><span id="file_upload" ></span></div>
						</div>
					</div>
					
			
					<div class="control-group">
						<label class="control-label" for="name">关键词：</label>
						<div class="controls">
							<input type="text" class="input-xlarge focused" name="keywords" style="width:450px;" value="{$r[keywords]}">
						</div>
					</div>
					<div class="control-group">
						<label class="control-label" for="name">描述：</label>
						<div class="controls">
							<textarea name="description" style="width:460px;height:90px;">{$r[description]}</textarea>
						</div>
					</div>
					<div class="control-group">
						<label class="control-label" for="name">内容：</label>
						<div class="controls">
							<script type="text/editor" style="width:650px;height:350px;" name="body" id="body" _type="editor">{$r[body]}</script>
						</div>
					</div>
					<div class="form-actions">
						<input type="submit" class="btn" value="保存" />
						<input type="button" class="btn btn-link" value="返回" onclick="history.back(-1)"/>
					</div>
				</form>	
			</div>
		</div>
	</div>
	<!-- include footer -->
<script>
		$(function() {
			$('#file_upload').uploadify({
				'swf'      : '/static/uploadify/uploadify.swf',
				'uploader' : '?m=upload&a=swfupfile',
				'buttonText' : '选择文件',
				'onUploadSuccess':function(file,data,response){
					$("#imgsrc").attr("src", data); 
					$("input[name=thumb]").val(data);
				},
			});
		});
	</script>
</body>
</html>