<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta name="renderer" content="webkit">
	<meta http-equiv="X-UA-Compatible" content="IE=edge" />
	<meta name="renderer" content="webkit">
	<meta http-equiv="X-UA-Compatible" content="IE=edge" />
	<meta name="viewport" content="width=device-width, minimum-scale=1, maximum-scale=1, user-scalable=no">
	<title>专题易 © 2016 ThinkInCloud</title>
	<link rel="stylesheet" type="text/css" href="__APPROOT__/css/dashboard.css" />
	<script type="text/javascript" src="/static/js/jquery.js"></script>
	<script type="text/javascript" src="__APPROOT__/js/common.js"></script>
</head>
<body>
	<!-- include header -->
	<div class="cp-wrap">
		<div class="crumb"></div>
		<div class="cp-form">
			<div class="box">
				<div class="box-title">修改资料</div>
				<form method="POST" class="AjaxPost" >
					
					<div class="control-group">
						<label class="control-label" for="name">旧密码：</label>
						<div class="controls">
							<input type="password" class="input-xlarge focused" name="oldpwd" >
						</div>
					</div>
					<div class="control-group">
						<label class="control-label" for="name">新密码：</label>
						<div class="controls">
							<input type="password" class="input-xlarge focused" name="password" >
						</div>
					</div>
					<div class="control-group">
						<label class="control-label" for="name">确定密码：</label>
						<div class="controls">
							<input type="password" class="input-xlarge focused" name="password2" >
						</div>
					</div>

					<div class="form-actions">
						<input type="submit" class="btn" value="保存" />
						<input type="button" class="btn btn-link" value="返回" onclick="history.back(-1)"/>
					</div>
				</form>	
			</div>

		</div>
	</div>
	<!-- include footer -->
	<script>

	</script>
</body>
</html>