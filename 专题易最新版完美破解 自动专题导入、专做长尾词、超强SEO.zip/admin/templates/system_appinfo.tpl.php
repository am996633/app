<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta name="renderer" content="webkit">
	<meta http-equiv="X-UA-Compatible" content="IE=edge" />
	<meta name="viewport" content="width=device-width, minimum-scale=1, maximum-scale=1, user-scalable=no">
	<title>专题易 © 2016 ThinkInCloud</title>
	<link rel="stylesheet" type="text/css" href="__APPROOT__/css/dashboard.css" />
	<script type="text/javascript" src="/static/js/jquery.js"></script>
	<script type="text/javascript" src="__APPROOT__/js/common.js"></script>
</head>
<body>
	<!-- include header -->
	<div class="cp-wrap">
		<div class="crumb"></div>
		<div class="cp-form">
			<div class="box">
				<form method="POST" action="?m=system&a=unbind" >
					
					<div class="control-group">
						<label class="control-label" for="name">网站ID：</label>
						<div class="controls">
							<p>{$conf[appid]}</p>
						</div>
					</div>
					<div class="control-group">
						<label class="control-label" for="name">密钥：</label>
						<div class="controls">
							<p>{$conf[appkey]}</p>
						</div>
					</div>
					<div class="form-actions">
						<input type="submit" class="btn" value="解除绑定" />
					</div>
				</form>	
			</div>
		</div>
	</div>
	<!-- include footer -->
	<script>
	</script>
</body>
</html>