<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta name="renderer" content="webkit">
	<meta http-equiv="X-UA-Compatible" content="IE=edge" />
	<meta name="viewport" content="width=device-width, minimum-scale=1, maximum-scale=1, user-scalable=no">
	<title>专题易 © 2016 ThinkInCloud</title>
	<link rel="stylesheet" type="text/css" href="__APPROOT__/css/dashboard.css" />
	<script type="text/javascript" src="/static/js/jquery.js"></script>
	<script type="text/javascript" src="__APPROOT__/js/common.js"></script>
	<style type="text/css">
		.jindu{position: absolute; width: 300px;height: 10px;background: #ccc;}
		.jindu1{position: relative;height: 10px;}
		#ProcessMsg{ float: right; height: 30px; line-height: 30px; color:#aaa; font-weight: 300; padding:0 20px; -webkit-transition: all 0.5s; transition: all 0.5s; width: 400px; text-align: center; overflow: hidden; }
		#ProcessMsg.show{  width: 100%; clear: both; text-align: center; background: #eee; border:solid 1px #ccc; margin:20px 0; padding: 20px 0; }
	</style>
</head>
<body >
	<!-- include header -->
	<div class="cp-wrap">
		<div class="crumb"></div>
		<div class="cp-table-top cl">
			<div class="fl">
				<form action="?m=topic&a=index" method="post">
					<input name="title" value="{$title}" type="text" placeholder="请输入您要搜索的标题"> 
					<input type="submit" value="搜索" class="btn" />&nbsp;&nbsp;
					<input type="button" class="btn" value="添加专题" onclick="window.location.href='?m=topic&a=add' ">
				</form>
			</div>
			<div class="fr">
				<input type="button" class="btn catch_start_btn" value="快速采集" onclick="catch_start(this)">&nbsp;&nbsp;
				<input type="button" class="btn catch_stop_btn" value="后台采集" onclick="catch_stop(this)" disabled>
			</div>
			<div id="ProcessMsg">后台执行自动采集中</div>
		</div>
		<div class="cp-table">
			<table width="100%" border="0" cellpadding="0" cellspacing="0">
				<tbody>
					<tr>
						<th width="50" align="left">ID</th>
						<th align="left">专题名称</th>
						<th align="left" width="300">采集进度</th>
						<th width="100" align="left">操作</th>
					</tr>
					<!-- foreach $list -->
					<tr>
						<td align="left">{$id}</td>
						<td align="left">{$title} {if $status==-1}<span style="color:#ccc;">采集失败</span>{/if}</td>
						<td>
							<!-- if $status==-1 -->
							<div class="jindu"></div>
							<!-- elseif $catchstatus==15 -->
							<div class="jindu">
								<div class="jindu1" style="width:{$width}px;background: green;"></div>
							</div>
							<!-- else -->
							<div class="jindu">
								<div class="jindu1" style="width:{$width}px;background: #3eb6f3;"></div>
							</div>
							<!-- /if -->
						</td>
						<td align="center">
							<a href="?m=topic&a=edit&id={$id}">	修改</a>
							<a href="?m=topic&a=del&id={$id}" onclick="return confirm('?')">删除</a>
						</td>
					</tr>
					<!-- /foreach -->
				</tbody>
			</table>
		</div>
		<div class="cp-pages">
			{$page}
		</div>
	</div>
	<!-- include footer -->
	<script>
		var catch_relaword_time = 10000;
		var catch_news_time = 2000;
		var catch_baike_time = 10000;
		var catch_wenwen_time = 5000;
		var catch_weibo_time = 10000;

		function catch_relaword(){
			$.ajax({
				url: "../catch/relaword", 
				type:"POST",
				dataType: "json",
				success: function(data){
					if(data.status!=1 && typeof(data.errType)!='undefined' && (data.errType=='appIdError' || data.errType=='domainError' || data.errType=='signError' || data.errType=='checkError') ){
						$("#ProcessMsg").html('网站未激活，不能采集');
						return;
					}
					if(data.status==1 && data.msg.length>0){
						$("#ProcessMsg").html(data.msg);
					}
					setTimeout(function(){
						catch_relaword();
					}, catch_relaword_time);
				},
				error: function(){
					setTimeout(function(){
						catch_relaword();
					}, 5000);
				}
			});
		}

		function catch_news(){
			$.ajax({
				url: "../catch/news", 
				type:"POST",
				dataType: "json",
				success: function(data){
					if(data.status!=1 && typeof(data.errType)!='undefined' && (data.errType=='appIdError' || data.errType=='domainError' || data.errType=='signError' || data.errType=='checkError') ){
						$("#ProcessMsg").html('网站未激活，不能采集');
						return;
					}
					if(data.status==1 && data.msg.length>0){
						$("#ProcessMsg").html(data.msg);
					}
					setTimeout(function(){
						catch_news();
					}, catch_news_time);
				},
				error: function(){
					setTimeout(function(){
						catch_news();
					}, 5000);
				}
			});
		}

		function catch_baike(){
			$.ajax({
				url: "../catch/baike", 
				type:"POST",
				dataType: "json",
				success: function(data){
					if(data.status!=1 && typeof(data.errType)!='undefined' && (data.errType=='appIdError' || data.errType=='domainError' || data.errType=='signError' || data.errType=='checkError') ){
						$("#ProcessMsg").html('网站未激活，不能采集');
						return;
					}
					if(data.status==1 && data.msg.length>0){
						$("#ProcessMsg").html(data.msg);
					}
					setTimeout(function(){
						catch_baike();
					}, catch_baike_time);
				},
				error: function(){
					setTimeout(function(){
						catch_baike();
					}, 5000);
				}
			});
		}

		function catch_wenwen(){
			$.ajax({
				url: "../catch/wenwen", 
				type:"POST",
				dataType: "json",
				success: function(data){
					if(data.status!=1 && typeof(data.errType)!='undefined' && (data.errType=='appIdError' || data.errType=='domainError' || data.errType=='signError' || data.errType=='checkError') ){
						$("#ProcessMsg").html('网站未激活，不能采集');
						return;
					}
					if(data.status==1 && data.msg.length>0){
						$("#ProcessMsg").html(data.msg);
					}
					setTimeout(function(){
						catch_wenwen();
					}, catch_wenwen_time);
				},
				error: function(){
					setTimeout(function(){
						catch_wenwen();
					}, 5000);
				}
			});
		}

		function catch_weibo(){
			$.ajax({
				url: "../catch/weibo", 
				type:"POST",
				dataType: "json",
				success: function(data){
					if(data.status!=1 && typeof(data.errType)!='undefined' && (data.errType=='appIdError' || data.errType=='domainError' || data.errType=='signError' || data.errType=='checkError') ){
						$("#ProcessMsg").html('网站未激活，不能采集');
						return;
					}
					if(data.status==1 && data.msg.length>0){
						$("#ProcessMsg").html(data.msg);
					}
					setTimeout(function(){
						catch_weibo();
					}, catch_weibo_time);
				},
				error: function(){
					setTimeout(function(){
						catch_weibo();
					}, 5000);
				}
			});
		}

		function check(){
			$.ajax({
				url: "../catch/check", 
				type:"POST",
				dataType: "json",
				success: function(data){
					if(data.status!=1 && typeof(data.errType)!='undefined' && (data.errType=='appIdError' || data.errType=='domainError' || data.errType=='signError' || data.errType=='checkError') ){
						$("#ProcessMsg").html('网站未激活，不能采集');
						return;
					}
					if(data.status==1 && data.msg.length>0){
						$("#ProcessMsg").html(data.msg);
					}
					setTimeout(function(){
						check();
					}, 15000)
				},
				error: function(){
					setTimeout(function(){
						check();
					}, 15000);
				}
			});
		}

		function catch_start(){
			catch_relaword_time = 1000;
			catch_news_time = 200;
			catch_baike_time = 1000;
			catch_wenwen_time = 500;
			catch_weibo_time = 1000;
			$("#ProcessMsg").addClass('show');
			$('.catch_start_btn').attr('disabled', true);
			$(".catch_stop_btn").attr('disabled', false);
		}

		function catch_stop(){
			catch_relaword_time = 10000;
			catch_news_time = 2000;
			catch_baike_time = 10000;
			catch_wenwen_time = 5000;
			catch_weibo_time = 10000;
			$("#ProcessMsg").removeClass('show');
			$('.catch_start_btn').attr('disabled', false);
			$(".catch_stop_btn").attr('disabled', true);
		}

		catch_relaword();
		catch_news();
		catch_baike();
		catch_wenwen();
		catch_weibo();
		check();
		
	</script>
</body>
</html>