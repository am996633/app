<!--//compress on #启用模板压缩  -->
<div class="header cl">
	<div class="logo cl">
		<a href="__APPROOT__/?m=dashboard">Easy 专题易</a>
	</div>
	<div class="menu cl">
		<ul>
			<!-- foreach $headMenu -->
			<li {if $current==1}class="cur"{/if} data-menuId="{$__i}"><a href="javascript:void(0);">{$name}</a></li>
			<!-- /foreach -->
		</ul>
	</div>
	<div class="user-info cl">
		<div class="user-welcome"> 你好{$user[username]}，欢迎使用专题易关键词建站系统！</div> 
		<div class="user-bar-icon">
			<a href="/" target="_blank"><span class="iconfont">&#xe6cc;</span>查看</a>
			<a href="http://www.liuliangshenqi.com.cn/help" target="_blank"><span class="iconfont">&#xe6b9;</span>帮助</a>
			<a href="?m=authorized&a=logout"><span class="iconfont">&#xe703;</span>退出</a>
		</div>
	</div>
</div>
<div class="left-menu"><div class="left-menu-list"></div></div>
