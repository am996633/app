<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta name="renderer" content="webkit">
	<meta http-equiv="X-UA-Compatible" content="IE=edge" />
	<meta name="viewport" content="width=device-width, minimum-scale=1, maximum-scale=1, user-scalable=no">
	<title>专题易 © 2016 ThinkInCloud</title>
	<link rel="stylesheet" type="text/css" href="__APPROOT__/css/dashboard.css" />
	<script type="text/javascript" src="/static/js/jquery.js"></script>
	<script type="text/javascript" src="__APPROOT__/js/common.js"></script>
</head>
<body>
	<!-- include header -->
	<div class="cp-wrap">
		<div class="crumb"></div>
		<div class="cp-form">
			<div class="box">
				<form method="POST" class="AjaxPost" action="?m=system&a=config" onsubmit="return false;">
					
					<div class="control-group">
						<label class="control-label" for="name">手机站开关：</label>
						<div class="controls">
							<input type="radio"  name="data[mobileSwitch]" value="1"  {if $var[mobileSwitch]==1}checked='checked'{/if}>&nbsp;&nbsp;是&nbsp;&nbsp;
							<input type="radio"  name="data[mobileSwitch]" value="0"  {if $var[mobileSwitch]==0}checked='checked'{/if}>&nbsp;&nbsp;否&nbsp;&nbsp;
						</div>
					</div>
					<div class="control-group">
						<label class="control-label" for="name">手机站域名：</label>
						<div class="controls">
							<input name="data[mobileHost]" value="{$var[mobileHost]}" type="text">
						</div>
					</div>
					<div class="form-actions">
						<input type="submit" class="btn" value="保存" />
					</div>
				</form>	
			</div>
		</div>
	</div>
	<!-- include footer -->
	<script>
		function 
	</script>
</body>
</html>