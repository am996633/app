<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta name="renderer" content="webkit">
	<meta http-equiv="X-UA-Compatible" content="IE=edge" />
	<meta name="viewport" content="width=device-width, minimum-scale=1, maximum-scale=1, user-scalable=no">
	<title>专题易 © 2016 ThinkInCloud</title>
	<link rel="stylesheet" type="text/css" href="__APPROOT__/css/dashboard.css" />
	<link rel="stylesheet" type="text/css" href="__APPROOT__/css/form-style.css" />
	<script type="text/javascript" src="/static/js/jquery.js"></script>
	<script type="text/javascript" src="__APPROOT__/js/common.js"></script>
</head>
<body>
	<!-- include header -->
	<div class="cp-wrap">
		<div class="crumb"></div>
		<div class="cp-form">
			<form method="POST" class="AjaxPost" action="?m=system&a=config" onsubmit="return false;">
				<div class="control-group">
					<label class="control-label" for="name">混淆比例：</label>
					<div class="controls controls-row">
						<input type="text" class="input-small focused" name="data[seoConfuseScale]" value="{$var[seoConfuseScale]}" >
						<span>混淆文章的比例，可填0-100，0关闭该功能，100全部文章都混淆</span>
					</div>
				</div>
				<div class="control-group">
					<label class="control-label" for="name">自动标题：</label>
					<div class="controls controls-row">
						<label><input type="radio"  name="data[autoTitle]" value="1" {if $var[autoTitle]==1}checked='checked'{/if}>&nbsp;&nbsp;是&nbsp;&nbsp;</label>
						<label><input type="radio"  name="data[autoTitle]" value="0"  {if $var[autoTitle]==0}checked='checked'{/if}>&nbsp;&nbsp;否&nbsp;&nbsp;</label>
					</div>
				</div>
				<div class="control-group">
					<label class="control-label" for="name">段落重排：</label>
					<div class="controls controls-row">
						<label><input type="radio"  name="data[paragraphConfuse]" value="1"  {if $var[paragraphConfuse]==1}checked='checked'{/if}>&nbsp;&nbsp;是&nbsp;&nbsp;</label>
						<label><input type="radio"  name="data[paragraphConfuse]" value="0"  {if $var[paragraphConfuse]==0}checked='checked'{/if}>&nbsp;&nbsp;否&nbsp;&nbsp;</label>
					</div>
				</div>
				<div class="control-group">
					<label class="control-label" for="name">语句重排：</label>
					<div class="controls controls-row">
						<label><input type="radio"  name="data[phrasesConfuse]" value="1" {if $var[phrasesConfuse]==1}checked='checked'{/if}>&nbsp;&nbsp;是&nbsp;&nbsp;</label>
						<label><input type="radio"  name="data[phrasesConfuse]" value="0"  {if $var[phrasesConfuse]==0}checked='checked'{/if}>&nbsp;&nbsp;否&nbsp;&nbsp;</label>
					</div>
				</div>
				<div class="form-actions">
					<input type="submit" class="btn" value="保存" />
				</div>
			</form>
		</div>
	</div>
	<!-- include footer -->
	<script type="text/javascript" src="/static/js/jquery.validform.js"></script>
	<script>

	</script>
</body>
</html>