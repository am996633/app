<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta name="renderer" content="webkit">
	<meta http-equiv="X-UA-Compatible" content="IE=edge" />
	<meta name="viewport" content="width=device-width, minimum-scale=1, maximum-scale=1, user-scalable=no">
	<title>专题易 © 2016 ThinkInCloud</title>
	<link rel="stylesheet" type="text/css" href="__APPROOT__/css/dashboard.css" />
	<link rel="stylesheet" type="text/css" href="__APPROOT__/css/form-style.css" />
	<link rel="stylesheet" type="text/css" href="__APPROOT__/css/system.css" />
	<script type="text/javascript" src="/static/js/jquery.js"></script>
	<script type="text/javascript" src="__APPROOT__/js/common.js"></script>
	<script type="text/javascript">
		function changeSwitch(field, obj){
			var tt = $(obj).attr("data");
			if(tt==1){
				$(obj).removeClass("turnbg_1");
				$(obj).addClass("turnbg_0");
				$(obj).attr("data",0);
			}else{
				$(obj).removeClass("turnbg_0");
				$(obj).addClass("turnbg_1");
				$(obj).attr("data",1);
			}
			var ts = $(obj).attr("data");
			$.ajax({
				'url':"?m=system&a=switchval",
				'type': 'post',
				'dataType': 'json',
				'data': {'field':field, 'data':ts},
				success:function(data){
				}
			})
		}

		function changeCaiji(obj){
			var tt = $(obj).attr("data");
			if(tt==1){
				$(obj).removeClass("turnbg_1");
				$(obj).addClass("turnbg_0");
				$(obj).attr("data",0);
			}else{
				$(obj).removeClass("turnbg_0");
				$(obj).addClass("turnbg_1");
				$(obj).attr("data",1);
			}
			var ts = $(obj).attr("data");
			$.ajax({
				'url':"?m=system&a=switchcaiji",
				'type': 'post',
				'dataType': 'json',
				'data': {'data':ts},
				success:function(data){
				}
			})
		}

		function NoCheck(){
			if(confirm("您还没有授权域名，马上授权绑定！")){
				window.location.href="?m=system&a=bind";
			}
		}

		$(function(){
			$.ajax({
				'url':"?m=system&a=getCaiji",
				'type': 'post',
				'dataType': 'json',
				success:function(data){
					if(data.status==1){
						var str = "<div class='control-group' style='float:left;'><label class='control-label'>自动采集开关：</label><div class='controls controls-row'><div class='switch turnbg_"+data['data']+"' data='"+data['data']+"' onclick='changeCaiji(this)'></div></div></div>";
						$("#caiji").after(str);
					}else{
						var str = "<div class='control-group' style='float:left;'><label class='control-label'>自动采集开关：</label><div class='controls controls-row'><div class='switch turnbg_0'  onclick='NoCheck()'></div></div></div>";
						$("#caiji").after(str);
					}
				},
				error: function(){ }
			});
		});

	</script>
</head>
<body>
	<!-- include header -->
	<div class="cp-wrap">
		<div class="crumb"></div>
		<div class="cp-form">
			<form method="POST" class="AjaxPost" onsubmit="return false;">
				<div class="cl" style="margin: 30px 0 10px;">
					<div class="control-group" style="float:left;" id="caiji">
						<label class="control-label">网站开关：</label>
						<div class="controls controls-row">
							<div class="switch turnbg_{$var[siteSwitch]}" data="{$var[siteSwitch]}" onclick="changeSwitch('siteSwitch', this)"></div>
						</div>
					</div>
				</div>

				<div class="control-group">
					<label class="control-label">网站名称：</label>
					<div class="controls controls-row">
						<input type="text" class="input-xlarge" name="data[siteName]" value="{$var[siteName]}" style="width:450px;" >
					</div>
				</div>

				<div class="control-group">
					<label class="control-label">网站副标题名称：</label>
					<div class="controls controls-row">
						<input type="text" class="input-xlarge" name="data[siteTitle]" value="{$var[siteTitle]}" style="width:450px;" >
					</div>
				</div>
				
				<div class="control-group">
					<label class="control-label">网站地址：</label>
					<div class="controls controls-row">
						http:// <input type="text" class="input-xlarge" name="data[webHost]" value="{$var[webHost]}" style="width:250px;" >
					</div>
				</div>
				<div class="control-group">
					<label class="control-label">网站关键词：</label>
					<div class="controls controls-row">
						<input type="text" class="input-xlarge" style="width:450px;" name="data[keywords]" value="{$var[keywords]}" >
					</div>
				</div>
				
				<div class="control-group">
					<label class="control-label">网站描述：</label>
					<div class="controls controls-row">
						<textarea name="data[description]" style="width:450px;height:90px;">{$var[description]}</textarea>
					</div>
				</div>

				<div class="control-group" >
					<label class="control-label">网站sitemap：</label>
					<div class="controls controls-row">
						<label><input type="radio"  name="data[sitemap]" value="1"  {if $var[sitemap]==1}checked='checked'{/if}> 开启</label>
						<label><input type="radio"  name="data[sitemap]" value="2"  {if $var[sitemap]==2}checked='checked'{/if}> 关闭</label>
						<span>可提交到百度站长，sitemap地址：http://<?php echo $this->conf['webHost']; ?>/sitemap.xml</span>

					</div>
				</div>

				<div class="control-group" >
					<label class="control-label">图片处理：</label>
					<div class="controls controls-row">
						<label><input type="radio"  name="data[downPicture]" value="1"  {if $var[downPicture]==1}checked='checked'{/if}> 本地图片</label>
						<label><input type="radio"  name="data[downPicture]" value="2"  {if $var[downPicture]==2}checked='checked'{/if}> 远程图片</label>
						<label><input type="radio"  name="data[downPicture]" value="0"  {if $var[downPicture]==0}checked='checked'{/if}> 过滤图片</label>
					</div>
				</div>

				<div class="control-group">
					<label class="control-label">网站统计代码：</label>
					<div class="controls controls-row">
						<textarea name="data[site_code]" style="width:450px;height:90px;">{$var[site_code]}</textarea>
					</div>
				</div>

				<div class="control-group">
					<label class="control-label">网站备案号：</label>
					<div class="controls controls-row">
						<input type="text" class="input-xlarge" style="width:450px;" 
						name="data[ipc]" value="{$var[ipc]}" >
					</div>
				</div>
				<div class="form-actions">
					<input type="submit" class="btn" value="保存" />
				</div>
			</form>		
		</div>
	</div>
	<!-- include footer -->
	<script type="text/javascript" src="/static/js/jquery.validform.js"></script>

</body>
</html>