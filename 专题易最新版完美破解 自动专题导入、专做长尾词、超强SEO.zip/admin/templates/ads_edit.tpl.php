<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta name="renderer" content="webkit">
	<meta http-equiv="X-UA-Compatible" content="IE=edge" />
	<meta name="viewport" content="width=device-width, minimum-scale=1, maximum-scale=1, user-scalable=no">
	<title>专题易 © 2016 ThinkInCloud</title>
	<link rel="stylesheet" type="text/css" href="__APPROOT__/css/dashboard.css" />
	<script type="text/javascript" src="/static/js/jquery.js"></script>
	<script type="text/javascript" src="__APPROOT__/js/common.js"></script>
</head>
<body onload="selectType()">
	<!-- include header -->
	<div class="cp-wrap">
		<div class="crumb"></div>
		<div class="cp-form">
					<div class="box">
				<div class="box-title">编辑广告</div>
					<form method="POST" class="AjaxPost">
					
					<div class="control-group">
						<label class="control-label" for="name">广告名称：</label>
						<div class="controls">
							<input type="text" class="input-xlarge focused" name="title" value="{$r[title]}" style="width:450px;">
						</div>
					</div>
					<div class="control-group">
						<label class="control-label" for="name">广告内容：</label>
						<div class="controls">
							<textarea rows="6"  style="width:450px;"  name="content">{$r[content]}</textarea>
						</div>
					</div>
					
					<div class="control-group">
						<label class="control-label" for="name">状态：</label>
						<div class="controls">
							<select name="status">
								<option value="1" {if $r[status]=="1"}selected='selected'{/if}>启用</option>
								<option value="0" {if $r[status]=="0"}selected='selected'{/if} >禁用</option>
							</select>
						</div>
					</div>
					
		
					<div class="form-actions" >
						<input type="submit" class="btn" value="保存" />
						<input type="button" class="btn btn-link" value="返回" onclick="history.back(-1)"/>
					</div>
				</form>	
			</div>
		</div>
	</div>
	<!-- include footer -->
		<script>
function selectType(){
	var type =$("#type").val();
	if(type==1){
		$("#cjurl").show();
		$("#url_nocontain").show();
		$("#url_contain").show();
	}else if(type==2){
		$("#cjurl").hide();
		$("#url_nocontain").hide();
		$("#url_contain").hide();
	}
}
	</script>
</body>
</html>