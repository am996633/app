<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta name="renderer" content="webkit">
	<meta http-equiv="X-UA-Compatible" content="IE=edge" />
	<meta name="viewport" content="width=device-width, minimum-scale=1, maximum-scale=1, user-scalable=no">
	<title>专题易 © 2016 ThinkInCloud</title>
	<link rel="stylesheet" type="text/css" href="__APPROOT__/css/dashboard.css" />
	<script type="text/javascript" src="/static/js/jquery.js"></script>
	<script type="text/javascript" src="__APPROOT__/js/common.js"></script>
	<script src="/static/uploadify/jquery.uploadify.min.js" type="text/javascript"></script>
	<link rel="stylesheet" type="text/css" href="/static/uploadify/uploadify.css">
	
	<style type="text/css">
		#poplayer
		{
			position:fixed;
			_position:absolute;
			top:15%;
			left:50%;
			width:450px;
			margin-left: -225px;
			min-height:350px;
			z-index:8888; 
			display:none;
			background-color:#FFF; 
			padding: 10px;
		}
		#covered
		{
			position:fixed;
			_position:absolute;
			z-index:888;
			top:0px;
			left:0px;
			width:100%;
			height:100%;
			background-color:Black;
			opacity:0.3;
			display:none;
		}
	</style>
	<script type="text/javascript">
		function showCon(){
			$("#covered").show();
			$("#poplayer").show();
		}
		function hideCon(){
			$("#covered").hide();
			$("#poplayer").hide();
		}
		$(function(){
			$("#covered").click(function(){
				$("#covered").hide();
				$("#poplayer").hide();
			});
		})
	</script>
</head>
<body>
	<div id="covered"></div>
	<div id="poplayer">
		<div><h1 onclick="hideCon()">上传须知</h1></div>
		<div style="padding: 8px;border:dashed 1px #ccc; margin: 5px 0;">
			<p>上传文件必须是txt文件</p>
			<p>每一行为一条替换记录</p>
			<p>文件格式下图所示:</p>
			<p style="color:red;">正在上传中,请不要刷新页面，请耐心等待，上传成功页面会自动刷新</p>
		</div>
		<div style="padding: 10px 0;"><img src="./images/uploadtemp.png" style="border:solid 1px #ccc;" /></div>
		<input type="file" id="file_upload"/>
		
		<div id="msg"></div>
	</div>
	<!-- include header -->
	<div class="cp-wrap">
		<div class="crumb"></div>
		<div class="cp-table-top cl">
			<div class="fl" style="margin-right:10px;display: inline-block;">
				<a href="?m=seo&a=reword_add" class="btn">单个添加</a>
			</div>
			<div class="fl" style="margin-right:10px;display: inline-block;">
				<a href="javascript:void(0);" class="btn" onclick="showCon()">批量上传</a>
			</div>
		</div>
		<div class="cp-table">
			<table width="100%" border="0" cellpadding="0" cellspacing="0">
				<tbody>
					<tr>
						<th width="35" align="left"></th>
						<th align="left">替换前
						</th>
						<th align="left">替换后
						</th>
						<th align="left">替换类型
						</th>
						<th width="100" align="center">操作</th>
					</tr>
					<!-- foreach $list -->
					<tr>
						<td align="left"></td>
						<td align="left">{$oldword}</td>
						<td align="left"> {$newword}</td>
						<td align="left"> 
							{if $type==1}单向{/if}
							{if $type==2}双向{/if}
						</td>
						<td align="center">
							<a href="?m=seo&a=reword_del&id={$id}" onclick="return confirm('确定删除？')">删除</a>
						</td>
					</tr>
					<!-- /foreach -->
				</tbody>
			</table>
			<!-- if !empty($list) -->
			<a href="?m=seo&a=reword_delall" class="btn" style="color:#fff;"  onclick="return confirm('确定清空数据吗？')" >清空数据</a>
			<!-- /if -->
		</div>
		<!-- if empty($list) -->
		<div class="noresult">暂时没有可显示数据</div>
		<!-- /if -->
		<div class="cp-pages">
			{$page}
		</div>
	</div>
	<!-- include footer -->
	<script>
		$(function() {
			$('#file_upload').uploadify({
				'swf'      : '/static/uploadify/uploadify.swf',
				'uploader' : '?m=seo&a=reword_upload&ssid={$_COOKIE[ssid]}',
				'buttonText' : '开始上传同义词',
				'onUploadSuccess':function(file,data,response){
					$("#file_upload").val(data);
					window.location.href=window.location.href;
				},
			});
		});
	</script>
</body>
</html>