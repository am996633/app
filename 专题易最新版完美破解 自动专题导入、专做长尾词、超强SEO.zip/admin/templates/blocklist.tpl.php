<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta name="renderer" content="webkit">
	<meta http-equiv="X-UA-Compatible" content="IE=edge" />
	<meta name="viewport" content="width=device-width, minimum-scale=1, maximum-scale=1, user-scalable=no">
	<title>专题易 © 2016 ThinkInCloud</title>
	<link rel="stylesheet" type="text/css" href="__APPROOT__/css/dashboard.css" />
	<script type="text/javascript" src="/static/js/jquery.js"></script>
	<script type="text/javascript" src="__APPROOT__/js/common.js"></script>
</head>
<body>
	<!-- include header -->
	<div class="cp-wrap">
		<div class="crumb"></div>
		<div class="cp-table-top">
			
		</div>
		<div class="cp-table">
			<table width="100%" border="0" cellpadding="0" cellspacing="0">
				<tbody>
					<tr>
						<th width="35" align="left"></th>
						<th align="left">标题</th>
						<th width="100" align="center">操作</th>
					</tr>
					<!-- foreach $list -->
					<tr>
						<td align="left"></td>
						<td align="left"> {$title}</td>
						<td align="center">
							<a href="?m=blocklist&a=del&id={$id}" onclick="return confirm('确定还原吗?')">还原</a>
						</td>
					</tr>
					<!-- /foreach -->
				</tbody>
			</table>
		</div>
		<!-- if empty($list) -->
		<div class="noresult">暂时没有可显示数据</div>
		<!-- /if -->
		<div class="cp-pages">
			{$page}
		</div>
	</div>
	<!-- include footer -->
	<script>
		
	</script>
</body>
</html>