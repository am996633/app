<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta name="renderer" content="webkit">
	<meta http-equiv="X-UA-Compatible" content="IE=edge" />
	<meta name="viewport" content="width=device-width, minimum-scale=1, maximum-scale=1, user-scalable=no">
	<title>专题易
	{ © 2016 ThinkInCloud</title>
	<link rel="stylesheet" type="text/css" href="__APPROOT__/css/dashboard.css" />
	<script type="text/javascript" src="/static/js/jquery.js"></script>
	<script type="text/javascript" src="__APPROOT__/js/common.js"></script>
</head>
<body>
	<!-- include header -->
	<div class="cp-wrap">
		<div class="crumb"></div>
		<div class="cp-form">
			<div class="box">
				<form method="POST"  action="?m=system&a=bind_next" class="AjaxPost">
					<input type="hidden" name="username" value="{$user_name}">
					<input type="hidden" name="password" value="{$password}">
					
					<div class="control-group">
						<label class="control-label" for="name">用户名：</label>
						<div class="controls">
							<span>{$user_name}</span>
						</div>
					</div>
					<div class="control-group">
						<label class="control-label" for="name">授权情况:</label>
						<div class="controls">
							<!-- if !$keynum -->
							<span>您的账号还没有获得授权，<a href="http://www.liuliangshenqi.com.cn" target="_blank" style="color:red;">在线购买</a></span>
							<!-- else -->
							<span>
								<p>共有授权{$keynum}个，已激活{$usenum}个，剩余{$num}个名额。</p>
								<!-- if $num==0 -->
								<p style="padding-top: 20px;">您的授权额度已用完，<a href="http://www.liuliangshenqi.com.cn" target="_blank" style="color:red;">点击购买授权</a></p>
								<!-- /if -->
							</span>
							<!-- /if -->
						</div>
					</div>
					<!-- if $num>0 -->
					<div class="form-actions">
						<input type="submit" class="btn" value="确认绑定" />
						<input type="button" class="btn btn-link" value="返回" onclick="history.back(-1)"/>
					</div>
					<!-- /if -->
				</form>	
			</div>
		</div>
	</div>
	<!-- include footer -->
	<script>
	</script>
</body>
</html>