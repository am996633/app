<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta name="renderer" content="webkit">
	<meta http-equiv="X-UA-Compatible" content="IE=edge" />
	<meta name="viewport" content="width=device-width, minimum-scale=1, maximum-scale=1, user-scalable=no">
	<title>专题易 © 2016 ThinkInCloud</title>
	<link rel="stylesheet" type="text/css" href="__APPROOT__/css/dashboard.css" />
	<script type="text/javascript" src="/static/js/jquery.js"></script>
	<script type="text/javascript" src="__APPROOT__/js/common.js"></script>
</head>
<body>
	<div class="header">
		<div class="header-box">
			<div class="logo">
				<a href="__APPROOT__/?m=dashboard">专题易
	</a>
			</div>
		</div>
	</div>
	<div class="login cl">
		<div class="left">
			<img src="images/wxkf.png" alt="微信号">
			<p>关注微信号</p>
			<p>接收安全预警</p>
		</div>
		<div class="right">
			<form method="POST" class="AjaxPost" >
				<div class="form-tip"></div>
				<div class="caption">登录</div>
				<div class="form-row">
					<label for="username">账号：</label>
					<div>
						<input type="text" name="username" class="input-large">
					</div>
				</div>
				<div class="form-row">
					<label for="password">密码：</label>
					<div>
						<input type="password" name="password" class="input-large">
					</div>
				</div>
				<div class="form-row">
					<input type="submit" class="btn" value="登录">
				</div>
			</form>
		</div>
	</div>
	<!-- include footer -->
</body>
</html>
