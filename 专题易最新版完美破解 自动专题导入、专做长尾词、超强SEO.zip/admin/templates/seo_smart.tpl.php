<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta name="renderer" content="webkit">
	<meta http-equiv="X-UA-Compatible" content="IE=edge" />
	<meta name="viewport" content="width=device-width, minimum-scale=1, maximum-scale=1, user-scalable=no">
	<title>专题易 © 2016 ThinkInCloud</title>
	<link rel="stylesheet" type="text/css" href="__APPROOT__/css/dashboard.css" />
	<link rel="stylesheet" type="text/css" href="__APPROOT__/css/system.css" />
	<script type="text/javascript" src="/static/js/jquery.js"></script>
	<script type="text/javascript" src="__APPROOT__/js/common.js"></script>
	<script src="/static/uploadify/jquery.uploadify.min.js" type="text/javascript"></script>
	<link rel="stylesheet" type="text/css" href="/static/uploadify/uploadify.css">


</head>
<body>
	<!-- include header -->
	<div class="cp-wrap">
	<div class="crumb"></div>
	<div style="margin-top:10px;">
		<div class="con1">
			<div class="title">云端计算，一键开启</div>
			<div class="content">16核+64G内存+BGP网络+负载均衡，强大可靠的计算能力保证伪原创算法的有效，高效</div>
		</div>
		<div class="con2">
			<div class="title">多角度立体原创，上百套原创算法</div>
			<div class="content">上百套伪原创算法，文章分词，词性，语法，篇章感情，我们的算法无所不能<br/>&nbsp;&nbsp;
			不同文章采用不同的算法，随机组合，原创还是伪原创百度傻傻分不清</div>
			<div class="content1 cl">
			<div >分词</div><span>+</span> 
			<div>文章感情</div> <span>+</span> 
			<div>文章语法</div><span>+</span>  
			<div >混淆</div> <span>+</span> 
			<div >优化分词 
			</div><span>&gt;&gt;</span> 
		</div>
		<div class="con3">
			<div class="title">原创算法库与智能学习相结合</div>
			<div class="content">基于强大的运算能力和庞大的数据，原创系统每45天完成一次算法更新，无须担心伪原创被识破</div>
			<div class="content1">
			<div class="btn" >30元/年</div>&nbsp;&nbsp;&nbsp;&nbsp;<span>系统正在准备中，敬请期待</span>
			</div>
		</div>
		</div>
	</div>
	</div>
  <!-- include footer -->
</body>
</html>