<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta name="renderer" content="webkit">
	<meta http-equiv="X-UA-Compatible" content="IE=edge" />
	<meta name="viewport" content="width=device-width, minimum-scale=1, maximum-scale=1, user-scalable=no">
	<title>专题易 © 2016 ThinkInCloud</title>
	<link rel="stylesheet" type="text/css" href="__APPROOT__/css/dashboard.css" />
	<script type="text/javascript" src="/static/js/jquery.js"></script>
	<script type="text/javascript" src="__APPROOT__/js/common.js"></script>
	<script type="text/javascript" src="http://cdn.hcharts.cn/jquery/jquery-1.8.3.min.js"></script>
	<style type="text/css">
		#container {
			height: 300px; 
		}
	</style>
	<script type="text/javascript">
		$(function () {

			var dategroup = [];
			<!-- foreach $spider_types $flag $spiderName -->
			var {$flag} =[];
			<!--/foreach-->

			<!-- foreach $list_count -->
			dategroup.push({$adddate});
			<!-- foreach $spider_types $flag $spiderName -->
			{$flag}.push({$$flag});
			<!--/foreach-->

			<!--/foreach-->
			
			var series_data = [];
			<!-- foreach $spider_types $flag $spiderName -->
			series_data.push({name: '{$spiderName}',data: {$flag}});
			<!--/foreach-->


			$('#container').highcharts({
				chart: {
					backgroundColor: '#F1F3F6'
				},
				credits: {
					enabled: false
				},
				tooltip: {
					crosshairs: true,
					shared: true,
					valueSuffix: ''
				},
				title: {
					text: '搜索引擎抓取量统计',
				},
				xAxis: {
					categories: dategroup
				},
				yAxis: {
					title: {
						text: '抓取次数'
					},
					plotLines: [{
						value: 0,
						width: 1,
						color: '#808080'
					}]
				},
				tooltip: {
					valueSuffix: '次'
				},
				legend: {
					layout: 'vertical',
					align: 'right',
					verticalAlign: 'middle',
					borderWidth: 0
				},
				series: series_data
			});
		});
	</script>
</head>
<body>
	<!-- include header -->
	<div class="cp-wrap">
		<div class="crumb">
		</div>
		<div class="cp-table">
			<div id="container"></div>
			<div id="datalist"></div>
		</div>
	</div>
	<!-- include footer -->	
	<script>
		$("#datalist").load("?m=spider&a=spider_list");
		$(document).on('click', ".cp-pages a", function(){
			$("#datalist").load($(this).prop("href"));
			return false;
		});
	</script>
	<script type="text/javascript" src="/static/js/highcharts.js"></script>
</body>
</html>