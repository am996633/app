<!--//compress on #启用模板压缩  -->
<div class="footer">
	<p>专题易 © 2016 ThinkInCloud</p>
</div>
<div class='msgTip'></div>
<script>
	<!--if !empty($headMenu)-->
	var subMenu = {$subMenu};
	var AlertMsg = getCookie('AlertMsg');
	if(AlertMsg.length > 0){
		cpAlert(AlertMsg, 1);
		setCookie("AlertMsg", "", -1000, '/');
	}
	var AlertErrMsg = getCookie('AlertErrMsg');
	if(AlertErrMsg.length > 0){
		cpAlert(AlertErrMsg, 0);
		setCookie("AlertErrMsg", "", -1000, '/');
	}

	loadLeftMenu($(".header .menu li.cur").index());
	$(".header .menu li").on('click', function(){
		var menuId = $(this).attr("data-menuId");
		if(menuId==0){
			window.location.href = '?m=dashboard';
		}else{
			$(this).addClass('cur').siblings().removeClass('cur');
			loadLeftMenu(menuId);
		}
	});
	<!--/if-->
	$(".AjaxPost").on('submit', function(){
		AjaxPost(this);
		return false;
	});

</script>
