<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta name="renderer" content="webkit">
	<meta http-equiv="X-UA-Compatible" content="IE=edge" />
	<meta name="viewport" content="width=device-width, minimum-scale=1, maximum-scale=1, user-scalable=no">
	<title>专题易 © 2016 ThinkInCloud</title>
	<link rel="stylesheet" type="text/css" href="__APPROOT__/css/dashboard.css" />
	<script type="text/javascript" src="/static/js/jquery.js"></script>
	<script type="text/javascript" src="__APPROOT__/js/common.js"></script>
	<link rel="stylesheet" type="text/css" href="__APPROOT__/css/system.css" />
	
	<style type="text/css">
		.tabcss{}
		.dbcss{color:#fff;}
	</style>
	<script type="text/javascript">
		function changeSwitch(obj,id){
			var tt = $(obj).attr("data");
			if(tt==1){
				$(obj).removeClass("turnbg_1");
				$(obj).addClass("turnbg_0");
				$(obj).attr("data",0);
			}else{
				$(obj).removeClass("turnbg_0");
				$(obj).addClass("turnbg_1");
				$(obj).attr("data",1);
			}
			var ts = $(obj).attr("data");
			window.location.href="?m=storageservice&a=changeStatus&status="+ts+"&id="+id;
		}
	</script>
</head>
<body>
	<!-- include header -->
	<div class="cp-wrap">
		<div class="crumb"></div>
		<div class="cp-table" id="tabcss">
			<table width="100%" border="0" cellpadding="0" cellspacing="0"  >
				<tbody>
					<tr>
						<td  align="left">
							云存储商
						</td>
						<td align="left">
							状态
						</td>
						<td width="100" align="center">操作</td>
					</tr>
					<!--  foreach $list -->
					<tr>
						<td  align="left" height="60">
							<a href="{$provider[$type][url]}" target="_blank"><img src="{$provider[$type][icon]}" style="vertical-align:middle;" /></a>
							{$provider[$type][desc]}
						</td>
						<td align="left" class="tabcss">
							<div class=" switch turnbg_{$status}" data="{$status}"  id="switch1"  onclick="changeSwitch(this,{$id})"></div>
						</td>
						<td width="100" align="center">
							{if $status ==1}
							<a href="?m=storageservice&a=edit&id={$id}">设置</a>
							{/if}
						</td>
					</tr>
					<!-- /foreach -->
				</tbody>
			</table>
		</div>
	</div>
	<!-- include footer -->
	<script>
	</script>
</body>
</html>