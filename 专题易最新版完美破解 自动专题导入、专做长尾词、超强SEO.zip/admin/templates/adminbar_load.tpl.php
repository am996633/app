<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta name="renderer" content="webkit">
	<meta http-equiv="X-UA-Compatible" content="IE=edge" />
	<meta name="viewport" content="width=device-width, minimum-scale=1, maximum-scale=1, user-scalable=no">
	<title>专题易 © 2016 ThinkInCloud</title>
	<link rel="stylesheet" type="text/css" href="__APPROOT__/css/dashboard.css" />
	<script type="text/javascript" src="/static/js/jquery.js"></script>
	<script type="text/javascript" src="__APPROOT__/js/common.js"></script>
	<script type='text/javascript'>
			$.post('{$mdurl}', {'upcache': '1'}, function(){
				window.location.href='{$mdurl}?'+Math.random();
			});
	</script>
</head>
<body>
	<div style="width:1120px; margin:0 auto ; height:150px; line-height:150px; font-size:24px; text-align:center;">
		<div style="">正在加载中.......</div>
	</div>
</body>
</html>