<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta name="renderer" content="webkit">
	<meta http-equiv="X-UA-Compatible" content="IE=edge" />
	<meta name="viewport" content="width=device-width, minimum-scale=1, maximum-scale=1, user-scalable=no">
	<title>专题易 © 2016 ThinkInCloud</title>
	<link rel="stylesheet" type="text/css" href="__APPROOT__/css/dashboard.css" />
	<link rel="stylesheet" type="text/css" href="__APPROOT__/css/form-style.css" />
	<script type="text/javascript" src="/static/js/jquery.js"></script>
	<script type="text/javascript" src="__APPROOT__/js/common.js"></script>
</head>
<body>
	<!-- include header -->
	<div class="cp-wrap">
		<div class="crumb"></div>
		
		<div class="cp-form">
			<form method="POST" class="AjaxPost" action="?m=system&a=config" onsubmit="return false;">
				<div class="control-group">
					<label class="control-label" for="name">文章关键词：</label>
					<div class="controls controls-row">
						<textarea name="data[seoWord]" style="width:450px;height:200px;">{$var[seoWord]}</textarea>
						<span>多个关键词用逗号或换行隔开</span>
					</div>
				</div>
				<div class="control-group">
					<label class="control-label" for="name">同时插入标题：</label>
					<div class="controls controls-row">
						<label><input type="radio"  name="data[seoTitle]" value="1" {if $var[seoTitle]==1}checked='checked'{/if}> 是 </label>
						<label><input type="radio"  name="data[seoTitle]" value="0"  {if $var[seoTitle]==0}checked='checked'{/if}> 否 </label>
					</div>
				</div>
				<div class="control-group">
					<label class="control-label" for="name">插入标题位置：</label>
					<div class="controls controls-row">
						<label><input type="radio"  name="data[seoTitle_x]" value="1" {if $var[seoTitle_x]==1}checked='checked'{/if}> 标题前面 </label>
						<label><input type="radio"  name="data[seoTitle_x]" value="2"  {if $var[seoTitle_x]==2}checked='checked'{/if}> 标题后面 </label>
						<label><input type="radio"  name="data[seoTitle_x]" value="3"  {if $var[seoTitle_x]==3}checked='checked'{/if}> 自由插入</label>
					</div>
				</div>
				
				<div class="control-group">
					<label class="control-label" for="name">插入数量：</label>
					<div class="controls controls-row">
						<input type="text" class="input-small focused" name="data[seoWordNum]" value="{$var[seoWordNum]}" >
						<span>每篇文章插入词语的数量</span>
					</div>
				</div>
				<div class="control-group">
					<label class="control-label" for="name">插入比例：</label>
					<div class="controls controls-row">
						<input type="text" class="input-small focused" name="data[seoWordScale]" value="{$var[seoWordScale]}" >
						<span>插入文章的比例，可填0-100，0关闭该功能，100全部文章都插入</span>
					</div>
				</div>
				
				<div class="form-actions">
					<input type="submit" class="btn" value="保存" />
				</div>
			</form>		
		</div>
	</div>
	<!-- include footer -->
	<script type="text/javascript" src="/static/js/jquery.validform.js"></script>
	<script>

	</script>
</body>
</html>