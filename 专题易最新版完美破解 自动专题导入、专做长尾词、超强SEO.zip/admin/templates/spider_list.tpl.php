<table width="100%" border="0" cellpadding="0" cellspacing="0">
	<tbody>
		<tr>
			<th width="150" align="center">时间</th>
			<th width="120" align="center">爬虫</th>
			<th align="left">抓取链接</th>
		</tr>
		<!-- foreach $list -->
		<tr>
			<td align="center">
				{date('Y-m-d H:i',$addtime)}
			</td>
			<td align="center"> {$spider_types[$spider]}</td>
			<td align="left"> {$url}</td>
		</tr>
		<!-- /foreach -->
	</tbody>
</table>

<!-- if empty($list) -->
<div class="noresult">暂时没有可显示数据</div>
<!-- /if -->
<a class="btn" style="color:#fff;" href="?m=spider&a=clean" onclick="return confirm('?')">清除全部记录</a>
<div class="cp-pages">
	{$page}
</div>