<table width="100%" border="0" cellpadding="0" cellspacing="0">
	<tr>
		<th align="left" ><input   id="all" type="checkbox" onclick="check_all()" />&nbsp;&nbsp;关键词</th>
		<th align="left">关注度</th>
	</tr>
	<!--foreach $list $v -->
	<tr>
		<td>
		{if isset($klist[$v['keyword']])}
		<input name="key_box[]" value="{$v['id']}" checked="checked"  disabled="true"  class="checkboxed" type="checkbox" />
		{else}
		<input name="key_box[]" value="{$v['id']}"  class="checkboxed" type="checkbox" />
		{/if}
			&nbsp;
			<span>{$v['keyword']}</span>&nbsp;&nbsp;
			{if isset($klist[$v['keyword']])}
			<span style="font-size:10px;color:#fff;background:#0092DC; padding-left:5px;padding-right:5px;">已选</span>
			{/if}
		</td>
		<td class="td_right">{$v['click']}</td>
	</tr> 
	<!-- /foreach-->
</table>
<div class="cl">
	<div class="fl">
		{if !empty($list)} 
		<input type="submit" value="加入我的专题" class="sub_keyword btn"  onclick="submitkeyword();" >
		<div id="msg" style="color:red;"></div>
		{/if}
	</div>
	<div class="cp-pages fr">
		{$pagelink}
	</div>
</div>

