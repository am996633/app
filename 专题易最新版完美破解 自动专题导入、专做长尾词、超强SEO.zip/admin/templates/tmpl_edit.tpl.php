<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta name="renderer" content="webkit">
	<meta http-equiv="X-UA-Compatible" content="IE=edge" />
	<meta name="viewport" content="width=device-width, minimum-scale=1, maximum-scale=1, user-scalable=no">
	<title>专题易 © 2016 ThinkInCloud</title>
	<link rel="stylesheet" type="text/css" href="__APPROOT__/css/dashboard.css" />
	<script type="text/javascript" src="/static/js/jquery.js"></script>
	<script type="text/javascript" src="__APPROOT__/js/common.js"></script>
</head>
<body>
	<!-- include header -->
	<div class="cp-wrap">
		<div class="crumb"></div>
		<div class="cp-form">
			<div class="box">
				<div class="box-title">编辑简述模板</div>
				<form method="POST" class="AjaxPost">
					<input name="id" type="hidden" value="{$r['id']}" />
					<div class="control-group">
						<label class="control-label" for="name">模板名称：</label>
						<div class="controls">
							<textarea  style="width:460px;" rows="8" name="content" >{$r['content']}</textarea>
							<div style="color:#777;">填写示例：
									<div>这是一个有关{topic}的专题，小编对{topic}相关要点进行了整理，<br/>疏理了最新的{topic}的相关报道，以及关于{topic}的微博评论，为什么{topic}，后续还会追踪报道，感谢您的关注。
								</div></div>
						</div>
					</div>
					<div class="form-actions" >
						<input type="submit" class="btn" value="保存" />
						<input type="button" class="btn btn-link" value="返回" onclick="history.back(-1)"/>
					</div>
				</form>	
			</div>
		</div>
	</div>
	<!-- include footer -->
</body>
</html>