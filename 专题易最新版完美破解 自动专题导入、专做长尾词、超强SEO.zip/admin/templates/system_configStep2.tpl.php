<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta name="renderer" content="webkit">
	<meta http-equiv="X-UA-Compatible" content="IE=edge" />
	<meta name="viewport" content="width=device-width, minimum-scale=1, maximum-scale=1, user-scalable=no">
	<title>专题易 © 2016 ThinkInCloud</title>
	<link rel="stylesheet" type="text/css" href="__APPROOT__/css/dashboard.css" />
	<script type="text/javascript" src="/static/js/jquery.js"></script>
	<script type="text/javascript" src="__APPROOT__/js/common.js"></script>
</head>
<body>
	<!-- include header -->
	<div class="cp-wrap">
		<div class="crumb"></div>
		<div class="cp-form">
			<div class="box">
				<div class="box-title">重新确认账户信息</div>
				<form method="POST"  class="AjaxPost" action="?m=system&a=configStep2">
					<input type="hidden" name="username" value="{$username}">
					<input type="hidden" name="ref" value="{$ref}">
					<div class="tip" style="margin:10px 130px; padding:5px; width:600px;border:dotted 1px #ccc;color:#F60;">
						由于您较长时间未更改过配置，为了您的系统安全，请重新校验站点激活账号的密码
					</div>
					<div class="control-group">
						<label class="control-label" for="name">授权账号：</label>
						<div class="controls">
							<p>{$username}</p>
						</div>
					</div>
					<div class="control-group">
						<label class="control-label" for="name">确认密码：</label>
						<div class="controls">
							<input type="password" class="input-xlarge focused" name="password" style="width:450px;">
							<input type="password" style="position:fixed;bottom:-9999px;"> <!-- 用于禁止密码填充 -->
						</div>
					</div>
					<div class="form-actions">
						<input type="submit" class="btn" value="确认" />
						<input type="button" class="btn btn-link" value="返回" onclick="history.back(-1)"/>
					</div>
				</form>	
			</div>
		</div>
	</div>
	<!-- include footer -->
	<script>

	</script>
</body>
</html>