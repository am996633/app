<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta name="renderer" content="webkit">
	<meta http-equiv="X-UA-Compatible" content="IE=edge" />
	<meta name="viewport" content="width=device-width, minimum-scale=1, maximum-scale=1, user-scalable=no">
	<title>专题易 © 2016 ThinkInCloud</title>
	<link rel="stylesheet" type="text/css" href="__APPROOT__/css/dashboard.css" />
	<script type="text/javascript" src="/static/js/jquery.js"></script>
	<script type="text/javascript" src="__APPROOT__/js/common.js"></script>
	<style type="text/css">
		.sql td{ line-height:25px; padding:5px; width:80px; border-right:1px solid #fff;border-top:1px solid #fff; }
		tr:nth-of-type(odd){ background:#ccc;}
	</style>
	<script type="text/javascript">
		function sqlChange(){
			var sql = $("#sql").val();
			$("#text_sql").val(sql);
		}
	</script>
</head>
<body>
	<!-- include header -->
	<div class="cp-wrap">
		<div class="crumb"></div>
		<div class="cp-form">
			<div class="box">
				
				<div class="box-title">SQL命令执行工具</div>
				<form method="POST" action="?m=tools&a=index">
					
					<div class="control-group" style="padding-left:20px;width:450px;">
						<select name="sql" id="sql" onchange="sqlChange()">
							<option value="">常用命令</option>
							<option value="REPAIR TABLE `attachment`;REPAIR TABLE `topic`;REPAIR TABLE `content`;REPAIR TABLE `contentbody`;REPAIR TABLE `topic_baike`;REPAIR TABLE `topic_wenwen`;REPAIR TABLE `topic_body`;REPAIR TABLE `urlcache`;REPAIR TABLE `spider`;">修复数据表 </option>
							<option value="OPTIMIZE TABLE `attachment`;OPTIMIZE TABLE `topic`;OPTIMIZE TABLE `content`;OPTIMIZE TABLE `contentbody`;OPTIMIZE TABLE `topic_baike`;OPTIMIZE TABLE `topic_wenwen`;OPTIMIZE TABLE `topic_body`;OPTIMIZE TABLE `urlcache`;OPTIMIZE TABLE `spider`;">优化数据表 </option>
						</select>
					</div>
					
					<div class="control-group" style="padding-left:20px;">
						<textarea name="command" style="width:500px; height:115px;" id="text_sql">{$command}</textarea>
					</div>
					<div class="form-actions" >
						<input type="submit" class="btn" value="执行" />
					</div>
				</form>	
				<div>{$msg}</div>
				{if isset($list)}
				<table class="sql" width="100%" cellpadding="0" cellspacing="0">
					<tr>
						<!--  foreach $columns $v1-->
						<td>{$v1}</td>
						<!-- /foreach -->
					</tr>
					<!--  foreach $list $v-->
					<tr>
						<!--  foreach $columns $v1-->
						<td>{htmlspecialchars( $v[$v1], ENT_QUOTES, 'utf-8')}</td>
						<!-- /foreach -->
					</tr>
					<!-- /foreach -->
				</table>
				{/if}
				<!-- if $errTable -->
				<div class="tip-box">
					系统检测到数据表{$errTable}需要修复，<a href="?m=tools&a=repair&table={$errTable}">点击修复</a>
				</div>
				<!-- /if -->
			</div>
		</div>
	</div>
	<!-- include footer -->
</body>
</html>