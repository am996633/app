<?php
define("NOFILTER", true);
define("APPNAME", substr(dirname($_SERVER['SCRIPT_NAME']), 1));
require dirname(dirname(__FILE__)).'/core/loader.php';

$_menuconfig = array(
	array(
		'系统首页',
		array(
			'groupName' => '快捷菜单',
			'menulink' => array(
				array('管理员', 'admin', 'index'),
				array('修改密码', 'admin', 'password'),
				),
			),
		),
	array(
		'专题管理',
		array(
			'groupName' => '专题管理',
			'menulink' => array(
				array('专题管理', 'topic', 'index'),
				array('批量添加专题', 'topic', 'add_alls'),
				array('文章列表', 'content', 'index'),
				),
			),
		array(
			'groupName' => '其他相关',
			'menulink' => array(
				array('专题简述模板', 'tmpl', 'index'),
				array('独立页面', 'page', 'index'),
				),
			),
		),
	array(
		'高级设置',
		array(
			'groupName' => '高级设置',
			'menulink' => array(
				array('过滤词语', 'setting', 'filterContent'),
				array('屏蔽网址', 'setting', 'shieldUrl'),
				),
			),
		),
	array(
		'搜索优化',
		array(
			'groupName' => '搜索优化',
			'menulink' => array(
				array('同义词替换', 'seo', 'reword'),
				array('关键词优化', 'seo', 'seoword'),
				array('文章混淆', 'seo', 'confuse'),
				),
			),
		),
	array(
		'其他管理',
		array(
			'groupName' => '其他管理',
			'menulink' => array(
				array('爬虫统计', 'spider', 'index'),
				array('广告管理', 'ads', 'index'),
				array('友情链接', 'flink', 'index'),
				array('SQL命令工具', 'tools', 'index'),
				array('图片云存储', 'storageservice', 'index'),
				),
			),
		),
	array(
		'系统设置',
		array(
			'groupName' => '参数设置',
			'menulink' => array(
				array('系统配置', 'system', 'config'),
				array('手机配置', 'system', 'mobileweb'),
				array('站点激活', 'system', 'bind'),
				array('在线更新', 'system', 'update'),
				),
			),
		),
	array(
		'云平台',
		array(
			'groupName' => '云平台',
			'menulink' => array(
				array('关键词库', 'keyword', 'index'),
				array('新词推荐', 'keyword', 'newword'),
				array('热词推荐', 'keyword', 'hotword'),
				),
			),
		),

	);

class admincp extends controller{

	public $user, $headMenu, $subMenu;
	private $_menuconfig;

	public function __construct(){
		global $_menuconfig;
		parent::__construct();
		$this->user = admin::get();
		$this->_menuconfig = $_menuconfig;
		$this->loadHeaderMenu();
		$this->loadLeftMenu();
	}

	/*
	 *  顶部菜单
	 */
	private function loadHeaderMenu(){
		foreach ($this->_menuconfig as $val) {
			$this->headMenu[] = array(
				'name' => $val[0],
				'id' => $val[1],
				'current' => 0,
				);
		}
		$findCur = false;
		foreach ($this->_menuconfig as $key => $val) {
			$val = array_slice($val, 1);
			foreach ($val as $vg) {
				foreach ($vg['menulink'] as $k => $v) {
					if($v[1] == M){
						$this->headMenu[$key]['current'] = 1;
						$findCur = true;
						break 3;
					}
				}
			}
		}
		if(!$findCur){
			$this->headMenu[0]['current'] = 1;
		}
	}

	/*
	 *  左边菜单
	 */
	private function loadLeftMenu(){
		$submenu = array();
		foreach ($this->_menuconfig as $key => $val) {
			$submenu_string = '';
			for($i=1; $i<count($val); $i++){
				$submenu_string .= '<div>';
				$submenu_string .= '<div class="menu-title active"><i class="menu-icon"></i>'.$val[$i]['groupName'].'</div>';
				$submenu_string .= '<ul>';
				foreach ($val[$i]['menulink'] as $menu) {
					$submenu_string .= '<li><a href="?m='.$menu[1].'&a='.$menu[2].'">'.$menu[0].'</a></li>';
				}
				$submenu_string .= '</ul>';
				$submenu_string .= '</div>';
			}
			$submenu[$key] = $submenu_string;
		}
		$this->subMenu = json_encode( $submenu );
	}
}

loader::init()->load('session')->run();

