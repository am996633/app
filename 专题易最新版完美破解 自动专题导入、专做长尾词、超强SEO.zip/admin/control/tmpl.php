<?php

if(!defined('IN_SYS')) exit('Access Denied');

class tmpl_controller extends admincp{

	public function __construct(){
		parent::__construct();
	}



	public function index(){
		$pg = new page("select * from tmpl order by id desc");
		$list = $pg->get_list(20);
		$page = $pg->get_page();
		require self::tpl('tmpl');
	}

	public function add(){
		if(IS_POST){
			$content  = gp("content",false);
			db::query("insert into tmpl(content) values('$content')");
			self::json( array('status' => 1, 'msg' => '添加成功', 'redirect' => '?m=tmpl') );
		}else{
			require self::tpl("tmpl_add");
		}
	}


	public function edit(){
		$id = gp('id');
		if(IS_POST){
			$content = gp("content",false);
			db::query("update tmpl set content='$content' where id='$id' ");
			self::json( array('status' => 1, 'msg' => '修改成功', 'redirect' => '?m=tmpl') );
		}else{
			$r = db::find("select * from tmpl where id='$id' ");
			require self::tpl("tmpl_edit");
		}
	}

	public function del(){
		$id = gp('id');
		db::query("delete from tmpl where id='$id' ");
		self::redirect("?m=tmpl", "删除成功");
	}




}


