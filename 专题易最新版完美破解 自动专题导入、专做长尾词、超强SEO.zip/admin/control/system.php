<?php

if(!defined('IN_SYS')) exit('Access Denied');

class system_controller extends admincp{

	public function __construct(){
		parent::__construct();
	}

	public function config(){
		if(IS_POST){
			$data = gp("data", false);
			if(isset($data['channel_time'])){
				$data['channel_time'] = max(300, $data['channel_time']);
			}
			if(isset($data['list_time'])){
				$data['list_time'] = max(600, $data['list_time']);
			}
			if(isset($data['page_time'])){
				$data['page_time'] = max(3600, $data['page_time']);
			}
			if(isset($data['webHost']) && empty($data['webHost'])){
				$data['webHost'] = $_SERVER['HTTP_HOST'];
			}
			foreach ($data as $key => $value) {
				db::query("update config set varValue='$value' where varName='$key' ");
			}
			self::json( config::update_config() );
		}else{
			$r = db::select("select * from config");
			$var = array();
			foreach ($r as $key => $value) {
				$var[$value['varName']] = $value['varValue'];
			}
			require self::tpl("system_config");

			
		}
	}

	public function configStep2(){
		$ref = gp('ref', false);
		if(IS_POST){
			$r = gp("username,password");
			$data = array();
			$data['username'] = $r['username'];
			$data['password'] = $r['password'];
			$data['appid'] = db::getfield("select varValue from config where varName='appid'");
			$toUrl = REMOTEAPI."/sync/updateConfigDate";
			$resdata = httpUnit::post($toUrl, $data);
			if($resdata['httpcode']!=200 || !($res = json_decode($resdata['html'], true)) ){
				self::redirect('?m=system&a=bind', "网络异常，请稍后再试");
			}
			if($res['status']==1){
				$res = config::update_config();
				if($res['status']==1){
					
					self::json( array('status' => 1, 'msg' => '配置修改成功', 'redirect' => $ref) );
				}else{
					self::json( $res );
				}
			}else{
				self::json($res);
			}
		}else{
			$username = gp('u');
			require self::tpl("system_configStep2");
		}
	}

	public function index(){
		$this->config();
	}

	//添加绑定
	public function bind(){
		if(IS_POST){
			$r = gp("username,password");
			$data = array();
			$data['username'] = $r['username'];
			$data['password'] = $r['password'];
			$data['url']= $_SERVER["HTTP_HOST"];
			$toUrl = REMOTEAPI."/sync/activate";
			$resdata = httpUnit::post($toUrl, $data);

			if($resdata['httpcode']!=200 || !($res = json_decode($resdata['html'], true)) ){
				self::redirect('?m=system&a=bind', "网络异常，请稍后再试");
			}
			$usenum = $res['usenum'];
			$keynum = $res['keynum'];
			$num = $keynum - $usenum;
			$user_name =$r['username'];
			$password = $r['password'];

			if($res['status']==1 && isset($res['appid'])){
				$appid = $res['appid'];
				$appkey = $res['appkey'];
				db::query("update config set varValue='$appkey' where varName = 'appkey'  ");
				db::query("update config set varValue='$appid' where varName = 'appid'  ");
				$upconfig = config::update_config();
				if($upconfig['status']){
					$this->conf['appid'] = $appid;
					$this->conf['appkey'] = $appkey;
					require self::tpl("system_appinfo");
				}else{
					self::redirect('?m=system&a=bind', $upconfig['errMsg']);
				}
			}elseif($res['status']==1 || $res['errType']=='noMoreKey'){
				require self::tpl("system_bind_next");
			}else{
				self::redirect( '?m=system&a=bind', $res['errMsg'] );
			}
		}else{
			if(empty($this->conf['appid']) || empty($this->conf['appkey'])){
				require self::tpl("system_bind");
			}else{
				require self::tpl("system_appinfo");
			}
		}
	}

	public function bind_next(){
		$r = gp("username,password");
		$url = $_SERVER["HTTP_HOST"];
		$data = array();
		$data['username'] = $r['username'];
		$data['password'] = $r['password'];
		$data['confirm'] =1;
		$data['url']= $url;
		$toUrl = REMOTEAPI."/sync/activate";
		$resdata = httpUnit::post($toUrl, $data);
		if($resdata['httpcode']!=200 || !($res = json_decode($resdata['html'], true)) ){
			self::redirect('?m=system&a=bind', "网络异常，请稍后再试");
		}
		if($res['status']!=1){
			self::redirect( '?m=system&a=bind', $res['errMsg'] );
		}
		$appkey = $res['appkey'];
		$appid = $res['appid'];
		$res=db::query("update config set varValue='$appkey' where varName = 'appkey'  ");
		$res_v=db::query("update config set varValue='$appid' where varName = 'appid'  ");
		$upconfig = config::update_config();
		if(!$upconfig['status']){
			self::json( array('status' => 0, 'errMsg' => '绑定失败', 'redirect'=>'?m=system&a=bind' ) );
		}else{
			self::json( array('status' => 1, 'msg' => '绑定成功', 'redirect'=>'?m=system&a=bind' ) );
		}
	}

	/*解除绑定*/
	public function unbind(){
		db::query("update config set varValue='' where varName='appkey' OR varName='appid'");
		config::update_config(false);
		self::redirect("?m=system&a=bind", "解绑成功");
	}

	public function mobileweb(){
		$r = db::select("select * from config");
		$var = array();
		foreach ($r as $key => $value) {
			$var[$value['varName']] = $value['varValue'];
		}
		require self::tpl("system_mobileweb");
	}

	public function switchval(){
		$varName = gp("field");
		$value = gp("data");
		$result = db::query("update config set varValue='$value' where varName='$varName' ");
		echo config::update_config();
	}

	public function switchcaiji(){
		$data = array();
		$data['version'] = $this->conf['softversion'];
		$data['appid'] = $this->conf['appid'];
		$data['http_host'] = $_SERVER['HTTP_HOST'];
		$data['status'] = gp("data");
		$msg = "";
		$toUrl = REMOTEAPI."/sync/checkstatus";
		$resdata = httpUnit::post($toUrl, $data, $this->conf['appkey']);
		if($resdata['httpcode']!=200 || !($res = json_decode($resdata['html'], true)) ){
			$msg = "网络异常，请稍后再试";
		}
		echo json_encode(true);
	}

	public function getCaiji(){
		$data = array();
		$data['version'] = $this->conf['softversion'];
		$data['appid'] = $this->conf['appid'];
		$data['http_host'] = $_SERVER['HTTP_HOST'];
		$respond['status'] = 0;
		if($data['appid']){
			$toUrl = REMOTEAPI."/sync/getStatus";
			$resdata = httpUnit::post($toUrl, $data, $this->conf['appkey']);
			if($resdata['httpcode']!=200 || !($res = json_decode($resdata['html'], true)) ){
				$respond['status'] = 1;
				$respond['data'] = 0;
			}elseif($res['status']==1){
				$respond['status'] = 1;
				$respond['data'] = $res['data'];
			}
		}
		echo json_encode($respond);
	}

	public function update(){
		$data = array();
		$data['version'] = $this->conf['softversion'];
		$data['appid'] = $this->conf['appid'];
		$data['http_host'] = $_SERVER['HTTP_HOST'];

		$toUrl = REMOTEAPI."/upgrade/checkupgrade";
		$resdata = httpUnit::post($toUrl, $data, $this->conf['appkey']);
		if($resdata['httpcode']!=200 || !($res = json_decode($resdata['html'], true)) ){
			self::redirect('?m=system&a=bind', "网络异常，请稍后再试");
		}
		self::delcache(DATA.'/tplcache');
		require self::tpl("system_update");
	}

	public function update_step2(){

		$data = array();
		$data['version'] = $this->conf['softversion'];
		$data['appid'] = $this->conf['appid'];
		$data['http_host'] = $_SERVER['HTTP_HOST'];

		$toUrl = REMOTEAPI."/upgrade/downupdate";
		$resdata = httpUnit::post($toUrl, $data, $this->conf['appkey']);
		if($resdata['httpcode']!=200 || !($res = json_decode($resdata['html'], true)) ){
			self::redirect('?m=system&a=bind', "网络异常，请稍后再试");
		}
		if($res['status']==1){
			$myfile = fopen(dirname(dirname(__FILE__))."/upgrade.php", "w") or die("无法写入文件!");
			fwrite($myfile, $res['content']);
			fclose($myfile);
			self::redirect('./upgrade.php');
		}else{
			self::redirect('?m=system&a=update', "升级失败");
		}
	}

	public static function delcache($dir) {
		if(!is_dir($dir)) return;
		$dh=opendir($dir);
		while ($file = readdir($dh)) {
			if($file != "." && $file != "..") {
				$fullpath = $dir."/".$file;
				if(!is_dir($fullpath)) {
					unlink($fullpath);
				} else {
					self::delcache($fullpath);
				}
			}
		}
		closedir($dh);
		// rmdir($dir);
	}

}

