<?php

if(!defined('IN_SYS')) exit('Access Denied');

class ads_controller extends admincp{

	public function __construct(){
		parent::__construct();
	}

	public function index(){
		$pg = new page("select *   from  ads order by id asc ");
		$list = $pg->get_list(20);
		$page = $pg->get_page();
		require self::tpl('ads');
	}

	public function add(){
		if(IS_POST){
			$time = time();
			$v = gp("title,content,status", false);
			db::query("insert into ads (title,content,addtime,status) 
			values ('$v[title]', '$v[content]','$time','$v[status]') ");
			self::json( array('status' => 1, 'msg' => '添加成功', 'redirect' => '?m=ads') );
		}else{
			require self::tpl("ads_add");
		}
	}

	public function edit(){
		$id = gp('id');
		if(IS_POST){
			$v = gp("title,content,status", false);
			db::query("update ads set title='$v[title]', content='$v[content]' ,status='$v[status]'
		 where id='$id' ");
			self::json( array('status' => 1, 'msg' => '修改成功', 'redirect' => '?m=ads') );
		}else{
			$r = db::find("select *  from ads  where id='$id' ");
			require self::tpl("ads_edit");
		}
	}

	public function del(){
		$id = gp('id');
		db::query("delete from ads where id='$id' ");
		self::redirect("?m=ads", "删除成功");
	}

}


