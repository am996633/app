<?php

if(!defined('IN_SYS')) exit('Access Denied');

class page_controller extends admincp{

	public function __construct(){
		parent::__construct();
	}

	public function index(){
		$pg = new page("select id,title from page  order by id desc");
		$list = $pg->get_list(20);
		$page = $pg->get_page();
		require self::tpl('page');
	}

	public function edit(){
		$id = gp('id');
		if(IS_POST){
			$v = gp("title,thumb,keywords,description");
			$body =  gp("body",false);
			db::query("update page set title='$v[title]', thumb='$v[thumb]', keywords='$v[keywords]',
			description='$v[description]',body='$body' where id='$id' ");
			self::json( array('status' => 1, 'msg' => '修改成功', 'redirect' => '?m=page') );
		}else{
			$r = db::find("select  *   from  page where id='$id' ");
			require self::tpl("page_edit");
		}
	}
}


