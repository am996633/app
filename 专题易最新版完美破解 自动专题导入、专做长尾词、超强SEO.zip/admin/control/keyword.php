<?php

if(!defined('IN_SYS')) exit('Access Denied');

class keyword_controller extends admincp{

	public function __construct(){
		parent::__construct();
	}

	public function index(){
		$data = array();
		$data['appid'] = $this->conf['appid'];
		$data['http_host'] = $_SERVER["HTTP_HOST"];
		$toUrl = REMOTEAPI."/keyword/getCategory";
		$res = httpUnit::json($toUrl, $data, $this->conf['appkey'], null);
		$list_type = $res['data'];
		require self::tpl("keyword_index");
	}

	public function getKeywordList(){
		$data = array();
		$catecagory_id = gp("catecagory_id");
		$data['appid'] = $this->conf['appid'];
		$data['http_host'] = $_SERVER["HTTP_HOST"];
		$data['categoryId'] = $catecagory_id;
		$page = $data['page'] = intval(gp('page'));
		$toUrl = REMOTEAPI."/keyword/getList";
		$res = httpUnit::json($toUrl, $data, $this->conf['appkey'], null);
		$list = $res['data'];

		if($list){
			$ks = array();
			foreach ($list as $key => $value) {
				$ks[] = "'".addslashes($value['keyword'])."'";
			}
			$kstr = join(',', $ks);
			$klist = db::select("select title from topic where title IN ($kstr) ", 'title');
		}

		$pageNum = $res['pageNum'];
		$paegstart = max(0, $data['page']-5);
		$paegend = min($pageNum-1, $data['page']+5);
		$pagelink = "";
		
		for ($i=$paegstart; $i<=$paegend; $i++) {
			$pagetext = $i+1;
			if($page==$i){
				$pagelink .= "<b onclick='keywords(\"{$catecagory_id}\", {$i})' >{$pagetext}</b>";
			}else{
				$pagelink .= "<a href='javascript:void(0);' onclick='keywords(\"{$catecagory_id}\", {$i})' >{$pagetext}</a>";
			}
		}
		$pagelink  .="<span>总计".$res['total']."词</span>";
		require self::tpl("keyword_list");
	}

	public function addKeyword(){
		$list_data = json_decode( stripslashes( gp('data', false) ) );
		$num = 0;
		$key_id = array();
		foreach ($list_data as $key => $value) {
			$id = $value[0];
			$keywor_val = $value[1];
			$time = time();
			$keyword = db::find("select id from topic where title ='$keywor_val'");
			$temp_pinyin  = topic::getAllWord($keywor_val);
			$pinyin = topic::checkPinyin($temp_pinyin);
			$pyurl = "/".$pinyin."/";
			if($keywor_val){
				if(empty($keyword)){
					$key_id[] = $id;
					db::query("insert into topic (title, pinyin, pyurl, description, addtime, click,flag) 
						values ('$keywor_val','$pinyin','$pyurl','','$time', 0 , 1) ");
					$num++;
				}
			} 
		}
		if($key_id){
			$data = array();
			$data['appid'] = $this->conf['appid'];
			$data['http_host'] = $_SERVER["HTTP_HOST"];
			$data['key_id'] = join(',', $key_id);
			$toUrl = REMOTEAPI."/keyword/updateclick";
			httpUnit::json($toUrl, $data, $this->conf['appkey'], null);
		}
		
		$data['status'] = 1;
		$data['msg'] = "成功添加".$num."个专题";
		echo json_encode($data);
	}

	public function newword(){
		require self::tpl("keyword_newword");
	}

	public function getNewKeywordList(){
		$data = array();
		$data['appid'] = $this->conf['appid'];
		$data['http_host'] = $_SERVER["HTTP_HOST"];
		$page = $data['page'] = intval(gp('page'));
		$toUrl = REMOTEAPI."/keyword/getNewword";
		$res = httpUnit::json($toUrl, $data,$this->conf['appkey'], null);
		$list = $res['data'];

		if($list){
			$ks = array();
			foreach ($list as $key => $value) {
				$ks[] = "'".addslashes($value['keyword'])."'";
			}
			$kstr = join(',', $ks);
			$klist = db::select("select title from topic where title IN ($kstr) ", 'title');
		}

		$pageNum = $res['pageNum'];
		$paegstart = max(0, $data['page']-5);
		$paegend = min($pageNum-1, $data['page']+5);
		$pagelink = "";
		for ($i=$paegstart; $i<=$paegend; $i++) {
			$pagetext = $i+1;
			if($page==$i){
				$pagelink .= "<b onclick='keywords({$i})'>{$pagetext}</b>";
			}else{
				$pagelink .= "<a href='javascript:void(0);' onclick='keywords({$i})' >{$pagetext}</a>";
			}
		}
		require self::tpl("keyword_list");
	}

	public function hotword(){
		require self::tpl("keyword_hotword");
	}

	public function getHotKeywordList(){
		$data = array();
		$data['appid'] = $this->conf['appid'];
		$data['http_host'] = $_SERVER["HTTP_HOST"];
		$page = $data['page'] = intval(gp('page'));
		$toUrl = REMOTEAPI."/keyword/getHotword";
		$res = httpUnit::json($toUrl, $data,$this->conf['appkey'], null);
		$list = $res['data'];

		if($list){
			$ks = array();
			foreach ($list as $key => $value) {
				$ks[] = "'".addslashes($value['keyword'])."'";
			}
			$kstr = join(',', $ks);
			$klist = db::select("select title from topic where title IN ($kstr) ", 'title');
		}

		$pageNum = $res['pageNum'];
		$paegstart = max(0, $data['page']-5);
		$paegend = min($pageNum-1, $data['page']+5);
		$pagelink = "";
		for ($i=$paegstart; $i<=$paegend; $i++) {
			$pagetext = $i+1;
			if($page==$i){
				$pagelink .= "<b onclick='keywords({$i})'>{$pagetext}</b>";
			}else{
				$pagelink .= "<a href='javascript:void(0);' onclick='keywords({$i})' >{$pagetext}</a>";
			}
		}
		require self::tpl("keyword_list");
	}

}

