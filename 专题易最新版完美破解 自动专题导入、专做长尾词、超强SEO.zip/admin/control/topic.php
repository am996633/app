<?php

if(!defined('IN_SYS')) exit('Access Denied');

class topic_controller extends admincp{

	public function __construct(){
		parent::__construct();
	}

	public function index(){

		$title = gp('title');
		$where = "";
		if($title){
			$where = " and title like '%$title%'";
		}

		$pg = new page("select *,(catchstatus+0) as catchstatus from topic where pid = 0 and flag= 1  $where order by id desc ");
		$list = $pg->get_list(15);
		foreach ($list as $key => $value) {
			$catchstatus = $value['catchstatus'];
			$list[$key]['width'] = ($catchstatus/15)*300;
		}
		$page = $pg->get_page();
		require self::tpl('topic');
	}

	public function add(){
		if(IS_POST){
			$time = time();
			$v = gp("title");
			$temp_pinyin  = topic::getAllWord($v);
			$pinyin = topic::checkPinyin($temp_pinyin);
			$pyurl = "/".$pinyin."/";
			$desc = gp("description",false);
			$topic = db::find("select id from topic where title='$v'");
			if(empty($topic)){
				db::query("insert into topic (title,pinyin,pyurl,description, addtime, click,flag) values ('$v','$pinyin','$pyurl','$desc','$time', 0 , 1) ");
				self::json( array('status' => 1, 'msg' => '添加成功', 'redirect' => '?m=topic') );
			}else{
				self::json( array('status' => 0, 'msg' => '该主题已经存在', 'redirect' => '?m=topic') );
			}
		}else{
			require self::tpl("topic_add");
		}
	}

	public function add_alls(){
		if(IS_POST){
			$time = time();
			$v = gp("title");
			$v = str_replace(",", "\r\n", $v);
			$v = explode("\r\n", $v);
			$v = array_filter($v);
			foreach ($v as $key => $value) {
				$topic = db::find("select id from topic where title='$value'");
				$temp_pinyin  = topic::getAllWord($value);
				$pinyin = topic::checkPinyin($temp_pinyin);
				$pyurl = "/".$pinyin."/";
				if(empty($topic)){
					db::query("insert into topic (title,pinyin,pyurl,description, addtime, click,flag) 
						values ('$value','$pinyin','$pyurl','','$time', 0 , 1) ");
				}
			}
			self::json( array('status' => 1, 'msg' => '添加成功', 'redirect' => '?m=topic') );
		}else{
			require self::tpl("topic_add_alls");
		}
	}


	public function edit(){
		$id = gp('id');
		$r = db::find("select * from topic where id='$id' ");
		if(IS_POST){
			$v = gp("title");
			$desc = gp("description",false);
			db::query("update topic set title='$v', description ='$desc' where id='$id' ");
			if($r['status']==-1){
				db::query("update topic set status=0,catchstatus=0 where id='$id' ");
			}
			self::json( array('status' => 1, 'msg' => '修改成功', 'redirect' => '?m=topic') );
		}else{
			require self::tpl("topic_edit");
		}
	}

	public function del(){
		$id = gp('id');
		$topic = db::find("select * from topic where id = '$id'");
		if(empty($topic)){
			self::redirect("?m=topic", "您访问的地址不存在");
		}else{
			$list_topic = db::select("select * from topic where pid ='$id'");
			foreach ($list_topic as $key => $value) {
				$this->delone($value['id']);
			}
			$this->delone($id);

			self::redirect("?m=topic", "删除成功");
		}
	}

	private function delone($id){
		$list_content = db::select("select * from content where kid ='$id'");
		foreach ($list_content as $k1 => $v1) {
			db::query("delete from contentbody where content_id='$v1[id]'");
		}
		db::query("delete from content where kid='$id'");

		db::query("delete from topic where id='$id' ");
		db::query("delete from topic_baike where kid='$id'");
		db::query("delete from topic_wenwen where kid='$id'");
		db::query("delete from topic_body where kid='$id'");
		db::query("delete from urlcache where kid='$id'");
	}

}

