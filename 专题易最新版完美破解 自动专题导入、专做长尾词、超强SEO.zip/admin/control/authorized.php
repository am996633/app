<?php

if(!defined('IN_SYS')) exit('Access Denied');

class authorized_controller extends controller{

	public function login(){
		if(IS_POST){
			$username = gp('username');
			$password = gp('password');
			$result = admin::login($username, $password);
			if($result['status']){
				setcookie('adminval',$result['status'],0,'/');
				setcookie('COOKIE_APPNAME',APPNAME,0,'/');
				self::json( array('status' => 1, 'msg' => "登录成功", 'redirect' => '?m=dashboard') );
			}else{
				self::json( array('status' => -1, 'errMsg' => $result['errMsg'] ) );
			}
		}else{
			require self::tpl("login");
		}
	}

	public function logout(){
		setcookie('adminval','',0,'/');
		setcookie('COOKIE_APPNAME','',0,'/');
		admin::logout();
		self::redirect('__APPROOT__');
	}	

	public function qrcode(){
		$errorCorrectionLevel = "L";
		$matrixPointSize = "4";
		$adminUrl = get_url();
		QRcode::png($adminUrl, false, $errorCorrectionLevel, $matrixPointSize);
	}
}

