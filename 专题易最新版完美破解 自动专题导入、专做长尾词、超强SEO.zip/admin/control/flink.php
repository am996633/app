<?php

if(!defined('IN_SYS')) exit('Access Denied');

class flink_controller extends admincp{

	public function __construct(){
		parent::__construct();
	}

	public function index(){
		$pg = new page("select *   from  flink");
		$list = $pg->get_list(20);
		$page = $pg->get_page();
		require self::tpl('flink');
	}

	public function add(){
		if(IS_POST){
			$time = time();
			$v = gp("sitename,url,status,note");
			db::query("insert into flink (sitename,url,note,addtime,status) 
			values ('$v[sitename]', '$v[url]', '$v[note]','$time','$v[status]') ");
			self::json( array('status' => 1, 'msg' => '添加成功', 'redirect' => '?m=flink') );
		}else{
			require self::tpl("flink_add");
		}
	}

	public function edit(){
		$id = gp('id');
		if(IS_POST){
			$v = gp("sitename,url,status,note");
			db::query("update flink set sitename='$v[sitename]', url='$v[url]', note='$v[note]' ,status='$v[status]'
		 where id='$id' ");
			self::json( array('status' => 1, 'msg' => '修改成功', 'redirect' => '?m=flink') );
		}else{
			$r = db::find("select *  from flink  where id='$id' ");
			require self::tpl("flink_edit");
		}
	}

	public function del(){
		$id = gp('id');
		db::query("delete from flink where id='$id' ");
		self::redirect("?m=flink", "删除成功");
	}

}


