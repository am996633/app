<?php

if(!defined('IN_SYS')) exit('Access Denied');

class adminbar_controller extends admincp{

	public function __construct(){
		parent::__construct();
	}
	
	public function del(){
		$id = gp('id');
		$con = db::find("select title,url from content where id ='$id'");
		$mdurl = make_uri($con['url']);
		$nowtime = time();
		db::query("insert into blacklist (title,burl,mdurl,addtime) values ('$con[title]','$con[url]','$mdurl','$nowtime')");
		db::query("delete from content where id='$id'");
		db::query("delete from contentbody where content_id ='$id'");
		echo "删除成功";
		self::redirect("/");
	}
	
	public function delcache(){
		$id = gp('id');
		$con = db::find("select url from content where id ='$id'");
		
		if($con){
			$mdurl = make_uri($con['url']);
			db::query("update content set updatetime=0 where id='$id'");
			require self::tpl("adminbar_load");
		}else{
			echo ("<script>history.back(-1);</script>");
		}
		
	}

}

