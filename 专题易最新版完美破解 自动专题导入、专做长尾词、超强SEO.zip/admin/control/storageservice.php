<?php

if(!defined('IN_SYS')) exit('Access Denied');

class storageservice_controller extends admincp{

	public $provider = array(
		'qiniu' => array(
			'icon' => "images/qiniu.png",
			'url' => "http://www.qiniu.com",
			'desc' => "七牛，致力于提供最适合开发者的数据在线托管、传输加速以及云端处理等服务。",
			),
		'upyun' => array(
			'icon' => "images/upyun.png",
			'url' => "http://www.upyun.com",
			'desc' => "又拍云，致力于为客户提供一站式的云加速服务，帮助客户解决数据存储、处理和加速问题，实现快速上云，让创业变得更简单。",
			)
		);

	public function __construct(){
		parent::__construct();
	}

	public function index(){
		$list = db::select("select * from storageservice");
		require self::tpl('storageservice');
	}

	public function changeStatus(){
		$id = gp("id");
		$status = gp("status");
		db::query("update storageservice set status =0 ");
		db::query("update storageservice set status ='$status' where id='$id'");
		$r = db::find("select * from storageservice where id='$id' ");
		if(empty($r['url']) && $status==1){
			self::redirect("?m=storageservice&a=edit&id=$id","您还需要配置云存储服务");
		}else{
			self::redirect("?m=storageservice&a=index");
		}
	}

	public function edit(){
		$id = gp("id");
		$r = db::find("select * from storageservice where id='$id' ");
		if(IS_POST){
			$url = gp("url");
			if($url==$_SERVER['HTTP_HOST']){
				self::redirect($_SERVER['REQUEST_URI'],"这里不是填写自己的网站域名");
			}
			if($r['status']==0 && $r['url']=='' && $url!=''){
				db::query("update storageservice set status=1 where id='$id'");
			}
			db::query("update storageservice set url ='$url' where id='$id'");
			self::redirect("?m=storageservice&a=index","修改成功");
		}else{
			if($r['status']==1 && $r['url']==''){
				db::query("update storageservice set status=0 where id='$id'");
			}
			require self::tpl('storageservice_edit');
		}
	}

}
