<?php

if(!defined('IN_SYS')) exit('Access Denied');

class dashboard_controller extends admincp{

	public function __construct(){
		parent::__construct();
	}

	public function index(){
		$memory_limit = ini_get('memory_limit');
		$free_space = formatsize(disk_free_space(dirname(dirname(__FILE__))));
		require self::tpl("dashboard");
	}

	public function submenu(){
		$menuId = gp('menuId');
		echo $this->loadLeftMenu($menuId);
	}
}

