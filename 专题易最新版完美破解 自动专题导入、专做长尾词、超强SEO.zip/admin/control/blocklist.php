<?php

if(!defined('IN_SYS')) exit('Access Denied');

class blocklist_controller extends admincp{

	public function __construct(){
		parent::__construct();
	}

	public function index(){
		$pg = new page("select * from blacklist ");
		$list = $pg->get_list(20);
		$page = $pg->get_page();
		require self::tpl('blocklist');
	}



	public function del(){
		$id = gp('id');
		db::query("delete from blacklist where id='$id' ");
		self::redirect("?m=blocklist", "取消成功");
	}

}


