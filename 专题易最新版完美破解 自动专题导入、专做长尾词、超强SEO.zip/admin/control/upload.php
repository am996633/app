<?php

if(!defined('IN_SYS')) exit('Access Denied');

class upload_controller extends controller{

	public function  uploadimage(){
		$config = array(
			"pathFormat" => "/data/attachment/image/{yyyy}{mm}/{dd}/{time}{rand:6}",
			"maxSize" => 2048000,
			"allowFiles" => array( ".png", ".jpg", ".jpeg", ".gif", ".bmp" ),
		);
		$up = new uploader('upfile', $config, 'upload');
		echo json_encode($up->getFileInfo());
	}
	public function  uploadfile(){
		$config = array(
			"pathFormat" => "/data/attachment/file/{yyyy}{mm}/{dd}/{time}{rand:6}",
			"maxSize" => 20480000,
			"allowFiles" => array( ".png", ".jpg", ".jpeg", ".gif", ".bmp", ".zip", ".rar", ".doc", ".docx", '.xls' ),
		);
		$up = new uploader('upfile', $config, 'upload');
		echo json_encode($up->getFileInfo());
	}
	public function  swfupfile(){
		$config = array(
			"pathFormat" => "/data/attachment/image/{yyyy}{mm}/{dd}/{time}{rand:6}",
			"maxSize" => 2048000,
			"allowFiles" => array( ".png", ".jpg", ".jpeg", ".gif", ".bmp", ".zip", ".rar", ".doc", ".docx", '.xls' ),
		);
		$up = new uploader('Filedata', $config, 'upload');
		//echo json_encode($up->getFileInfo());
		$data = $up->getFileInfo();
		echo $data['url'];
		

	}


}