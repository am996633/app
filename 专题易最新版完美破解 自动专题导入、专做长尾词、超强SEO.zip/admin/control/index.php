<?php

if(!defined('IN_SYS')) exit('Access Denied');

class index_controller extends admincp{

	public function __construct(){
		parent::__construct();
	}

	public function index(){
		if(admin::check()){
			echo "<script>window.location.href='?m=dashboard';</script>";
		}else{
			echo "<script>window.location.href='?m=authorized&a=login';</script>";
		}
	}

}
