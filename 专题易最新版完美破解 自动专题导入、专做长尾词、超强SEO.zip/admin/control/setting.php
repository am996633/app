<?php

if(!defined('IN_SYS')) exit('Access Denied');

class setting_controller extends admincp{

	public function __construct(){
		parent::__construct();
	}
	
	//网址屏蔽
	public  function shieldUrl(){
		if(IS_POST){
			$data = gp("data");
			foreach ($data as $key => $value) {
				db::query("update config set varValue='$value' where varName='$key' ");
			}
			self::json( config::update_config() );
		}else{
			$r = db::select("select * from config");
			$var = array();
			foreach ($r as $key => $value) {
				$var[$value['varName']] = $value['varValue'];
			}
			require self::tpl("setting_shieldurl");
		}
	}
	
	//内容过滤
	public function  filterContent(){
			if(IS_POST){
			$data = gp("data");
			foreach ($data as $key => $value) {
				db::query("update config set varValue='$value' where varName='$key' ");
			}
			self::json( config::update_config() );
		}else{
			$r = db::select("select * from config");
			$var = array();
			foreach ($r as $key => $value) {
				$var[$value['varName']] = $value['varValue'];
			}
			require self::tpl("setting_filtercontent");
		}
	}
}

