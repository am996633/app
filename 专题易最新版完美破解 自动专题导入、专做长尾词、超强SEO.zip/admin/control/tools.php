<?php

if(!defined('IN_SYS')) exit('Access Denied');

class tools_controller extends admincp{

	public function __construct(){
		parent::__construct();
	}

	public  function  index(){
		$sql = "";
		$msg="";
		$command  = gp("command",false);
		if(IS_POST){
			$temp_sql = explode(";", $command);
			foreach ($temp_sql as $sql){
				if(empty($sql)) continue;
				if(preg_match("#^select #i", $sql)){
					if(strpos($sql, 'limit')===false){
						$sql = $sql." limit 10";
					}
					$columns = array();
					$list = db::select($sql);
					if($list){
						foreach ($list[0] as $key =>$v){
							$columns[] = $key;
						}
					}
					$msg = "查询".$sql;
				}else{
					$result = db::query($sql);
					if($result){
						$msg .= $sql."执行成功<br/>";
					}else{
						$msg .= $sql."执行失败<br/>";
					}
				}
			}

		}

		$errTable = '';
		$tables = db::select("show table status");
		foreach($tables as $table){
			if(empty($table['Engine'])){
				$errTable = $table['Name'];
			}
		}

		require $this->tpl("tools");
	}

	public function repair(){
		$table = gp('table');
		db::query("repair table $table ");
		self::redirect('?m=tools&a=index', '修复完成');
	}

}


