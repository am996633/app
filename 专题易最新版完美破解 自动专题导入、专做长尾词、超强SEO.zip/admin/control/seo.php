<?php

if(!defined('IN_SYS')) exit('Access Denied');

class seo_controller extends admincp{

	public function __construct(){
		parent::__construct();
	}

	public function reword(){
		$pg = new page("select * FROM reword order by id desc");
		$list = $pg->get_list(20);
		$page = $pg->get_page();
		require self::tpl('seo_reword');
	}

	public function reword_del(){
		$id = gp('id');
		db::query("delete from reword where id='$id'");
		self::redirect("?m=seo&a=reword", "删除成功");
	}

	public function reword_delall(){
		db::query("delete from reword ");
		self::redirect("?m=seo&a=reword", "删除成功");
	}

	public function reword_add(){
		if(IS_POST){
			$msg ="";
			$v = gp('oldword,newword,type');
			if(preg_match("#[^a-z0-9\.]#",$v['oldword']) && preg_match("#[^a-z0-9\.]#",$v['newword'])){
				db::query("insert into reword (oldword,newword,type) values ('$v[oldword]','$v[newword]','$v[type]')");
				$msg ="添加成功";
			}else{
				$msg ="替换前存在非法字符";
			}
			self::json( array('status' => 1, 'msg' => "$msg", 'redirect' => '?m=seo&a=reword') );
		}else{
			require self::tpl('seo_reword_add');
		}
	}

	//导入同义词替换文件
	public function reword_upload(){
		$time = time();
		$config = array(
			"pathFormat" => "/data/temp/{time}{rand:6}",
			"maxSize" => 2048000,
			"allowFiles" => array(  '.txt' ),
			);
		$up = new uploader('Filedata', $config, 'upload');
		$data = $up->getFileInfo();

		$file = ROOT.$data['url'];
		$content = file_get_contents($file);
		unlink($file);
		$content = iconv('gb2312','utf-8//IGNORE', $content);
		$array = explode("\r\n", $content);
		for($i=0; $i<count($array); $i++)
		{
			$str_word = $array[$i];
			if(strstr($str_word,',')){
				$str = explode(',',$str_word);
				$r = db::find("select * from reword where oldword='$str[0]' and newword='$str[1]' and `type`=2");
				if(!$r){
					if(preg_match("#[^a-z0-9\.]#",$str[0]) && preg_match("#[^a-z0-9\.]#",$str[1])){
						db::query("insert into reword(oldword,newword,`type`,addtime) values('$str[0]','$str[1]',2,'$time')");
					}
				}
			}elseif(strstr($str_word,'->')){
				$str = explode('->',$str_word);
				$r = db::find("select * from reword where oldword='$str[0]' and newword='$str[1]' and `type`=1");
				if(!$r){
					if(preg_match("#[^a-z0-9\.]#",$str[0]) && preg_match("#[^a-z0-9\.]#",$str[1])){
						db::query("insert into reword(oldword,newword,`type`,addtime) values('$str[0]','$str[1]',1,'$time')");
					}
				}
			}
		}
		echo  "导入成功";
	}
	
	//文章混淆
	public function confuse(){
		$r = db::select("select * from config");
		$var = array();
		foreach ($r as $key => $value) {
			$var[$value['varName']] = $value['varValue'];
		}
		require self::tpl("seo_confuse");
	}
	
	//文章标题随机插入关键词
	public function seoword(){
		$r = db::select("select * from config");
		$var = array();
		foreach ($r as $key => $value) {
			$var[$value['varName']] = $value['varValue'];
		}
		require self::tpl("seo_seoword");
	}
	
	public function smart(){
		require self::tpl("seo_smart");
	}
	
}

