<?php

if(!defined('IN_SYS')) exit('Access Denied');

class content_controller extends admincp{

	public function __construct(){
		parent::__construct();
	}


	public function index(){

		$where = "";
		$title = gp("title");
		if($title){
			$where = " where title like '%$title%' ";
		}
		$pg = new page("select id,title from content  $where order by id desc");
		$list = $pg->get_list(20);
		$page = $pg->get_page();
		
		require self::tpl('content');
	}

	public function add(){
		if(IS_POST){
			$time = time();
			$v = gp("title,thumb,keywords,description,category_id");
			$body = gp("body",false);
			db::query("insert into content (title, thumb, keywords, description,addtime,category_id)
			values ('$v[title]', '$v[thumb]', '$v[keywords]', '$v[description]','$time','$v[category_id]') ");
			$content_id = db::insert_id();
			db::query("insert into contentbody (body,content_id)
				values ('$body','$content_id')");
			self::json( array('status' => 1, 'msg' => '添加成功', 'redirect' => '?m=content') );
		}else{
				require self::tpl("content_add");
		}
	}

	public function edit(){
		$id = gp('id');
		if(IS_POST){
			$v = gp("title,thumb,keywords,description");
			$body =  gp("body",false);
			$body = str_replace(zty::get_attachment_host().'/uploads/attachment/', '{#attachmentPath#}/uploads/attachment/', $body);
			db::query("update content set title='$v[title]', thumb='$v[thumb]', keywords='$v[keywords]',
			description='$v[description]' where id='$id' ");
			db::query("update contentbody set body='$body'  where content_id='$id'");
			self::json( array('status' => 1, 'msg' => '修改成功', 'redirect' => '?m=content') );
		}else{
			$r = db::find("select *,ct.id as cid  from content as ct  inner join contentbody as cy  on ct.id = cy.content_id  where ct.id='$id' ");
			$r['body'] = str_replace('{#attachmentPath#}', zty::get_attachment_host(), $r['body']);
			require self::tpl("content_edit");
		}
	}

	public function del(){
		$id = gp('id');
		db::query("delete from content where id='$id' ");
		db::query("delete from contentbody where content_id='$id' ");
		self::redirect("?m=content", "删除成功");
	}

}


