<?php

if(!defined('IN_SYS')) exit('Access Denied');

class spider_controller extends admincp{

	public function __construct(){
		parent::__construct();
	}

	public function index(){
		$add_time = time()-3600*24*31;

		$spider_types = spider::spider_types();
		$sql = "SELECT ";
		foreach ($spider_types as $key => $value) {
			$sql .= "count(CASE WHEN spider='$key' THEN spider END) as {$key},";
		}
		$sql .= "adddate FROM spider where addtime> '$add_time' GROUP BY adddate ";
		$list_count = db::select($sql);
		require self::tpl('spider');
	}

	public  function spider_list(){
		$spider_types = spider::spider_types();
		$pg = new page("select * FROM spider order by id desc");
		$list = $pg->get_list(15);
		$page = $pg->get_page();
		require self::tpl('spider_list');
	}

	public  function clean(){
		db::query("truncate table spider");
		self::redirect("?m=spider", "清除成功");
	}
}

