
/*
 * Cookie相关
 */
 function getCookie(name) {
 	var arg = name + "=";
 	var alen = arg.length;
 	var clen = document.cookie.length;
 	var i = 0;
 	while (i < clen) {
 		var j = i + alen;
 		if (document.cookie.substring(i, j) == arg) {
 			var endstr = document.cookie.indexOf(";", j);
 			if (endstr == -1) {
 				endstr = document.cookie.length
 			}
 			return document.cookie.substring(j, endstr);
 		}
 		i = document.cookie.indexOf(" ", i) + 1;
 		if (i == 0) break
 	}
 return ""
}

function setCookie(name, value, expires, path, domain, secure) {
	document.cookie = name + "=" + value + ((expires) ? "; expires=" + expires: "") + ((path) ? "; path=" + path: "") + ((domain) ? "; domain=" + domain: "") + ((secure) ? "; secure": "")
}

/*
 * 提示框
 */
 var cpAlertTimer = [];
 function cpAlert(cpMsg){
 	var status = typeof arguments[1]!='undefined' ? arguments[1] : 1;
 	var msgTipBox = $(".msgTip");
 	if(status == -1){
 		msgTipBox.css({"backgroundColor": "#ffa313"});
 	}else if(status == 0){
 		msgTipBox.css({"backgroundColor": "#b9b9b9"});
 	}else if(status == 1){
 		msgTipBox.css({"backgroundColor": "#3EB6F3"});
 	}
 	clearTimeout(cpAlertTimer);
 	msgTipBox.stop(true, true).html(cpMsg).show().animate({height: "60px", opacity:0.8}, 500, function(){
 		cpAlertTimer = setTimeout(function(){
 			msgTipBox.animate({height: "0px"}, 200, function(){
 				$(this).hide();
 			})
 		}, 1200)
 	});
 }


/*
 * 左边栏菜单加载
 */
 function loadLeftMenu(menuId){
 	var dataobj = $(subMenu[menuId]);
 	var findCurrent = false;
 	dataobj.find("li").each(function(){
 		if( window.location.href.indexOf( $(this).find('a').attr('href') )!=-1 ){
 			$(this).addClass('cur');
 			findCurrent = true;
 		}
 	});
 	if(findCurrent==false){
 		var tryUrl = window.location.href.replace(new RegExp('&a=.*?$'), '');
 		tryUrl += '&a=index';
 		dataobj.find("li").each(function(){
 			if( tryUrl.indexOf( $(this).find('a').attr('href') )!=-1 ){
 				$(this).addClass('cur');
 				findCurrent = true;
 			}
 		});
 	};
 	$(".left-menu-list").html(dataobj);
 	if(findCurrent){
 		var menuTxt = $(".header .menu li.cur a").html();
 		var menuLink = '<a href="javascript:loadLeftMenu('+menuId+')">'+menuTxt+'</a> ';
 		var groupTxt = dataobj.find('.cur').parent().prev().text();
 		var groupLink = '<a href="javascript:loadLeftMenu('+menuId+')">'+groupTxt+'</a> ';
 		if($('.crumb span').length>0){
 			crumb = menuLink + groupLink + dataobj.find('.cur a').prop("outerHTML") + ' ' + $('.crumb span').prop("outerHTML");
 		}else{
 			crumb = menuLink + groupLink + dataobj.find('.cur a').prop("outerHTML");
 		}
 		$('.crumb').html(crumb);
 	}
 };

/*
 * Ajax 提交表单
 */
 function AjaxPost(formObj){
 	var submitBtn = $(formObj).find("input[type=submit]");
 	var submitBtnTxt = submitBtn.val();
 	var formAction = $(formObj).attr("action");
 	submitBtn.val("正在提交");
 	$.ajax({
 		type: "POST",
 		url: formAction ? formAction : window.location.href,
 		data: $(formObj).serialize(),
 		dataType: "json",
 		success: function(data){
 			if(data.status==1){
 				if(typeof data.redirect != 'undefined'){
 					setCookie('AlertMsg', data.msg, 0, '/');
 					window.location.href = data.redirect;
 				}else{
 					cpAlert(data.msg, data.status);
 				}
 			}else{
 				if(typeof data.redirect != 'undefined'){
 					setCookie('AlertErrMsg', data.errMsg, 0, '/');
 					window.location.href = data.redirect;
 				}else{
 					cpAlert(data.errMsg, data.status);
 				}
 			}
 			submitBtn.val(submitBtnTxt);
 		},
 		error: function(data){
 			cpAlert(data.responseText.replace(/<\/?[^>]*>/g, ''), 0);
 			submitBtn.val(submitBtnTxt);
 		}
 	});
 }

