<?php

require dirname(__FILE__).'/core/loader.php';
loader::init()->run();

