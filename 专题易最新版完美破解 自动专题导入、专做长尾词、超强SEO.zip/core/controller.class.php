<?php

class controller{

	public $conf, $rest_uri, $web_url, $mobile_url, $target;

	public function __construct(){
		$uri_info = parse_url($_SERVER['REQUEST_URI']);
		$this->rest_uri = trim($uri_info['path'], '/');

		$conf_file = DATA.'/cache/config_cache.inc.php';
		$this->conf = array();
		if(!is_file($conf_file)){
			config::update_config(false);
		}

		$this->conf = include $conf_file;
		$GLOBALS['conf'] = $this->conf;

		define('IS_MOBILE_SITE_OPEN', !empty($GLOBALS['conf']['mobileHost']) && $GLOBALS['conf']['mobileSwitch']==1);
		define('IS_MOBILE_SITE', IS_MOBILE_SITE_OPEN && $_SERVER['HTTP_HOST']==$GLOBALS['conf']['mobileHost']);
		$this->web_url = 'http://'.$GLOBALS['conf']['webHost'].$_SERVER['REQUEST_URI'];
		$this->mobile_url = 'http://'.$GLOBALS['conf']['mobileHost'].$_SERVER['REQUEST_URI'];
		$this->target = IS_MOBILE_SITE ? "_self" : "_blank";
		
		if(!defined('APPNAME')){
			if(empty($GLOBALS['conf']['webHost'])){
				controller::page_503();
				throw new Exception("请求的地址无法识别，请检查 <br> <b>网站后台</b> &gt; <b>系统设置</b> &gt; <b>网站地址</b>");
			}elseif( !in_array($_SERVER['HTTP_HOST'], array( $GLOBALS['conf']['webHost'], $GLOBALS['conf']['mobileHost'] ) ) ){
				header('HTTP/1.1 301 Moved Permanently');
				header("Location: http://".$GLOBALS['conf']['webHost']);
			}
			
			if($this->conf['siteSwitch']==0){
				$this->page_503();
				if(self::tpl('closed', true)){
					require self::tpl('closed');
				}else{
					echo '<p style="text-align:center;line-height:500px;">网站维护中，请稍后访问</p>';
				}
				exit;
			}
		}
	}

	public static function alert($msg){
		header("P3P:CP=CAO PSA OUR");
		setrawcookie('AlertMsg', $msg, 0, '/');
	}

	public static function redirect($url, $msg=null){
		$msg && self::alert($msg);
		if(!empty($url)){
			if(defined('APPNAME')){
				$url = str_replace('__APPROOT__', '/'.APPNAME, $url);
			}
			header("Location: $url ");
			echo ("<script>window.location.href='$url';</script>");
			exit;
		}
	}

	public static function json($data){
		global $debug;
		if($debug || !empty($_GET['formatjson'])){
			echo json_encode($data);
		}else{
			header('Content-type: application/json');
			echo json_encode($data);
		}
		exit;
	}

	public static function jsonp($data, $msg=null){
		header('Content-type: application/javascript');
		$callback = gp("callback", 'dash');
		if(empty($callback)) $callback = "_callback";
		echo "$callback(".json_encode($data).")";
		exit;
	}

	public static function page_404($content=false){
		header('HTTP/1.1 404 Not Found');
		header("Status: 404 Not Found");
		if(self::tpl('404', true)){
			require self::tpl('404');
		}else{
			echo $content?$content:'HTTP/1.1 404 Not Found';
		}
		exit;
	}

	public static function page_503(){
		header('HTTP/1.1 503 Service Temporarily Unavailable');
		header('Status: 503 Service Temporarily Unavailable');
		header('Retry-After: 3600');
	}

	public static function tpl($tplName, $onlyCheck=false){
		if(defined('APPNAME')){
			$path = ROOT.DS.APPNAME.DS.'templates';
			$cachepath = DATA.DS.'tplcache'.DS.APPNAME;
		}else{
			if(IS_MOBILE_SITE){
				$path = ROOT.DS.'templates'.DS.'mobile';
				$cachepath = DATA.DS.'tplcache'.DS.'mobile';
			}else{
				$path = ROOT.DS.'templates';
				$cachepath = DATA.DS.'tplcache';
			}
		}
		$tplName = $tplName.'.tpl.php';
		if($onlyCheck){
			return is_file($path.DS.$tplName);
		}else{
			$ins = new template($tplName,$path,$cachepath);
			return $ins->view();
		}
	}

}

