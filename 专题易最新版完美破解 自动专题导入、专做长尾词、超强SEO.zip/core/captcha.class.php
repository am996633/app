<?php

/**
 * @version    $Id: captcha.class.php 115 2016-07-02 13:10:58Z qinjinpeng $
 */

if(!defined('IN_SYS')) exit('Access Denied');

class captcha{

	private $width  = 70;
	private $height = 28;

    public function __construct(){
		header("Pragma:no-cache\r\n");
		header("Cache-Control:no-cache\r\n");
		header("Expires:0\r\n");
		header("Content-type: image/PNG");  
    }
    
    public function randstr(){
        $chars='ABCDEFGHJKMNPQRSTUVWXYZabcdefghjkmnpqrstuvwxyz23456789';
        $i = 4;
        $str = '';
        $len = strlen($chars);
        while($i--){
            $r = mt_rand(0,$len-1);
            $str .= $chars[$r];
        }
        $_SESSION['checkcode'] = $str;
        return $str;
    }
    
	public function show() {
		$im = imagecreate($this->width, $this->height);

		$gray = imagecolorallocate($im, 238,238,238); 
		imagefill($im,0,0,$gray);
		
		$randstr = $this->randstr();
		$len = strlen($randstr);
		for($i=0; $i<$len; $i++){
			$size = rand(14, 16);
			$randcolor = imagecolorallocate($im, rand(0,150),rand(0,150),rand(0,150));
			imagettftext($im, $size, mt_rand(-30,30), 7+$i*$size, 22, $randcolor, DATA.DS.'font'.DS.'georgia.ttf', $randstr[$i]);
		}

		$randcolor = imagecolorallocate($im,rand(0,255),rand(0,255),rand(0,255));
		$y = floor($this->height/2+5);
		$w = 3;
		for($x=5; $x<$this->width-5; $x++) {
			if($x%3==0) $y += mt_rand(-1, 1);
			if($x%5==0){
				$w += mt_rand(-1, 1);
				$w = $w<=3?$w:3;
			}
			for($i=0; $i<$w; $i++){
				imagesetpixel($im, $x, $y+$i, $randcolor);
			}
		}
		
		$image = imagepng($im); 
		imagedestroy($im);
		return $image;
	}
	
}

?>