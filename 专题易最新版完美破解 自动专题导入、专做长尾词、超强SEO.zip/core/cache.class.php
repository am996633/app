<?php

class cache{
	public static $init;
	public static $is_mem = true;
	
	public static function init(){
		if(!isset(self::$init)){
			if(class_exists('Memcache')) {
				$driver = 'Memcache_driver';
			}else{
				self::$is_mem = false;
				$driver = 'file_cache_driver';
			}
			self::$init = new $driver;
		}
		return self::$init;
	}
	
	public static function is_mem(){
		return self::$is_mem;
	}

	public static function get($name){
		return self::init()->get($name);
	}
	
	public static function set($name, $value, $expire=1800){
		return self::init()->set($name, $value, $expire);
	}
	
	public static function delete($name){
		return self::init()->delete($name);
	}
}

class Memcache_driver {
	private $mmc = NULL;
	private $group = ''; 
	private $ver = 0;

	public function __construct() {
		global $memConfig;
		$this->mmc = new Memcache;
		foreach($memConfig['MEM_SERVER'] as $config) {
			call_user_func_array(array($this->mmc, 'addServer'), $config);         
		}
		$this->group = md5( $memConfig['MEM_GROUP'] );
	}

	//获得memcache的版本信息
	public function version(){
		return $this->mmc->getVersion();
	}

	//读取缓存
	public function get($key) {
		return $this->mmc->get($this->group.$key);
	}

	//设置缓存
	public function set($key,$value,$expire = 1800) {
		return $this->mmc->set($this->group.$key, $value, 0, $expire);
	}

	//添加缓存
	public function add($key, $value, $expire = 1800) {
		return $this->mmc->add($this->group.$key, $value, $expire);
	}

	//替换缓存
	public function replace($key, $value, $expire = 1800){
		return $this->mmc->replace($this->group.$key, $value);
	}

	//自增1
	public function inc($key, $value = 1) {
		return $this->mmc->increment($this->group.$key, $value);
	}

	//自减1
	public function des($key, $value = 1) {
		return $this->mmc->decrement($this->group.$key, $value);
	}

	//删除
	public function del($key) {
		return $this->mmc->delete($this->group.$key);
	}

	//全部清空
	public function delete() {
		return  $this->mmc->flush();
	}

	//关闭缓存
	public function close() {
		return $this->mmc->close();
	}

}

//文件缓存驱动
class file_cache_driver{
	
	public function cache_file_path($arg){
		if(stripos($arg, '_')!==false){
			list($prefix, ) = explode('_', $arg);
		}
		$prefix = empty($prefix)?'':$prefix.'/';
		$arg = md5($arg);
		return DATA.'/cache/'.$prefix.substr($arg, 0, 2).'/'.substr($arg, 2, 2).'/'.substr($arg, 4, 28).'.php';	
	}
	
	public function get($name) {
		global $timestamp;
		$cachefile = $this->cache_file_path($name);
		if(is_file($cachefile)){
			$data = file_get_contents( $cachefile );
			$hash = substr($data, 14, 32);
			$data = substr($data, 46);
			if($hash != md5($data)){
				return false;
			}else{
				$data = unserialize($data);
				if($timestamp < $data['time']){
					return $data['data'];
				}
			}
		}
		return false;
	}
	
	public function set($name, $value, $expire) {
		global $timestamp;
		$cachefile = $this->cache_file_path($name);
		$cachefile_dir = dirname($cachefile);
		if(!is_dir($cachefile_dir)){
			mkdir($cachefile_dir, 0755, true);
		}
		$r['time'] = $timestamp+$expire;
		$r['data'] = $value;
		$data = serialize($r);
		$hash = md5($data);
		$data = "<?php exit; ?>".$hash.$data;
		$result = file_put_contents($cachefile, $data);
		clearstatcache();
	}
	
	public function delete($name) {
		$cachefile = $this->cache_file_path($name);
		if(is_file($cachefile)){
			return unlink($cachefile);
		}
		return true;
	}
}

