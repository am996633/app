<?php

/**
 * @version    $Id: loader.php 470 2016-06-07 09:53:12Z qinjinpeng $
 */

define("IN_SYS",true);

define('DS', DIRECTORY_SEPARATOR);
define("CORE", dirname(__FILE__) );
define("ROOT", dirname(CORE));
define("DATA", ROOT.DS."data");
define("RESOURCE", DATA.DS."resource");
define('TIMESTAMP', time());

if(!is_file(DATA.DS.'config.php')){
	echo '<script>window.location.href="install.php";</script>';
	exit;
}

header("Content-type: text/html; charset=utf-8");
if(version_compare(PHP_VERSION, '5.2.0', '<')) throw new Exception("Worning: PHP VERSION NOT SUPPORT!", 0);
define("IS_POST", isset($_SERVER['REQUEST_METHOD']) && $_SERVER['REQUEST_METHOD']=='POST' || isset($_REQUEST['callback']) );
define("IS_AJAX", isset($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH'])=='xmlhttprequest' );

error_reporting(0);
set_exception_handler(array('llsq_exception', 'exception_handler'));
set_error_handler(array('llsq_exception', 'exception_error_handler'));
register_shutdown_function(array('llsq_exception', 'exception_shutdown_handler'));

include DATA.DS.'config.php';
include CORE.DS.'functions.php';
include RESOURCE.DS.'runtime.php';

date_default_timezone_set('PRC');
set_include_path(CORE.PATH_SEPARATOR.get_include_path());
session_save_path( DATA.DS.'session' );
@ini_set('memory_limit',         '64M');
@ini_set('session.cache_expire',  180);
@ini_set('session.use_trans_sid', 0);
@ini_set('session.use_cookies',   1);
@ini_set('session.auto_start',    0);

@set_time_limit(120);
@ignore_user_abort(true);

foreach(array('_POST', '_GET', '_COOKIE', '_REQUEST') as $_method) {
	if(!defined('NOFILTER'))
	{
		$$_method = filter::xss($$_method);
	}
	$$_method = filter::input($$_method);
}

class llsq_exception{
	public static $error = array();
	/*
	 * 异常处理
	 */
	public static function exception_handler($exception){
		$errstr = $exception->getMessage();
		$errfile = $exception->getFile();
		$errline = $exception->getLine();
		self::exception_error_handler(0 , $errstr, $errfile, $errline);
	}
	
	/*
	 * 异常处理
	 */
	public static function exception_shutdown_handler() {
		if(($error = error_get_last())) {
			self::exception_error_handler($error['type'], $error['message'], $error['file'], $error['line']);
		}
		if(self::$error){
			self::$error = join("<br/>", self::$error);
			self::show_error(self::$error);
		}
	}
	
	/*
	 * 异常处理
	 */
	public static function exception_error_handler($errno, $errstr, $errfile, $errline){
		global $debug;
		$errfile = str_replace("\\", '/', str_replace(ROOT, '', $errfile));
		$errortype = array (0 => 'Exception', 1 => 'Fatal error', 2 => 'Warning', 4 => 'Parsing Error', 8 => 'Notice', 16 => 'Core Error', 32 => 'Core Warning', 64 => 'Compile Error', 128 => 'Compile Warning', 256 => 'User Error', 512 => 'User Warning', 1024 => 'User Notice', 2048 => 'Runtime Notice', 4096 => 'Recoverable Error', 8192 => 'Deprecated' );
		$error_message = $errortype[$errno].' | '.str_pad($errstr,50).' | '.$errfile.' | '.$errline.' | '.get_url();
		if(!is_dir(DATA.'/log')) mkdir(DATA.'/log', 0777, true);
		error_log('<?php exit;?>'.date('m-d H:i:s').' | '.$error_message."\r\n", 3, DATA.'/log/errorlog_'.date("Y-m-d").'.php');
		if($debug){
			self::$error[] = $errno ? "<b>{$errortype[$errno]}</b>: $errstr in <b>$errfile</b> on line <b>$errline</b>" : $errstr ;
		}else{
			if(in_array($errno, array(0, E_ERROR, E_PARSE, E_CORE_ERROR, E_COMPILE_ERROR, E_USER_ERROR))){
				controller::page_503();
				self::$error[] = $errno ? "系统发生".$errortype[$errno]."错误" : $errstr;
			}
		}
	}

	/*
	 * 异常输出
	 */
	public static function show_error($message){
		global $debug;
		$debug_bar_color = $debug?"#E6A43F":'#EEE';
		if(IS_AJAX){
			$data['status'] = 0;
			$data['errMsg'] = $message;
			echo json_encode($data);
			exit;
		}else{
			echo '<meta http-equiv="Content-Type" content="text/html; charset=utf-8">';
			echo "<h1>System Error!</h1><div style='position:relative;border:solid 1px #CCC;padding:10px;margin-bottom:28px;background-color:#F6F6F6;font-size:12px;z-index:9999;'>$message</div>";
			echo "<p style='position:fixed;bottom:0px;left:0px;width:100%;background-color:{$debug_bar_color};border-top:solid 1px #0094df;padding:5px;z-index:9999;'><font color=#666 size=1>系统已记录此错误, 由此给您带来不便我们深感歉意.</font></p>";
		}
	}
}