<?php

/**
 * @version    $Id: functions.php 416 2016-05-09 10:15:17Z tic $
 *  函数库
 */

function gp($key, $filter=true){
	if(strpos($key, ',')!==false){
		$keys = explode(',', $key);
		foreach($keys as $key) $tmp[$key] = gp($key, $filter);
		return $tmp;
	}
	if(isset($_REQUEST[$key])){
		$value = $_REQUEST[$key];
		if(is_string($filter) && !validate::$validate($filter)){
			$value = false;
		}elseif($filter===true){
			filter::check_disallow_char($value);
			return safe_replace($value);
		}else{
			filter::check_disallow_char($value);
		}
	}else{
		$value = null;
	}
	return $value;
}

function html2text($string){
	if(empty($string)) return $string;
	if(is_string($string)){
		return htmlspecialchars($string, ENT_QUOTES, 'utf-8');
	}else{
		return array_map('html2text', $string);
	}
}

function safe_replace($string) {
	if(empty($string)) return $string;
	if(is_array($string)) return array_map('safe_replace', $string);
	$string = str_replace('%20','',$string);
	$string = str_replace('%27','',$string);
	$string = str_replace('%2527','',$string);
	$string = str_replace('*','',$string);
	$string = str_replace('#','',$string);
	$string = str_replace('%','',$string);
	$string = str_replace(';','',$string);
	$string = str_replace('&','&amp;',$string);
	$string = str_replace('"','&quot;',$string);
	$string = str_replace("'",'&#039;',$string);	
	$string = str_replace('<','&lt;',$string);
	$string = str_replace('>','&gt;',$string);
	$string = str_replace("{",'',$string);
	$string = str_replace('}','',$string);
	$string = str_replace('\\','',$string);
	return $string;
}

function dump($var){
	echo '<pre>';
	print_r($var);
	echo '</pre>';
}

function get_url() {
	$sys_protocal = isset($_SERVER['SERVER_PORT']) && $_SERVER['SERVER_PORT'] == '443' ? 'https://' : 'http://';
	$php_self = $_SERVER['PHP_SELF'] ? $_SERVER['PHP_SELF'] : $_SERVER['SCRIPT_NAME'];
	$path_info = isset($_SERVER['PATH_INFO']) ? $_SERVER['PATH_INFO'] : '';
	$relate_url = isset($_SERVER['REQUEST_URI']) ? $_SERVER['REQUEST_URI'] : $php_self.(isset($_SERVER['QUERY_STRING']) ? '?'.$_SERVER['QUERY_STRING'] : $path_info);
	return $sys_protocal.(isset($_SERVER['HTTP_HOST']) ? $_SERVER['HTTP_HOST'] : '').$relate_url;
}

function get_client_ip() {
	$ip = $_SERVER['REMOTE_ADDR'];
	if (isset($_SERVER['HTTP_CLIENT_IP']) && preg_match('/^([0-9]{1,3}\.){3}[0-9]{1,3}$/', $_SERVER['HTTP_CLIENT_IP'])) {
		$ip = $_SERVER['HTTP_CLIENT_IP'];
	} elseif(isset($_SERVER['HTTP_X_FORWARDED_FOR']) AND preg_match_all('#\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}#s', $_SERVER['HTTP_X_FORWARDED_FOR'], $matches)) {
		foreach ($matches[0] AS $xip) {
			if (!preg_match('#^(10|172\.16|192\.168)\.#', $xip)) {
				$ip = $xip;
				break;
			}
		}
	}
	return $ip;
}

function cut($string, $length, $dot = ''){
	$string = strip_tags($string);
	if(strlen($string) <= $length) {
		return $string;
	}
	$pre = chr(1);
	$end = chr(1);
	$string = str_replace(array('&amp;', '&quot;', '&lt;', '&gt;', '&nbsp;'), array($pre.'&'.$end, $pre.'"'.$end, $pre.'<'.$end, $pre.'>'.$end, $pre.' '.$end), $string);
	$strcut = '';
	$n = $tn = $noc = 0;
	while($n < strlen($string)) {
		$t = ord($string[$n]);
		if($t == 9 || $t == 10 || (32 <= $t && $t <= 126)) {
			$tn = 1; $n++; $noc++;
		} elseif(194 <= $t && $t <= 223) {
			$tn = 2; $n += 2; $noc += 2;
		} elseif(224 <= $t && $t <= 239) {
			$tn = 3; $n += 3; $noc += 2;
		} elseif(240 <= $t && $t <= 247) {
			$tn = 4; $n += 4; $noc += 2;
		} elseif(248 <= $t && $t <= 251) {
			$tn = 5; $n += 5; $noc += 2;
		} elseif($t == 252 || $t == 253) {
			$tn = 6; $n += 6; $noc += 2;
		} else {
			$n++;
		}
		if($noc >= $length) {
			break;
		}
	}
	if($noc > $length) {
		$n -= $tn;
	}
	$strcut = substr($string, 0, $n);
	$strcut = str_replace(array($pre.'&'.$end, $pre.'"'.$end, $pre.'<'.$end, $pre.'>'.$end, $pre.' '.$end), array('&amp;', '&quot;', '&lt;', '&gt;', '&nbsp;'), $strcut);
	$pos = strrpos($strcut, chr(1));
	if($pos !== false) {
		$strcut = substr($strcut,0,$pos);
	}
	return $strcut.$dot;
}

function table($table, $field, $id){
	global $db;
	$rs = $db->select("SHOW COLUMNS FROM `$table`");
	foreach($rs as $r){
		if($r['Key'] == 'PRI'){
			$primary = $r['Field'];
			break;
		}
	}
	if(!empty($primary)){
		$result = $db->find("SELECT `$field` FROM `$table` WHERE `$primary`= '$id'");
	}
	return isset($result[$field])?$result[$field]:'';
}

function formatsize( $bytes ) {
	$units = array( 0 => 'B', 1 => 'kB', 2 => 'MB', 3 => 'GB' );
	$log = log( $bytes, 1024 );
	$power = (int) $log;
	$size = pow(1024, $log - $power);
	return round($size, 2) . ' ' . $units[$power];
}

function write_log($log){
	$time = time();
	$log = addslashes($log);
	db::query("insert into log (content, addtime) values ('$log', $time) ");
}

function fixsrc($img){
	static $oss;
	if(!isset($oss)){
		$oss = db::find("select * from storageservice where status = 1 AND url!=''");
	}
	if($oss){
		return 'http://'.$oss['url'].$img;
	}else{
		return $img;
	}
}
