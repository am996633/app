<?php

class userTag{

	/**
	 *  调用广告
	 * @access    public
	 * @return    array
	 */

	public static function ad($id){
		$ad = db::find("select content from ads where id ='$id'");
		$html ="<div>".$ad['content']."</div>";
		return  $html;
	}

}

