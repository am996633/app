
DROP TABLE IF EXISTS `admin`;
CREATE TABLE `admin` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `username` varchar(20) DEFAULT NULL,
  `password` varchar(32) DEFAULT NULL,
  `salt` varchar(10) DEFAULT '',
  `realname` varchar(30) DEFAULT NULL,
  `status` tinyint(1) DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `status` (`status`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `ads`;
CREATE TABLE `ads` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(100) DEFAULT NULL,
  `content` text,
  `addtime` int(11) DEFAULT NULL,
  `status` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO `ads` (`id`, `title`, `content`, `addtime`, `status`) VALUES
(2,	'右边栏顶部300*300',	'',	1459502838,	1),
(1,	'公共顶部banner1',	'<a href=\"http://www.llsq.cn/\" target=\"_blank\"><img src=\"/static/images/pic1.jpg\"></a>',	1459502303,	1),
(3,	'首页顶部banner2',	'<a href=\"http://www.caijixia.net/\" target=\"_blank\"><img src=\"/static/images/pic2.jpg\"></a>',	1467612588,	1);

DROP TABLE IF EXISTS `attachment`;
CREATE TABLE `attachment` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `hash` varchar(255) DEFAULT NULL,
  `url` varchar(255) DEFAULT NULL,
  `addtime` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `hash` (`hash`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `config`;
CREATE TABLE `config` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `varName` varchar(255) DEFAULT NULL,
  `varValue` text,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO `config` (`id`, `varName`, `varValue`) VALUES
(1,	'siteName',	'专题易'),
(2,	'webHost',	''),
(5,	'keywords',	''),
(6,	'description',	''),
(7,	'siteSwitch',	'1'),
(9,	'downPicture',	'1'),
(10,	'phrasesConfuse',	'0'),
(11,	'paragraphConfuse',	'0'),
(12,	'seoWord',	''),
(13,	'seoTitle',	'0'),
(14,	'seoTitle_x',	'3'),
(16,	'shieldUrl',	''),
(17,	'filterContent',	''),
(18,	'ipc',	'京ICP备10002345号'),
(19,	'site_code',	''),
(20,	'page_time',	'31622400'),
(21,	'appkey',	''),
(22,	'appid',	''),
(23,	'mobileSwitch',	'0'),
(24,	'mobileHost',	''),
(25,	'softversion',	'1.1.2'),
(26,	'autoTitle',	'0'),
(27,	'seoWordNum',	'3'),
(28,	'seoWordScale',	'100'),
(29,	'seoConfuseScale',	'100'),
(30,	'sitemap',	'1'),
(31,	'siteTitle',	'为做长尾词流量而生');

DROP TABLE IF EXISTS `content`;
CREATE TABLE `content` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `kid` int(11) DEFAULT NULL,
  `title` varchar(60) DEFAULT NULL,
  `url` varchar(255) DEFAULT NULL,
  `keywords` varchar(200) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `url_id` int(255) DEFAULT NULL,
  `thumb` varchar(150) DEFAULT NULL,
  `addtime` int(11) DEFAULT NULL,
  `updatetime` int(11) DEFAULT NULL,
  `click` int(11) DEFAULT '1',
  `status` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `thumb` (`thumb`),
  KEY `click` (`click`),
  KEY `category_id` (`kid`,`thumb`,`click`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `contentbody`;
CREATE TABLE `contentbody` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `content_id` int(11) DEFAULT NULL,
  `body` mediumtext,
  PRIMARY KEY (`id`),
  KEY `content_id` (`content_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `flink`;
CREATE TABLE `flink` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sitename` varchar(50) DEFAULT NULL,
  `url` varchar(180) DEFAULT NULL,
  `note` varchar(255) DEFAULT NULL,
  `addtime` int(11) DEFAULT NULL,
  `status` tinyint(4) DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO `flink` (`id`, `sitename`, `url`, `note`, `addtime`, `status`) VALUES
(3,	'流量神器',	'http://www.liuliangshenqi.com.cn/',	'系统默认',	1459480559,	1),
(4,	'采集侠',	'http://www.caijixia.net',	'系统默认',	1459480559,	1),
(5,	'专题易',	'http://www.zhuantiyi.com',	'系统默认',	1459480559,	1);

DROP TABLE IF EXISTS `log`;
CREATE TABLE `log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `content` text,
  `addtime` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `page`;
CREATE TABLE `page` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(60) DEFAULT NULL,
  `ename` varchar(255) DEFAULT NULL,
  `keywords` varchar(200) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `thumb` varchar(150) DEFAULT NULL,
  `addtime` int(11) DEFAULT NULL,
  `updatetime` int(11) DEFAULT NULL,
  `body` mediumtext,
  PRIMARY KEY (`id`),
  KEY `thumb` (`thumb`),
  KEY `category_id` (`thumb`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO `page` (`id`, `title`, `ename`, `keywords`, `description`, `thumb`, `addtime`, `updatetime`, `body`) VALUES
(1,	'关于我们',	'about',	'',	'',	'',	NULL,	NULL,	'<p style=\"text-indent: 2em; text-align: left;\">桂林新领酷信息科技有限公司（<a href=\"http://www.thinkincloud.cn\" target=\"_blank\" title=\"\" class=\"un_line\">ThinkInCloud</a> Inc.）是国内领先的站长软件解决方案提供商。公司位于山水甲天下美誉的桂林，是一家拥有自主知识产权的高科技软件企业。公司拥有产品策划、技术研发、市场推广、网站优化等各方面的优秀人才，团队成员具有多年大型建站软件的研发和运营经验，长期致力于为站长朋友提供优化推广解决方案。</p><p style=\"text-indent: 2em; text-align: left;\">公司旗下有多款产品，包括<a href=\"http://www.caijixia.net\" target=\"_blank\" title=\"\" class=\"un_line\">采集侠</a>、<a href=\"http://www.llsq.cn\" target=\"_blank\" title=\"\" class=\"un_line\">流量神器</a>、<a href=\"http://www.zhuantiyi.com\" target=\"_blank\" title=\"\" class=\"un_line\">专题易</a>、<a href=\"http://www.newsyee.com\" target=\"_blank\" title=\"\" class=\"un_line\">软文易</a>、<a href=\"http://www.yumicms.cn\" target=\"_blank\" title=\"\" class=\"un_line\">域名托管CMS</a>、站群系统等多款产品，其中采集侠在5年的时间里已经为数十万活跃网站提供服务，拥有良好的口碑！</p><p style=\"text-indent: 2em; text-align: left;\">以服务客户为宗旨，以推动互联网信息产业的发展为己任，专注于站长优化推广软件研发，是我们始终不变的追求。。。。</p><p><br/></p>'),
(2,	'免责声明',	'shengming',	'',	'',	'',	NULL,	NULL,	'<p style=\"text-indent: 2em; text-align: left;\"><span style=\"text-indent: 2em;\">感谢您选择专题易建站软件。希望我们能努力为您提供一个高效建站、快速赚取流量的站群建设方案。</span><br/></p><p style=\"text-indent: 2em; text-align: left;\">专题易建站软件的官方网址是： http://www.zhuantiyi.com （以下简称：专题易）</p><p style=\"text-indent: 2em; text-align: left;\">为了使你正确并合法的使用本软件，请你在使用前务必阅读清楚下面的协议条款：</p><p style=\"text-indent: 2em; text-align: left;\">一、本授权协议适用且仅适用于专题易 1.x.x 版本，专题易官方对本授权协议的最终解释权。</p><p style=\"text-indent: 2em; text-align: left;\">二、协议许可的权利</p><p style=\"text-indent: 2em; text-align: left;\">1、您仅在获得商业授权许可的基础上，才能将此软件用于网站建设。</p><p style=\"text-indent: 2em; text-align: left;\">2、您可以在协议规定的约束和限制范围内修改专题易源代码或界面风格以适应您的网站要求，但不得对修改的源码二次发布。</p><p style=\"text-indent: 2em; text-align: left;\">3、您需保证您对所采集的内容具有合法使用权，您需独立承担与这些内容的相关法律责任。</p><p style=\"text-indent: 2em; text-align: left;\">4、获得商业授权之后，您将永久获得该软件的使用权，可以将本软件应用于商业建站，同时享有长期（12年）的技术支持服务，技术支持仅限功能操作的线上指导和系统问题修复</p><p style=\"text-indent: 2em; text-align: left;\">商业授权用户享有反映和提出意见的权力，相关意见将被作为首要考虑，但没有一定被采纳的承诺或保证。</p><p><br/></p>'),
(3,	'工作机会',	'work',	'',	'',	'',	NULL,	NULL,	'<p style=\"text-indent: 2em; text-align: left;\">为了发展需要，持续提供优质的产品和服务，我们渴望汲取优秀的人才，与我们一起共同迎接美好的明天！</p><p style=\"text-indent: 2em; text-align: left;\">新领酷（桂林）招聘 各种编程语言程序员和UI设计师，有意者请发送简历至 hr@email.thinkincloud.cn</p><p><br/></p>'),
(4,	'联系我们',	'contact',	'',	'',	'',	NULL,	NULL,	'<p style=\"text-indent: 2em; text-align: left;\">桂林新领酷信息科技有限公司</p><p style=\"text-indent: 2em; text-align: left;\">公司地址：桂林市穿山东路高新万达广场</p><p style=\"text-indent: 2em; text-align: left;\">联系电话：010-xxxxxx / xxxxxx</p><p style=\"text-indent: 2em; text-align: left;\">邮政编码：100000</p><p style=\"text-indent: 2em; text-align: left;\">电子邮箱：service@thinkincloud.cn</p><p><br/></p>'),
(5,	'帮助中心',	'help',	'',	'',	'',	NULL,	NULL,	'<p>这是一个提供最新话题专题的网站，小编整理的近期的热门话题，分门别类为您提供优秀的阅读体验，快速获取最多的有用的信息！</p>');

DROP TABLE IF EXISTS `reword`;
CREATE TABLE `reword` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `oldword` varchar(255) DEFAULT NULL,
  `newword` varchar(255) DEFAULT NULL,
  `addtime` int(11) DEFAULT NULL,
  `type` int(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `sessions`;
CREATE TABLE `sessions` (
  `session_id` char(32) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL DEFAULT '',
  `expiry` int(10) unsigned NOT NULL DEFAULT '0',
  `ip` char(15) NOT NULL DEFAULT '',
  `data` char(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`session_id`),
  KEY `expiry` (`expiry`)
) ENGINE=MEMORY DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `spider`;
CREATE TABLE `spider` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `url` varchar(255) DEFAULT NULL,
  `addtime` int(11) DEFAULT NULL,
  `spider` varchar(255) DEFAULT NULL,
  `adddate` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `spider` (`spider`),
  KEY `addtime` (`addtime`),
  KEY `adddate` (`adddate`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `storageservice`;
CREATE TABLE `storageservice` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(20) DEFAULT NULL,
  `url` varchar(255) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO `storageservice` (`id`, `type`, `url`, `status`) VALUES
(1,	'qiniu',	'',	0),
(2,	'upyun',	'',	0);

DROP TABLE IF EXISTS `tmpl`;
CREATE TABLE `tmpl` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `content` text,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO `tmpl` (`id`, `content`) VALUES
(6,	'这是一个有关{topic}的专题，小编对{topic}相关要点进行了整理，\r\n疏理了最新的{topic}的相关报道，感谢您的关注。'),
(11,	'最新最全的{topic}专题，包括关于{topic}的最新报道，{topic}的相关微博评论，为什么{topic}，现场追踪报道。'),
(10,	'{topic}是怎么回事？心里有疑问、想法？小编为你精心整理{topic}的相关资料，为您解惑。');

DROP TABLE IF EXISTS `topic`;
CREATE TABLE `topic` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pid` int(11) DEFAULT '0',
  `title` varchar(60) DEFAULT NULL,
  `pinyin` varchar(100) DEFAULT NULL,
  `pyurl` varchar(255) DEFAULT NULL,
  `negative` double(3,2) DEFAULT NULL,
  `positive` double(3,2) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `addtime` int(11) DEFAULT NULL,
  `click` int(11) DEFAULT NULL,
  `flag` tinyint(1) DEFAULT '0',
  `catchstatus` bit(4) DEFAULT b'0',
  `status` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `pid` (`pid`),
  KEY `title` (`title`),
  KEY `pinyin` (`pinyin`),
  KEY `status` (`status`),
  KEY `flag` (`flag`),
  KEY `flag_2` (`flag`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `topic_baike`;
CREATE TABLE `topic_baike` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `kid` int(11) DEFAULT NULL,
  `bk_url` varchar(255) DEFAULT NULL,
  `bk_title` varchar(255) DEFAULT NULL,
  `thumb` varchar(255) DEFAULT NULL,
  `bk_content` mediumtext,
  `click` int(11) DEFAULT '1',
  `addtime` int(11) DEFAULT NULL,
  `status` int(11) DEFAULT '-1',
  PRIMARY KEY (`id`),
  KEY `kid` (`kid`),
  KEY `status` (`status`),
  KEY `click` (`click`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `topic_body`;
CREATE TABLE `topic_body` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `kid` int(11) DEFAULT NULL,
  `desc` text,
  `body` mediumtext,
  `weibo` mediumtext,
  `addtime` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `kid` (`kid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `topic_wenwen`;
CREATE TABLE `topic_wenwen` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `kid` int(11) DEFAULT NULL,
  `ww_url` varchar(255) DEFAULT NULL,
  `ww_title` varchar(255) DEFAULT NULL,
  `ww_content` mediumtext,
  `click` int(11) DEFAULT '1',
  `addtime` int(11) DEFAULT NULL,
  `status` int(11) DEFAULT '-1',
  PRIMARY KEY (`id`),
  KEY `kid` (`kid`),
  KEY `click` (`click`),
  KEY `status` (`status`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `urlcache`;
CREATE TABLE `urlcache` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `kid` int(11) DEFAULT NULL,
  `url` varchar(255) DEFAULT NULL,
  `status` tinyint(4) DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `url` (`url`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
