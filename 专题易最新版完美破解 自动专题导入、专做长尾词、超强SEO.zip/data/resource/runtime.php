<?php

if(!defined('IN_SYS')) exit('Access Denied');

define("PHARROOT", dirname(__FILE__) );

define('REMOTEAPI', "http://api.zhuantiyi.com");

function __autoload($class){
	if(is_file(CORE.DS.$class.'.class.php')) {
		include CORE.DS.$class.'.class.php';
	}elseif(is_file(PHARROOT.DS.$class.'.class.php')){
		include PHARROOT.DS.$class.'.class.php';
	}
}

class admin{

	public static function login($username, $password){
		header("P3P:CP=CAO PSA OUR");
		$result['status'] = 0;
		$rs = db::find("select * from admin where username='$username'");
		if($rs){
			$password_encode = self::password_encode($username, $password, $rs['salt']);
			if($rs['status']!=1){
				$result['errMsg'] = "账号已关闭";
			}elseif($rs['password'] != $password_encode ){
				$result['errMsg'] = "用户名或密码错误";
			}
		}else{
			$result['errMsg'] = "用户名或密码错误";
		}
		if(empty($result['errMsg'])){
			$result['status'] = 1;
			$_SESSION['cp_islogin'] = true;
			$_SESSION['cp_mid'] = $rs['id'];
		}
		return $result;
	}

	public static function logout(){
		unset( $_SESSION['cp_islogin'] );
		unset( $_SESSION['cp_mid'] );
	}

	public static function check(){
		if(isset($_SESSION['cp_islogin']) && $_SESSION['cp_islogin']==true){
			return true;
		}
		return false;
	}

	public static function get(){
		if(isset($_SESSION['cp_islogin']) && $_SESSION['cp_islogin']==true ){
			$result = db::find("select id,username,realname from admin where id='$_SESSION[cp_mid]' AND status=1 ");
			if($result){
				return $result;
			}
		}
		echo "<script>window.location.href='/".APPNAME."/?m=authorized&a=login';</script>";
		exit;
	}

	public static function password_encode($username, $password, $salt){
		return md5($username.md5($password).$salt);
	}

}

class config{

	public static function update_config($sync=true){
		$r = db::select("select * from config");
		$var = array();
		foreach ($r as $key => $value) {
			$var[$value['varName']] = $value['varValue'];
		}
		$var['http_host'] = $_SERVER['HTTP_HOST'];

		if($sync){
			//远程同步配置
			$postData['data'] = serialize($var);
			$postData['appid'] = $var['appid'];
			$toUrl = REMOTEAPI."/sync/website_config";
			$res = httpUnit::post($toUrl, $postData, $var['appkey']);
			if($res['httpcode']!=200 || !($val = json_decode($res['html'], true)) ){
				return array('status'=>0, 'errMsg'=>'网络异常，请稍后再试');
			}
			if($val['status']==1){
				$respond = $val;
			}elseif($val){
				if($val['errType']=='longTimeNoLoginError'){
					$val['redirect'] = "?m=system&a=configStep2&u=".$val['username'].'&ref='.urlencode($_SERVER['HTTP_REFERER']);
				}else{
					$val['redirect'] = "?m=system&a=bind";
				}
				return $val;
			}
		}else{
			$respond = true;
		}
		
		$data = '<?php return ';
		$data .= var_export($var, true);
		$data .= ';';
		if(!is_dir(DATA.'/cache')){
			mkdir(DATA.'/cache');
		}
		file_put_contents(DATA.'/cache/config_cache.inc.php', $data);
		return $respond;
	}

}

/**
 * @version    $Id: runtime.php 272 2016-08-04 07:23:58Z qinjinpeng $
 */

if(!defined('IN_SYS')) exit('Access Denied');

class crypt{

	public static function encrypt($data){
		srand((double)microtime() * 1000000);
		$rand = md5(rand(0, 32000));
		$ctr = 0;
		$tmp = '';
		for($i = 0; $i < strlen($data); $i++){
			$ctr = $ctr == strlen($rand) ? 0 : $ctr;
			$tmp .= $rand[$ctr].($data[$i] ^ $rand[$ctr++]);
		}
		return rtrim(base64_encode(self::proc($tmp)),'=');
	}

	public static function decrypt($data){
		$data = self::proc(base64_decode($data));
		$tmp = '';
		for($i = 0; $i < strlen($data); $i++){
			$tmp .= $data[$i] ^ $data[++$i];
		}
		return $tmp;
	}

	protected static function proc($data){
		global $auth_key;
		if(empty($auth_key)){
			exit('authkey does not exists!');	
		}
		$ctr = 0;
		$tmp = '';
		for($i = 0; $i < strlen($data); $i++){
			$ctr = $ctr == strlen($auth_key) ? 0 : $ctr;
			$tmp .= $data[$i] ^ $auth_key[$ctr++];
		}
		return $tmp;
	}

	//加密后更短，加密内容固定
	public static function string_encode($string, $type = 'ENCODE', $key='') {
		global $auth_key;
		$string = (string)$string;
		if(empty($key)){
			if(empty($auth_key)) die('auth_key not exists');
			$key = $auth_key;   
		}
		$string = ($type == 'DECODE') ? base64_decode($string) : $string;
		$key_len = strlen($key);
		$key     = md5($key);
		$string_len = strlen($string);
		$code = '';
		for ($i=0; $i<$string_len; $i++) {
			$j = ($i * $key_len) % 32;
			$code .= $string[$i] ^ $key[$j];
		}
		return ($type == 'ENCODE') ? rtrim(base64_encode($code),'=') : $code;
	}

	public static function to62($n) {
		$base = 62;
		$index = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
		$ret = '';
		for($t = floor(log10($n) / log10($base)); $t >= 0; $t --) {
			$a = floor($n / pow($base, $t));
			$ret .= substr($index, $a, 1);
			$n -= $a * pow($base, $t);
		}
		return $ret;
	}

	public static function from62($s) {
		$base = 62;
		$index = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
		$ret = 0;
		$len = strlen($s) - 1;
		for($t = 0; $t <= $len; $t ++) {
			$ret += strpos($index, substr($s, $t, 1)) * pow($base, $len - $t);
		}
		return $ret;
	}

	public static $url_replace_map = array(
		'/news/' => '$0',
		'/list/' => '$1',
		'/view/' => '$2',
		'/article/' => '$3',
		'/content/' => '$4',
		'/photo/' => '$5',
		'/blog/' => '$6',
		'.shtml' => '$7',
		'.html' => '$8',
		'.php' => '$9',
		'/2010/' => '$a',
		'/2011/' => '$b',
		'/2012/' => '$c',
		'/2013/' => '$d',
		'/2014/' => '$e',
		'/2015/' => '$f',
		'/2016/' => '$g',
		'/2017/' => '$h',
		'/2018/' => '$i',
		'/2019/' => '$j',
		'/2020/' => '$k',
		);

	public static function url_encode($str){
		foreach (self::$url_replace_map as $key => $value) {
			$str = str_replace($key, $value, $str);
		}
		$str = self::myencode($str);
		return $str;
	}

	public static function url_decode($str){
		$str = self::mydecode($str);
		if(!preg_match('#^[_=&/?\.\:a-z0-9-\#\^\$]*$#i', $str)){
			return false;
		}
		$url_replaces = array_flip(self::$url_replace_map);
		foreach ($url_replaces as $key => $value) {
			$str = str_replace($key, $value, $str);
		}
		return $str;
	}
	
	public static $base64_config = array('_','-','0','1','2','3','4','5','6','7','8','9', 'a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z','A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z');
	
	public static function getBytes($string) { 
		$data = iconv("UTF-8","GBK",$string);
		return unpack("C*",$data);
	}

	public static function array_index($t){
		return array_search($t, self::$base64_config);
	}

	public static function mydecode($str){
		$str = str_replace("!","",$str);
		$slen = strlen($str);
		$mod = $slen%4;
		$num = floor($slen/4);
		$desc = array();
		for($i=0;$i<$num;$i++){
			$arr = array_map(array('self', 'array_index'),str_split(substr($str,$i*4,4)));
			$desc_0 = ($arr[0]<<2)|(($arr[1]&48)>>4);
			$desc_1 = (($arr[1]&15)<<4)|(($arr[2]&60)>>2);
			$desc_2 = (($arr[2]&3)<<6)|$arr[3];
			$desc = array_merge($desc, array($desc_0,$desc_1,$desc_2));
		}
		if($mod == 0) return implode('', array_map("chr",$desc));
		$arr = array_map(array('self', 'array_index'), str_split(substr($str,$num*4,4)));
		if(count($arr) == 1) {
			$desc_0 = $arr[0]<<2;
			if($desc_0 != 0) $desc = array_merge($desc, array($desc_0));
		}else if(count($arr) == 2) {
			$desc_0 = ($arr[0]<<2)|(($arr[1]&48)>>4);
			$desc = array_merge($desc, array($desc_0));
		}else if(count($arr) == 3) {
			$desc_0 = ($arr[0]<<2)|(($arr[1]&48)>>4);
			$desc_1 = ($arr[1]<<4)|(($arr[2]&60)>>2);
			$desc = array_merge($desc, array($desc_0,$desc_1));
		}
		return implode('', array_map("chr",$desc));
	}

	public static function myencode($str){
		$byte_arr = self::getBytes($str);
		$slen=count($byte_arr);
		$smod = ($slen%3);
		$snum = floor($slen/3);
		$desc = array();
		for($i=1;$i<=$snum;$i++){
			$index_num = ($i-1)*3;
			$_dec0= $byte_arr[$index_num+1]>>2;
			$_dec1= (($byte_arr[$index_num+1]&3)<<4)|($byte_arr[$index_num+2]>>4);
			$_dec2= (($byte_arr[$index_num+2]&0xF)<<2)|($byte_arr[$index_num+3]>>6); 
			$_dec3= $byte_arr[$index_num+3]&63;
			$desc = array_merge($desc, array(self::$base64_config[$_dec0],self::$base64_config[$_dec1],self::$base64_config[$_dec2],self::$base64_config[$_dec3]));
		}
		if($smod==0) return implode('',$desc);
		$n = ($snum*3)+1;
		$_dec0= $byte_arr[$n]>>2;
		if(!isset($byte_arr[$n+1])){
			$_dec1= (($byte_arr[$n]&3)<<4);
			$_dec2=$_dec3="";
		}else{
			$_dec1= (($byte_arr[$n]&3)<<4)|($byte_arr[$n+1]>>4);
			$_dec2= self::$base64_config[($byte_arr[$n+1]&0xF)<<2];
			$_dec3="";
		}
		$desc = array_merge($desc,array(self::$base64_config[$_dec0],self::$base64_config[$_dec1],$_dec2,$_dec3));
		return implode('',$desc);
	}

}



class httpUnit{

	public static function json($url, $post_data=array(), $signkey='', $cookiefile=''){
		$data = self::post($url, $post_data, $signkey, $cookiefile);
		if($data['httpcode']!=200){
			$errStr = "通信失败，请稍后再试";
		}else{
			$result = json_decode($data['html'], true);
			if(!is_array($result)){
				$errStr = "接口通信错误！";
				if($GLOBALS['debug']){
					$errStr .= "<p>".var_dump($data)."</p>";
				}
			}elseif($result['status']!=1){
				$errStr = $result['errMsg'];
			}
		}
		
		if(!empty($errStr)){
			$is_sign_error = isset($result['errType']) && in_array($result['errType'], array('appIdError', 'domainError', 'signError', 'checkError') ) ? true : false ;
			if(IS_AJAX){
				if( $is_sign_error && defined('APPNAME') ){
					controller::json( array('status' => $result['status'], 'errMsg' => $result['errMsg'], 'redirect' => '?m=system&a=bind') );
				}else{
					controller::json( $result );
				}
			}else{
				if( $is_sign_error && defined('APPNAME') ){
					controller::redirect('?m=system&a=bind', $result['errMsg']);
				}else{
					controller::page_503();
					throw new Exception($result['errMsg']);
				}
			}
		}
		return $result;
	}

	public static function get($url){
		return self::post($url);
	}

	public static function post($url, $post_data=array(), $signkey='', $cookiefile=''){
		if(!empty($post_data)){
			$post_method = 'POST';
			$post_type = 1;
		}else{
			$post_method = 'GET';
			$post_type = 0;
		}
		if(!empty($signkey)){
			$post_data['sign'] = self::sign($post_data, $signkey);
		}
		$ch = curl_init();
		if(!empty($cookiefile)){
			if(is_array($cookiefile)){
				curl_setopt($ch, CURLOPT_COOKIE, str_replace('&', ';', http_build_query($cookiefile)));
			}else{
				$cookie_jar = DATA.'/temp/cookie_'.$cookiefile.'.inc';
				curl_setopt($ch, CURLOPT_COOKIEJAR, $cookie_jar);
				curl_setopt($ch, CURLOPT_COOKIEFILE, $cookie_jar);
			}
		}
		curl_setopt($ch, CURLOPT_RETURNTRANSFER,1);
		curl_setopt($ch, CURLOPT_HTTP_VERSION, CURL_HTTP_VERSION_1_0);
		curl_setopt($ch, CURLOPT_USERAGENT, self::userAgent());
		curl_setopt($ch, CURLOPT_CUSTOMREQUEST, $post_method);
		curl_setopt($ch, CURLOPT_REFERER, self::get_referer($url) );
		curl_setopt($ch, CURLOPT_URL, $url);
		curl_setopt($ch, CURLOPT_POST, $post_type);
		if(!empty($post_data)){
			curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($post_data) );
		}
		curl_setopt($ch, CURLOPT_ENCODING, 'gzip,deflate');
		curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
		curl_setopt($ch, CURLOPT_HEADER, 1);
		curl_setopt($ch, CURLOPT_NOSIGNAL,1);

		if(strpos($url, 'https://')!==false){
			curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, true);//SSL证书认证
			curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 2);//严格认证
			curl_setopt($ch, CURLOPT_CAINFO, DATA.'/resource/cacert.pem');
		}

		defined('CURLOPT_TIMEOUT_MS') && curl_setopt($ch, CURLOPT_TIMEOUT_MS, 60000);
		$result = curl_exec($ch);
		if($result !== false) {
			$return['httpcode'] = curl_getinfo($ch, CURLINFO_HTTP_CODE);
			$return['charset'] = self::get_charset( curl_getinfo($ch, CURLINFO_CONTENT_TYPE) );
			$headerSize = curl_getinfo($ch, CURLINFO_HEADER_SIZE);
			$return['header'] = substr($result, 0, $headerSize);
			$return['html'] = substr($result, $headerSize);
		}else{
			$err = curl_error($ch);
			$return['httpcode'] = 0;
			$return['errMsg'] = $err;
		}
		curl_close($ch);
		return $return;
	}

	public static function sogou($url, $post_data=array()){
		$res = self::post($url, $post_data, null, 'sogou');
		if( $res['httpcode']=='200' && strpos($res['html'], "您的访问过于频繁")!==false){
			if(self::read_code($res['html'])){
				$res = self::post($url, $post_data, null, 'sogou');
				if($res['httpcode']=='200' && strpos($res['html'], "您的访问过于频繁")!==false){
					$res['httpcode'] = '0';
				}else{
					$lockfile = DATA.DS.'temp'.DS.'sogou.lock';
					unlink($lockfile);
				}
			}
		}
		return $res;
	}

	private static function read_code($content){
		$lockfile = DATA.DS.'temp'.DS.'sogou.lock';
		$code_url = "http://www.sogou.com/antispider/util/seccode.php";
		$resimg = self::post($code_url, null, null, 'sogou');

		$data['appid'] = $GLOBALS['conf']['appid'];
		$data['http_host'] = $_SERVER["HTTP_HOST"];
		$data['image'] = $resimg['html'];

		$captcha = self::json(REMOTEAPI."/captchaApi", $data, $GLOBALS['conf']['appkey']);

		$post_data = array();
		if(preg_match('#<input type="hidden" name="r" id="from" value="([^"]*?)"#', $content, $mt))
		{
			$r =$mt[1] ;
		}
		$post_url ="http://www.sogou.com/antispider/thank.php";
		$post_data['c'] = $captcha['result'];
		$post_data['r'] = $r;
		$post_data['v'] = 5;
		$res_data = self::post($post_url, $post_data, null, "sogou");
		$data_result = json_decode($res_data['html'], true);
		if($data_result['code']!=3){
			return true;
		}
		return false;
	}

	public static function sign_check($signkey){
		while (list ($key, $val) = each ($_REQUEST)) {
			if($key == "sign" || $key == "m" || $key == "a") continue;
			else $para[$key] = stripslashes($val);
		}

		ksort($para);
		reset($para);

		$arg  = "";
		while (list ($key, $val) = each ($para)) {
			$arg.=$key."=".$val."&";
		}
		$arg = substr($arg,0,count($arg)-2);
		$sign = md5($arg.$signkey);

		if($sign == $_REQUEST["sign"]){
			return true;
		}
		return false;
	}

	private static function sign($para=array(), $signkey){
		ksort($para);
		reset($para);

		$arg  = "";
		while (list ($key, $val) = each ($para)) {
			if($key == "sign" || $key == "m" || $key == "a") continue;
			$arg.=$key."=".$val."&";
		}
		$arg = substr($arg,0,count($arg)-2);
		return md5($arg.$signkey);
	}

	public static function userAgent($ua = null){
		static $useragent;
		if($ua){
			$useragent = $ua;
		}
		if(!empty($useragent)){
			return $useragent;
		}
		if(isset($_SERVER['HTTP_USER_AGENT'])){
			$user_agent = $_SERVER['HTTP_USER_AGENT'];
		}else{
			$user_agent = "Mozilla/5.0 (compatible; Baiduspider/2.0; +http://www.baidu.com/search/spider.html)";
		}
		return $user_agent;
	}

	private static function get_charset($string){
		if($string){
			if(preg_match("#charset=(gb2312|gbk|utf-8)#si", $string, $mt)){
				return strtolower( $mt[1] );
			}
			if(preg_match("#charset=\"(gb2312|gbk|utf-8)\"#si", $string, $mt)){
				return strtolower( $mt[1] );
			}
		}
		return false;
	}

	private static function get_referer($url){
		$noReferer = array(
			'qpic.cn',
			'v4.cc',
		);
		$host = 'http://'.parse_url($url, PHP_URL_HOST);
		foreach ($noReferer as $key => $value) {
			if(strpos($host, $value)!==false){
				return null;
			}
		}
		return $host;
	}

}

class loader{
	
	public $m, $a;
	/*
	 * Init 开始
	 */
	public static function init(){
		$loader = new loader();
		$loader->environment();
		$loader->router();
		return $loader;
	}
	/*
	 * 加载模块
	 */
	public function load($extension){
		$this->{'load_'.$extension}();
		return $this;
	}

	/*
	 * 运行项目
	 */
	public function run(){
		if(defined('APPNAME')){
			$file = ROOT.'/'.APPNAME.'/control/'.$this->m.'.php';
		}else{
			$file = ROOT.'/control/'.$this->m.'.php';
		}
		if(!is_file($file)){
			$this->m = 'topic';
			$file = ROOT.'/control/'.$this->m.'.php';
		}
		define('M', $this->m);
		define('A', $this->a);
		
		require $file;
		$m = M.'_controller';
		$object = new $m();
		if( method_exists($object, A) ){
			call_user_func( array($object, A ));
		}elseif( method_exists($object, '_empty') ){
			call_user_func( array($object, '_empty' ), A);
		}else{
			controller::page_404();
		}
	}

	/*
	 * 环境变量处理
	 */
	public function environment(){

		if (!isset($_SERVER['REQUEST_URI']))
		{
			if (isset($_SERVER['HTTP_X_ORIGINAL_URL']))
			{
				$_SERVER['REQUEST_URI'] = $_SERVER['HTTP_X_ORIGINAL_URL'];
			}
			else
			{
				$_SERVER['REQUEST_URI'] = $_SERVER['PHP_SELF'] .'?'. $_SERVER['QUERY_STRING'];
			}
		}

		$_SERVER['REQUEST_URI'] = str_replace('/index.php', '', $_SERVER['REQUEST_URI']);
		
		$temp = strtoupper(urldecode(urldecode($_SERVER['REQUEST_URI'])));
		if(strpos($temp, '<') !== false || strpos($temp, '"') !== false || strpos($temp, "'") !== false || strpos($temp, "*") !== false || strpos($temp, 'CONTENT-TRANSFER-ENCODING') !== false) {
			controller::page_404();
		}
	}

	/*
	 * 路由
	 */
	public function router(){
		if( $request_uri_fixed = trim( preg_replace('#\?.*$#', '', $_SERVER['REQUEST_URI']), '/') ){
			$request_uri_variable = explode('/', $request_uri_fixed );
			foreach ($request_uri_variable as $key => $value) {
				if(defined('APPNAME')){
					$keyidx = $key-1;
				}else{
					$keyidx = $key;
				}
				if($keyidx==0){
					$_GET['m'] = $value;
				}elseif($keyidx==1){
					$_GET['a'] = $value;
				}elseif($keyidx>=2 && $keyidx%2==0&& isset($request_uri_variable[$keyidx+1]) && preg_match('#^[a-z0-9_]*$#', $value) ){
					$_GET[$value] = $_REQUEST[$value] = $request_uri_variable[$keyidx+1];
				}
			}
		}

		$this->m = !empty($_GET['m'])?preg_replace('#[^a-z0-9_]#i', '', $_GET['m']):'index';
		$this->a = !empty($_GET['a'])?preg_replace('#[^a-z0-9_]#i', '', $_GET['a']):'index';
	}

	/*
	 * session模块
	 */
	public function load_session(){
		return new session();
	}

}

/**
 * @version    $Id: runtime.php 272 2016-08-04 07:23:58Z qinjinpeng $
 */

class segment {
	public $rank_dic = array();
	public $one_name_dic = array();
	public $two_name_dic = array();
	public $new_word = array();
	public $source_string = '';
	public $result_string = '';
	public $split_char = ' ';
	public $SplitLen = 4;
	public $especial_char = "和|的|是";
	public $new_word_limit = "在|的|与|或|就|你|我|他|她|有|了|是|其|能|对|地";
	public $common_unit = "年|月|日|时|分|秒|点|元|百|千|万|亿|位|辆";
	public $cn_number = "０|１|２|３|４|５|６|７|８|９|＋|－|％|．|ａ|ｂ|ｃ|ｄ|ｅ|ｆ|ｇ|ｈ|ｉ|ｊ|ｋ|ｌ|ｍ|ｎ|ｏ|ｐ|ｑ|ｒ|ｓ |ｔ|ｕ|ｖ|ｗ|ｘ|ｙ|ｚ|Ａ|Ｃ|Ｄ|Ｅ|Ｆ|Ｇ|Ｈ|Ｉ|Ｊ|Ｋ|Ｌ|Ｍ|Ｎ|Ｏ|Ｐ|Ｑ|Ｒ|Ｓ|Ｔ|Ｕ|Ｖ|Ｗ|Ｘ|Ｙ|Ｚ";
	public $cn_sg_num = "一|二|三|四|五|六|七|八|九|十|百|千|万|亿|数";
	public $max_len = 13;
	public $min_len = 3;
	public $cn_two_name = "端木 南宫 谯笪 轩辕 令狐 钟离 闾丘 长孙 鲜于 宇文 司徒 司空 上官 欧阳 公孙 西门 东门 左丘 东郭 呼延 慕容 司马 夏侯 诸葛 东方 赫连 皇甫 尉迟 申屠";
	public $cn_one_name = "赵钱孙李周吴郑王冯陈褚卫蒋沈韩杨朱秦尤许何吕施张孔曹严华金魏陶姜戚谢邹喻柏水窦章云苏潘葛奚范彭郎鲁韦昌马苗凤花方俞任袁柳酆鲍史唐费廉岑薛雷贺倪汤滕殷罗毕郝邬安常乐于时傅皮卡齐康伍余元卜顾孟平黄穆萧尹姚邵堪汪祁毛禹狄米贝明臧计伏成戴谈宋茅庞熊纪舒屈项祝董粱杜阮蓝闵席季麻强贾路娄危江童颜郭梅盛林刁钟徐邱骆高夏蔡田樊胡凌霍虞万支柯咎管卢莫经房裘缪干解应宗宣丁贲邓郁单杭洪包诸左石崔吉钮龚程嵇邢滑裴陆荣翁荀羊於惠甄魏加封芮羿储靳汲邴糜松井段富巫乌焦巴弓牧隗谷车侯宓蓬全郗班仰秋仲伊宫宁仇栾暴甘钭厉戎祖武符刘姜詹束龙叶幸司韶郜黎蓟薄印宿白怀蒲台从鄂索咸籍赖卓蔺屠蒙池乔阴郁胥能苍双闻莘党翟谭贡劳逄姬申扶堵冉宰郦雍郤璩桑桂濮牛寿通边扈燕冀郏浦尚农温别庄晏柴翟阎充慕连茹习宦艾鱼容向古易慎戈廖庚终暨居衡步都耿满弘匡国文寇广禄阙东殴殳沃利蔚越夔隆师巩厍聂晁勾敖融冷訾辛阚那简饶空曾沙须丰巢关蒯相查后江游竺";

	function __construct($loaddic=true) {
		if($loaddic) {
			for($i=0;$i<strlen($this->cn_one_name)-1;$i++){
				$this->one_name_dic[$this->cn_one_name[$i].$this->cn_one_name[$i+1]] = 1;
				$i++;
			}
			$twoname = explode(" ",$this->cn_two_name);
			foreach($twoname as $n){ $this->two_name_dic[$n] = 1; }
			unset($twoname);
			unset($this->cn_two_name);
			unset($this->cn_one_name);
			$dicfile = DATA."/resource/dict.csv";
			$fp = fopen($dicfile,'r');
			while($line = fgets($fp,64)){
				$ws = explode(' ',$line);
				$this->rank_dic[strlen($ws[0])][$ws[0]] = $ws[1];
			}
			fclose($fp);
		}
	}

	function clear() {
		unset($this->rank_dic);
	}
	function get_source($str) {
		$str = iconv('utf-8','gbk//ignore',$str);
		$this->source_string = $str;
		$this->result_string = '';
	}
	function simple_split($str) {
		$this->source_string = $this->revise_string($str);
		return $this->source_string;
	}
	function split_result($str='',$try_num_name=true,$try_diff=true) {
		$str = trim($str);
		if($str!='') $this->get_source($str);
		else return '';
		$this->source_string = preg_replace('/ {1,}/',' ',$this->revise_string($this->source_string));
		$spwords = explode(' ',$this->source_string);
		$spLen = count($spwords) - 1;
		$spc = $this->split_char;
		for($i=$spLen;$i>=0;$i--){
			if(ord($spwords[$i][0])<33) continue;
			else if(!isset($spwords[$i][$this->min_len])) $this->result_string = $spwords[$i].$spc.$this->result_string;
			else if(ord($spwords[$i][0])<0x81){
				$this->result_string = $spwords[$i].$spc.$this->result_string;
			} else {
				$this->result_string = $this->split_mm($spwords[$i],$try_num_name,$try_diff).$spc.$this->result_string;
			}
		}
		$okstr = iconv('gbk','utf-8',$this->result_string);
		return $okstr;
	}
	function par_number($str) {
		if($str == '') return '';
		$ws = explode(' ',$str);
		$wlen = count($ws);
		$spc = $this->split_char;
		$reStr = '';
		for($i=0;$i<$wlen;$i++){
			if($ws[$i]=='') continue;
			if($i>=$wlen-1) $reStr .= $spc.$ws[$i];
			else{ $reStr .= $spc.$ws[$i]; }
		}
		return $reStr;
	}
	function par_other($word_array) {
		$wlen = count($word_array)-1;
		$rsStr = '';
		$spc = $this->split_char;
		for($i=$wlen;$i>=0;$i--) {
			if(preg_match('/'.$this->cn_sg_num.'/',$word_array[$i])) {
				$rsStr .= $spc.$word_array[$i];
				if($i>0 && preg_match('/^'.$this->common_unit.'/',$word_array[$i-1]) ) {
					$rsStr .= $word_array[$i-1]; $i--;
				} else {
					while($i>0 && preg_match("/".$this->cn_sg_num."/",$word_array[$i-1]) ){ $rsStr .= $word_array[$i-1]; $i--; }
				}
				continue;
			}
			if(strlen($word_array[$i])==4 && isset($this->two_name_dic[$word_array[$i]])) {
				$rsStr .= $spc.$word_array[$i];
				if($i>0&&strlen($word_array[$i-1])==2){
					$rsStr .= $word_array[$i-1];$i--;
					if($i>0&&strlen($word_array[$i-1])==2){ $rsStr .= $word_array[$i-1];$i--; }
				}
			} else if(strlen($word_array[$i])==2 && isset($this->one_name_dic[$word_array[$i]])) {
				$rsStr .= $spc.$word_array[$i];
				if($i>0&&strlen($word_array[$i-1])==2){
					if(preg_match("/".$this->especial_char."/",$word_array[$i-1])) continue;
					$rsStr .= $word_array[$i-1];$i--;
					if($i>0 && strlen($word_array[$i-1])==2 &&
						!preg_match("/".$this->especial_char."/",$word_array[$i-1]))
						{ $rsStr .= $word_array[$i-1];$i--; }
				}
			} else {
				$rsStr .= $spc.$word_array[$i];
			}
		}
		$rsStr = preg_replace("/^".$spc."/","",$rsStr);
		return $rsStr;
	}
	function split_mm($str,$try_num_name=true,$try_diff=true) {
		$spc = $this->split_char;
		$spLen = strlen($str);
		$rsStr = $okWord = $tmpWord = '';
		$word_array = array();
		for($i=($spLen-1);$i>=0;) {
			if($i<=$this->min_len){
				if($i==1){
					$word_array[] = substr($str,0,2);
				} else {
					$w = substr($str,0,$this->min_len+1);
					if($this->is_word($w)){
						$word_array[] = $w;
					}else{
						$word_array[] = substr($str,2,2);
						$word_array[] = substr($str,0,2);
					}
				}
				$i = -1; break;
			}
			if($i>=$this->max_len) $max_pos = $this->max_len;
			else $max_pos = $i;
			$isMatch = false;
			for($j=$max_pos;$j>=0;$j=$j-2){
				$w = substr($str,$i-$j,$j+1);
				if($this->is_word($w)){
					$word_array[] = $w;
					$i = $i-$j-1;
					$isMatch = true;
					break;
				}
			}
			if(!$isMatch){
				if($i>1) {
					$word_array[] = $str[$i-1].$str[$i];
					$i = $i-2;
				}
			}
		}

		if($try_num_name) {
			$rsStr = $this->par_other($word_array);
		} else {
			$wlen = count($word_array)-1;
			for($i=$wlen;$i>=0;$i--){
				$rsStr .= $spc.$word_array[$i];
			}
		}
		if($try_diff) $rsStr = $this->test_diff(trim($rsStr));
		return $rsStr;
	}
	function auto_description($str,$keyword,$strlen) {
		$this->source_string = $this->revise_string($this->source_string);
		$spwords = explode(" ",$this->source_string);
		$keywords = explode(" ",$this->keywords);
		$regstr = "";
		foreach($keywords as $k=>$v) {
			if($v=="") continue;
			if(ord($v[0])>0x80 && strlen($v)<3) continue;
			if($regstr=="") $regstr .= "($v)";
			else $regstr .= "|($v)";
		}
	}
	function test_diff($str) {
		$str = preg_replace("/ {1,}/"," ",$str);
		if($str == ""||$str == " ") return "";
		$ws = explode(' ',$str);
		$wlen = count($ws);
		$spc = $this->split_char;
		$reStr = "";
		for($i=0;$i<$wlen;$i++) {
			if($i>=($wlen-1)) {
				$reStr .= $spc.$ws[$i];
			} else {
				if($ws[$i]==$ws[$i+1]){
					$reStr .= $spc.$ws[$i].$ws[$i+1];
					$i++; continue;
				}
				if(strlen($ws[$i])==2 && strlen($ws[$i+1])<8 && strlen($ws[$i+1])>2) {
					$addw = $ws[$i].$ws[$i+1];
					$t = 6;
					$testok = false;
					while($t>=4) {
						$w = substr($addw,0,$t);
						if($this->is_word($w) && ($this->get_rank($w) > $this->get_rank($ws[$i+1])*2) ) {
							$limit_word = substr($ws[$i+1],strlen($ws[$i+1])-$t-2,strlen($ws[$i+1])-strlen($w)+2);
							if($limit_word!="") $reStr .= $spc.$w.$spc.$limit_word;
							else $reStr .= $spc.$w;
							$testok = true;
							break;
						}
						$t = $t-2;
					}
					if(!$testok) $reStr .= $spc.$ws[$i];
					else $i++;
				} else if(strlen($ws[$i])>2 && strlen($ws[$i])<8 && strlen($ws[$i+1])>2 && strlen($ws[$i+1])<8) {
					$t21 = substr($ws[$i+1],0,2);
					$t22 = substr($ws[$i+1],0,4);
					if($this->is_word($ws[$i].$t21)) {
						if(strlen($ws[$i])==6||strlen($ws[$i+1])==6){
							$reStr .= $spc.$ws[$i].$t21.$spc.substr($ws[$i+1],2,strlen($ws[$i+1])-2);
							$i++;
						} else {
							$reStr .= $spc.$ws[$i];
						}
					} else if(strlen($ws[$i+1])==6) {
						if($this->is_word($ws[$i].$t22)) {
							$reStr .= $spc.$ws[$i].$t22.$spc.$ws[$i+1][4].$ws[$i+1][5];
							$i++;
						} else { $reStr .= $spc.$ws[$i]; }
					} else if(strlen($ws[$i+1])==4) {
						$addw = $ws[$i].$ws[$i+1];
						$t = strlen($ws[$i+1])-2;
						$testok = false;
						while($t>0) {
							$w = substr($addw,0,strlen($ws[$i])+$t);
							if($this->is_word($w) && ($this->get_rank($w) > $this->get_rank($ws[$i+1])*2) ) {
								$limit_word = substr($ws[$i+1],$t,strlen($ws[$i+1])-$t);
								if($limit_word!="") $reStr .= $spc.$w.$spc.$limit_word;
								else $reStr .= $spc.$w;
								$testok = true;
								break;
							}
							$t = $t-2;
						}
						if(!$testok) $reStr .= $spc.$ws[$i];
						else $i++;
					}else {
						$reStr .= $spc.$ws[$i];
					}
				} else {
					$reStr .= $spc.$ws[$i];
				}
			}
		}
		return $reStr;
	}
	function is_word($okWord){
		$slen = strlen($okWord);
		if($slen > $this->max_len) return false;
		else return isset($this->rank_dic[$slen][$okWord]);
	}
	function revise_string($str) {
		$spc = $this->split_char;
		$slen = strlen($str);
		if($slen==0) return '';
		$okstr = '';
		$prechar = 0;
		for($i=0;$i<$slen;$i++){
			if(ord($str[$i]) < 0x81) {
				if(ord($str[$i]) < 33){
					//$str[$i]!="\r"&&$str[$i]!="\n"
					if($prechar!=0) $okstr .= $spc;
					$prechar=0;
					continue;
				} else if(preg_match("/[^0-9a-zA-Z@\.%#:\\/\\&_-]/",$str[$i])) {
					if($prechar==0) {
						$okstr .= $str[$i]; $prechar=3;
					} else {
						$okstr .= $spc.$str[$i]; $prechar=3;
					}
				} else {
					if($prechar==2||$prechar==3) {
						$okstr .= $spc.$str[$i]; $prechar=1;
					} else {
						if(preg_match("/@#%:/",$str[$i])){ $okstr .= $str[$i]; $prechar=3; }
						else { $okstr .= $str[$i]; $prechar=1; }
					}
				}
			} else{
				if($prechar!=0 && $prechar!=2) $okstr .= $spc;
				if(isset($str[$i+1])){
					$c = $str[$i].$str[$i+1];
					if(preg_match("/".$this->cn_number."/",$c)) {
						$okstr .= $this->get_alab_num($c); $prechar = 2; $i++; continue;
					}
					$n = hexdec(bin2hex($c));
					if($n>0xA13F && $n < 0xAA40) {
						if($c=="《"){
							if($prechar!=0) $okstr .= $spc." 《";
							else $okstr .= " 《";
							$prechar = 2;
						} else if($c=="》"){
							$okstr .= "》 ";
							$prechar = 3;
						} else{
							if($prechar!=0) $okstr .= $spc.$c;
							else $okstr .= $c;
							$prechar = 3;
						}
					} else {
						$okstr .= $c;
						$prechar = 2;
					}
					$i++;
				}
			}
			//中文字符
		}
		//结束循环
		return $okstr;
	}
	function find_new_word($str,$maxlen=6) {
		$okstr = "";
		return $str;
	}
	function get_keyword($str,$ilen=-1) {
		if($str=='') return '';
		else $this->split_result($str,true,true);
		$okstr = $this->result_string;
		$ws = explode(' ',$okstr);
		$okstr = $wks = '';
		foreach($ws as $w) {
			$w = trim($w);
			if(strlen($w)<2) continue;
			if(!preg_match("/[^0-9:-]/",$w)) continue;
			if(strlen($w)==2&&ord($w[0])>0x80) continue;
			if(isset($wks[$w])) $wks[$w]++;
			else $wks[$w] = 1;
		}
		if(is_array($wks)) {
			arsort($wks);
			if($ilen==-1) {
				foreach($wks as $w=>$v) {
					if($this->get_rank($w)>500) $okstr .= $w." ";
				}
			}  else {
				foreach($wks as $w=>$v){
					if((strlen($okstr)+strlen($w)+1)<$ilen) $okstr .= $w." ";
					else break;
				}
			}
		}
		$okstr = iconv('gbk','utf-8',$okstr);
		return trim($okstr);
	}
	function get_rank($w){
		if(isset($this->rank_dic[strlen($w)][$w])) return $this->rank_dic[strlen($w)][$w];
		else return 0;
	}
	function get_alab_num($fnum){
		$nums = array("０","１","２","３","４","５","６",
			"７","８","９","＋","－","％","．",
			"ａ","ｂ","ｃ","ｄ","ｅ","ｆ","ｇ","ｈ","ｉ","ｊ","ｋ","ｌ","ｍ",
			"ｎ","ｏ","ｐ","ｑ","ｒ","ｓ ","ｔ","ｕ","ｖ","ｗ","ｘ","ｙ","ｚ",
			"Ａ","Ｂ","Ｃ","Ｄ","Ｅ","Ｆ","Ｇ","Ｈ","Ｉ","Ｊ","Ｋ","Ｌ","Ｍ",
			"Ｎ","Ｏ","Ｐ","Ｑ","Ｒ","Ｓ","Ｔ","Ｕ","Ｖ","Ｗ","Ｘ","Ｙ","Ｚ");
		$fnums = "0123456789+-%.abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
		$fnum = str_replace($nums,$fnums,$fnum);
		return $fnum;
	}
}




class seo{

	public static function excute($body, $origdata){

		$body = seo::seoword($body, $origdata);
		$body = seo::confuse($body, $origdata);
		return $body;
	}

	public static function seoword($body){
		//print_r($body);
		$GLOBALS['conf']['seoWordNum'] = intval($GLOBALS['conf']['seoWordNum']);
		//未开启
		if(empty($GLOBALS['conf']['seoWord']) || !$GLOBALS['conf']['seoWordNum']){
			return $body;
		}
		//伪原创比例
		$ys = crypt::from62( substr( md5($body['title']), 0, 3) ) % 100;
		$seoWordScale = intval($GLOBALS['conf']['seoWordScale']);
		if($seoWordScale<$ys){
			return $body;
		}
		//取出词语
		$sw_arr = str_replace(array(',', '，'), "\n", $GLOBALS['conf']['seoWord']);
		$sw_arr = explode("\n", $sw_arr);
		foreach ($sw_arr as &$value) {
			$value = trim($value);
		}

		$sw_arr = array_filter( $sw_arr );
		$idx = mt_rand(0, max(0, count($sw_arr)-$GLOBALS['conf']['seoWordNum']) );
		$sw_arr = array_slice($sw_arr, $idx, $GLOBALS['conf']['seoWordNum']);
		$seowords = addslashes( join(',', $sw_arr) );

		//print_r($sw_arr);
		if(!empty($sw_arr)){
			//插入文章
			$sw_arr_num = count($sw_arr);
			$body_array = explode('，', $body['body']);
			//print_r($body_array);
			$body_s_count = count($body_array);
			$snum = ceil(($body_s_count/2)/$sw_arr_num);
			foreach ($sw_arr as $key => $value) {
				$k = $snum * $key + 1;
				if(isset($body_array[$k])){
					$body_array[$k] = $value.$body_array[$k];
				}
			}
			$body['body'] = join("，", $body_array);
			//插入标题
			if($GLOBALS['conf']['seoTitle']=='1'){
				if($GLOBALS['conf']['seoTitle_x']=='1'){
					$body['title'] = strip_tags($sw_arr[0]).$body['title'];
				}elseif($GLOBALS['conf']['seoTitle_x']=='2'){
					$body['title'] = $body['title'].strip_tags($sw_arr[0]);
				}elseif($GLOBALS['conf']['seoTitle_x']=='3'){
					$tlen = mb_strlen($body['title'], 'utf-8');
					$blen = mb_strlen($body['body'], 'utf-8');
					$sp = $blen%$tlen;
					$body['title'] = mb_substr($body['title'], 0, $sp, 'utf-8').strip_tags($sw_arr[0]).mb_substr($body['title'], $sp, $tlen-$sp, 'utf-8');
				}
			}
		}
		return $body;
	}

	public static function confuse($body){

		//未开启
		$seoConfuseScale  = intval($GLOBALS['conf']['seoConfuseScale']);
		$title = $body['title'];
		$myNum = crypt::from62( substr( md5($title), 0, 3) );
		$ys = $myNum % 100;
		if($seoConfuseScale<$ys){
			return $body;
		}
		//print_r($body);
		//自动标题  autoTitle
		if($GLOBALS['conf']['autoTitle']==1){
			$temp_body = $body['body'];
			$temp_body = str_replace(array("。", "！", "：", "？", "，", "\n"), ",",  $temp_body);
			$temp_body = strip_tags(trim($temp_body));
			$temp_body = explode(",", $temp_body);
			$temp_body = array_filter($temp_body);

			$segment  = new segment();
			$temp_title = $segment->split_result($title);
			$temp_title = explode(" ", $temp_title);
			$temp_title = array_filter($temp_title);
			$y = 0;
			$z = 0;

			$new_body = array();
			foreach ($temp_body as $k => $v){
				if(mb_strlen($v, 'utf-8')>=10 && mb_strlen($v,'utf-8')<=30){
					$new_body[] = $v;
					$x = 0;
					foreach ($temp_title as $tit){
						if(strpos($v, $tit)){
							$x++;
						}
					}
					if($x > $y){
						$y = $x;
						$z = $k;
					}
				}
			}

			if($z>0){
				$body['title'] = $temp_body[$z];
			}else{
				if(!empty($new_body)){
					$new_body_count = count($new_body);
					$body['title'] = $new_body[$myNum%$new_body_count];
				}
			}
		}

		//段落重排
		if($GLOBALS['conf']['paragraphConfuse']==1 && $GLOBALS['conf']['phrasesConfuse']==0){
			$temp = preg_replace('/<(\/p|br[\s]*[\/]?)>/iU','<\\1>-|-',$body['body']);
			$s = explode('-|-',$temp);
			$arr = array();
			foreach ($s as $k =>$v){
				$arr[crypt::from62(substr( md5($v), 0, 3))] = $v;
			}
			ksort($arr);
			$body['body'] = implode(" ",$arr);
		}

		//语句重排
		if($GLOBALS['conf']['phrasesConfuse']==1){
			$str_body = str_replace(array("。", "！", "：", "？", "，", "\n"), ",", $body['body'] );
			$str_body =preg_replace("#(<p[^>]*>|</p>)#i", "", $str_body);
			$str_body = explode(",", $str_body);
			$str_body = array_filter($str_body);
			$str_body = array_values($str_body);
			$arr1 = array();
			foreach ($str_body as $k =>$v){
				$arr1[crypt::from62(substr( md5($v), 0, 3))] = $v;
			}
			ksort($arr1);
			foreach ($arr1 as $k =>$v){
				if($k%15==0){
					$arr1[crypt::from62(substr( md5($v), 0, 3))] = $v."。</p><p>";
				}elseif($k%5==0){
					$arr1[crypt::from62(substr( md5($v), 0, 3))] = $v."。";
				}else{
					$arr1[crypt::from62(substr( md5($v), 0, 3))] = $v."，" ;
				}
			}
			$str1 = implode(" ",$arr1);
			$str1 = strip_tags($str1, '<img>,<p>,<span>,<br>,<br/>,<b>,<strong>,<a>');
			$body['body'] = "<p>".$str1."</p>";
		}
		// print_r($body);
		return $body;
	}

}

class  spider{

	public static function spider_types(){
		return array(
			'Baiduspider' => '百度',
			'Googlebot' => '谷歌',
			'Sogou' => '搜狗',
			'Bingbot' => '必应',
			'Yisouspider' => '神马', 
			'HaoSouSpider' => '360搜索',
			);
	}

	public static  function write(){
		$url = get_url();
		$user_agent = $_SERVER['HTTP_USER_AGENT'];
		
		$rand = rand(0,1000);
		if($rand==0){
			$del_time = time()-3600*24*31;
			db::query("delete from spider where addtime < '$del_time' ");
		}
		$spider_types = spider::spider_types();
		foreach ($spider_types as $k => $v){
			$test = stripos($user_agent, $k)!==false;
			if($k == 'HaoSouSpider'){
				$test = $test || stripos($user_agent, '360Spider')!==false;
			}
			if($test){
				$now_time = time();
				$adddate = date('Ymd',time());
				db::query("insert into spider (url,spider,addtime,adddate) values ('$url','$k','$now_time','$adddate')");
				break;
			}
		}
	}
}

class topic{


	public static function checkPinyin($pinyin, $n=0){
		$pinyin_str = $n?$pinyin.'_'.(string)$n:$pinyin;
		$topic = db::find("select id from topic where pinyin='$pinyin_str'");
		if(!empty($topic)){
			return topic::checkPinyin($pinyin, $n+1);
		}
		return $pinyin_str;
	}

	public static function getAllWord($str){
		preg_match_all("#.#su", $str, $mt);
		$pinyin = join('',array_map(create_function('$data', '$pyclass = new pinyin(); 
			$py = $pyclass->getPinyin($data);
			if(isset($py[0])){
				return $py[0];
			}'), $mt[0]));
		$pinyin = str_replace(' ', '', $pinyin);
		return $pinyin;
	}
}

class zty{

	//获取文章内容
	public static function getNews($urlcache){
		$kid = $urlcache['kid'];
		$url = $urlcache['url'];
		$url_id = $urlcache['id'];

		db::query("update urlcache set status = 1 where id ='$url_id'");
		$result = httpUnit::get($url);
		if($result['httpcode']!=200){
			write_log("{$url}下载失败，状态码{$result['httpcode']}");
			return false;
		}
		$data = array();
		$result['html'] = preg_replace('/<!--.*-->/isU', '', $result['html']);
		$result['html'] = preg_replace('/<(script|style).*<\/\1>/isU', '', $result['html']);
		$data['data'] = $result['html'];
		if($result['charset']){
			$data['charset'] = $result['charset'];
		}

		$data['url'] = $url;
		$data['appid'] = $GLOBALS['conf']['appid'];
		$data['http_host'] = $_SERVER["HTTP_HOST"];
		$toUrl = REMOTEAPI."/dataapi/getNews";
		$res = httpUnit::json($toUrl, $data, $GLOBALS['conf']['appkey']);

		$res = zty::replace_word($res);
		$res = seo::seoword($res);
		$res = seo::confuse($res);
		$title = addslashes( trim( $res['title'] ) );
		$keywords = addslashes( $res['keywords'] );
		$description = addslashes( $res['description'] );
		
		if($res['body'] && mb_strlen($res['body'], 'utf-8')>60){
			$body = $res['body'];
			$body = zty::convert_images_patch($body);
			$body = zty::convert_url_patch($body);

			$thumb = zty::get_thumb($body); 
			$time = time();
			$body = addslashes( $body );
			if(db::find("select id from content where title='$title' ")){
				return $res;
			}
			$randclick = mt_rand(0, 100);
			db::query("insert into content
				(kid,title,keywords,description,url_id,thumb,addtime,updatetime,click)
				values 
				('$kid','$title','$keywords','$description','$url_id','$thumb','$time','$time','$randclick') ");
			$content_id = db::insert_id();
			db::query("insert into contentbody (content_id, body)
				values ('$content_id','$body')");

			$con_url = "";
			$topic  = db::find("select id,pid,pinyin from topic where id ='$kid'");
			$pid = $topic['pid'];
			if($pid==0){
				$con_url = "/".$topic['pinyin']."/".$content_id.".html";
			}else{
				$temp_topic = db::find("select id,pid,pinyin from topic where id='$pid'");
				$con_url ="/".$temp_topic['pinyin']."/".$topic['pinyin']."/".$content_id.".html";
			}

			db::query("update content set url='$con_url' where id ='$content_id'");
			$count = db::getfield("select count(*) from content  where  kid = '$kid'");

			if($count>=5){
				db::query("update topic set catchstatus=catchstatus|2 where id ='$kid'");
				$list = db::query("delete  from urlcache where status = 0 and kid ='$kid' ");
			}
			return $res;
		}
	}

	//根据关键词采集文章url
	public static function getNewsList($topic){
		$pid = $topic['pid'];
		$topic_id = $topic['id'];
		$time = time();
		$toUrl = "http://news.sogou.com/news?num=50&query=".urlencode($topic['title']);
		$resdata = httpUnit::get($toUrl);
		$html_content = mb_convert_encoding($resdata['html'], 'utf-8', 'gbk');
		if(preg_match("/<body[^>]*>(.*?)<div id=\"right\"/isU", $html_content, $mt)){
			$html_content = $mt[1];
		}
		$html_content = preg_replace('/<!--.*-->/isU', '', $html_content);
		$html_content = preg_replace('/<(script|style).*<\/\1>/isU', '', $html_content);
		$api_url = REMOTEAPI."/dataapi/urlcache";
		$data =array();
		$data['data'] = $html_content;
		$data['appid'] = $GLOBALS['conf']['appid'];
		$data['http_host'] = $_SERVER["HTTP_HOST"];
		$result = httpUnit::json($api_url, $data, $GLOBALS['conf']['appkey']);
		$list_url = $result['data'];
		$num = 0;
		if($list_url){
			foreach ($list_url as $key => $value) {
				$urlcache = db::find("select url  from urlcache where url ='$value'");
				if(empty($urlcache)){
					db::query("insert into urlcache(kid,url) values('$topic_id','$value')");
					$num++;
				}
			}
		}
		if($num==0){
			$url_cache = db::find("select * from urlcache where kid ='$topic_id' AND status=0 ");
			if(empty($url_cache)){
				db::query("update topic set catchstatus=catchstatus|2 where id ='$topic_id'");
			}
		}
		return $num;
	}

	//根据关键词抓取相关关键词
	public static function getRelaword($topic){

		$lockfile = DATA.DS.'temp'.DS.'sogou.lock';
		if(is_file($lockfile) && time() - filemtime($lockfile)<60){
			return;
		}
		$topic_id = $topic['id'];
		db::query("update topic set catchstatus=catchstatus|1 where id ='$topic_id'");
		$time = time();
		$toUrl = "http://www.sogou.com/web?num=100&sort=1&pid=sogou-site-f04cd7399b2b0128-2029&query=".urlencode($topic['title']);
		$resdata = httpUnit::sogou($toUrl);
		
		$html_content = $resdata['html'];
		$api_url = REMOTEAPI."/dataapi/Relaword";
		$html_content = preg_replace('#[\.\,\:\s\#a-z0-9-_]*\{[^\}]*\}#', '', $html_content);
		$html_content = preg_replace('/<(script|style).*<\/\1>/isU', '', $html_content);

		$data =array();
		$data['data'] = $html_content;
		$data['appid'] = $GLOBALS['conf']['appid'];
		$data['http_host'] = $_SERVER["HTTP_HOST"];
		
		$result = httpUnit::json($api_url, $data, $GLOBALS['conf']['appkey']);

		$topic_py = $topic['pinyin'];
		$keywordNum = 0;
		if($topic['pid']==0){
			if($result['keyword']){
				foreach ($result['keyword'] as $key => $value) {
					$temp_pinyin  = topic::getAllWord($value);
					$pinyin = topic::checkPinyin($temp_pinyin);
					$pyurl = '/'.$topic_py.'/'.$pinyin.'/';
					if($keywordNum<=3){
						$value_adds = addslashes($value);
						$temp_topic = db::find("select id from topic where title='$value_adds'");
						if(empty($temp_topic)){
							$keywordNum++;
							db::query("insert into topic (pid,title,pinyin,pyurl,addtime,click,flag,catchstatus,status) 
								values ('$topic_id','$value_adds','$pinyin','$pyurl','$time', 0, 0, 0, 0 ) ");
						}
					}
				}
			}
		}

		$topic_body = db::find("select * from topic_body where kid='$topic_id'");
		if(empty($topic_body)){
			db::query("insert into topic_body(kid,body,addtime) 
				values ('$topic_id','$result[description]','$time' ) ");
		}
		$baikeNum = 0;
		if($result['baike']){
			foreach ($result['baike'] as $key => $value) {
				$bk_url = "";
				if(strpos($value, "?")!==false){
					$bk_url = preg_replace('#\?.*?$#', '', $value);
				}else{
					$bk_url = $value;
				}
				$topic_baike = db::find("select * from topic_baike where bk_url ='$bk_url'");
				if(empty($topic_baike)){
					db::query("insert into topic_baike(kid,bk_url,addtime) 
						values ('$topic_id','$bk_url','$time' ) ");
				}
			}
		}
	}

	//采集百科内容
	public  static function baike($baike){
		$bk_url = $baike['bk_url'];
		$bk_id = $baike['id'];
		db::query("update topic_baike set status=0 where id='$bk_id'");
		$resdata = httpUnit::get($bk_url);
		$html_content = $resdata['html'];
		$html_content = preg_replace('/<(script|style).*<\/\1>/isU', '', $html_content);
		$html_content = preg_replace('/<!--.*?-->/is', '', $html_content);
		$data= array();
		if(strrpos($bk_url, "sogou")!==false){
			$data['type'] = "sogou";
		}
		if(strrpos($bk_url, "baidu")!==false){
			$data['type'] = "baidu";
		}
		$data['data'] = $html_content;
		$data['appid'] = $GLOBALS['conf']['appid'];
		$data['http_host'] = $_SERVER["HTTP_HOST"];
		$toUrl = REMOTEAPI."/dataapi/baike"; 
		$resdata = httpUnit::post($toUrl, $data, $GLOBALS['conf']['appkey']);
		$result = json_decode($resdata['html'],true);
		if(!$result){
			controller::page_503();
			$errStr = "接口通信错误！";
			if($GLOBALS['debug']){
				$errStr .= "<p>".var_dump($resdata)."</p>";
			}
			throw new Exception($errStr);
		}elseif($result['status']!=1){
			controller::page_503();
			throw new Exception($result['errMsg']);
		}
		$title = addslashes($result['title']);
		$content = addslashes($result['data']);
		if( mb_strlen($title, 'utf-8')>5 && mb_strlen($content, 'utf-8')>20 ){
			db::query("update topic_baike set bk_title ='$title',bk_content='$content' where id='$bk_id'");
		}else{
			db::query("delete from topic_baike where id='$bk_id'");
		}
		return $result;
	}

	public static function getWenwenList($topic){
		$topic_id = $topic['id'];
		$times = time();
		$toUrl="http://wenwen.sogou.com/s/?w=".urlencode($topic['title']);
		$resdata = httpUnit::post($toUrl, null, null, array('ssuid'=>2000000000 + mt_rand(0,1000)));
		$html_content = $resdata['html'];
		$api_url = REMOTEAPI."/dataapi/getWenwenList"; 
		$data['data'] = $html_content;
		$data['appid'] = $GLOBALS['conf']['appid'];
		$data['http_host'] = $_SERVER["HTTP_HOST"];
		$result = httpUnit::json($api_url, $data, $GLOBALS['conf']['appkey']);
		
		if(empty($result['data'])){
			db::query("update topic set catchstatus=catchstatus|8 where id ='$topic_id'");
			return 0;
		}
		$num = 0;
		foreach ($result['data'] as $key => $value){
			$url = "http://wenwen.sogou.com".$value['url'];
			$title = addslashes( $value['title'] );
			$ww = db::find("select * from topic_wenwen where ww_url = '$url' and kid = '$topic_id' ");
			if(empty($ww)){
				$bk_url = "";
				if(strpos($url, "?")!==false){
					$bk_url = preg_replace('#\?.*?$#', '', $url);
				}else{
					$bk_url = $url;
				}
				if(mb_strlen($title, 'utf-8')>5){
					db::query("insert into topic_wenwen(kid,ww_url,ww_title,addtime) values('$topic_id','$bk_url','$title','$times')");
				}
				$num++;
			}
			if($num>4){
				break;
			}
		}
		return $num;
	}

	public static function getWenwen($wenwen){
		$ww_url = $wenwen['ww_url'];
		$ww_id = $wenwen['id'];
		$result ="";
		db::query("update topic_wenwen set status=0 where  id = '$ww_id' ");
		preg_match('#/z/q([0-9]*)\.htm#', $ww_url, $mt);
		if(substr($mt[1], 0, 3)=='300'){
			$id = substr($mt[1],3, 10);
			$url = "http://wenwen.sogou.com/world/ajax/app/recanswerlist?id=".$id;
			$result =  json_decode(file_get_contents($url),true );
			$content  = $result['data']['answerList'][0]['content'];
			db::query("update topic_wenwen set ww_content = '$content' where  id = '$ww_id' ");
		}else{
			$resdata = httpUnit::get($ww_url);
			$html_content = $resdata['html'];
			$html_content = preg_replace('/<(script|style).*<\/\1>/isU', '', $html_content);
			$html_content = preg_replace('/<!--.*?-->/is', '', $html_content);
			$data= array();
			$data['data'] = $html_content;
			$data['appid'] = $GLOBALS['conf']['appid'];
			$data['http_host'] = $_SERVER["HTTP_HOST"];
			$toUrl = REMOTEAPI."/dataapi/getWenwen"; 
			$result = httpUnit::json($toUrl, $data, $GLOBALS['conf']['appkey']);

			$title = $result['title'];
			$content = addslashes($result['content']);
			if(mb_strlen($title, 'utf-8')>5 && mb_strlen($content, 'utf-8')>20){
				db::query("update topic_wenwen set ww_title='$title',ww_content = '$content'  where  id = '$ww_id' ");
			}else{
				db::query("delete from topic_wenwen where id='$ww_id' ");
			}
		}
		$data['status'] = 1;
	}

	public static function weibo($topic){
		db::query("update topic set catchstatus=catchstatus|4 where id ='$topic[id]'");
		$respond = httpUnit::get('https://www.baidu.com/s?rtt=2&tn=baiduwb&rn=20&cl=2&wd='.urlencode($topic['title']));
		$html_content = preg_replace('/<(script|style).*<\/\1>/isU', '', $respond['html']);
		$html_content = preg_replace('/<!--.*?-->/is', '', $html_content);
		$data['data'] = $html_content;
		if($topic['pid']==0){
			$data['keyword'] = $topic['title'];
		}
		$data['appid'] = $GLOBALS['conf']['appid'];
		$data['http_host'] = $_SERVER["HTTP_HOST"];
		$api_url = REMOTEAPI."/dataapi/weibo";
		$res =  httpUnit::json($api_url, $data, $GLOBALS['conf']['appkey']);
		
		$flag = false;
		if($res['data']){
			$temp_wb = addslashes( serialize($res['data']) );
			db::query("update topic_body set weibo='$temp_wb' where kid ='$topic[id]'");
			$flag = true;
		}
		$negative = "";
		$positive = "";
		if($res['negative']){
			$negative = $res['negative'];
			$positive = $res['positive'];
		}
		db::query("update topic set negative = '$negative' , positive= '$positive' where id ='$topic[id]'");
		return $flag;
	}

	public static function convert_images_url_path($url){
		$img_ext = pathinfo($url, PATHINFO_EXTENSION);
		$md5 = md5($url);
		$md51 = substr($md5, 0,2);
		$md52 = substr($md5, 2,2);
		$md53 = substr($md5, 10,16);
		$hash = $md51.$md52.$md53;
		if(in_array($img_ext, array('jpg', 'jpeg', 'png', 'gif'))){
			$img_ext = ".".$img_ext;
		}elseif($img_ext==''){
			$img_ext = ".img";
		}else{
			return "";
		}
		$str_img = "/uploads/attachment/".$md51."/".$md52."/".$md53.$img_ext;
		if(!is_file(ROOT.$str_img)){
			$imgcon = db::find("select * from attachment where hash='$hash'");
			if(empty($imgcon)){
				$now_time = time();
				db::query("insert into attachment (hash,url,addtime)
					values ('$hash','$url','$now_time')");
			}
		}
		return $str_img;
	}

	public static function convert_url_patch($body){
		return preg_replace_callback('/\[url=([^\]]*)\](.*?)\[\/url\]/is', create_function('$data', 'return $data[2];'), $body);
	}

	//转换文章内图片地址
	public static function convert_images_patch($body, $alt=''){
		$body = preg_replace_callback('/\[img\]([^\]]*)\[\/img\]/is', create_function('$data', 'if($GLOBALS[\'conf\'][\'downPicture\']==1){
			$str_img = zty::convert_images_url_path($data[1]);
			if($str_img){
				return "<img src=\"{#attachmentPath#}{$str_img}\" alt=\"@img#alt@\">";
			}else{
				return "";
			}
		}elseif($GLOBALS[\'conf\'][\'downPicture\']==2){
			return "<img src=\"{$data[1]}\" alt=\"@img#alt@\">";
		}else{
			return "";
		}'), $body);
		$body= str_replace('@img#alt@', $alt, $body);
		return $body;
	}

	//获取附件主机名
	public static function get_attachment_host(){
		static $imghost;
		if(!isset($imghost)){
			$imghost = "";
			$imgurl = db::find("select * from storageservice where status = 1 AND url!=''");
			if($imgurl){
				$imghost = "http://".$imgurl['url'];
			}
		}
		return $imghost;
	}

	//接受数组参数
	public static function replace_word($body){
		static $list_rword;
		if(empty($list_rword)){
			$list_rword = db::select("select * from reword");
			foreach ($list_rword as &$v) {
				$v['oldword'] = urldecode( trim( json_encode( urlencode( $v['oldword']) ), '"') );
				$v['newword'] = urldecode( trim( json_encode( urlencode( $v['newword']) ), '"') );
			}
		}

		$GLOBALS['protecttag'] = array();
		$body = preg_replace_callback('#<a.*?>.*?</a>|<img.*?>|\[img\].*?\[/img\]|\[url\].*?\[/url\]#is', create_function('$data', '$key = substr(md5($data[0]), 10, 16);
			$GLOBALS[\'protecttag\'][$key] = $data[0];
			return \'~\'.$key.\'~\';'), $body);


		foreach($list_rword as $r){
			if($r['type']==1){
				$body = str_replace($r['oldword'], $r['newword'], $body);
			}elseif($r['type']==2){
				$body = str_replace($r['oldword'], '#@replace@#', $body);
				$body = str_replace($r['newword'], $r['oldword'], $body);
				$body = str_replace('#@replace@#', $r['newword'], $body);
			}
		}
		//释放保护
		$body = preg_replace_callback('#~([a-z0-9]{16})~#is', create_function('$data', 'if(isset($GLOBALS[\'protecttag\'][$data[1]])){
			return $GLOBALS[\'protecttag\'][$data[1]];
		}
		return $data[0];'), $body);
		return $body;
	}


	public static function get_thumb($body){
		if(preg_match("/src=\"(.*?)\"/", $body, $match)){
			return str_replace('{#attachmentPath#}', '', $match[1]);
		}
		return '';
	}

}