<?php
define('IN_SYS', true);
header("Content-Type: text/html; charset=utf-8");
$step = empty($_POST["step"])?'step1':$_POST["step"];
$filename = dirname(__FILE__)."/data/config.php";
if (file_exists($filename)) { 
	echo "您已经安装过该系统，如需重新安装请删掉".$filename."下的配置文件config.php";
	exit;
} 
if($step=="ajax"){
	$dhost = $_POST['dbhost'];
	$duser = $_POST['username'];
	$dpwd =  $_POST['pwd'];
	$dbname = $_POST['dbname'];
	$hostinfo = explode(":", $dhost);
	$dhost = $hostinfo[0];
	$port = isset($hostinfo[1])?$hostinfo[1]:3306;
	$conn = @mysqli_connect($dhost, $duser, $dpwd, null, $port);
	$status = 0;
	$msg ="";
	if($conn){
		$result = @mysqli_select_db($conn, $dbname );
		if(!$result){
			$msg ="数据库连接成功，正在为你创建数据库！";
			$status = 2;
		}else{
			$msg ="你的数据库已经存在，是否要覆盖，不覆盖的请取消安装！";
			$status = 3;
		}
	}else{
		$msg ="数据库连接失败";
	}
	$data = array();
	$data['status']=$status;
	$data['msg'] =$msg;
	print_r(json_encode($data));
	exit;
}

?>
<!DOCTYPE html>
<html>
<head>
	<meta charset='utf-8' />
	<title>专题易安装程序</title>
	<link type="text/css" rel="stylesheet" href="/static/css/reset.css" />
	<script  src="/static/js/jquery.js"></script>
	<script type="text/javascript">
		function checkTest(){
			if($("#dbhost").val()!="" && $("#username").val()!="" && $("#pwd").val()!="" && $("#dbname").val()!=""){
				$.ajax({
					url: "install.php",
					type:"POST",
					data: {step:"ajax",dbhost:$("#dbhost").val(),username:$("#username").val(),pwd:$("#pwd").val(),dbname:$("#dbname").val()},
					dataType: "json",
					success: function(data){
						if(data['status']==0){
							$("#msg1").text(data['msg']);
						}else if(data['status']==3){
							if(confirm(data['msg']+"?")){
								document.form1.submit();
							}
						}else{
							$("#msg").text("");
							document.form1.submit();
						}
					}
				});
			}else{
				$("#msg").text("数据库主机,数据库用户,数据库密码,数据库名称必填");
			}
			return false;
		}

		function uncheck(){
			var obj = document.getElementsByName("boxname");
			if(obj[0].checked){	
				$('#btn').attr('disabled',false);
			}else{
				$('#btn').attr('disabled',true);
			}
		}

		function defaultval(){
			alert(1);
			location.herf="install.php";
		}
		function checkBox(){
			$('#btn').attr('disabled',true);
		}

	</script>
	<style type="text/css">
		input[type=submit],input[type=button]{ background: #0698e4; border:none; border-radius: 3px; color: #FFF; cursor: pointer;  }
		input[type=submit]:hover,input[type=button]:hover{ background-color: #0288cd; }
		input[type=submit]:disabled,input[type=button]:disabled{ background: #aaa; }
		.fontcolor {
			color: #0288D0;
			font-size: 18px;
			background: url(/static/images/i.png) no-repeat 153px 10px;
		}
		.menu{ padding-right: 30px; margin-right: -10px; }
		.tab,.tab1 {
			font-size: 12px;
			width: 600px;
			border: 1px solid #ececec;
		}
		.tab td,th {
			line-height: 30px;
			width: 100px;
			border-bottom: 1px solid #ececec;
			text-align: center;
		}
		.tab1 td {
			line-height: 30px;
			border-bottom: 1px solid #ececec;
			padding-left: 20px;
		}
		li{float:left; padding:5px;}
	</style>
</head>
<body onload="checkBox()">
	<div style="width: 950px; margin: 0 auto;">

		<div style="height:60px;border-bottom:1px solid #ccc; padding:10px;clear:both">
			<div style="float:left;padding:10px 50px 0;font-size:28px;color: #0288cd;">
				Easy 专题易
			</div>
			<div  style="float:right;">
				<ul>
					<li><a href="http://www.zhuantiyi.com" target="_blank">网站官网</a></li>
					<li><a href="http://www.zhuantiyi.com/help" target="_blank">帮助中心</a></li>
				</ul>
			</div>
		</div>

		<div style="margin-top: 50px;" class="cl">
			<div class="fl" style="width:160px; height: 280px; font-size: 14px; border-right: solid 1px #ddd; text-align: right;color:#666; line-height:30px;">
				<div style="border-bottom: solid 1px #ddd; font-size: 18px; line-height: 40px; margin-bottom: 20px; padding-right:20px; ">安装步骤</div>
				<div class="menu <?php if($step=="step1"){echo "fontcolor";}?> ">许可协议</div>
				<div class="menu <?php if($step=="step2"){echo "fontcolor";}?> ">环境检测</div>
				<div class="menu <?php if($step=="step3"){echo "fontcolor";}?> " onclick="checkTest()">参数配置</div>
				<div class="menu <?php if($step=="step4"){echo "fontcolor";}?> ">完成安装</div>

			</div>
			<div class="fr" style="width:760px;"><?php if($step=="step1"){
				?>
				<div class="step1">
					<form action="install.php" method="post">
						<div id="lisence" style="color:#888; font-size: 16px;line-height: 30px;"></div> 
						<div style="padding-top:10px;">
							<input type="hidden" value="step2" name="step" /> 
							<label>
								<input type="checkbox" name="boxname" id="boxname" value="1"  onclick="uncheck()"/>
								我已经阅读并同意此协议
							</label>
							&nbsp;&nbsp;
							<input type="submit" value="继续" id="btn" />
						</div>
					</form>
				</div>
				<script>
					$.getJSON("http://api.zhuantiyi.com/lisence/get?callback=?", function(data){
						$("#lisence").html(data);
					});
				</script>
				<?php 
			}elseif($step=="step2"){
				function TestWrite($d)
				{
					$tfile = '_dedet.txt';
					$d = preg_replace("#\/$#", '', $d);
					$fp = @fopen($d.'/'.$tfile,'w');
					if(!$fp) return false;
					else
					{
						fclose($fp);
						$rs = @unlink($d.'/'.$tfile);
						if($rs) return true;
						else return false;
					}
				}

				$phpv = phpversion();
				if(version_compare(PHP_VERSION, '5.2.0', '<')){
					$phpv = "<font color=red>{$phpv} （必须5.2或以上版本）</font>";
				}
				$sp_os = PHP_OS;
				$sp_server = $_SERVER['SERVER_SOFTWARE'];
				$sp_name = $_SERVER['SERVER_NAME'];
				$upload =  TestWrite(dirname(__FILE__).'/uploads');
				$data =  TestWrite(dirname(__FILE__).'/data');
				?>
				<form action="install.php" method="post">
					<div style="line-height: 30px; padding:10px;">
						<div>
							<h1>服务器信息</h1>
						</div>
						<div>服务器域名：<?php echo $sp_name;?></div>
						<div>服务器操作系统：<?php echo $sp_os; ?></div>
						<div>服务器解译引擎：<?php echo $sp_server; ?></div>
						<div>PHP版本：<?php echo  $phpv;?></div>
						<div>系统安装目录：<?php echo dirname(__FILE__); ?></div>
						<div>
							<h1>环境检测</h1>
						</div>
						<div>curl扩展：<?php echo function_exists('curl_init')?'已开启':'<font color="red">未开启</font>' ?></div>
						<div>mb_string扩展：<?php echo function_exists('mb_substr')?'已开启':'<font color="red">未开启</font>' ?></div>
						<div>mysqli扩展：<?php echo function_exists('mysqli_connect')?'已开启':'<font color="red">未开启</font>' ?></div>
						<div>
							<h1>目录权限检测</h1>
						</div>
						<div>系统要求必须满足下列所有的目录权限全部可读写的需求才能使用，其它应用目录可安装后在管理后台检测。</div>
						<table class="tab" cellpadding="0" cellspacing="0">
							<tr>
								<th>目录名</th>
								<th>读取权限</th>
								<th>写入权限</th>
							</tr>
							<tr>
								<td>/uploads</td>
								<td>可读</td>
								<td><?php  if($upload==1){ echo "可写";}else{echo "<span style='color:red;font-size:16px;' >不可写</span>";}?></td>
							</tr>
							<tr>
								<td>/data</td>
								<td>可读</td>
								<td><?php if($data==1){ echo "可写";}else{echo "<span style='color:red;font-size:16px;' >不可写</span>";}?></td>
							</tr>
						</table>
						<div style="padding-top:10px;">
							<input type="hidden" value="step3" name="step" />
							<input type="button" onClick="window.location.href='install.php';" value="返回上一步" /> 
							&nbsp;&nbsp;
							<?php if($upload==0 || $data==0){?>
								<span style='color:red;font-size:16px;' >没有写入权限，请修改权限后安装！</span>
								<?php }elseif(version_compare(PHP_VERSION, '5.2.0', '<') || !function_exists('curl_init') || !function_exists('mb_substr') || !function_exists('mysqli_connect')){ ?>
									<span style='color:red;font-size:16px;' >环境不满足安装条件！</span>
									<?php }else{ ?>
										<input type="submit" value="下一步" />
										<?php } ?>
									</div>
								</div>
							</form>
							<?php 
						}elseif($step=="step3"){
							?>
							<div style="line-height: 30px; ">
								<form name="form1" action="install.php" method="post" onsubmit="return checkTest();">
									<div><h1>数据库设定</h1></div>
									<table class="tab1" cellpadding="0" cellspacing="0" border="0">
										<tr>
											<td>数据库主机：<input name="dbhost" id="dbhost" type="text" value="127.0.0.1" /> <small>一般为localhost或127.0.0.1</small></td>
										</tr>
										<tr>
											<td>数据库用户：<input name="username" id="username" type="text"/></td>
										</tr>
										<tr>
											<td>数据库密码：<input name="pwd" id="pwd" type="password"/></td>
										</tr>
										<tr>
											<td>数据库名称：<input name="dbname" id="dbname" type="text"/></td>
										</tr>
									</table>
									<div id="msg" style="color:red;"></div>
									<div id="msg1" style="color:red;"></div>
									<div><h1>管理员初始密码</h1></div>
									<table class="tab1" cellpadding="0" cellspacing="0">
										<tr>
											<td>用户名：</td>
											<td><input name="adminname" type="text"/></td>
										</tr>
										<tr>
											<td>密 码：</td>
											<td><input name="adminpwd" type="text"/></td>
										</tr>
									</table>
									<div style="padding-top:10px;">
										<input type="hidden" value="step4" name="step" /> 
										<input type="button" onclick="window.history.back();" value="返回上一步" /> 
										<input type="submit" value="继续"  />
									</div>

								</form>
							</div>
							<?php 
						}elseif($step=="step4"){
							$dbhost = $_POST['dbhost'];
							$dbuser = $_POST['username'];
							$dbpassword =  $_POST['pwd'];
							$dbname =  $_POST['dbname'];
							$admin_name = $_POST['adminname'];
							$admin_pwd = $_POST['adminpwd'];
							$hostinfo = explode(":", $dbhost);
							$db_host = $hostinfo[0];
							$port = isset($hostinfo[1])?$hostinfo[1]:3306;
							$conn = mysqli_connect($db_host, $dbuser, $dbpassword, null, $port);
							$result = mysqli_select_db($conn, $dbname );
							mysqli_query($conn, "SET character_set_connection='utf8',character_set_results='utf8',character_set_client=binary,sql_mode=''");
							if(!$result){
								mysqli_query($conn,"create database  ".$dbname);
								mysqli_select_db($conn, $dbname );
							}
							$sqls = file_get_contents(dirname(__FILE__).'/data/install.sql');
							$sqls = str_replace('USING BTREE', '', $sqls);
							$sqls = preg_replace("/[\r\n]{1,}/","\n",$sqls);
							$sql_arr = preg_split("#;[ \t]{0,}\n#", $sqls);
							foreach ($sql_arr as $sql){
								$sql = trim($sql);
								if($sql!='' && substr($sql, 0, 2)!='--'){
									mysqli_query($conn, $sql);
								}
							}
							$rand = rand(1000,9999);
							$adminpwd = md5($admin_name.md5($admin_pwd).$rand);

							mysqli_query($conn,"insert into admin (username,password,salt) values ('$admin_name','$adminpwd',$rand)");
							$myfile = fopen(dirname(__FILE__)."/data/config.php", "w") or die("无法写入配置文件!");
							$num = "";
							for($i=1;$i<=10;$i++){
								$num .= chr(mt_rand(33, 126));
							}
							$num = addslashes( $num );
							$txt = "<?php\n//数据库服务器连接地址\n\$dbhost = '{$dbhost}';\n//数据库名\n\$dbname = '{$dbname}';\n//数据库用户名\n\$dbuser = '{$dbuser}';\n//数据库密码\n\$dbpassword = '{$dbpassword}';\n// 调试模式，开发阶段设置为false，网站上线运行设置为false\n\$debug = false;\n// 加密随机字符串\n\$auth_key = '{$num}';";
							fwrite($myfile, $txt);
							fclose($myfile);
							?>
							<div style="height: 150px; line-height:30px; padding:10px;">
								<div>恭喜您，网站安装成功！</div>
								<div>
									<input type="button" onclick="window.location.href='/admin';" value="立即登陆" /> 
								</div>
							</div>
							<?php }?>

						</div>
					</div>
				</div>
			</body>
			</html>
