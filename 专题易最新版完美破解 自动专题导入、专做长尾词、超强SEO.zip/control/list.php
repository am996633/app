<?php

/**
 * @version    $Id: list.php 169 2016-07-11 10:09:33Z qinjinpeng $
 */

class list_controller extends controller{

	public  $nav = array();
	public function __construct(){
		parent::__construct();
		spider::write();
	}
	public function index(){
		$this->loadlist(1);
	}

	public function _empty(){
		$url = $this->rest_uri;
		$avgs = explode('/', $url);
		if(preg_match("#list_(\d*).html#si", $avgs[1],$mt)){
			$page = $mt[1];
		}else{
			$this->page_404();
		}
		$this->loadlist($page);
	}

	private function loadlist($page){
		$hd_nav = "list";
		$pg = new page("select * from topic  where pid = 0 and flag = 1 and status = 1 order by id desc");
		$pg->page = $page;
		$list = $pg->get_list(8);
		foreach ($list as $key => $value) {
			$list[$key]['list_article'] = db::select("select * from content where kid ='$value[id]' and status = 1  limit 5");
			usort($list[$key]['list_article'], create_function('$a, $b', 'return strlen($a[\'thumb\'])<strlen($b[\'thumb\']);') );
			foreach ($list[$key]['list_article'] as &$art) {
				$art['thumb'] = empty($art['thumb'])?'/static/images/default.png':$art['thumb'];
			}
		}
		$page = $pg->get_page("/list/list_{page}.html");
		$list_hot = db::select("select * from topic where pid = 0 and flag = 1 and status = 1 order by click desc limit 20");

		$topic_max_id = db::getfield("select id from topic order by id desc");
		$topic_rand_id = max(10, mt_rand($topic_max_id-1000, $topic_max_id));
		$list_rand = db::select("select * from topic where pid = 0 and flag = 1 and status = 1 AND id<$topic_rand_id order by topic.id desc limit 20");
		require $this->tpl('list');
	}
}

