<?php

/**
 * @version    $Id: question.php 221 2016-07-18 10:33:16Z qinjinpeng $
 */

class question_controller extends controller{

	public $nav =  array();
	public function __construct(){
		parent::__construct();
		spider::write();
	}

	public function index(){
		$page = 1;
		$this->loadlist($page);
	}

	public function _empty(){
		$url = $this->rest_uri;
		$avgs = explode('/', $url);
		if(preg_match("#list_(\d*).html#si", $avgs[1], $mt)){
			$page = $mt[1];
			$this->loadlist($page);
		}else{
			$this->page_404();
		}
	}

	private function loadlist($page){
		$hd_nav = "question";
		$pg = new page("select tk.*,tc.pyurl as url from topic_wenwen as tk left join topic as tc on tk.kid = tc.id WHERE tk.status=1 order by tk.id desc");
		$pg->page = $page;
		$list = $pg->get_list(10);
		$page = $pg->get_page("/question/list_{page}.html");
		$ww_hot = db::select("select tk.*,tc.pyurl as url from topic_wenwen as tk left join topic as tc on tk.kid = tc.id WHERE tk.status=1 order by tk.click desc limit 10");
		$ww_max_id = db::getfield("select id from topic_wenwen order by id desc");
		$ww_rand_id = max(10, mt_rand($ww_max_id-1000, $ww_max_id));
		$ww_rand = db::select("select tk.*,tc.pyurl as url from topic_wenwen as tk left join topic as tc on tk.kid = tc.id WHERE tk.status=1 AND tk.id<$ww_rand_id order by tk.id desc limit 10 ");
		require $this->tpl('question_list');
	}
}

