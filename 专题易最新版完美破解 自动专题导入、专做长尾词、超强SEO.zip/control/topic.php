<?php

/**
 * @version    $Id: category.php 433 2016-05-11 10:13:23Z qinjinpeng $
 */

class topic_controller extends controller{

	public $nav = array(), $left_arrow = array(), $right_arrow = array();

	public function __construct(){
		parent::__construct();
		spider::write();
	}

	public function _empty(){
		switch ($_SERVER['REQUEST_URI']) {
			case '/sitemap.xml':
			$this->sitemap();
			break;
			default:
			$this->display();
			break;
		} 
	}
	
	public function sitemap(){
		if($this->conf['sitemap']==1){
			header("Content-Type:text/xml");
			$topic_list = db::select("select * from topic where flag = 1 order by id desc limit 500");
			$str ='<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">';
			$str_list ="";
			foreach ($topic_list as $key => $value) {
				$str_list .="<url>
				<loc>http://".$this->conf['webHost'].$value['pyurl']."</loc>
				<lastmod>".date('Y-m-d',$value['addtime'])."</lastmod>
				<changefreq>daily</changefreq>
				<priority>0.9</priority>\n</url>";
			}
			echo $str.$str_list."</urlset>";
		}else{
			$this->page_404();
		}
	}
	
	public function display(){
		$url = $this->rest_uri;
		$avgs = explode('/', $url);
		$index_url = $avgs[0];
		if(isset($avgs[1])){
			//百科页面
			if(preg_match("#(.*?)_\d*.html#si", $url,$mt)){
				if(strpos($mt[1], "baike")!==false){
					$this->baike_view();
				}elseif(strpos($mt[1], "question")!==false){
					$this->question_view();
				}elseif(strpos($mt[1], "info")!==false){
					$this->topic_info();
				}else{
					$this->page_404();
				}
			}else{
				//文章内容
				if(preg_match("#(\d*).html#si", $avgs[1], $mt)){
					$this->article_view($mt[1]);
				}elseif(isset($avgs[2])){
					if(preg_match("#(\d*).html#si", $avgs[2], $mt)){
						$this->article_view($mt[1]);
					}else{
						$this->page_404("您访问的页面不存在");
					}
				}else{
					//二级词页面
					$this->topic_child();
				}
			}
		}else{
			//主词页面
			$this->topic_index($index_url);
		}
	}

	public function topic_index($py){
		$topic = db::find("select * from topic where pinyin ='$py' and pid = 0");
		if(empty($topic)){
			$this->page_404();
		}else{
			$aid = $topic['id'];
			db::query("update topic set click = click +1 where id = '$aid'");
			$pid = $topic['pid'];
			$current = $py;
			$index_url = $py;
			$topic['negative'] = $topic['negative']*100;
			$topic['positive'] = $topic['positive']*100;
			$list_baike = db::select("select * from topic_baike where kid ='$aid' AND status=1");
			$this->nav = db::select("select * from topic where pid ='$aid' and status = 1 ");
			$topics = array();
			foreach ($this->nav as $key => $value){
				$cid  = $value['id'];
				$topics[$key] = $value;
				$topics[$key]['arclist'] = db::select("select * from content where kid = '$value[id]'");
			}
			$topic_body = db::find("select * from topic_body where kid ='$aid'");
			$list_weibo = array();
			if($topic_body['weibo']){
				$list_weibo = unserialize($topic_body['weibo']);
			}
			$list = db::select("select *,ct.id as cid from content as ct left join contentbody as cy 
				on ct.id = cy.content_id  where ct.kid = '$aid' order by ct.id desc");
			
			$list_wenwen = db::select("select * from topic_wenwen where kid ='$aid' AND status=1");
			$topic_child_list = db::select("select * from topic where pid = '$aid' ");
			$child_id = "";
			foreach ($topic_child_list as $key => $value) {

				if($key==0){
					$child_id .=$value['id'];
				}else{
					$child_id .=",".$value['id'];
				}
			}
			if(empty($child_id)){
				$child_id = $aid;
			}
			$slidelist = db::select("select * from content where kid in( $child_id) and thumb <> ''  limit 5 ");
			$this->lr_arrow($topic['id']);
			require $this->tpl('topic');
		}
	}

	public function topic_child(){
		$avgs = explode('/', $this->rest_uri);
		$topic = db::find("select * from topic where pinyin ='$avgs[0]'");
		if(empty($topic)){
			$this->page_404();
		}
		$topic_child = db::find("select * from topic where pinyin ='$avgs[1]' and pid = '$topic[id]'");
		db::query("update topic set click = click +1 where id = '$topic_child[id]'");
		if(empty($topic) || empty($topic_child)){
			$this->page_404();
		}else{
			$topic_child['negative'] = $topic_child['negative']*100;
			$topic_child['positive'] = $topic_child['positive']*100;
			$index_url = $avgs[0];
			$current = $avgs[1];
			$list = db::select("select *,ct.id as cid from content as ct left join contentbody as cy 
				on ct.id = cy.content_id  where ct.kid = '$topic_child[id]' order by ct.id desc");

			$topic_body = db::find("select * from topic_body where  kid = '$topic_child[id]'");
			$list_weibo = array();
			if($topic_body['weibo']){
				$list_weibo = unserialize($topic_body['weibo']);
			}

			$list_wenwen = db::select("select * from topic_wenwen where kid ='$topic_child[id]' AND status=1");
			$list_baike = db::select("select * from topic_baike where kid ='$topic_child[id]' AND status=1");
			$this->nav = db::select("select * from topic where pid ='$topic[id]' and status = 1 ");
			$this->lr_arrow($topic['id']);
			require $this->tpl('topic_child');
		}
	}

	public function article_view($aid){
		$url  = "/".$this->rest_uri;
		$avgs = explode('/', $this->rest_uri);
		$page = db::find("select * from content as ct left join contentbody as cy 
			on ct.id = cy.content_id  where ct.url = '$url'");

		$xg_list = db::select("select * from content limit 5 ");
		$ys_list = db::select("select * from content  order by click desc limit 5");
		if(empty($page)){
			$this->page_404();
		}

		$page['body'] = str_replace('{#attachmentPath#}', zty::get_attachment_host(), $page['body']);
		
		$topic = db::find("select * from topic where pinyin ='$avgs[0]'");
		db::query("update content  set click = click+1 where id = '$aid'");
		$index_url = $avgs[0];
		if(isset($avgs[2])){
			$current = $avgs[1];
			$topic_child = db::find("select * from topic where pinyin ='$avgs[1]'");
			$this->nav = db::select("select * from topic where pid ='$topic_child[pid]' and status = 1 ");
		}else{
			$current = $avgs[0];
			$this->nav = db::select("select * from topic where pid ='$topic[id]' and status = 1 ");
		}

		$list_hot = db::select("select * from content where status = 1 order by click desc limit 9");
		$list_new = db::select("select * from content where status = 1 order by id desc limit 9");

		require $this->tpl('article_view');
	}

	public function baike_view(){
		$avgs = explode('/', $this->rest_uri);
		$data = $this->page_check("baike");
		$temp_topic = $data['temp_topic'];
		$topic = $data['topic'];

		$bk = db::find("select * from topic_baike where id = '$data[mt]' and kid = '$temp_topic[id]'");

		if($bk){
			$list_baike = db::select("select * from topic_baike where kid ='$bk[kid]'");
			if($temp_topic['pid'] ==0){
				$current = $avgs[0];
				$nav_id = $temp_topic['id'];
			}else{
				$current = $avgs[1];
				$nav_id = $temp_topic['pid'];
			}
			$this->nav = db::select("select * from topic where pid ='$nav_id'");
			require $this->tpl('baike_view');
		}else{
			$this->page_404();
		}
	}

	public function question_view(){
		$avgs = explode('/', $this->rest_uri);
		$data = $this->page_check("question");
		$temp_topic = $data['temp_topic'];
		
		$topic = $data['topic'];
		$ww = db::find("select * from topic_wenwen where id = '$data[mt]' and kid = '$temp_topic[id]'");
		if(empty($ww)){
			$this->page_404();
		}
		db::query("update topic_wenwen set click=click+1 where id = '$data[mt]'");
		$list_wenwen = db::select("select * from topic_wenwen where kid ='$temp_topic[id]'");
		if($temp_topic['pid'] ==0){
			$current = $avgs[0];
			$nav_id = $temp_topic['id'];
		}else{
			$current = $avgs[1];
			$nav_id = $temp_topic['pid'];
		}
		$this->nav = db::select("select * from topic where pid ='$nav_id'");
		require $this->tpl('question_view');
	}

	public function topic_info(){
		$avgs = explode('/', $this->rest_uri);
		$data = $this->page_check("info");
		$temp_topic = $data['temp_topic'];
		$topic = $data['topic'];
		$page = db::find("select * from topic_body where id ='$data[mt]' and kid = '$temp_topic[id]'");
		if(empty($page)){
			$this->page_404();	
		}
		
		if($temp_topic['pid'] ==0){
			$current = $avgs[0];
			$nav_id = $temp_topic['id'];
		}else{
			$current = $avgs[1];
			$nav_id = $temp_topic['pid'];
		}
		$list_hot = db::select("select * from content where status = 1 order by click desc limit 9");
		$list_new = db::select("select * from content where status = 1 order by id desc limit 9");

		$this->nav = db::select("select * from topic where pid ='$nav_id'");
		require $this->tpl('topic_info');
	}

	public function page_check($type){
		$url  = "/".$this->rest_uri;
		$avgs = explode('/', $this->rest_uri);
		$topic = db::find("select * from topic where pinyin ='$avgs[0]'");
		$mt_id = 0;
		if(isset($avgs[2])){
			$nav_url = "/".$avgs[0]."/".$avgs[1]."/";
			if (preg_match("#".$type."_(\d*).html#si",$avgs[2],$mt)) {
				$mt_id = $mt[1];
			}
		}else{
			$nav_url = "/".$avgs[0]."/";
			if (preg_match("#".$type."_(\d*).html#si",$avgs[1],$mt)) {
				$mt_id = $mt[1];
			}
		}
		$temp_topic = db::find("select * from topic where pyurl ='$nav_url'");
		if(empty($temp_topic)){
			$this->page_404("您访问的页面不存在");	
		}
		$data['mt'] = $mt_id;
		$data['temp_topic'] = $temp_topic;
		$data['topic'] = $topic;
		return $data;
	}

	private function lr_arrow($topicid){
		$this->left_arrow = db::find("select * from topic where id>$topicid AND pid=0 AND flag=1 AND status=1 order by id asc");
		$this->right_arrow = db::find("select * from topic where id<$topicid AND pid=0 AND flag=1 AND status=1 order by id desc");
	}
}

