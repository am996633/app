<?php

/**
 * @version    $Id: baike.php 221 2016-07-18 10:33:16Z qinjinpeng $
 */

class baike_controller extends controller{

	public $nav =  array();
	public function __construct(){
		parent::__construct();
		spider::write();
	}
	
	public function index(){
		$page = 1;
		$this->loadlist($page);
	}

	public function _empty(){
		$url = $this->rest_uri;
		$avgs = explode('/', $url);
		if(preg_match("#list_(\d*).html#si", $avgs[1],$mt)){
			$page = $mt[1];
			$this->loadlist($page);
		}else{
			self::page_404();
		}
	}

	private function loadlist($page){
		$hd_nav = "baike";
		$pg = new page("select tk.*,tc.pyurl as url from topic_baike as tk left join topic as tc on tk.kid = tc.id where tk.status=1 order by tk.id asc");
		$pg->page = $page;
		$list = $pg->get_list(10);
		$page = $pg->get_page("/baike/list_{page}.html");
		$nav = array();
		$baike_hot = db::select("select tk.*,tc.pyurl as url from topic_baike as tk left join topic as tc on tk.kid = tc.id where tk.status=1 order by tk.click desc limit 10");
		$baike_max_id = db::getfield("select id from topic_baike order by id desc");
		$baike_rand_id = max(10, mt_rand($baike_max_id-1000, $baike_max_id));
		$baike_rand = db::select("select tk.*,tc.pyurl as url from topic_baike as tk left join topic as tc on tk.kid = tc.id where tk.id<$baike_rand_id AND tk.status=1 order by tk.id desc limit 10");
		require $this->tpl('baike_list');
	}
}

