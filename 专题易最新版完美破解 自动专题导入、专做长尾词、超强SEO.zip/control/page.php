<?php

/**
 * @version    $Id: page.php 375 2016-04-27 09:26:37Z tic $
 */

class page_controller extends controller{

	public $nav =  array();
	public $list_hot, $list_new;
	public function __construct(){
		parent::__construct();
		spider::write();

		$this->list_hot = db::select("select * from content where status = 1 order by click desc limit 9");
		$this->list_new = db::select("select * from content where status = 1 order by id desc limit 9");
	}

	public function _empty($ename){	
		$url = $this->rest_uri;
		$avgs = explode('/', $url);
		if(preg_match("#(.*?).html#si", $avgs[1],$mt1)){
			$page = db::find("select * from page where ename='$mt1[1]'");
			if(empty($page)){
				$this->page_404();
			}
			require $this->tpl('page');
		}
	}


}