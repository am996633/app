<?php

/**
 * @version    $Id: uploads.php 294 2016-04-17 08:01:26Z qinjinpeng $
 */

class uploads_controller extends controller{

	public function __construct(){
		parent::__construct();
	}

	public function attachment(){

		$arr = explode('/', substr($_SERVER['REQUEST_URI'],0,strrpos($_SERVER['REQUEST_URI'], '.')));
		$str_md5 = addslashes($arr[3].$arr[4].$arr[5]);
		$ext = strtolower( pathinfo($_SERVER['REQUEST_URI'], PATHINFO_EXTENSION) );
		if($ext=='img'){
			$ext = "images";
		}elseif(!in_array($ext, array('jpg', 'jpeg', 'png', 'gif'))){
			$this->page_404();
		}
		
		$img = db::find("select * from attachment where hash='$str_md5'");
		if(!$img){
			$this->page_404();
		}
		
		$flag = false;
		$oss = db::find("select * from storageservice where status = 1 AND url!=''");
		if($oss){
			$isqiniu = $_SERVER['HTTP_USER_AGENT']=="qiniu-imgstg-spider-1.0" && $_SERVER['HTTP_X_QINIU_SRC_HOST']==$oss['url'];
			$isupyun = isset($_SERVER['HTTP_X_VIA']) && strpos($_SERVER['HTTP_X_VIA'], 'shanks')!==false;
			if( !$isqiniu && !$isupyun ){
				$this->page_404();
			}
			$flag = true;
		}
		
		header('Content-type: image/'.$ext);
		$seconds_to_cache = 3600*48; 
		$ts = gmdate("D, d M Y H:i:s", time() + $seconds_to_cache) . " GMT"; 
		header("Expires: $ts");
		header("Pragma: cache");
		header("Cache-Control: max-age=$seconds_to_cache");

		$file = ROOT."/uploads/attachment/".$arr[3]."/".$arr[4]."/".$arr[5].'.'.$ext;
		if(is_file($file)){
			echo file_get_contents($file);
			exit;
		}
		
		if(!$flag && !is_dir(dirname($file))){
			mkdir(dirname($file), 0777, true);
		}

		//部分跳转的地址
		if(strpos($img['url'], '=http://')!==false){
			$img['url'] = urldecode( substr($img['url'], strpos($img['url'], '=http://')+1) );
		}
		
		$result = httpUnit::get($img['url']);
		if($result['httpcode']!=200 || empty($result['html'])){
			$nopic = base64_decode('/9j/4QAYRXhpZgAASUkqAAgAAAAAAAAAAAAAAP/sABFEdWNreQABAAQAAAA8AAD/7gAOQWRvYmUAZMAAAAAB/9sAhAAGBAQEBQQGBQUGCQYFBgkLCAYGCAsMCgoLCgoMEAwMDAwMDBAMDg8QDw4MExMUFBMTHBsbGxwfHx8fHx8fHx8fAQcHBw0MDRgQEBgaFREVGh8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx//wAARCAABAAEDAREAAhEBAxEB/8QBogAAAAcBAQEBAQAAAAAAAAAABAUDAgYBAAcICQoLAQACAgMBAQEBAQAAAAAAAAABAAIDBAUGBwgJCgsQAAIBAwMCBAIGBwMEAgYCcwECAxEEAAUhEjFBUQYTYSJxgRQykaEHFbFCI8FS0eEzFmLwJHKC8SVDNFOSorJjc8I1RCeTo7M2F1RkdMPS4ggmgwkKGBmElEVGpLRW01UoGvLj88TU5PRldYWVpbXF1eX1ZnaGlqa2xtbm9jdHV2d3h5ent8fX5/c4SFhoeIiYqLjI2Oj4KTlJWWl5iZmpucnZ6fkqOkpaanqKmqq6ytrq+hEAAgIBAgMFBQQFBgQIAwNtAQACEQMEIRIxQQVRE2EiBnGBkTKhsfAUwdHhI0IVUmJy8TMkNEOCFpJTJaJjssIHc9I14kSDF1STCAkKGBkmNkUaJ2R0VTfyo7PDKCnT4/OElKS0xNTk9GV1hZWltcXV5fVGVmZ2hpamtsbW5vZHV2d3h5ent8fX5/c4SFhoeIiYqLjI2Oj4OUlZaXmJmam5ydnp+So6SlpqeoqaqrrK2ur6/9oADAMBAAIRAxEAPwD1Tir/AP/Z');
			$flag || file_put_contents($file, $nopic);
			echo $nopic;
		}else{
			$flag || file_put_contents($file, $result['html']);
			echo $result['html'];
		}
	}
}

