<?php

/**
 * @version    $Id: topic.php 328 2016-04-20 09:44:54Z tic $
 *    1  1   1  1
 *    问 微  新 相
 */

class catch_controller extends controller{

	public function __construct(){
		parent::__construct();
	}

	//相关词 
	public function relaword(){
		$topic = array();
		$list_topic = db::select("select *,(catchstatus+0) as catchstatus from topic where status=0 order by pid desc, id asc limit 10");
		foreach ($list_topic as $key => $value) {
			if( ($value['catchstatus'] & 1)==0 ){
				$topic[] = $value;
			}
		}
		$data = array();
		$data['status'] = 1;
		$data['msg'] = '';
		if($topic){
			$topic = $topic[mt_rand(0, count($topic)-1)];
			$res = zty::getRelaword($topic);
			$data['msg'] = "开始采集“$topic[title]”的相关信息";
		}
		echo json_encode($data);
	}

	//新闻
	public function news(){
		$data = array();
		$data['status'] = 1;
		$data['msg'] = '';
		$keyword = array();
		$list_keyword = db::select("select *,(catchstatus+0) as catchstatus from topic where status=0 order by pid desc,id asc limit 10");
		foreach ($list_keyword as $key => $value) {
			if( ($value['catchstatus'] & 2)==0 ){
				$keyword[] = $value;
			}
		}
		if($keyword){
			$keyword = $keyword[mt_rand(0, count($keyword)-1)];
			$kid = $keyword['id'];
			$urlcache = db::find("select * from urlcache where kid ='$kid' ");
			if($urlcache){
				$url_cache = db::find("select * from urlcache where kid ='$kid' AND status=0 ");
				if(empty($url_cache)){
					db::query("update topic set catchstatus=catchstatus|2 where id ='$kid'");
					$data['msg'] = "关键词“$keyword[title]”采集文章完成";
				}else{
					$res = zty::getNews($url_cache);
					if($res){
						$data['msg'] = "采集到“$keyword[title]”的文章“$res[title]”";
					}
				}
			}else{
				$num = zty::getNewsList($keyword);
				$data['msg'] = "关键词“$keyword[title]”采集到{$num}个文章地址";
			}
		}
		echo json_encode($data);
	}
	
	public function baike(){
		$data = array();
		$data['status'] = 1;
		$data['msg'] = '';
		$baike = db::find("select * from topic_baike where status = -1");
		if($baike){
			$res = zty::baike($baike);
			$data['msg'] = "采集到百科内容“$res[title]”";
		}
		echo json_encode($data);
	}

	public function weibo(){
		$data = array();
		$data['status'] = 1;
		$data['msg'] = '';
		$keyword = array();
		$list_keyword = db::select("select *,(catchstatus+0) as catchstatus from topic where status=0 order by pid desc, id asc limit 10");

		foreach ($list_keyword as $key => $value) {
			if( ($value['catchstatus'] & 4)==0 ){
				$keyword[] = $value;
			}
		}
		if($keyword){
			$keyword = $keyword[mt_rand(0, count($keyword)-1)];
			$flag = zty::weibo($keyword);
			$data['msg'] = "关键词“$keyword[title]”的相关微博采集完成";
		}
		echo json_encode($data);
	}

	public function wenwen(){
		$keyword = array();
		$list_keyword = db::select("select *,(catchstatus+0) as catchstatus from topic where status=0 order by pid desc, id asc limit 10");
		foreach ($list_keyword as $key => $value) {
			if( ($value['catchstatus'] & 8)==0 ){
				$keyword[] = $value;
			}
		}
		$data = array();
		$data['status'] = 1;
		$data['msg'] = '';
		if($keyword){
			$keyword = $keyword[mt_rand(0, count($keyword)-1)];
			$title = $keyword['title'];
			$kid = $keyword['id'];
			$topic_wenwen = db::find("select * from topic_wenwen where kid ='$kid' ");
			if($topic_wenwen){
				//存在 抓取内容
				$wenwen = db::find("select * from topic_wenwen where kid ='$kid' AND status=-1 ");
				if(empty($wenwen)){
					db::query("update topic set catchstatus=catchstatus|8 where id ='$kid'");
					$data['msg'] = "关键词“$keyword[title]”的问问采集完毕";
				}else{
					zty::getWenwen($wenwen);
					$data['msg'] = "采集“$keyword[title]”的问问“$wenwen[ww_title]”";
				}
			}else{
				//不存在
				$num = zty::getWenwenList($keyword);
				$data['msg'] = "采集到“$keyword[title]”的问问 $num 个";
			}
		}
		echo json_encode($data);
	}

	public function check(){
		$num = 0;
		$list_keyword = db::select("select *,(catchstatus+0) as catchstatus from topic where catchstatus = 15 and status = 0  ");
		foreach ($list_keyword as $key => $keyword) {
			$id = $keyword['id'];
			$title = $keyword['title'];
			if($keyword['pid']==0){
				$list_topic = db::select("select id from topic where pid ='$id' and status = 0");
				if(!empty($list_topic)){
					continue;
				}
			}

			$time = time();
			$count = db::getfield("select count(*) from content where kid = '$id'");
			if($count){
				db::query("update topic set addtime=$time, status = 1 where id ='$id'");
			}else{
				db::query("update topic set addtime=$time, status = -1 where id ='$id'");
			}
			$tmpl = db::find("select * from tmpl order by rand() limit 1");
			if($tmpl){
				$tmpl_content = addslashes(str_replace('{topic}', $title, $tmpl['content']));
				db::query("update topic_body set `desc` = '$tmpl_content' where kid ='$id'");
			}
			
			db::query("update content set status = 1 where kid = '$id'");
			db::query("update topic_wenwen set status = 1 where kid = '$id'");
			db::query("update topic_baike set status = 1 where kid = '$id'");
			$num++;
			break;
		}

		$data['status'] = 1;
		$data['msg'] = "";
		if($num>0){
			$data['msg'] = "关键词“$keyword[title]”完全采集完成";
		}
		echo json_encode($data);
	}

	public function test(){
		echo 'server is ok';
	}

}

