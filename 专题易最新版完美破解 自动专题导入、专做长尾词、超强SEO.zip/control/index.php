<?php

/**
 * @version    $Id: index.php 414 2016-05-07 05:16:22Z qinjinpeng $
 */

class index_controller extends controller{

	public  $nav = array();
	public function __construct(){
		parent::__construct();
		spider::write();
	}

	public function index(){
		$hd_nav = "";
		$list_parent = db::select("select * from topic where pid = 0 and status = 1 order by id desc limit 30");
		foreach ($list_parent as $key => $value) {
			$cid = $value['id'];
			$list_parent[$key]['list_article'] = db::select("select * from content where kid = '$cid' and status = 1 limit 5");
			usort($list_parent[$key]['list_article'], create_function('$a, $b', 'return strlen($a[\'thumb\'])<strlen($b[\'thumb\']);') );
			$list_parent[$key]['list_topic'] = db::select("select * from topic where pid ='$cid' and status = 1 ");
		}
		
		$list = db::select("select *  from  content  where status = 1 order by click desc limit 19");
		usort($list, create_function('$a, $b', 'return strlen($a[\'thumb\'])<strlen($b[\'thumb\']);') );
		foreach ($list as &$art) {
			$art['thumb'] = empty($art['thumb'])?'/static/images/default.png':$art['thumb'];
		}
		
		$list_baike = db::select("select *,bk.id as id from  topic_baike as bk 
			left join topic as tc on bk.kid = tc.id 
			where bk.status = 1  order by bk.id desc limit 10");

		$list_hot = db::select("select * from content where status = 1 order by click desc limit 9");
		$list_new = db::select("select * from content where status = 1 order by id desc limit 9");

		$flink = db::select("select * from flink where status = 1");
		require $this->tpl('index');
	}
}

