<?php

/**
 * @version    $Id: article.php 375 2016-04-27 09:26:37Z tic $
 */

class article_controller extends controller{

	public $nav =  array();
	public $list_hot, $list_new;
	public function __construct(){
		parent::__construct();
		spider::write();

		$this->list_hot = db::select("select * from content where status = 1 order by click desc limit 9");
		$this->list_new = db::select("select * from content where status = 1 order by id desc limit 9");
	}

	public function index(){
		$hd_nav = "article";
		$page = 0;	
		$pg = new page("select * from content  where status = 1  order by id desc");
		$pg->page = $page;
		$list = $pg->get_list(10);
		$pagelink = $pg->get_page("/article/list_{page}.html");
		
		foreach ($list as &$art) {
			$art['thumb'] = empty($art['thumb'])?'/static/images/default.png':$art['thumb'];
		}

		
		require $this->tpl('article_list');
	}

	public function _empty($ename){	
		$url = $this->rest_uri;
		$avgs = explode('/', $url);
		if(preg_match("#list_(\d*).html#si", $avgs[1],$mt)){
			$hd_nav = "article";
			$page = $mt[1];
			$pg = new page("select * from content  where status = 1  order by id desc");
			$pg->page = $page;
			$list = $pg->get_list(10);
			$pagelink = $pg->get_page("/article/list_{page}.html");

			foreach ($list as &$art) {
				$art['thumb'] = empty($art['thumb'])?'/static/images/default.png':$art['thumb'];
			}
			
			require $this->tpl('article_list');
		}else{
			$this->page_404();
		}
	}

	public function search(){
		$hd_nav = "article";
		$keyword = gp("keyword");
		$page = gp("page");
		if($page<0){
			$page = 1;
		}
		$where ="";
		if($keyword){
			$where = "  and title like '%$keyword%' ";
		}
		$pg = new page("select * from content  where status = 1 $where  order by id desc");
		$list = $pg->get_list(10);
		$pagelink = $pg->get_page("/article/search/?keyword=".urlencode($keyword)."&page={page}");
		
		foreach ($list as &$art) {
			$art['thumb'] = empty($art['thumb'])?'/static/images/default.png':$art['thumb'];
		}
		require $this->tpl('article_list');
	}

	
}

