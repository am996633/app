

function add_link(){
	if($("#link_name").val()=="" || $("#links").val()==""){
		$("#msg").text("名称和链接不能为空");
	}else{
		$("#msg").text("");
		document.form1.submit();
	}
	return false;
}


function add_all(){            
	var ids = document.getElementsByName("key_box[]");               
	var flag = false ;               
	for(var i=0;i<ids.length;i++){
		if(ids[i].checked){
			return true;
			break ;
		}
	}
	if(!flag){
		$("#msg").text("请最少选择一项！"); 
		return false ;
	}
	return false;
}

function check_all(){
	var ids = document.getElementById("all");  
	if(ids.checked){   
		$(".checkboxed").attr("checked", true);  
	}else{    
		$(".checkboxed").attr("checked", false);  
	}    
	
}







