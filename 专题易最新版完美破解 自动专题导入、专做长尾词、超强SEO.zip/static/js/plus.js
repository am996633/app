// 加载编辑器
$(function(){
	if(typeof UE !== 'undefined'){
		$("textarea[_type=minieditor],script[_type=minieditor]").each(function(){
			var name = $(this).attr("id");
			var editorOption = {
				toolbars:window.UEDITOR_CONFIG.minitoolbars,
				initialFrameHeight:220,
				elementPathEnabled:false,
				wordCount:false
				//post_params:post_params
			}
			editor = UE.getEditor(name, editorOption);
		})
		$("textarea[_type=editor],script[_type=editor]").each(function(){
			var name = $(this).attr("id");
			var editorOption = {
				toolbars: window.UEDITOR_CONFIG.toolbars
				//post_params:post_params
			}
			editor = UE.getEditor(name, editorOption);
		})
		if(typeof editor!='undefined'){
			editor.addListener( 'ready', function( e ) {
				editor.fireEvent("catchRemoteImage");
			});
		}
	}
})

//滑动门
$(function(){
	//鼠标hover滑动门
	$("*[class*=tb_]").mouseover(
		function(){
			classname = $(this).attr("class").match(/tb_[0-9a-z]*/g)[0];
			var mark = classname.split("_")[1];
			var i = $(".tb_"+mark).index(this);
			$(".tb_"+mark).removeClass("current").eq(i).addClass("current");
			$(".tbc_"+mark).hide().eq(i).show();
		}
		)
	$("*[class*=tbc_]").each(function(){
		classname = $(this).attr("class").match(/tbc_[0-9a-z]*/g)[0];
		if( typeof tbgroup != "undefined" && classname==tbgroup ) $(this).hide();
		tbgroup = classname;
	})
	//鼠标点击滑动门
	$("*[class*=ctb_]").click(
		function(){
			classname = $(this).attr("class").match(/ctb_[0-9a-z]*/g)[0];
			var mark = classname.split("_")[1];
			var i = $(".ctb_"+mark).index(this);
			$(".ctb_"+mark).removeClass("current").eq(i).addClass("current");
			$(".ctbc_"+mark).hide().eq(i).show();
		}
		)
	$("*[class*=ctbc_]").each(function(){
		classname = $(this).attr("class").match(/ctbc_[0-9a-z]*/g)[0];
		if( typeof tbgroup != "undefined" && classname==tbgroup ) $(this).hide();
		tbgroup = classname;
	})
})

$(function(){
	var startTop = 0;
	if($("#fix_top").length>0){
		startTop = $("#fix_top").offset().top;
	}
	
	$(document).scroll(function(){
		var top = $(document).scrollTop();
		if(top>450){
			$("#top").show();
		}else{
			$("#top").hide();
		}
		if(startTop>0 && top>startTop-5){
			if(!$("#fix_top").hasClass('fix_top')){
				var startLeft = $("#fix_top").offset().left;
				var startWidth = $("#fix_top").width();
				$("#fix_top").addClass("fix_top");
				$(".fix_top").css({"left": startLeft, "width": startWidth});
			}
		}else{
			$("#fix_top").removeClass("fix_top");
		}
	});
});

$(function(){
	$(".index_wenwen").hover(function(){
		$(this).addClass('hover').siblings().removeClass("hover");
	})
})