<?php
include dirname(__FILE__).'/inc.php';
phpcaiji();
?>