<?php
$username="admin";
$password="admincaonima";
?>