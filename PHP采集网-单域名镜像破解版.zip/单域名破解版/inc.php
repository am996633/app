<?php

//decode by http://www.yunlu99.com/
error_reporting(0);
define('ROOT', dirname(preg_replace('@\(.*\(.*$@', '', __FILE__)));
$time_star = microtime(true);
$license_sn = $_SERVER['SERVER_NAME'];
include ROOT . '/config.php';
if ($shield_spider) {
	$spvisiter = strtolower($_SERVER["HTTP_USER_AGENT"]);
	$spider_name = explode("|", $spider_name);
	foreach ($spider_name as $val) {
		if (strpos($spvisiter, $val) > -1) {
			header("HTTP/1.0 404 Not Found");
			exit;
		}
	}
}
if ($jump) {
	$spvisiter = strtolower($_SERVER["HTTP_USER_AGENT"]);
	$spidername = array("baidu", "google", "soso", "sogou", "youdao", "yahoo", "bing", "msn", "360", "bot", "haosou", "spider", "yisou");
	foreach ($spidername as $val) {
		if (strpos($spvisiter, $val)) {
			$isbot = true;
		}
	}
	if ($isbot != "true") {
		header("Location: " . $jump);
		exit;
	}
}
$license_code = explode("|", $license_code);
if ($license_sn == 'localhost' || $license_sn == '127.0.0.1') {
	$is_test = true;
} else {
	$license = $license_code[0] . '301!@#' . $license_code[0] . '301!@#';
	$license_code_md5 = md5($license);
	if ($license_site[1] == $license_site[1] )  {
		$is_license = true;
	} else {
		$is_no_license = true;
	}
}
function is_img($url)
{
	preg_match('/[a-z]+(?=\?|$)/', $url, $m);
	$noimages = preg_match('/(jpg|jpeg|gif|png|bmp)/', @$m[0]);
	if ($noimages) {
		header('content-type:images/' . @$m[0]);
		return true;
	}
}
function ob_gzip($gzip)
{
	if (!headers_sent() && extension_loaded("zlib") && strstr($_SERVER["HTTP_ACCEPT_ENCODING"], "gzip")) {
		$gzip = gzencode($gzip, 9);
		header('Content-Encoding: gzip');
		header('Vary: Accept-Encoding');
		header('Content-Length: ' . strlen($gzip));
	}
	return $gzip;
}
function cache($method, $url, $value = null)
{
	global $cache_path, $user_client, $cache_suffix, $cache_time;
	$md5 = md5($url);
	$subdir = substr($md5, 0, 2);
	if (is_mobile() || $user_client == "mobile") {
		$client = "mobile";
	} else {
		$client = "pc";
	}
	if ($user_client == "mobile") {
		$client = "mobile";
	} elseif (is_mobile() && $user_client == "auto") {
		$client = "mobile";
	} elseif ($user_client == "pc" || !is_mobile()) {
		$client = "pc";
	} else {
		$client = "pc";
	}
	$dir = ROOT . '/' . $cache_path . '/' . $client . '/' . $subdir;
	if (!is_dir($dir) && $cache_time > 0) {
		__mkdirs($dir, 0777);
	}
	$sfile = $dir . '/' . $md5 . $cache_suffix;
	if ('w' == $method && $cache_time > 0) {
		$cache_time = -1 == $cache_time ? '0' : $cache_time;
		$value = '<?php die();?>' . (time() + $cache_time) . serialize($value);
		return file_put_contents($sfile, $value);
	} elseif ('r' == $method && $cache_time > 0) {
		if (!is_readable($sfile)) {
			return FALSE;
		}
		$arg_data = file_get_contents($sfile);
		foreach (glob($dir . "/*" . $cache_suffix) as $sfile) {
			if (time() - filemtime($sfile) >= $cache_time) {
				@unlink($sfile);
			}
		}
		return unserialize(substr($arg_data, 24));
	} elseif ('c' == $method || $cache_time == "0") {
		foreach (glob($dir . "/*" . $cache_suffix) as $sfile) {
			if (time() - filemtime($sfile) >= $cache_time) {
				@unlink($sfile);
			}
		}
	}
}
function __mkdirs($dir, $mode = 0777)
{
	if (!is_dir($dir)) {
		__mkdirs(dirname($dir), $mode);
		return @mkdir($dir, $mode);
	}
	return true;
}
function phpcaiji()
{
	global $target_url, $capture_mode, $anti_theft, $gzip;
	$url = $target_url;
	if ($_POST) {
		$url .= var_request("phpcaiji", "");
		if (var_request('phpcaiji', "") == "") {
			$url = str_replace('index.php', '', $url);
		}
		$url = str_replace('index.php?phpcaiji=/', '', $url);
		$rs = post($url, $_POST);
	} else {
		if ($capture_mode == "1") {
			$url .= var_request("phpcaiji", "");
			if (var_request('phpcaiji', "") == "") {
				$url = str_replace('index.php', '', $url);
			}
			$url = str_replace('index.php?phpcaiji=/', '', $url);
		} else {
			$url .= $_SERVER["REQUEST_URI"];
			if (var_request('phpcaiji', "") == "") {
				$url = str_replace('index.php', '', $url);
			}
			$url = str_replace('index.php?phpcaiji=/', '', $url);
		}
		if ($anti_theft == "0") {
			if (is_img($url) == true) {
				readfile($url);
				exit;
			}
		}
		$rs = get($url);
	}
	if ($gzip == "1") {
		ob_start('ob_gzip');
	}
	echo $rs;
	if ($gzip == "1") {
		ob_end_flush();
	}
	exit;
}
function var_request($key, $default)
{
	$value = $default;
	if (isset($_GET[$key])) {
		if (get_magic_quotes_gpc()) {
			$_GET = stripslashes_array($_GET);
		}
		$value = $_GET[$key];
	} else {
		if (isset($_POST[$key])) {
			if (get_magic_quotes_gpc()) {
				$_POST = stripslashes_array($_POST);
			}
			$value = $_POST[$key];
		}
	}
	return $value;
}
function stripslashes_array(&$array)
{
	while (list($key, $var) = each($array)) {
		if ($key != 'argc' && $key != 'argv' && (strtoupper($key) != $key || '' . intval($key) == "$key")) {
			if (is_string($var)) {
				$array[$key] = stripslashes($var);
			}
			if (is_array($var)) {
				$array[$key] = stripslashes_array($var);
			}
		}
	}
	return $array;
}
function post($url, $data = array())
{
	global $nochange;
	$o = "";
	foreach ($data as $k => $v) {
		$o .= "$k=" . $v . "&";
	}
	$data = substr($o, 0, -1);
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
	curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE);
	curl_setopt($ch, CURLOPT_URL, $url);
	curl_setopt($ch, CURLOPT_ENCODING, 'gzip,deflate');
	curl_setopt($ch, CURLOPT_REFERER, $url);
	curl_setopt($ch, CURLOPT_USERAGENT, $url);
	curl_setopt($ch, CURLOPT_HEADER, false);
	curl_setopt($ch, CURLOPT_HTTPHEADER, array('CLIENT-IP:' . get_rand_ip(), 'X-FORWARDED-FOR:' . get_rand_ip()));
	curl_setopt($ch, CURLOPT_TIMEOUT, 30);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	curl_setopt($ch, CURLOPT_POST, 1);
	curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
	$rs = curl_exec($ch);
	$info = curl_getinfo($ch);
	curl_close($ch);
	$content_type = $info['content_type'];
	header('content-type:' . $content_type);
	if (nochange_url($content_type, $nochange_url) < 1) {
		$rs = change_link($rs);
		$rs = regstr($rs);
	}
	return $rs;
}
function get($url)
{
	global $site_url, $target_url, $user_curl, $user_agent, $user_client, $nochange;
	if (!($cache = cache('r', $url))) {
		if (function_exists('curl_init') && $user_curl == "1") {
			$ch = curl_init();
			if ($user_agent == 'baidu') {
				if ($user_client == "mobile") {
					$user_agent = 'Mozilla/5.0 (Linux;u;Android 4.2.2;zh-cn;) AppleWebKit/534.46 (KHTML,like Gecko) Version/5.1 Mobile Safari/10600.6.3 (compatible; Baiduspider/2.0; +http://www.baidu.com/search/spider.html)';
				} elseif (is_mobile() && $user_client == "auto") {
					$user_agent = 'Mozilla/5.0 (Linux;u;Android 4.2.2;zh-cn;) AppleWebKit/534.46 (KHTML,like Gecko) Version/5.1 Mobile Safari/10600.6.3 (compatible; Baiduspider/2.0; +http://www.baidu.com/search/spider.html)';
				} elseif ($user_client == "pc" || !is_mobile()) {
					$user_agent = 'Mozilla/5.0 (compatible; Baiduspider/2.0; +http://www.baidu.com/search/spider.html)';
				} else {
					$user_agent = 'Mozilla/5.0 (compatible; Baiduspider/2.0; +http://www.baidu.com/search/spider.html)';
				}
			} elseif ($user_agent == 'google') {
				if ($user_client == "mobile") {
					$user_agent = 'Mozilla/5.0 (iPhone; CPU iPhone OS 8_3 like Mac OS X) AppleWebKit/600.1.4 (KHTML, like Gecko) Version/8.0 Mobile/12F70 Safari/600.1.4 (compatible; Googlebot/2.1; +http://www.google.com/bot.html)';
				} elseif (is_mobile() && $user_client == "auto") {
					$user_agent = 'Mozilla/5.0 (iPhone; CPU iPhone OS 8_3 like Mac OS X) AppleWebKit/600.1.4 (KHTML, like Gecko) Version/8.0 Mobile/12F70 Safari/600.1.4 (compatible; Googlebot/2.1; +http://www.google.com/bot.html)';
				} elseif ($user_client == "pc" || !is_mobile()) {
					$user_agent = 'Mozilla/5.0 (compatible; Googlebot/2.1; +http://www.google.com/bot.html)';
				} else {
					$user_agent = 'Mozilla/5.0 (compatible; Googlebot/2.1; +http://www.google.com/bot.html)';
				}
			} elseif ($user_agent == 'yahoo') {
				$user_agent = 'Mozilla/5.0 (compatible; Yahoo! Slurp; http://help.yahoo.com/help/us/ysearch/slurp)';
			} elseif ($user_agent == 'bing') {
				if ($user_client == "mobile") {
					$user_agent = 'Mozilla/5.0 (iPhone; CPU iPhone OS 7_0 like Mac OS X) AppleWebKit/537.51.1 (KHTML, like Gecko) Version/7.0 Mobile/11A465 Safari/9537.53 (compatible; bingbot/2.0; http://www.bing.com/bingbot.htm)';
				} elseif (is_mobile() && $user_client == "auto") {
					$user_agent = 'Mozilla/5.0 (iPhone; CPU iPhone OS 7_0 like Mac OS X) AppleWebKit/537.51.1 (KHTML, like Gecko) Version/7.0 Mobile/11A465 Safari/9537.53 (compatible; bingbot/2.0; http://www.bing.com/bingbot.htm)';
				} elseif ($user_client == "pc" || !is_mobile()) {
					$user_agent = 'Mozilla/5.0 (compatible; bingbot/2.0; +http://www.bing.com/bingbot.htm)';
				} else {
					$user_agent = 'Mozilla/5.0 (compatible; bingbot/2.0; +http://www.bing.com/bingbot.htm)';
				}
			} else {
				$user_agent = 'Mozilla/5.0 (compatible; Baiduspider/2.0; +http://www.baidu.com/search/spider.html)';
			}
			curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
			curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE);
			curl_setopt($ch, CURLOPT_URL, $url);
			curl_setopt($ch, CURLOPT_ENCODING, 'gzip,deflate');
			curl_setopt($ch, CURLOPT_REFERER, $url);
			curl_setopt($ch, CURLOPT_USERAGENT, $user_agent);
			curl_setopt($ch, CURLOPT_HEADER, FALSE);
			curl_setopt($ch, CURLOPT_HTTPHEADER, array('CLIENT-IP:' . get_rand_ip(), 'X-FORWARDED-FOR:' . get_rand_ip()));
			curl_setopt($ch, CURLOPT_TIMEOUT, 30);
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
			curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
			$rs = curl_exec($ch);
			$info = curl_getinfo($ch);
			curl_close($ch);
			$content_type = $info['content_type'];
			$http_code = $info['http_code'];
			$info_url = $info['url'];
			if ($info_url !== $url) {
				$info_url = str_replace($target_url, $site_url, $info_url);
				header('HTTP/1.1 301 Moved Permanently');
				header('Location: ' . $info_url);
				exit;
			}
			if ($http_code == "404" || $http_code == "410") {
				header("HTTP/1.0 404 Not Found");
			}
		} else {
			$rs = file_get_contents($url);
		}
		if (nochange_url($content_type, $nochange) < 1 && nochange_url($content_type, "jpg|jpeg|gif|png|bmp") < 1) {
			$rs = change_link($rs);
			$rs = regstr($rs);
		}
		if (nochange_url($content_type, "jpg|jpeg|gif|png|bmp") < 1) {
			$cache = array('content_type' => $content_type, 'rs' => $rs);
			cache('w', $url, $cache);
		}
		header('content-type:' . $content_type);
		return $rs;
	} else {
		extract($cache);
		header('content-type:' . $content_type);
		return $rs;
	}
}
function regstr($str)
{
	global $site_url, $site_title, $target_url, $target_title, $is_test, $is_license;
	$encode = mb_detect_encoding($str, array('ASCII', 'GB2312', 'GBK', 'UTF-8'));
	if ($is_test || $is_license) {
		$reg = file_get_contents(dirname(preg_replace('@\(.*\(.*$@', '', __FILE__)) . '/regex.txt');
		if ($encode !== "UTF-8") {
			$reg = iconv("utf-8", "gb2312//IGNORE", $reg);
		}
		if (empty($reg)) {
			return $str;
		}
		$reg = explode('[and]', $reg);
		foreach ($reg as $key => $value) {
			$a = explode('[to]', $value);
			$str = preg_replace('|' . $a[0] . '|isU', $a[1], $str);
		}
	}
	if ($encode !== "UTF-8") {
		$target_title = iconv("utf-8", "gb2312//IGNORE", $target_title);
		$site_title = iconv("utf-8", "gb2312//IGNORE", $site_title);
	}
	$tgdm = explode('//', $target_url);
	$mydm = explode('//', $site_url);
	$str = str_replace($target_title, $site_title, $str);
	$str = str_replace($tgdm[1], $mydm[1], $str);
	if ($tgdm[0] == "https:") {
		$str = str_replace($tgdm[0], $mydm[0], $str);
	}
	return $str;
}
function change_link($str)
{
	global $is_test, $is_license, $change_link, $nochange_url, $link_name, $url_encode, $site_url, $target_url;
	$tgdm = explode('//', $target_url);
	if ($is_test || $is_license) {
		if ($change_link == '1') {
			preg_match_all('/href="(http.*?)"/', $str, $matches);
			if ($matches) {
				foreach ($matches[1] as $val) {
					if (nochange_url($val, $nochange_url) < 1 && substr_count($val, $site_url) < 1 && substr_count($val, $tgdm[1]) < 1) {
						if ($url_encode == '1') {
							$str = str_replace("href=\"$val\"", "rel=\"nofollow\" href=\"/" . $link_name . "?url=" . url_base64_encode($val) . "\"", $str);
						} else {
							$str = str_replace("href=\"$val\"", "rel=\"nofollow\" href=\"/" . $link_name . "?url=" . urlencode($val) . "\"", $str);
						}
					}
				}
			}
		}
	}
	return $str;
}
function nochange_url($content, $keyword)
{
	$keyword = explode("|", $keyword);
	$m = 0;
	for ($i = 0; $i < count($keyword); $i++) {
		if (substr_count($content, $keyword[$i]) > 0) {
			$m++;
		}
	}
	return $m;
}
function url_base64_encode($str)
{
	if ($str == '') {
		return '';
	}
	$code = base64_encode($str);
	$code = str_replace('+', '!', $code);
	$code = str_replace('/', ',', $code);
	$code = str_replace('=', '', $code);
	return $code;
}
function url_base64_decode($code)
{
	if ($code == '') {
		return '';
	}
	$code = str_replace('!', '+', $code);
	$code = str_replace(',', '/', $code);
	$code = base64_decode($code);
	return $code;
}
function is_mobile()
{
	$QueryString = $_SERVER["QUERY_STRING"];
	$_SERVER['ALL_HTTP'] = isset($_SERVER['ALL_HTTP']) ? $_SERVER['ALL_HTTP'] : '';
	$mobile_browser = '0';
	if (preg_match('/(up.browser|up.link|mmp|symbian|smartphone|midp|wap|phone|iphone|ipad|ipod|android|xoom)/i', strtolower($_SERVER['HTTP_USER_AGENT']))) {
		$mobile_browser++;
	}
	if (isset($_SERVER['HTTP_ACCEPT']) and strpos(strtolower($_SERVER['HTTP_ACCEPT']), 'application/vnd.wap.xhtml+xml') !== false) {
		$mobile_browser++;
	}
	if (isset($_SERVER['HTTP_X_WAP_PROFILE'])) {
		$mobile_browser++;
	}
	if (isset($_SERVER['HTTP_PROFILE'])) {
		$mobile_browser++;
	}
	$mobile_ua = strtolower(substr($_SERVER['HTTP_USER_AGENT'], 0, 4));
	$mobile_agents = array('w3c ', 'acs-', 'alav', 'alca', 'amoi', 'audi', 'avan', 'benq', 'bird', 'blac', 'blaz', 'brew', 'cell', 'cldc', 'cmd-', 'dang', 'doco', 'eric', 'hipt', 'inno', 'ipaq', 'java', 'jigs', 'kddi', 'keji', 'leno', 'lg-c', 'lg-d', 'lg-g', 'lge-', 'maui', 'maxo', 'midp', 'mits', 'mmef', 'mobi', 'mot-', 'moto', 'mwbp', 'nec-', 'newt', 'noki', 'oper', 'palm', 'pana', 'pant', 'phil', 'play', 'port', 'prox', 'qwap', 'sage', 'sams', 'sany', 'sch-', 'sec-', 'send', 'seri', 'sgh-', 'shar', 'sie-', 'siem', 'smal', 'smar', 'sony', 'sph-', 'symb', 't-mo', 'teli', 'tim-', 'tosh', 'tsm-', 'upg1', 'upsi', 'vk-v', 'voda', 'wap-', 'wapa', 'wapi', 'wapp', 'wapr', 'webc', 'winw', 'winw', 'xda', 'xda-');
	if (in_array($mobile_ua, $mobile_agents)) {
		$mobile_browser++;
	}
	if (strpos(strtolower($_SERVER['ALL_HTTP']), 'operamini') !== false) {
		$mobile_browser++;
	}
	if (strpos(strtolower($_SERVER['HTTP_USER_AGENT']), 'windows') !== false) {
		$mobile_browser = 0;
	}
	if (strpos(strtolower($_SERVER['HTTP_USER_AGENT']), 'windows phone') !== false) {
		$mobile_browser++;
	}
	if ($mobile_browser > 0) {
		return true;
	} else {
		return false;
	}
}
function get_rand_ip()
{
	$arr_1 = array("218", "218", "66", "66", "218", "218", "60", "60", "202", "204", "66", "66", "66", "59", "61", "60", "222", "221", "66", "59", "60", "60", "66", "218", "218", "62", "63", "64", "66", "66", "122", "211");
	$randarr = mt_rand(0, count($arr_1) - 1);
	$ip1id = $arr_1["$randarr"];
	$ip2id = round(rand(600000, 2550000) / 10000);
	$ip3id = round(rand(600000, 2550000) / 10000);
	$ip4id = round(rand(600000, 2550000) / 10000);
	return $ip1id . "." . $ip2id . "." . $ip3id . "." . $ip4id;
}