<?php
if(!defined('VV_PLUS')){
    exit('Access Denied');
}
class bdping{
    public $var_2;
    public $var_3;
    public $info = array("name" => "<font color=blue>�ٶ���������</font>", "info" => "<font color=blue>��ȡ��վ�����������͵��ٶ�</font>", "status" => 1, "author" => "<font color=blue>vivi</font>", "version" => "<font color=blue>3.0</font>",);
    public function init(){
        global $var_1;
        global $caiji_config;
        $this -> fun_4 = $_SERVER["SERVER_PORT"] == 443 ? 'https://' : 'http://';
        $this -> fun_5 = $_SERVER["HTTP_HOST"];
        $this -> cachefile = VV_DATA . '/bdpingcache/' . $this -> fun_5 . '.cache';
        $this -> fun_6 = VV_DATA . '/bdpingcache/' . $this -> fun_5 . '_result.cache';
        if($caiji_config["plus_bdping_set"]){
            $this -> fun_7 = $caiji_config["plus_bdping_config"];
        }else{
            $this -> fun_8 = dirname(__FILE__) . '/config.php';
            if(is_file($this -> fun_8)){
                $this -> fun_7 = require($this -> fun_8);
            }
        }
    }
    public function before_get(){
    }
    public function source(){
    }
    public function before_cache(){
    }
    public function end(){
        global $var_1;
        global $v_config;
        if(!$this -> istime()){
            return false;
        }
        if($this -> fun_7["path_type"] != 'both'){
            if(is_index() && $this -> fun_7["path_type"] != 'index'){
                return false;
            }
            if(!is_index() && $this -> fun_7["path_type"] != 'other'){
                return false;
            }
        }
        $var_4 = true;
        $var_5 = $GLOBALS["allhref"];
        if(!isset($GLOBALS["all_links"])){
            $GLOBALS["all_links"] = get_all_link($GLOBALS["html"]);
            $var_5 = $GLOBALS["allhref"];
            $var_4 = false;
        }
        $var_5 = array_unique($var_5);
        if(!$var_5){
            return false;
        }
        foreach($var_5 as $var_6 => $var_7){
            if(!isgoodurl($var_7) && !is_fanurl($var_7)){
                continue;
            }
            $var_8 = $var_7;
            if($var_4){
                $var_8 = get_showurl($var_7, $v_config["web_urlencode_suffix"]);
            }
            if(!preg_match('~^https?://~', $var_8)){
                $var_8 = $this -> fun_4 . $this -> fun_5 . $var_8;
            }
            $var_9[] = $var_8;
        }
        if(!$var_9){
            return false;
        }
        if(is_file($this -> cachefile)){
            $var_10 = unserialize(file_get_contents($this -> cachefile));
            $var_10 = array_merge($var_10, $var_9);
        }else{
            $var_10 = $var_9;
        }
        $var_11 = $this -> fun_7["maxnum"]?$this -> fun_7["maxnum"]:500;
        $var_10 = array_slice($var_10, "0", $var_11);
        rsort($var_10);
        $var_10 = array_unique($var_10);
        write($this -> cachefile, serialize($var_10));
        $var_12 = $this -> baiduping($var_10);
        write($this -> fun_6, $var_12);
    }
    public function istime(){
        global $var_1;
        $var_13 = $this -> fun_7["cachetime"]?$this -> fun_7["cachetime"]:20;
        if(!is_file($this -> cachefile) || (@filemtime($this -> cachefile) + $var_13 * 3600) < time()){
            return true;
        }
        return false;
    }
    private function baiduping($v_14){
        global $var_1;
        if(is_array($v_14)){
            $v_14 = implode("
", $v_14);
        }
        $var_15 = 10;
        $var_16 = 'http://data.zz.baidu.com/urls?site=' . $this -> fun_7["site"] . '&token=' . $this -> fun_7["token"];
        $var_17 = curl_init();
        $var_18 = array(CURLOPT_URL => $var_16, CURLOPT_POST => true, CURLOPT_TIMEOUT => $var_15, CURLOPT_RETURNTRANSFER => true, CURLOPT_POSTFIELDS => $v_14, CURLOPT_HTTPHEADER => array('Content-Type: text/plain'),);
        curl_setopt_array($var_17, $var_18);
        $var_19 = curl_exec($var_17);
        return $var_19;
    }
}
?>