<?php
return array (
  'site' => 'a.feiz.ml',
  'token' => 'ax1sad23dwaxa',
  'cachetime' => '10',
  'maxnum' => '500',
  'path_type' => 'both',
);
?>