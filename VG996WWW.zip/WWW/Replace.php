﻿<?php
// + 官网：www.966seo.com
// +----------------------------------------------------------------------
// + VG目录站群团队最新力作，达到秒收录秒排名效果！
// +----------------------------------------------------------------------
// + VG目录站群泛目录适合各行业操作关键词快速排名！
// +----------------------------------------------------------------------
// + VG目录站群泛目录：为关键词秒收秒排快速排名而生！
// +----------------------------------------------------------------------
	header("Content-Type: text/html; charset=UTF-8");
	$data = include '/data/conf/database.php';
	$prefix = $data['prefix'];
	$mulu_name = trim(read_mulu($prefix.'m_mulu'),"\xEF\xBB\xBF");
	$keyword = trim(read_data($prefix.'m_keyword'));
	if(strstr($html,'{url}')){
		while(strstr($html,'{url}')){
			$url = trim(read_data($prefix.'m_url'),"\xEF\xBB\xBF");
			$html = preg_replace('/{url}/',$url,$html,1);
		}
	}

	if(strstr($html,'{后缀}')){
		$suffix = trim(read_data($prefix.'m_suffix'),"\xEF\xBB\xBF");
		$html = preg_replace('/{后缀}/',$suffix,$html);
	}


	while(strstr($html,'{句子}')){
		$juzi = trim(read_data($prefix.'m_juzi'));
		$html = preg_replace('/{句子}/',$juzi,$html,1);
	}

        if(strstr($html,'{转码句子}')){
            while(strstr($html,'{转码句子}')){
                $zm_juzi = zm_content(read_data($prefix.'m_juzi'));
                $html = preg_replace('/{转码句子}/',$zm_juzi,$html,1);
            }
        }


        if(strstr($html,'{特殊句子}')){
            while(strstr($html,'{特殊句子}')){
                $ts_juzi = clfh(read_data($prefix.'m_juzi'));
                $html = preg_replace('/{特殊句子}/',$ts_juzi,$html,1);
            }
        }


	if(strstr($html,'{关键词}')){
		$html = preg_replace('/{关键词}/',$keyword,$html);
	}

	if(strstr($html,'{转码关键词}')){
		$zm_keyword = zm_content($keyword);
		$html = preg_replace('/{转码关键词}/',$zm_keyword,$html);
	}

        if(strstr($html,'{干扰码}')){
            while(strstr($html,'{干扰码}')){
                $html = preg_replace('/{干扰码}/',randCode(mt_rand(8,8),-1),$html,1);
            }
        }

	if(strstr($html,'{时间}')){
		$time = date("Y年m月d日 H:i");
		$html = preg_replace('/{时间}/',$time,$html);
	}

	if(strstr($html,'{年月日}')){
		$ymd = date("Ymd");
		$html = preg_replace('/{年月日}/',$ymd,$html);
	}

	if(strstr($html,'{目录}')){
		$html = preg_replace('/{目录}/',$mulu_name,$html);
	}

	if(strstr($html,'{年月}')){
		$ym = date("Ym");
		$html = preg_replace('/{年月}/',$ym,$html);
	}

	while(strstr($html,'{随机年份}')){
		$sjy = read_y();
		$html = preg_replace('/{随机年份}/',$sjy,$html,1);
	}

	while(strstr($html,'{人名}')){
		$name = trim(read_data($prefix.'m_name'));
		$html = preg_replace('/{人名}/',$name,$html,1);
	}

	while(strstr($html,'{城市}')){
		$city = trim(read_data($prefix.'m_city'));
		$html = preg_replace('/{城市}/',$city,$html,1);
	}

	while(strstr($html,'{栏目}')){
		$column = trim(read_data($prefix.'m_column'));
		$html = preg_replace('/{栏目}/',$column,$html,1);
	}

	while(strstr($html,'{热词}')){
		$hotwords = trim(read_data($prefix.'m_hotwords'));
		$html = preg_replace('/{热词}/',$hotwords,$html,1);
	}

	while(strstr($html,'{奖项}')){
		$prize = trim(read_data($prefix.'m_prize'));
		$html = preg_replace('/{奖项}/',$prize,$html,1);
	}

	while(strstr($html,'{学校}')){
		$school = trim(read_data($prefix.'m_school'));
		$html = preg_replace('/{学校}/',$school,$html,1);
	}

	while(strstr($html,'{书名}')){
		$book = trim(read_data($prefix.'m_book'));
		$html = preg_replace('/{书名}/',$book,$html,1);
	}

	while(strstr($html,'{爱好}')){
		$hobby = trim(read_data($prefix.'m_hobby'));
		$html = preg_replace('/{爱好}/',$hobby,$html,1);
	}

	while(strstr($html,'{图片}')){
		$img = trim(read_data($prefix.'m_pic'),"\xEF\xBB\xBF");
		$html = preg_replace('/{图片}/',$img,$html,1);
	}

	while(strstr($html,'{来源}')){
		$from = trim(read_data($prefix.'m_from'));
		$html = preg_replace('/{来源}/',$from,$html,1);
	}

	while(strstr($html,'{新闻标题}')){
		$title = trim(read_data($prefix.'m_title'));
		$html = preg_replace('/{新闻标题}/',$title,$html,1);
	}

	while(strstr($html,'{字母}')){
		$letter = randCode(mt_rand(2,3),1);
		$html = preg_replace('/{字母}/',$letter,$html,1); 
	}

	while(strstr($html,'{数字}')){
		$number = randCode(mt_rand(2,3),3);
		$html = preg_replace('/{数字}/',$number,$html,1);
	}

?>