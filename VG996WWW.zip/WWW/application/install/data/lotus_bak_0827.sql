SET time_zone = "+00:00";


CREATE DATABASE IF NOT EXISTS `red_com` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;


DROP TABLE IF EXISTS `lotus_api`;
CREATE TABLE IF NOT EXISTS `lotus_api` (
  `id` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `base_url` varchar(255) DEFAULT NULL,
  `hash` varchar(50) DEFAULT NULL,
  `method` varchar(10) DEFAULT NULL,
  `is_token` varchar(255) DEFAULT '0',
  `app_id` int(11) DEFAULT NULL,
  `param` varchar(255) DEFAULT NULL,
  `key` varchar(255) DEFAULT NULL,
  `value` varchar(255) DEFAULT NULL,
  `create_time` int(11) DEFAULT NULL,
  `update_time` int(11) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=46 DEFAULT CHARSET=utf8;

TRUNCATE TABLE `lotus_api`;
INSERT INTO `lotus_api` (`id`, `name`, `base_url`, `hash`, `method`, `is_token`, `app_id`, `param`, `key`, `value`, `create_time`, `update_time`) VALUES(1, 'test', 'https://www.lotusadmin.top/index/index/testPost.html', 'NGPJPXYFLBFCTASBXYMYJ97R5', 'no_limit', '0', NULL, 'id:2|name:999919999999999999999999999999999', NULL, NULL, 1511938273, 1516843876);
INSERT INTO `lotus_api` (`id`, `name`, `base_url`, `hash`, `method`, `is_token`, `app_id`, `param`, `key`, `value`, `create_time`, `update_time`) VALUES(45, '轮播图', 'https://www.lotusadmin.top/index/index/testPost.html', 'INW2BZIXLBZJXHZ4QD4QGBLQ2', 'no_limit', '1', NULL, 'id:1|name:活动1|image:http://www.baidu.com', NULL, NULL, 1516413527, 1516694611);

DROP TABLE IF EXISTS `lotus_app`;
CREATE TABLE IF NOT EXISTS `lotus_app` (
  `id` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `app_id` int(11) NOT NULL,
  `secret` varchar(255) NOT NULL,
  `create_time` int(11) DEFAULT NULL,
  `update_time` int(11) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=69 DEFAULT CHARSET=utf8;

TRUNCATE TABLE `lotus_app`;
INSERT INTO `lotus_app` (`id`, `name`, `app_id`, `secret`, `create_time`, `update_time`) VALUES(48, '67890', 83315454, 'T5TIKY52PXW92KI8T47YNCPY2', 1512900450, 1514554017);
INSERT INTO `lotus_app` (`id`, `name`, `app_id`, `secret`, `create_time`, `update_time`) VALUES(49, 'jjj', 89701605, 'CSOS6G1EX3PBE5QLWVOKJ4S4N', 1513262603, 1516368208);
INSERT INTO `lotus_app` (`id`, `name`, `app_id`, `secret`, `create_time`, `update_time`) VALUES(51, '33213213', 36632265, 'SJXMOASBN1F7ZD85V44FPFZD5', 1513749512, 1513749512);
INSERT INTO `lotus_app` (`id`, `name`, `app_id`, `secret`, `create_time`, `update_time`) VALUES(52, '66', 41119516, 'VG57ZSSDC1PN66QWHTQ167BXW', 1514170106, 1514170106);
INSERT INTO `lotus_app` (`id`, `name`, `app_id`, `secret`, `create_time`, `update_time`) VALUES(54, 'fff', 35381515, 'FW8R3HD2DK7UVSK1UNPWUX3VR', 1514337763, 1514337763);
INSERT INTO `lotus_app` (`id`, `name`, `app_id`, `secret`, `create_time`, `update_time`) VALUES(55, 'gggg', 17816116, 'V42T5EVD39Y19PHVQVKAP6AAM', 1514337920, 1514337920);
INSERT INTO `lotus_app` (`id`, `name`, `app_id`, `secret`, `create_time`, `update_time`) VALUES(61, '888', 82758191, '2584LUAXGDEF2OFJESDQKPAVC', 1515790384, 1515790384);
INSERT INTO `lotus_app` (`id`, `name`, `app_id`, `secret`, `create_time`, `update_time`) VALUES(62, '首页测试数据', 85221630, 'B3IXA9U7PRKQPBIJPJWBI6OVX', 1516412439, 1516412439);
INSERT INTO `lotus_app` (`id`, `name`, `app_id`, `secret`, `create_time`, `update_time`) VALUES(63, 'frsfsd', 62661704, 'LZ8UTZOZO6QFB8EY6HIX2UJC2', 1516606772, 1516606772);
INSERT INTO `lotus_app` (`id`, `name`, `app_id`, `secret`, `create_time`, `update_time`) VALUES(65, 'test11', 67203101, 'EA3NX4PARMR63RUMATX27A5IY', 1516694560, 1516694560);
INSERT INTO `lotus_app` (`id`, `name`, `app_id`, `secret`, `create_time`, `update_time`) VALUES(66, 'test11', 42597693, 'JGBRGA7EXDY8T5INDBJO6PHCE', 1516756425, 1516756425);
INSERT INTO `lotus_app` (`id`, `name`, `app_id`, `secret`, `create_time`, `update_time`) VALUES(67, 'ssdfgsdf', 62128950, 'IG4NT2KGVA72E1VRDEDFZBZUL', 1516760748, 1516760748);
INSERT INTO `lotus_app` (`id`, `name`, `app_id`, `secret`, `create_time`, `update_time`) VALUES(68, '11111111', 82120651, 'OPYRD3BIOUXV75556X34DAYCR', 1516760764, 1516760764);

DROP TABLE IF EXISTS `lotus_article`;
CREATE TABLE IF NOT EXISTS `lotus_article` (
  `id` int(10) unsigned NOT NULL COMMENT '文章ID',
  `cid` smallint(5) unsigned NOT NULL COMMENT '分类ID',
  `title` varchar(255) NOT NULL DEFAULT '' COMMENT '标题',
  `introduction` varchar(255) DEFAULT '' COMMENT '简介',
  `content` longtext COMMENT '内容',
  `author` varchar(20) DEFAULT '' COMMENT '作者',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '状态 0 待审核  1 审核',
  `reading` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '阅读量',
  `thumb` varchar(255) DEFAULT '' COMMENT '缩略图',
  `photo` text COMMENT '图集',
  `is_top` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '是否置顶  0 不置顶  1 置顶',
  `is_recommend` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '是否推荐  0 不推荐  1 推荐',
  `sort` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '排序',
  `create_time` datetime NOT NULL COMMENT '创建时间',
  `publish_time` datetime NOT NULL COMMENT '发布时间'
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='文章表';

TRUNCATE TABLE `lotus_article`;
INSERT INTO `lotus_article` (`id`, `cid`, `title`, `introduction`, `content`, `author`, `status`, `reading`, `thumb`, `photo`, `is_top`, `is_recommend`, `sort`, `create_time`, `publish_time`) VALUES(1, 1, '测试文章一', '', '<p>测试内容</p>', 'admin', 1, 0, '', NULL, 0, 0, 0, '2017-04-11 14:10:10', '2017-04-11 14:09:45');

DROP TABLE IF EXISTS `lotus_auth_group`;
CREATE TABLE IF NOT EXISTS `lotus_auth_group` (
  `id` mediumint(8) unsigned NOT NULL,
  `title` char(100) NOT NULL DEFAULT '',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `rules` varchar(255) NOT NULL COMMENT '权限规则ID'
) ENGINE=MyISAM AUTO_INCREMENT=193 DEFAULT CHARSET=utf8 COMMENT='权限组表';

TRUNCATE TABLE `lotus_auth_group`;
INSERT INTO `lotus_auth_group` (`id`, `title`, `status`, `rules`) VALUES(1, '超级管理组', 1, '1,2,3,103');

DROP TABLE IF EXISTS `lotus_auth_group_access`;
CREATE TABLE IF NOT EXISTS `lotus_auth_group_access` (
  `uid` mediumint(8) unsigned NOT NULL,
  `group_id` mediumint(8) unsigned NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='权限组规则表';

TRUNCATE TABLE `lotus_auth_group_access`;
INSERT INTO `lotus_auth_group_access` (`uid`, `group_id`) VALUES(1, 1);
INSERT INTO `lotus_auth_group_access` (`uid`, `group_id`) VALUES(27, 2);
INSERT INTO `lotus_auth_group_access` (`uid`, `group_id`) VALUES(28, 2);
INSERT INTO `lotus_auth_group_access` (`uid`, `group_id`) VALUES(29, 50);
INSERT INTO `lotus_auth_group_access` (`uid`, `group_id`) VALUES(30, 52);
INSERT INTO `lotus_auth_group_access` (`uid`, `group_id`) VALUES(31, 54);
INSERT INTO `lotus_auth_group_access` (`uid`, `group_id`) VALUES(32, 2);
INSERT INTO `lotus_auth_group_access` (`uid`, `group_id`) VALUES(33, 64);
INSERT INTO `lotus_auth_group_access` (`uid`, `group_id`) VALUES(34, 1);
INSERT INTO `lotus_auth_group_access` (`uid`, `group_id`) VALUES(35, 52);
INSERT INTO `lotus_auth_group_access` (`uid`, `group_id`) VALUES(36, 35);
INSERT INTO `lotus_auth_group_access` (`uid`, `group_id`) VALUES(37, 52);
INSERT INTO `lotus_auth_group_access` (`uid`, `group_id`) VALUES(38, 65);
INSERT INTO `lotus_auth_group_access` (`uid`, `group_id`) VALUES(39, 59);
INSERT INTO `lotus_auth_group_access` (`uid`, `group_id`) VALUES(40, 69);
INSERT INTO `lotus_auth_group_access` (`uid`, `group_id`) VALUES(41, 69);
INSERT INTO `lotus_auth_group_access` (`uid`, `group_id`) VALUES(42, 69);
INSERT INTO `lotus_auth_group_access` (`uid`, `group_id`) VALUES(43, 61);
INSERT INTO `lotus_auth_group_access` (`uid`, `group_id`) VALUES(44, 62);
INSERT INTO `lotus_auth_group_access` (`uid`, `group_id`) VALUES(45, 64);
INSERT INTO `lotus_auth_group_access` (`uid`, `group_id`) VALUES(46, 69);
INSERT INTO `lotus_auth_group_access` (`uid`, `group_id`) VALUES(47, 70);
INSERT INTO `lotus_auth_group_access` (`uid`, `group_id`) VALUES(48, 70);
INSERT INTO `lotus_auth_group_access` (`uid`, `group_id`) VALUES(49, 70);
INSERT INTO `lotus_auth_group_access` (`uid`, `group_id`) VALUES(50, 69);
INSERT INTO `lotus_auth_group_access` (`uid`, `group_id`) VALUES(51, 70);
INSERT INTO `lotus_auth_group_access` (`uid`, `group_id`) VALUES(52, 70);
INSERT INTO `lotus_auth_group_access` (`uid`, `group_id`) VALUES(53, 70);
INSERT INTO `lotus_auth_group_access` (`uid`, `group_id`) VALUES(54, 70);
INSERT INTO `lotus_auth_group_access` (`uid`, `group_id`) VALUES(55, 1);
INSERT INTO `lotus_auth_group_access` (`uid`, `group_id`) VALUES(56, 1);
INSERT INTO `lotus_auth_group_access` (`uid`, `group_id`) VALUES(57, 72);
INSERT INTO `lotus_auth_group_access` (`uid`, `group_id`) VALUES(58, 72);
INSERT INTO `lotus_auth_group_access` (`uid`, `group_id`) VALUES(59, 72);
INSERT INTO `lotus_auth_group_access` (`uid`, `group_id`) VALUES(60, 72);
INSERT INTO `lotus_auth_group_access` (`uid`, `group_id`) VALUES(61, 1);
INSERT INTO `lotus_auth_group_access` (`uid`, `group_id`) VALUES(62, 78);
INSERT INTO `lotus_auth_group_access` (`uid`, `group_id`) VALUES(63, 78);
INSERT INTO `lotus_auth_group_access` (`uid`, `group_id`) VALUES(64, 1);
INSERT INTO `lotus_auth_group_access` (`uid`, `group_id`) VALUES(65, 117);
INSERT INTO `lotus_auth_group_access` (`uid`, `group_id`) VALUES(66, 90);
INSERT INTO `lotus_auth_group_access` (`uid`, `group_id`) VALUES(67, 90);
INSERT INTO `lotus_auth_group_access` (`uid`, `group_id`) VALUES(68, 102);
INSERT INTO `lotus_auth_group_access` (`uid`, `group_id`) VALUES(69, 102);
INSERT INTO `lotus_auth_group_access` (`uid`, `group_id`) VALUES(70, 102);
INSERT INTO `lotus_auth_group_access` (`uid`, `group_id`) VALUES(71, 106);
INSERT INTO `lotus_auth_group_access` (`uid`, `group_id`) VALUES(72, 106);
INSERT INTO `lotus_auth_group_access` (`uid`, `group_id`) VALUES(73, 112);
INSERT INTO `lotus_auth_group_access` (`uid`, `group_id`) VALUES(74, 111);
INSERT INTO `lotus_auth_group_access` (`uid`, `group_id`) VALUES(75, 78);
INSERT INTO `lotus_auth_group_access` (`uid`, `group_id`) VALUES(76, 126);
INSERT INTO `lotus_auth_group_access` (`uid`, `group_id`) VALUES(77, 1);
INSERT INTO `lotus_auth_group_access` (`uid`, `group_id`) VALUES(78, 123);
INSERT INTO `lotus_auth_group_access` (`uid`, `group_id`) VALUES(79, 1);
INSERT INTO `lotus_auth_group_access` (`uid`, `group_id`) VALUES(80, 123);
INSERT INTO `lotus_auth_group_access` (`uid`, `group_id`) VALUES(81, 129);
INSERT INTO `lotus_auth_group_access` (`uid`, `group_id`) VALUES(82, 135);
INSERT INTO `lotus_auth_group_access` (`uid`, `group_id`) VALUES(83, 129);
INSERT INTO `lotus_auth_group_access` (`uid`, `group_id`) VALUES(84, 138);
INSERT INTO `lotus_auth_group_access` (`uid`, `group_id`) VALUES(85, 137);
INSERT INTO `lotus_auth_group_access` (`uid`, `group_id`) VALUES(86, 1);
INSERT INTO `lotus_auth_group_access` (`uid`, `group_id`) VALUES(87, 138);
INSERT INTO `lotus_auth_group_access` (`uid`, `group_id`) VALUES(88, 138);
INSERT INTO `lotus_auth_group_access` (`uid`, `group_id`) VALUES(89, 138);
INSERT INTO `lotus_auth_group_access` (`uid`, `group_id`) VALUES(90, 138);
INSERT INTO `lotus_auth_group_access` (`uid`, `group_id`) VALUES(91, 117);
INSERT INTO `lotus_auth_group_access` (`uid`, `group_id`) VALUES(92, 156);
INSERT INTO `lotus_auth_group_access` (`uid`, `group_id`) VALUES(93, 156);
INSERT INTO `lotus_auth_group_access` (`uid`, `group_id`) VALUES(94, 163);
INSERT INTO `lotus_auth_group_access` (`uid`, `group_id`) VALUES(95, 164);
INSERT INTO `lotus_auth_group_access` (`uid`, `group_id`) VALUES(96, 145);
INSERT INTO `lotus_auth_group_access` (`uid`, `group_id`) VALUES(97, 172);
INSERT INTO `lotus_auth_group_access` (`uid`, `group_id`) VALUES(98, 175);
INSERT INTO `lotus_auth_group_access` (`uid`, `group_id`) VALUES(99, 1);
INSERT INTO `lotus_auth_group_access` (`uid`, `group_id`) VALUES(100, 173);
INSERT INTO `lotus_auth_group_access` (`uid`, `group_id`) VALUES(101, 180);
INSERT INTO `lotus_auth_group_access` (`uid`, `group_id`) VALUES(102, 181);
INSERT INTO `lotus_auth_group_access` (`uid`, `group_id`) VALUES(103, 185);
INSERT INTO `lotus_auth_group_access` (`uid`, `group_id`) VALUES(104, 187);
INSERT INTO `lotus_auth_group_access` (`uid`, `group_id`) VALUES(105, 187);
INSERT INTO `lotus_auth_group_access` (`uid`, `group_id`) VALUES(106, 187);

DROP TABLE IF EXISTS `lotus_auth_rule`;
CREATE TABLE IF NOT EXISTS `lotus_auth_rule` (
  `id` mediumint(8) unsigned NOT NULL,
  `name` varchar(80) NOT NULL DEFAULT '' COMMENT '规则名称',
  `title` varchar(20) NOT NULL,
  `type` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '状态',
  `pid` smallint(5) unsigned NOT NULL COMMENT '父级ID',
  `icon` varchar(50) DEFAULT '' COMMENT '图标',
  `sort` int(50) unsigned NOT NULL COMMENT '排序',
  `condition` char(100) DEFAULT ''
) ENGINE=MyISAM AUTO_INCREMENT=239 DEFAULT CHARSET=utf8 COMMENT='规则表';

TRUNCATE TABLE `lotus_auth_rule`;
INSERT INTO `lotus_auth_rule` (`id`, `name`, `title`, `type`, `status`, `pid`, `icon`, `sort`, `condition`) VALUES(1, 'admin/user/default', '用户管理', 1, 1, 0, 'xe68e', 10, '');
INSERT INTO `lotus_auth_rule` (`id`, `name`, `title`, `type`, `status`, `pid`, `icon`, `sort`, `condition`) VALUES(2, 'admin/user/userlist', '用户列表', 1, 1, 1, '', 0, '');
INSERT INTO `lotus_auth_rule` (`id`, `name`, `title`, `type`, `status`, `pid`, `icon`, `sort`, `condition`) VALUES(3, 'admin/auth/index', '权限管理', 1, 1, 1, '', 0, '');
INSERT INTO `lotus_auth_rule` (`id`, `name`, `title`, `type`, `status`, `pid`, `icon`, `sort`, `condition`) VALUES(4, 'admin/auth/showRole', '角色列表', 1, 1, 1, '', 0, '');
INSERT INTO `lotus_auth_rule` (`id`, `name`, `title`, `type`, `status`, `pid`, `icon`, `sort`, `condition`) VALUES(8, 'admin/api/app_list', '接口仓库', 1, 1, 7, '', 0, '');
INSERT INTO `lotus_auth_rule` (`id`, `name`, `title`, `type`, `status`, `pid`, `icon`, `sort`, `condition`) VALUES(5, 'admin/DbManage/default', '数据库', 1, 0, 0, 'xe631', 0, '');
INSERT INTO `lotus_auth_rule` (`id`, `name`, `title`, `type`, `status`, `pid`, `icon`, `sort`, `condition`) VALUES(6, 'admin/DbManage/index', '优化', 1, 1, 5, '', 0, '');
INSERT INTO `lotus_auth_rule` (`id`, `name`, `title`, `type`, `status`, `pid`, `icon`, `sort`, `condition`) VALUES(7, 'admin/api/default', '接口管理', 1, 0, 0, 'xe857', 100, '');
INSERT INTO `lotus_auth_rule` (`id`, `name`, `title`, `type`, `status`, `pid`, `icon`, `sort`, `condition`) VALUES(202, 'admin/file_system/index', '文件管理', 1, 0, 0, 'xe61d', 200, '');
INSERT INTO `lotus_auth_rule` (`id`, `name`, `title`, `type`, `status`, `pid`, `icon`, `sort`, `condition`) VALUES(203, 'sadasd', '一级菜单', 1, 0, 0, 'xe609', 20, '');
INSERT INTO `lotus_auth_rule` (`id`, `name`, `title`, `type`, `status`, `pid`, `icon`, `sort`, `condition`) VALUES(209, 'jhgjhghj', '二级', 1, 1, 203, 'xe660', 0, '');
INSERT INTO `lotus_auth_rule` (`id`, `name`, `title`, `type`, `status`, `pid`, `icon`, `sort`, `condition`) VALUES(210, 'jkjkh', '三级菜单', 1, 1, 209, '', 0, '');
INSERT INTO `lotus_auth_rule` (`id`, `name`, `title`, `type`, `status`, `pid`, `icon`, `sort`, `condition`) VALUES(216, 'admin/content/default', '内容管理', 1, 1, 0, 'xe655', 0, '');
INSERT INTO `lotus_auth_rule` (`id`, `name`, `title`, `type`, `status`, `pid`, `icon`, `sort`, `condition`) VALUES(217, 'admin/content/title_list', '标题库管理', 1, 1, 216, '', 0, '');
INSERT INTO `lotus_auth_rule` (`id`, `name`, `title`, `type`, `status`, `pid`, `icon`, `sort`, `condition`) VALUES(218, 'admin/content/juzi_list', '句子库管理', 1, 1, 216, '', 0, '');
INSERT INTO `lotus_auth_rule` (`id`, `name`, `title`, `type`, `status`, `pid`, `icon`, `sort`, `condition`) VALUES(220, 'admin/default', '基本配置', 1, 1, 0, 'xe631', 0, '');
INSERT INTO `lotus_auth_rule` (`id`, `name`, `title`, `type`, `status`, `pid`, `icon`, `sort`, `condition`) VALUES(221, 'admin/basic_config/rule_list', 'URL规则', 1, 1, 220, '', 0, '');
INSERT INTO `lotus_auth_rule` (`id`, `name`, `title`, `type`, `status`, `pid`, `icon`, `sort`, `condition`) VALUES(223, 'admin/content/from_list', '来源库管理', 1, 1, 216, '', 0, '');
INSERT INTO `lotus_auth_rule` (`id`, `name`, `title`, `type`, `status`, `pid`, `icon`, `sort`, `condition`) VALUES(224, 'admin/content/hotwords_list', '热词库管理', 1, 1, 216, '', 0, '');
INSERT INTO `lotus_auth_rule` (`id`, `name`, `title`, `type`, `status`, `pid`, `icon`, `sort`, `condition`) VALUES(225, 'admin/content/name_list', '人名库管理', 1, 1, 216, '', 0, '');
INSERT INTO `lotus_auth_rule` (`id`, `name`, `title`, `type`, `status`, `pid`, `icon`, `sort`, `condition`) VALUES(226, 'admin/content/city_list', '城市库管理', 1, 1, 216, '', 0, '');
INSERT INTO `lotus_auth_rule` (`id`, `name`, `title`, `type`, `status`, `pid`, `icon`, `sort`, `condition`) VALUES(227, 'admin/content/school_list', '学校库管理', 1, 1, 216, '', 0, '');
INSERT INTO `lotus_auth_rule` (`id`, `name`, `title`, `type`, `status`, `pid`, `icon`, `sort`, `condition`) VALUES(229, 'admin/content/hobby_list', '爱好库管理', 1, 1, 216, '', 0, '');
INSERT INTO `lotus_auth_rule` (`id`, `name`, `title`, `type`, `status`, `pid`, `icon`, `sort`, `condition`) VALUES(230, 'admin/content/book_list', '书名库管理', 1, 1, 216, '', 0, '');
INSERT INTO `lotus_auth_rule` (`id`, `name`, `title`, `type`, `status`, `pid`, `icon`, `sort`, `condition`) VALUES(231, 'admin/content/column_list', '栏目库管理', 1, 1, 216, '', 0, '');
INSERT INTO `lotus_auth_rule` (`id`, `name`, `title`, `type`, `status`, `pid`, `icon`, `sort`, `condition`) VALUES(232, 'admin/content/prize_list', '奖项库管理', 1, 1, 216, '', 0, '');
INSERT INTO `lotus_auth_rule` (`id`, `name`, `title`, `type`, `status`, `pid`, `icon`, `sort`, `condition`) VALUES(233, 'admin/basic_config/suffix_list', '后缀规则', 1, 1, 220, '', 0, '');
INSERT INTO `lotus_auth_rule` (`id`, `name`, `title`, `type`, `status`, `pid`, `icon`, `sort`, `condition`) VALUES(234, 'admin/content/pic_list', '图片库管理', 1, 1, 216, '', 0, '');
INSERT INTO `lotus_auth_rule` (`id`, `name`, `title`, `type`, `status`, `pid`, `icon`, `sort`, `condition`) VALUES(237, 'admin/basic_config/tpl', '模板配置', 1, 1, 220, '', 0, '');
INSERT INTO `lotus_auth_rule` (`id`, `name`, `title`, `type`, `status`, `pid`, `icon`, `sort`, `condition`) VALUES(236, 'admin/basic_config/keyword_list', '关键词', 1, 1, 220, '', 0, '');
INSERT INTO `lotus_auth_rule` (`id`, `name`, `title`, `type`, `status`, `pid`, `icon`, `sort`, `condition`) VALUES(238, 'admin/basic_config/edit_script', '脚本配置', 1, 1, 220, '', 0, '');

DROP TABLE IF EXISTS `lotus_category`;
CREATE TABLE IF NOT EXISTS `lotus_category` (
  `id` int(10) unsigned NOT NULL COMMENT '分类ID',
  `name` varchar(50) NOT NULL COMMENT '分类名称',
  `alias` varchar(50) DEFAULT '' COMMENT '导航别名',
  `content` longtext COMMENT '分类内容',
  `thumb` varchar(255) DEFAULT '' COMMENT '缩略图',
  `icon` varchar(20) DEFAULT '' COMMENT '分类图标',
  `list_template` varchar(50) DEFAULT '' COMMENT '分类列表模板',
  `detail_template` varchar(50) DEFAULT '' COMMENT '分类详情模板',
  `type` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '分类类型  1  列表  2 单页',
  `sort` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT '排序',
  `pid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '上级分类ID',
  `path` varchar(255) DEFAULT '' COMMENT '路径',
  `create_time` datetime NOT NULL
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='分类表';

TRUNCATE TABLE `lotus_category`;
INSERT INTO `lotus_category` (`id`, `name`, `alias`, `content`, `thumb`, `icon`, `list_template`, `detail_template`, `type`, `sort`, `pid`, `path`, `create_time`) VALUES(1, '分类一', '', '', '', '', '', '', 1, 0, 0, '0,', '2016-12-22 18:22:24');

DROP TABLE IF EXISTS `lotus_file`;
CREATE TABLE IF NOT EXISTS `lotus_file` (
  `id` int(11) NOT NULL,
  `url` varchar(255) DEFAULT NULL,
  `size` varchar(20) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=80 DEFAULT CHARSET=utf8;

TRUNCATE TABLE `lotus_file`;
INSERT INTO `lotus_file` (`id`, `url`, `size`) VALUES(78, '/public/uploads/20180122/110b27950ae3e564d25d444bed1d49f2.jpg', '25k');
INSERT INTO `lotus_file` (`id`, `url`, `size`) VALUES(79, '/public/uploads/20180122/f2490bd3510643a2a678f0050548ac4a.jpg', '157k');

DROP TABLE IF EXISTS `lotus_link`;
CREATE TABLE IF NOT EXISTS `lotus_link` (
  `id` int(10) unsigned NOT NULL,
  `name` varchar(20) NOT NULL DEFAULT '' COMMENT '链接名称',
  `link` varchar(255) DEFAULT '' COMMENT '链接地址',
  `image` varchar(255) DEFAULT '' COMMENT '链接图片',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '状态 1 显示  2 隐藏',
  `sort` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '排序'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='友情链接表';

TRUNCATE TABLE `lotus_link`;
DROP TABLE IF EXISTS `lotus_m_book`;
CREATE TABLE IF NOT EXISTS `lotus_m_book` (
  `id` int(11) NOT NULL,
  `m_book` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

TRUNCATE TABLE `lotus_m_book`;
DROP TABLE IF EXISTS `lotus_m_city`;
CREATE TABLE IF NOT EXISTS `lotus_m_city` (
  `id` int(11) NOT NULL,
  `m_city` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

TRUNCATE TABLE `lotus_m_city`;
DROP TABLE IF EXISTS `lotus_m_column`;
CREATE TABLE IF NOT EXISTS `lotus_m_column` (
  `id` int(11) NOT NULL,
  `m_column` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

TRUNCATE TABLE `lotus_m_column`;
DROP TABLE IF EXISTS `lotus_m_from`;
CREATE TABLE IF NOT EXISTS `lotus_m_from` (
  `id` int(11) NOT NULL,
  `m_from` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

TRUNCATE TABLE `lotus_m_from`;
DROP TABLE IF EXISTS `lotus_m_hobby`;
CREATE TABLE IF NOT EXISTS `lotus_m_hobby` (
  `id` int(11) NOT NULL,
  `m_hobby` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

TRUNCATE TABLE `lotus_m_hobby`;
DROP TABLE IF EXISTS `lotus_m_hotwords`;
CREATE TABLE IF NOT EXISTS `lotus_m_hotwords` (
  `id` int(11) NOT NULL,
  `m_hotwords` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

TRUNCATE TABLE `lotus_m_hotwords`;
DROP TABLE IF EXISTS `lotus_m_juzi`;
CREATE TABLE IF NOT EXISTS `lotus_m_juzi` (
  `id` int(11) NOT NULL,
  `juzi` varchar(255) DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

TRUNCATE TABLE `lotus_m_juzi`;
DROP TABLE IF EXISTS `lotus_m_keyword`;
CREATE TABLE IF NOT EXISTS `lotus_m_keyword` (
  `id` int(11) NOT NULL,
  `m_keyword` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

TRUNCATE TABLE `lotus_m_keyword`;
DROP TABLE IF EXISTS `lotus_m_mulu`;
CREATE TABLE IF NOT EXISTS `lotus_m_mulu` (
  `config_name` varchar(11) DEFAULT '',
  `value` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

TRUNCATE TABLE `lotus_m_mulu`;
INSERT INTO `lotus_m_mulu` (`config_name`, `value`) VALUES('tpl_name', 'app');

DROP TABLE IF EXISTS `lotus_m_name`;
CREATE TABLE IF NOT EXISTS `lotus_m_name` (
  `id` int(11) NOT NULL,
  `m_name` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

TRUNCATE TABLE `lotus_m_name`;
DROP TABLE IF EXISTS `lotus_m_pic`;
CREATE TABLE IF NOT EXISTS `lotus_m_pic` (
  `id` int(11) NOT NULL,
  `m_pic` varchar(255) DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

TRUNCATE TABLE `lotus_m_pic`;
DROP TABLE IF EXISTS `lotus_m_prize`;
CREATE TABLE IF NOT EXISTS `lotus_m_prize` (
  `id` int(11) NOT NULL,
  `m_prize` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

TRUNCATE TABLE `lotus_m_prize`;
DROP TABLE IF EXISTS `lotus_m_school`;
CREATE TABLE IF NOT EXISTS `lotus_m_school` (
  `id` int(11) NOT NULL,
  `m_school` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

TRUNCATE TABLE `lotus_m_school`;
DROP TABLE IF EXISTS `lotus_m_suffix`;
CREATE TABLE IF NOT EXISTS `lotus_m_suffix` (
  `id` int(11) NOT NULL,
  `m_suffix` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

TRUNCATE TABLE `lotus_m_suffix`;
DROP TABLE IF EXISTS `lotus_m_title`;
CREATE TABLE IF NOT EXISTS `lotus_m_title` (
  `id` int(11) NOT NULL,
  `title` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

TRUNCATE TABLE `lotus_m_title`;
DROP TABLE IF EXISTS `lotus_m_url`;
CREATE TABLE IF NOT EXISTS `lotus_m_url` (
  `id` int(11) NOT NULL,
  `m_url` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

TRUNCATE TABLE `lotus_m_url`;
DROP TABLE IF EXISTS `lotus_nav`;
CREATE TABLE IF NOT EXISTS `lotus_nav` (
  `id` int(10) unsigned NOT NULL,
  `pid` int(10) unsigned NOT NULL COMMENT '父ID',
  `name` varchar(20) NOT NULL COMMENT '导航名称',
  `alias` varchar(20) DEFAULT '' COMMENT '导航别称',
  `link` varchar(255) DEFAULT '' COMMENT '导航链接',
  `icon` varchar(255) DEFAULT '' COMMENT '导航图标',
  `target` varchar(10) DEFAULT '' COMMENT '打开方式',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '状态  0 隐藏  1 显示',
  `sort` int(11) NOT NULL DEFAULT '0' COMMENT '排序'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='导航表';

TRUNCATE TABLE `lotus_nav`;
DROP TABLE IF EXISTS `lotus_options`;
CREATE TABLE IF NOT EXISTS `lotus_options` (
  `option_value` varchar(255) NOT NULL,
  `option_name` int(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

TRUNCATE TABLE `lotus_options`;
DROP TABLE IF EXISTS `lotus_slide`;
CREATE TABLE IF NOT EXISTS `lotus_slide` (
  `id` int(10) unsigned NOT NULL,
  `cid` int(10) unsigned NOT NULL COMMENT '分类ID',
  `name` varchar(50) NOT NULL COMMENT '轮播图名称',
  `description` varchar(255) DEFAULT '' COMMENT '说明',
  `link` varchar(255) DEFAULT '' COMMENT '链接',
  `target` varchar(10) DEFAULT '' COMMENT '打开方式',
  `image` varchar(255) DEFAULT '' COMMENT '轮播图片',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '状态  1 显示  0  隐藏',
  `sort` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '排序'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='轮播图表';

TRUNCATE TABLE `lotus_slide`;
DROP TABLE IF EXISTS `lotus_slide_category`;
CREATE TABLE IF NOT EXISTS `lotus_slide_category` (
  `id` int(10) unsigned NOT NULL,
  `name` varchar(50) NOT NULL COMMENT '轮播图分类'
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='轮播图分类表';

TRUNCATE TABLE `lotus_slide_category`;
INSERT INTO `lotus_slide_category` (`id`, `name`) VALUES(1, '首页轮播');

DROP TABLE IF EXISTS `lotus_system`;
CREATE TABLE IF NOT EXISTS `lotus_system` (
  `id` int(10) unsigned NOT NULL,
  `name` varchar(50) NOT NULL COMMENT '配置项名称',
  `value` text NOT NULL COMMENT '配置项值'
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='系统配置表';

TRUNCATE TABLE `lotus_system`;
INSERT INTO `lotus_system` (`id`, `name`, `value`) VALUES(1, 'site_config', 'a:7:{s:10:"site_title";s:30:"Think Admin 后台管理系统";s:9:"seo_title";s:0:"";s:11:"seo_keyword";s:0:"";s:15:"seo_description";s:0:"";s:14:"site_copyright";s:0:"";s:8:"site_icp";s:0:"";s:11:"site_tongji";s:0:"";}');

DROP TABLE IF EXISTS `lotus_user`;
CREATE TABLE IF NOT EXISTS `lotus_user` (
  `id` int(10) unsigned NOT NULL,
  `username` varchar(50) NOT NULL COMMENT '用户名',
  `password` varchar(50) NOT NULL COMMENT '密码',
  `mobile` varchar(11) DEFAULT '' COMMENT '手机',
  `email` varchar(50) DEFAULT '' COMMENT '邮箱',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '用户状态  1 正常  2 禁止',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `last_login_time` datetime DEFAULT NULL COMMENT '最后登陆时间',
  `last_login_ip` varchar(50) DEFAULT '' COMMENT '最后登录IP'
) ENGINE=MyISAM AUTO_INCREMENT=107 DEFAULT CHARSET=utf8 COMMENT='用户表';

TRUNCATE TABLE `lotus_user`;

DROP TABLE IF EXISTS `m_title`;
CREATE TABLE IF NOT EXISTS `m_title` (
  `id` int(11) NOT NULL,
  `m_title` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

TRUNCATE TABLE `m_title`;

ALTER TABLE `lotus_api`
  ADD PRIMARY KEY (`id`);

ALTER TABLE `lotus_app`
  ADD PRIMARY KEY (`id`),
  ADD KEY `app_id` (`app_id`);

ALTER TABLE `lotus_article`
  ADD PRIMARY KEY (`id`);

ALTER TABLE `lotus_auth_group`
  ADD PRIMARY KEY (`id`);

ALTER TABLE `lotus_auth_group_access`
  ADD UNIQUE KEY `uid_group_id` (`uid`,`group_id`),
  ADD KEY `uid` (`uid`),
  ADD KEY `group_id` (`group_id`);

ALTER TABLE `lotus_auth_rule`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`) USING BTREE;

ALTER TABLE `lotus_category`
  ADD PRIMARY KEY (`id`);

ALTER TABLE `lotus_file`
  ADD PRIMARY KEY (`id`);

ALTER TABLE `lotus_link`
  ADD PRIMARY KEY (`id`);

ALTER TABLE `lotus_m_book`
  ADD PRIMARY KEY (`id`);

ALTER TABLE `lotus_m_city`
  ADD PRIMARY KEY (`id`);

ALTER TABLE `lotus_m_column`
  ADD PRIMARY KEY (`id`);

ALTER TABLE `lotus_m_from`
  ADD PRIMARY KEY (`id`);

ALTER TABLE `lotus_m_hobby`
  ADD PRIMARY KEY (`id`);

ALTER TABLE `lotus_m_hotwords`
  ADD PRIMARY KEY (`id`);

ALTER TABLE `lotus_m_juzi`
  ADD PRIMARY KEY (`id`);

ALTER TABLE `lotus_m_keyword`
  ADD PRIMARY KEY (`id`);

ALTER TABLE `lotus_m_name`
  ADD PRIMARY KEY (`id`);

ALTER TABLE `lotus_m_pic`
  ADD PRIMARY KEY (`id`);

ALTER TABLE `lotus_m_prize`
  ADD PRIMARY KEY (`id`);

ALTER TABLE `lotus_m_school`
  ADD PRIMARY KEY (`id`);

ALTER TABLE `lotus_m_suffix`
  ADD PRIMARY KEY (`id`);

ALTER TABLE `lotus_m_title`
  ADD PRIMARY KEY (`id`);

ALTER TABLE `lotus_m_url`
  ADD PRIMARY KEY (`id`);

ALTER TABLE `lotus_nav`
  ADD PRIMARY KEY (`id`);

ALTER TABLE `lotus_options`
  ADD PRIMARY KEY (`option_value`);

ALTER TABLE `lotus_slide`
  ADD PRIMARY KEY (`id`);

ALTER TABLE `lotus_slide_category`
  ADD PRIMARY KEY (`id`);

ALTER TABLE `lotus_system`
  ADD PRIMARY KEY (`id`);

ALTER TABLE `lotus_user`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

ALTER TABLE `m_title`
  ADD PRIMARY KEY (`id`);


ALTER TABLE `lotus_api`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=46;
ALTER TABLE `lotus_app`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=69;
ALTER TABLE `lotus_article`
  MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '文章ID',AUTO_INCREMENT=2;
ALTER TABLE `lotus_auth_group`
  MODIFY `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=193;
ALTER TABLE `lotus_auth_rule`
  MODIFY `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=239;
ALTER TABLE `lotus_category`
  MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '分类ID',AUTO_INCREMENT=2;
ALTER TABLE `lotus_file`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=80;
ALTER TABLE `lotus_link`
  MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT;
ALTER TABLE `lotus_m_book`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
ALTER TABLE `lotus_m_city`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
ALTER TABLE `lotus_m_column`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
ALTER TABLE `lotus_m_from`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
ALTER TABLE `lotus_m_hobby`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
ALTER TABLE `lotus_m_hotwords`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
ALTER TABLE `lotus_m_juzi`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
ALTER TABLE `lotus_m_keyword`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
ALTER TABLE `lotus_m_name`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
ALTER TABLE `lotus_m_pic`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
ALTER TABLE `lotus_m_prize`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
ALTER TABLE `lotus_m_school`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
ALTER TABLE `lotus_m_suffix`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
ALTER TABLE `lotus_m_title`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
ALTER TABLE `lotus_m_url`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
ALTER TABLE `lotus_nav`
  MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT;
ALTER TABLE `lotus_slide`
  MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT;
ALTER TABLE `lotus_slide_category`
  MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
ALTER TABLE `lotus_system`
  MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
ALTER TABLE `lotus_user`
  MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=107;
ALTER TABLE `m_title`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

