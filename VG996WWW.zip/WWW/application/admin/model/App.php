<?php
namespace app\admin\model;
use think\Model;
class App extends Model
{
	protected $autoWriteTimestamp = true;
}
