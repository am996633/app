<?php
namespace app\admin\validate;

use think\Validate;

class School extends Validate
{
    protected $rule = [
        'm_school'       => 'require|min:3|max:100|unique:m_school',
    ];
    protected $message = [
        'm_school.require' =>'VG目录站群：不能为空',
        'm_school.unique'  =>'VG目录站群：不能重复',
        'm_school.min'     =>'VG目录站群：太短',
        'm_school.max'     =>'VG目录站群：太长',
    ];
}