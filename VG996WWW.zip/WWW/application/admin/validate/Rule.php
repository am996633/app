<?php
namespace app\admin\validate;

use think\Validate;

class Rule extends Validate
{
    protected $rule = [
        'm_url'       => 'require|min:3|max:100|unique:m_url',
    ];
    protected $message = [
        'm_url.require' =>'VG目录站群：不能为空',
        'm_url.unique'      =>'VG目录站群：不能重复',
        'm_url.min'     =>'VG目录站群：太短',
        'm_url.max'     =>'VG目录站群：太长',
    ];
}