<?php
namespace app\admin\validate;

use think\Validate;

class Name extends Validate
{
    protected $rule = [
        'm_name'       => 'require|min:3|max:100|unique:m_name',
    ];
    protected $message = [
        'm_name.require' =>'VG目录站群：不能为空',
        'm_name.unique'  =>'VG目录站群：不能重复',
        'm_name.min'     =>'VG目录站群：太短',
        'm_name.max'     =>'VG目录站群：太长',
    ];
}