<?php
namespace app\admin\validate;

use think\Validate;

class Book extends Validate
{
    protected $rule = [
        'm_book'       => 'require|min:3|max:100|unique:m_book',
    ];
    protected $message = [
        'm_book.require' =>'VG目录站群：不能为空',
        'm_book.unique'  =>'VG目录站群：不能重复',
        'm_book.min'     =>'VG目录站群：太短',
        'm_book.max'     =>'VG目录站群：太长',
    ];
}