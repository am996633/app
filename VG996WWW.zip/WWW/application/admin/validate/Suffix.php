<?php
namespace app\admin\validate;

use think\Validate;

class Suffix extends Validate
{
    protected $rule = [
        'm_suffix'       => 'require|min:3|max:100|unique:m_suffix',
    ];
    protected $message = [
        'm_suffix.require' =>'VG目录站群：不能为空',
        'm_suffix.unique'  =>'VG目录站群：不能重复',
        'm_suffix.min'     =>'VG目录站群：太短',
        'm_suffix.max'     =>'VG目录站群：太长',
    ];
}