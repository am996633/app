<?php
namespace app\admin\validate;

use think\Validate;

class Hotwords extends Validate
{
    protected $rule = [
        'm_hotwords'       => 'require|min:3|max:100|unique:m_hotwords',
    ];
    protected $message = [
        'm_hotwords.require' =>'VG目录站群：不能为空',
        'm_hotwords.unique'  =>'VG目录站群：不能重复',
        'm_hotwords.min'     =>'VG目录站群：太短',
        'm_hotwords.max'     =>'VG目录站群：太长',
    ];
}