<?php
namespace app\admin\validate;

use think\Validate;

class From extends Validate
{
    protected $rule = [
        'm_from'       => 'require|min:3|max:100|unique:m_from',
    ];
    protected $message = [
        'm_from.require' =>'VG目录站群：不能为空',
        'm_from.unique'  =>'VG目录站群：不能重复',
        'm_fromm_from.min'     =>'VG目录站群：太短',
        'm_from.max'     =>'VG目录站群：太长',
    ];
}