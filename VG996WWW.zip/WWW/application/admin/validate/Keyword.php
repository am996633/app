<?php
namespace app\admin\validate;

use think\Validate;

class Keyword extends Validate
{
    protected $rule = [
        'm_keyword'       => 'require|min:3|max:100|unique:m_keyword',
    ];
    protected $message = [
        'm_keyword.require' =>'VG目录站群：不能为空',
        'm_keyword.unique'  =>'VG目录站群：不能重复',
        'm_keyword.min'     =>'VG目录站群：太短',
        'm_keyword.max'     =>'VG目录站群：太长',
    ];
}