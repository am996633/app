<?php
namespace app\admin\validate;

use think\Validate;

class Auth extends Validate
{
    protected $rule = [
        'pid'       => 'require',
        'title'     => 'require|min:2|max:15|unique:auth_rule',
        'name'      => 'require|unique:auth_rule',
        'sort'      =>'require|number',
    ];
    protected $message = [
    	'title.require' =>'VG目录站群：菜单名称不能为空',
    	'title.min'		=>'VG目录站群：菜单名称太短',
    	'title.max'		=>'VG目录站群：菜单名称太长',
    	'title.unique'	=>'VG目录站群：系统中已经存在该菜单名称',
    	'name.require'	=>'VG目录站群：控制器不能为空',
    	'name.unique'	=>'VG目录站群：控制器必须唯一',
        'sort.require'  =>'VG目录站群：排序不能为空',
        'sort.number'   =>'VG目录站群：排序必须为数字',     
    ];
    protected $scene = [
        'edit'  => [
            'title',
            'name',
            'sort',
        ],
    ];

}
