<?php
namespace app\admin\validate;

use think\Validate;

class Hobby extends Validate
{
    protected $rule = [
        'm_hobby'       => 'require|min:3|max:100|unique:m_hobby',
    ];
    protected $message = [
        'm_hobby.require' =>'VG目录站群：不能为空',
        'm_hobby.unique'  =>'VG目录站群：不能重复',
        'm_hobby.min'     =>'VG目录站群：太短',
        'm_hobby.max'     =>'VG目录站群：太长',
    ];
}