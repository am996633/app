<?php
namespace app\admin\validate;

use think\Validate;

class Prize extends Validate
{
    protected $rule = [
        'm_prize'       => 'require|min:3|max:100|unique:m_prize',
    ];
    protected $message = [
        'm_prize.require' =>'VG目录站群：不能为空',
        'm_prize.unique'  =>'VG目录站群：不能重复',
        'm_prize.min'     =>'VG目录站群：太短',
        'm_prize.max'     =>'VG目录站群：太长',
    ];
}