<?php
namespace app\admin\validate;

use think\Validate;

class Title extends Validate
{
    protected $rule = [
        'title'       => 'require|min:3|max:100|unique:m_title',
    ];
    protected $message = [
        'title.require' =>'VG目录站群：标题名称不能为空',
        'title.unique'      =>'VG目录站群：标题名称不能重复',
        'title.min'     =>'VG目录站群：标题名称太短',
        'title.max'     =>'VG目录站群：标题名称太长',
    ];
}