<?php
namespace app\admin\validate;

use think\Validate;

class Juzi extends Validate
{
    protected $rule = [
        'juzi'       => 'require|min:3|max:100|unique:m_juzi',
    ];
    protected $message = [
        'juzi.require' =>'VG目录站群：不能为空',
        'juzi.unique'  =>'VG目录站群：不能重复',
        'juzi.min'     =>'VG目录站群：太短',
        'juzi.max'     =>'VG目录站群：太长',
    ];
}