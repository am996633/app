<?php
namespace app\admin\validate;

use think\Validate;

class City extends Validate
{
    protected $rule = [
        'm_city'       => 'require|min:3|max:100|unique:m_city',
    ];
    protected $message = [
        'm_city.require' =>'VG目录站群：不能为空',
        'm_city.unique'  =>'VG目录站群：不能重复',
        'm_city.min'     =>'VG目录站群：太短',
        'm_city.max'     =>'VG目录站群：太长',
    ];
}