<?php
namespace app\admin\validate;

use think\Validate;

class Column extends Validate
{
    protected $rule = [
        'm_column'       => 'require|min:3|max:100|unique:m_column',
    ];
    protected $message = [
        'm_column.require' =>'VG目录站群：不能为空',
        'm_column.unique'  =>'VG目录站群：不能重复',
        'm_column.min'     =>'VG目录站群：太短',
        'm_column.max'     =>'VG目录站群：太长',
    ];
}