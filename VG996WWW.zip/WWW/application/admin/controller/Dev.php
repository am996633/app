<?php
namespace app\admin\controller;

use think\Db;

class Dev extends Main
{
    function simple(){

        $request = $this->request;
        if($request->isPost() ){
            $simple_config                = $this->request->post('simple_config/a');
            // $site_config['code'] = htmlspecialchars_decode($site_config['code']);
            $data['value']              = serialize($simple_config);
            if (Db::name('system')->where('name', 'simple_config')->update($data) !== false) {
                $this->success('VG目录站群：提交成功');
            } else {
                $this->error('VG目录站群：提交失败');
            }
        }else{
            $simple_config = Db::name('system')->field('value')->where('name', 'simple_config')->find();
            $simple_config = unserialize($simple_config['value']);


            return $this->fetch('simple', ['simple_config' => $simple_config]);
        }
       
    }

    function auth(){
        $request = $this->request;
        if($request->isPost() ){
            $auth_config                = $this->request->post('auth_config/a');
            // $site_config['code'] = htmlspecialchars_decode($site_config['code']);
            $data['value']              = serialize($auth_config);
            if (Db::name('system')->where('name', 'auth_config')->update($data) !== false) {
                $this->success('VG目录站群：提交成功');
            } else {
                $this->error('VG目录站群：提交失败');
            }
        }else{
            $auth_config = Db::name('system')->field('value')->where('name', 'auth_config')->find();
            $auth_config = unserialize($auth_config['value']);


            return $this->fetch('auth', ['auth_config' => $auth_config]);
        }
    }


    function site_config(){
        $request = $this->request;
        if($request->isPost() ){
            $site_config                = $this->request->post('site_config/a');
            // $site_config['code'] = htmlspecialchars_decode($site_config['code']);
            $data['value']              = serialize($site_config);
            if (Db::name('system')->where('name', 'site_config')->update($data) !== false) {
                $this->success('VG目录站群：提交成功');
            } else {
                $this->error('VG目录站群：提交失败');
            }
        }else{
            $site_config = Db::name('system')->field('value')->where('name', 'site_config')->find();
            $site_config = unserialize($site_config['value']);
            return $this->fetch('site_config', ['site_config' => $site_config]);
        }
    }

}
