<?php
namespace app\admin\controller;

use think\Db;
class Index extends Main
{  
    /**
     * 首页展示
    */
    public function index()
    {
        return $this->fetch();
    }
    /**
     * 桌面页
    */
    public function welcome()
    {

        $request = $this->request;

        if($request->isPost()){
            $tpl_name = $request->post('tpl_name');

            if(strlen(trim( $tpl_name))>50){
                $this->error('长度限制在50个英文字符');
            }

            Db::name('m_mulu')
                ->where('config_name','tpl_name')
                ->update(['value'=>$tpl_name]);
            $this->success('VG目录站群：设置成功');

        }else{
            $tpl_name = Db::name('m_mulu')->where('config_name','tpl_name')->value('value');
            $this->assign('tpl_name',$tpl_name);
            return $this->fetch();
        }

        
    }

    public function clear_cache(){
        $files = getFile('cache');

        if($files['0']==null){
            $this->error('VG目录站群：无缓存,无需清除');
        }

        // var_dump($files);
        foreach ($files  as  $file) {
            unlink('cache'.DS.$file);
        }
        $this->success('VG目录站群：已清空缓存');
    }

}
