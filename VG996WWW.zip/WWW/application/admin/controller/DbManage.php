<?php
namespace app\admin\controller;

use think\Db;

class DbManage extends Main
{
  //VG目录站群：数据库维护页面展示 
  function index(){
    $db_names =  Db::getTables();
    $count = count($db_names);
    $this->assign('db_names',$db_names);
    $this->assign('count',$count);
    return $this->fetch();
  }
  
}
