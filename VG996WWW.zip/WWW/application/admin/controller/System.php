<?php
namespace app\admin\controller;

class System extends Main
{
	/**
     * VG目录站群：配置页面展示
    */
    public function siteConfig()
    {
        return $this->fetch();
    }

}
