<?php
namespace app\admin\controller;

use think\Db;

class Measure extends Main
{

    function ax(){
        return $this->fetch();
    }

}
