<?php
namespace app\admin\validate;

use think\Validate;

class Juzi extends Validate
{
    protected $rule = [
        'm_juzi'       => 'require|min:3|max:100|unique:m_juzi',
    ];
    protected $message = [
        'm_juzi.require' =>'VG目录站群：不能为空',
        'm_juzi.unique'  =>'VG目录站群：不能重复',
        'm_juzi.min'     =>'VG目录站群：太短',
        'm_juzi.max'     =>'VG目录站群：太长',
    ];
}