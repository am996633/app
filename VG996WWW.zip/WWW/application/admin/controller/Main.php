<?php
namespace app\admin\controller;

use org\Auth;
use think\Controller;
use think\Db;
use think\Session;


class Main extends Controller
{
    /**
     * VG目录站群：初始化
    */
    public function _initialize()
    {
        $module = $this->request->module();
        if (!lotus_is_installed() && $module != 'install') {
            header('Location: ' . lotus_get_root() . '/?s=install');
            exit;
        }

        $username  = session('username');
        if (empty($username)) {
            $this->redirect('admin/user/login');
        }
        $this->checkAuth();
        $this->getMenu();
    }
    /**
     * 权限检查
     * @return bool
     */
    protected function checkAuth()
    {

        if (!Session::has('user_id')) {
            $this->redirect('admin/login/index');
        }

        $module     = $this->request->module();
        $controller = $this->request->controller();
        $action     = $this->request->action();
        // VG目录站群：排除权限
        $not_check = [
                'admin/Index/index',
                'admin/Index/welcome',
                'admin/AuthGroup/getjson',
                'admin/System/clear',
                // 'admin/Content/add_title',
                // 'admin/Content/edit_title',
                // 'admin/Content/add_juzi',
                // 'admin/Content/edit_juzi',
                // 'admin/Content/edit_form',
                // 'admin/Content/add_form',
                // 'admin/Content/edit_hotwords',
                // 'admin/Content/add_hotwords',
                // 'admin/Content/edit_name',
                // 'admin/Content/add_name',
                // 'admin/Content/edit_city',
                // 'admin/Content/add_city',
                // 'admin/Content/edit_school',
                // 'admin/Content/add_school',
                 // 'admin/Content/edit_hobby',
                // 'admin/Content/add_hobby',
                 // 'admin/Content/edit_book',
                // 'admin/Content/add_book',
                 // 'admin/Content/edit_column',
                // 'admin/Content/add_column',
                // 'admin/Content/edit_prize',
                // 'admin/Content/add_prize',
                // 'admin/Content/edit_pic',
                // 'admin/Content/add_pic',
                // 'admin/Content/edit_keyword',
                // 'admin/Content/add_keyword',

                // 'admin/BasicConfig/edit_rule',
                // 'admin/BasicConfig/add_rule',

                // 'admin/BasicConfig/edit_suffix',
                // 'admin/BasicConfig/add_suffix',

                // 'admin/BasicConfig/edit_suffix',
                // 'admin/BasicConfig/add_suffix',

                // 'admin/BasicConfig/add_keyword',
                // 'admin/BasicConfig/edit_keyword', 
                
                


            ];

        if (!in_array($module . '/' . $controller . '/' . $action, $not_check)) {
            $auth     = new Auth();
            $admin_id = Session::get('user_id');
            if (!$auth->check($module . '/' . $controller . '/' . $action, $admin_id) && $admin_id != 1) {
                $this->error('VG目录站群：没有权限','');
            }
        }
    }
    
    /**
     * VG目录站群：获取侧边栏菜单
     */
    protected function getMenu()
    {
        $menu           = [];
        $admin_id       = Session::get('user_id');
        $auth           = new Auth();
        $auth_rule_list = Db::name('auth_rule')->where('status', 1)->order(['sort' => 'ASC'])->select();
        foreach ($auth_rule_list as $value) {
            if ($auth->check($value['name'], $admin_id) || $admin_id == 1) {
                $menu[] = $value;
            }
        }
        $menu = !empty($menu) ? array2tree($menu) : [];
        $this->assign('menu', $menu);
    }
}
