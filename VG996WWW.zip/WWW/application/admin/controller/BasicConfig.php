<?php
namespace app\admin\controller;

use \think\Db;
use \think\Reuquest;
class BasicConfig extends Main
{
	function rule_list(){
		$rule_list =  Db::name('m_url')
			->order('id desc')
			->paginate(20);
		$this->assign('rule_list',$rule_list);
		return $this->fetch();
	}




    function add_rule(){
        $request = $this->request;
        if($request->isPost()){
            $post = $request->post();
            $validate  = validate('rule'); 
            $res = $validate->check($post);

             // Db::name('m_juzi')->insert($post);
             //    $this->success('增加成功');

            if($res!==true){
                $this->error($validate->getError());
            }else{
                Db::name('m_url')->insert($post);
                $this->success('VG目录站群：增加成功');
            }
        }else{
            $this->assign('gongneng','rule');
            $this->assign('field','规则');
            return $this->fetch('add_rule');
        }
    }

   function edit_rule($id=''){
        $request = $this->request;
        if($request->isPost()){
            $post = $request->post();
            $validate  = validate('rule'); 
            $res = $validate->check($post);
            if($res!==true){
                $this->error($validate->getError());
            }else{
                Db::name('m_url')->where('id',$post['id'])->update(['m_url'=>$post['m_url'] ]);
                $this->success('VG目录站群：修改成功');
            }
        }else{
            $rule = Db::name('m_url')->find($id);
            $this->assign('gongneng','rule');
            $this->assign('field','规则');
            return $this->fetch('edit_rule',['rule'=>$rule]);
        }
    }



    function delete_all_rule(){
        Db::query("TRUNCATE TABLE lotus_m_url");
        $this->success('已清空');    
    }


    function delete_many_rule(){
        $id = $this->request->post('id');
        $res =  Db::name('m_url')
        ->delete($id);
        // if($res){
        //     $this->success('success');
        // }else{
        //     $this->error('error');
        // }
        
    }



	function import_rule(){
        $request = $this->request;
        if($file=request()->file('file')){
            if($file){
                $info = $file->move(ROOT_PATH . 'public' . DS . 'uploads');
                if($info){
                    // 输出 jpg
                    // echo $info->getExtension();
                    // 输出 20160820/42a79759f284b767dfcb2a0197904287.jpg
                    $save_name = ROOT_PATH . 'public' . DS . 'uploads'.DS.$info->getSaveName();
                    // 输出 42a79759f284b767dfcb2a0197904287.jpg
                    // echo $info->getFilename();
                    $this->import_txt_rule($save_name);
                    $this->success('VG目录站群：导入成功');
                    // $data = [ 
                    //     'code'=>0,
                    //     'msg'=>'success',
                    //     'data'=>['src'=>$save_name]
                    // ];
                    // return json($data);
                }else{
                // 上传失败获取错误信息
                    $data = [ 
                        'code'=>-1,
                        'msg'=>'error',
                        'data'=>['src'=>'']
                    ];
                    return json($data);
                }
            }
            
        }else{
             return $this->fetch();
        }

    }



    function  import_txt_rule($save_name){
	    $file=fopen($save_name, "r");
	    $txt=array();
	        $i=0;
	        //输出文本中所有的行，直到文件结束为止。
	        while(! feof($file))
	        {
	         $txt[$i]= fgets($file);//fgets()函数从文件指针中读取一行
	         $i++;
	        }
	        fclose($file);
	        $txt=array_filter($txt);
	        foreach ($txt as $key => $value) {
	            $data = [];
	            $data['m_url'] =   $value;
	            Db::name('m_url')
	                ->insert($data);
	        }
    }




    function delete_rule($id){
        Db::name('m_url')->delete($id);
        $this->success('VG目录站群：删除成功');
    }



    //后缀


    function suffix_list(){
        $suffix_list =  Db::name('m_suffix')
            ->order('id desc')
            ->paginate(20);
        $this->assign('suffix_list',$suffix_list);
        return $this->fetch();
    }


    function import_suffix(){
        $request = $this->request;
        if($file=request()->file('file')){
            if($file){
                $info = $file->move(ROOT_PATH . 'public' . DS . 'uploads');
                if($info){
                    // 输出 jpg
                    // echo $info->getExtension();
                    // 输出 20160820/42a79759f284b767dfcb2a0197904287.jpg
                    $save_name = ROOT_PATH . 'public' . DS . 'uploads'.DS.$info->getSaveName();
                    // 输出 42a79759f284b767dfcb2a0197904287.jpg
                    // echo $info->getFilename();
                    $this->import_txt_suffix($save_name);
                    $this->success('VG目录站群：导入成功');
                    // $data = [ 
                    //     'code'=>0,
                    //     'msg'=>'success',
                    //     'data'=>['src'=>$save_name]
                    // ];
                    // return json($data);
                }else{
                // 上传失败获取错误信息
                    $data = [ 
                        'code'=>-1,
                        'msg'=>'error',
                        'data'=>['src'=>'']
                    ];
                    return json($data);
                }
            }
            
        }else{
             return $this->fetch();
        }

    }



    function  import_txt_suffix($save_name){
        $file=fopen($save_name, "r");
        $txt=array();
            $i=0;
            //输出文本中所有的行，直到文件结束为止。
            while(! feof($file))
            {
             $txt[$i]= fgets($file);//fgets()函数从文件指针中读取一行
             $i++;
            }
            fclose($file);
            $txt=array_filter($txt);
            foreach ($txt as $key => $value) {
                $data = [];
                $data['m_suffix'] =   $value;
                Db::name('m_suffix')
                    ->insert($data);
            }
    }


    function add_suffix(){
        $request = $this->request;
        if($request->isPost()){
            $post = $request->post();
            $validate  = validate('suffix'); 
            $res = $validate->check($post);

             // Db::name('m_juzi')->insert($post);
             //    $this->success('增加成功');

            if($res!==true){
                $this->error($validate->getError());
            }else{
                Db::name('m_suffix')->insert($post);
                $this->success('VG目录站群：增加成功');
            }
        }else{
            $this->assign('gongneng','suffix');
            $this->assign('field','后缀');
            return $this->fetch('b_add');
        }
    }

   function edit_suffix($id=''){
        $request = $this->request;
        if($request->isPost()){
            $post = $request->post();
            $validate  = validate('suffix'); 
            $res = $validate->check($post);
            if($res!==true){
                $this->error($validate->getError());
            }else{
                Db::name('m_suffix')->where('id',$post['id'])->update(['m_suffix'=>$post['m_suffix'] ]);
                $this->success('VG目录站群：修改成功');
            }
        }else{
            $title = Db::name('m_suffix')->find($id);
            $this->assign('gongneng','suffix');
            $this->assign('field','后缀');
            return $this->fetch('b_edit',['title'=>$title]);
        }
    }



    function delete_all_suffix(){
        Db::query("TRUNCATE TABLE lotus_m_suffix");
        $this->success('已清空');    
    }


    function delete_many_suffix(){
        $id = $this->request->post('id');
        $res =  Db::name('m_suffix')
        ->delete($id);
        // if($res){
        //     $this->success('success');
        // }else{
        //     $this->error('error');
        // }
        
    }


     function delete_suffix($id){
        Db::name('m_suffix')->delete($id);
        $this->success('VG目录站群：删除成功');
    }


    // function 


      //关键词

    function  keyword_list(){
        $list = Db::name('m_keyword')
        ->order('id desc')
        ->paginate('20');
        $this->assign('list',$list);
        $this->assign('gongneng','keyword');
        $this->assign('field','关键词');
        return $this->fetch('keyword_list');
    }


    function add_keyword(){
        $request = $this->request;
        if($request->isPost()){
            $post = $request->post();
            $validate  = validate('keyword'); 
            $res = $validate->check($post);

             // Db::name('m_juzi')->insert($post);
             //    $this->success('增加成功');

            if($res!==true){
                $this->error($validate->getError());
            }else{
                Db::name('m_keyword')->insert($post);
                $this->success('VG目录站群：增加成功');
            }
        }else{
            $this->assign('gongneng','keyword');
            $this->assign('field','关键词');
            return $this->fetch('add_keyword');
        }
    }


    function edit_keyword($id=''){
        $request = $this->request;
        if($request->isPost()){
            $post = $request->post();
            $validate  = validate('keyword'); 
            $res = $validate->check($post);
            if($res!==true){
                $this->error($validate->getError());
            }else{
                Db::name('m_keyword')->where('id',$post['id'])->update(['m_keyword'=>$post['m_keyword'] ]);
                $this->success('VG目录站群：修改成功');
            }
        }else{
            $title = Db::name('m_keyword')->find($id);
            $this->assign('gongneng','keyword');
            $this->assign('field','关键词');
            return $this->fetch('edit_keyword',['title'=>$title]);
        }
    }



    function import_keyword(){
        $request = $this->request;
        if($file=request()->file('file')){
            if($file){
                $info = $file->move(ROOT_PATH . 'public' . DS . 'uploads');
                if($info){
                    // 输出 jpg
                    // echo $info->getExtension();
                    // 输出 20160820/42a79759f284b767dfcb2a0197904287.jpg
                    $save_name = ROOT_PATH . 'public' . DS . 'uploads'.DS.$info->getSaveName();
                    // 输出 42a79759f284b767dfcb2a0197904287.jpg
                    // echo $info->getFilename();
                    $this->import_txt($save_name,'m_keyword');
                    $this->success('VG目录站群：导入成功');
                    // $data = [ 
                    //     'code'=>0,
                    //     'msg'=>'success',
                    //     'data'=>['src'=>$save_name]
                    // ];
                    // return json($data);
                }else{
                // 上传失败获取错误信息
                    $data = [ 
                        'code'=>-1,
                        'msg'=>'error',
                        'data'=>['src'=>'']
                    ];
                    return json($data);
                }
            }
            
        }else{
            $this->assign('function_name',__FUNCTION__);
            return $this->fetch('import_keyword');
        }
    }


    function delete_all_keyword(){
        Db::query("TRUNCATE TABLE lotus_m_keyword");
        $this->success('已清空');    
    }

    function delete_many_keyword(){
        $id = $this->request->post('id');
        $res =  Db::name('m_keyword')
        ->delete($id);
        if($res){
            $this->success('success');
        }else{
            $this->error('error');
        }
        
    }

    function delete_keyword($id){
        Db::name('m_keyword')->delete($id);
        $this->success('VG目录站群：删除成功');
    }


    function  import_txt($save_name,$db){
        $file=fopen($save_name, "r");
        $txt=array();
            $i=0;
            //输出文本中所有的行，直到文件结束为止。
            while(! feof($file))
            {
             $txt[$i]= fgets($file);//fgets()函数从文件指针中读取一行
             $i++;
            }
            fclose($file);
            $txt=array_filter($txt);
                $data['create_time'] = date('Y-m_d H:i:s',time());
            foreach ($txt as $key => $value) {
                $data = [];
                $data[$db] =   $value;
                Db::name($db)
                    ->insert($data);
            }
    }


    function tpl(){
        $files =  $this->getFile('templates');
        $this->assign('count',count($files));
        $this->assign('files',$files);
        return $this->fetch();
    }


    function delete_tpl(){
        $file = $this->request->post('tpl_name');
        unlink('templates'.DS.$file);
        $this->success('VG目录站群：删除成功');
    }

    //获取文件列表
    function getFile($dir) {
        $fileArray[]=NULL;
        if (false != ($handle = opendir ( $dir ))) {
            $i=0;
            while ( false !== ($file = readdir ( $handle )) ) {
                //去掉"“.”、“..”以及带“.xxx”后缀的文件
                if ($file != "." && $file != ".."&&strpos($file,".")) {
                    $fileArray[$i]= $file;
                    if($i==100){
                        break;
                    }
                    $i++;
                }
            }
            //关闭句柄
            closedir ( $handle );
        }
        return $fileArray;
    }

    function import_tpl(){
        $request = $this->request;
        if($file=request()->file('file')){
            if($file){
                $info = $file->rule('uniqid')->move('./templates');
                // $info = $file->move(ROOT_PATH . 'templates');
                // 上传失败获取错误信息
                $this->success('success');
            }
            
        }else{
            $this->assign('function_name',__FUNCTION__);
            return $this->fetch('import_tpl');
        }
    }


    function edit_script(){
        $request = $this->request;
        if($request->isPost()){
           $post = $request->post();
           if(!empty($post['ac'])){
                $this->write_file('js/a.js',$post['ac']);
           }
           if(!empty($post['bc'])){
                $this->write_file('js/b.js',$post['bc']);
           }
           $this->success('VG目录站群：保存成功');

        }else{
            $ac = $this->read_file('js/a.js');
            $bc = $this->read_file('js/b.js');
            $this->assign('ac',$ac);
            $this->assign('bc',$bc);
            return $this->fetch();
        }
    }

    function read_file($filename){
        // $filename = "/usr/local/something.txt";
        $handle = @fopen($filename, "r");//读取二进制文件时，需要将第二个参数设置成'rb'
        //通过filesize获得文件大小，将整个文件一下子读到一个字符串中
        $contents = @fread($handle, filesize ($filename));
        fclose($handle);
        return $contents;
    }

    function write_file($filename,$txt){
        $myfile = fopen($filename, "w") or die("Unable to open file!");
        fwrite($myfile, $txt);
        fclose($myfile);
        return true;
    }



}