<?php
namespace app\admin\controller;

use \think\Db;
use \think\Reuquest;
class Content extends Main
{




    function  title_list(){
        $count  = Db::name('m_title')->count();
        $this->assign('count',$count);
        $title_list = Db::name('m_title')
        ->order('id desc')
        ->paginate('20');
        return $this->fetch('title_list',['title_list'=>$title_list]);
    }

    function add_title(){
        $request = $this->request;
        if($request->isPost()){
            $post = $request->post();
            $validate  = validate('title'); 
            $res = $validate->check($post);
            if($res!==true){
                $this->error($validate->getError());
            }else{
                Db::name('m_title')->insert($post);
                $this->success('VG目录站群：增加标题成功');
            }
        }else{
            return $this->fetch('add_title');
        }
    }


    function edit_title($id=''){
        $request = $this->request;
        if($request->isPost()){
            $post = $request->post();
            $validate  = validate('title'); 
            $res = $validate->check($post);
            if($res!==true){
                $this->error($validate->getError());
            }else{
                Db::name('m_title')->where('id',$post['id'])->update(['title'=>$post['title'] ]);
                $this->success('VG目录站群：修改标题成功');
            }
        }else{
            $title = Db::name('m_title')->find($id);
            return $this->fetch('edit_title',['title'=>$title]);
        }
    }

     function view_pic(){
        $m_pic  = $this->request->get('m_pic');
        $this->assign('m_pic',$m_pic);
        return $this->fetch();
    }


    function delete_title($id){
        Db::name('m_title')->delete($id);
        $this->success('VG目录站群：删除成功');
    }


    function import_title(){
        $request = $this->request;
        if($file=request()->file('file')){
            if($file){
                $info = $file->move(ROOT_PATH . 'public' . DS . 'uploads');
                if($info){
                    // 输出 jpg
                    // echo $info->getExtension();
                    // 输出 20160820/42a79759f284b767dfcb2a0197904287.jpg
                    $save_name = ROOT_PATH . 'public' . DS . 'uploads'.DS.$info->getSaveName();
                    // 输出 42a79759f284b767dfcb2a0197904287.jpg
                    // echo $info->getFilename();
                    $this->import_txt_title($save_name);
                    $this->success('VG目录站群：导入成功');
                    // $data = [ 
                    //     'code'=>0,
                    //     'msg'=>'success',
                    //     'data'=>['src'=>$save_name]
                    // ];
                    // return json($data);
                }else{
                // 上传失败获取错误信息
                    $data = [ 
                        'code'=>-1,
                        'msg'=>'error',
                        'data'=>['src'=>'']
                    ];
                    return json($data);
                }
            }
            
        }else{
             return $this->fetch();
        }
    }


    function  import_txt_title($save_name){
    $file=fopen($save_name, "r");
    $txt=array();
        $i=0;
        //输出文本中所有的行，直到文件结束为止。
        while(! feof($file))
        {
         $txt[$i]= fgets($file);//fgets()函数从文件指针中读取一行
         $i++;
        }
        fclose($file);
        $txt=array_filter($txt);
            $data['create_time'] = date('Y-m_d H:i:s',time());
        foreach ($txt as $key => $value) {
            $data = [];
            $data['title'] =   $value;
            Db::name('m_title')
                ->insert($data);
        }
    }


    function delete_all_title(){
        Db::query("TRUNCATE TABLE lotus_m_title");
        $this->success('VG目录站群：已清空');    
    }

    function delete_many_title(){
        $id = $this->request->post('id');
        $res =  Db::name('m_title')
        ->delete($id);
        if($res){
            $this->success('success');
        }else{
            $this->error('error');
        }
        
    }



    function  juzi_list(){
        $list = Db::name('m_juzi')
        ->order('id desc')
        ->paginate('20');
        $this->assign('list',$list);
        return $this->fetch();
    }


    function add_juzi(){
        $request = $this->request;
        if($request->isPost()){
            $post = $request->post();
            $validate  = validate('juzi'); 
            $res = $validate->check($post);

             // Db::name('m_juzi')->insert($post);
             //    $this->success('增加成功');

            if($res!==true){
                $this->error($validate->getError());
            }else{
                Db::name('m_juzi')->insert($post);
                $this->success('VG目录站群：增加成功');
            }
        }else{
            return $this->fetch('add_juzi');
        }
    }


    function edit_juzi($id=''){
        $request = $this->request;
        if($request->isPost()){
            $post = $request->post();
            $validate  = validate('juzi'); 
            $res = $validate->check($post);
            if($res!==true){
                $this->error($validate->getError());
            }else{
                Db::name('m_juzi')->where('id',$post['id'])->update(['m_juzi'=>$post['m_juzi'] ]);
                $this->success('VG目录站群：修改成功');
            }
        }else{
            $title = Db::name('m_juzi')->find($id);
            return $this->fetch('edit_juzi',['title'=>$title]);
        }
    }


    function  import_txt($save_name,$db){
    $file=fopen($save_name, "r");
    $txt=array();
        $i=0;
        //输出文本中所有的行，直到文件结束为止。
        while(! feof($file))
        {
         $txt[$i]= fgets($file);//fgets()函数从文件指针中读取一行
         $i++;
        }
        fclose($file);
        $txt=array_filter($txt);
            $data['create_time'] = date('Y-m_d H:i:s',time());
        foreach ($txt as $key => $value) {
            $data = [];
            $data[$db] =   $value;
            Db::name($db)
                ->insert($data);
        }
    }


    function import_juzi(){
        $request = $this->request;
        if($file=request()->file('file')){
            if($file){
                $info = $file->move(ROOT_PATH . 'public' . DS . 'uploads');
                if($info){
                    // 输出 jpg
                    // echo $info->getExtension();
                    // 输出 20160820/42a79759f284b767dfcb2a0197904287.jpg
                    $save_name = ROOT_PATH . 'public' . DS . 'uploads'.DS.$info->getSaveName();
                    // 输出 42a79759f284b767dfcb2a0197904287.jpg
                    // echo $info->getFilename();
                    $this->import_txt($save_name,'m_juzi');
                    $this->success('VG目录站群：导入成功');
                    // $data = [ 
                    //     'code'=>0,
                    //     'msg'=>'success',
                    //     'data'=>['src'=>$save_name]
                    // ];
                    // return json($data);
                }else{
                // 上传失败获取错误信息
                    $data = [ 
                        'code'=>-1,
                        'msg'=>'error',
                        'data'=>['src'=>'']
                    ];
                    return json($data);
                }
            }
            
        }else{
             return $this->fetch();
        }
    }


     function delete_all_juzi(){
        Db::query("TRUNCATE TABLE lotus_m_juzi");
        $this->success('VG目录站群：已清空');    
    }

    function delete_many_juzi(){
        $id = $this->request->post('id');
        $res =  Db::name('m_juzi')
        ->delete($id);
        if($res){
            $this->success('success');
        }else{
            $this->error('error');
        }
        
    }


    function delete_juzi($id){
        Db::name('m_title')->delete($id);
        $this->success('VG目录站群：删除成功');
    }


    //来源
    function  from_list(){
        $list = Db::name('m_from')
        ->order('id desc')
        ->paginate('20');
        $this->assign('list',$list);
        return $this->fetch();
    }


    function add_from(){
        $request = $this->request;
        if($request->isPost()){
            $post = $request->post();
            $validate  = validate('from'); 
            $res = $validate->check($post);

             // Db::name('m_juzi')->insert($post);
             //    $this->success('增加成功');

            if($res!==true){
                $this->error($validate->getError());
            }else{
                Db::name('m_from')->insert($post);
                $this->success('VG目录站群：增加成功');
            }
        }else{
            return $this->fetch('add_from');
        }
    }


    function edit_from($id=''){
        $request = $this->request;
        if($request->isPost()){
            $post = $request->post();
            $validate  = validate('juzi'); 
            $res = $validate->check($post);
            if($res!==true){
                $this->error($validate->getError());
            }else{
                Db::name('m_from')->where('id',$post['id'])->update(['m_from'=>$post['m_juzi'] ]);
                $this->success('VG目录站群：修改成功');
            }
        }else{
            $title = Db::name('m_from')->find($id);
            return $this->fetch('edit_from',['title'=>$title]);
        }
    }



    function import_from(){
        $request = $this->request;
        if($file=request()->file('file')){
            if($file){
                $info = $file->move(ROOT_PATH . 'public' . DS . 'uploads');
                if($info){
                    // 输出 jpg
                    // echo $info->getExtension();
                    // 输出 20160820/42a79759f284b767dfcb2a0197904287.jpg
                    $save_name = ROOT_PATH . 'public' . DS . 'uploads'.DS.$info->getSaveName();
                    // 输出 42a79759f284b767dfcb2a0197904287.jpg
                    // echo $info->getFilename();
                    $this->import_txt($save_name,'m_from');
                    $this->success('VG目录站群：导入成功');
                    // $data = [ 
                    //     'code'=>0,
                    //     'msg'=>'success',
                    //     'data'=>['src'=>$save_name]
                    // ];
                    // return json($data);
                }else{
                // 上传失败获取错误信息
                    $data = [ 
                        'code'=>-1,
                        'msg'=>'error',
                        'data'=>['src'=>'']
                    ];
                    return json($data);
                }
            }
            
        }else{
            $this->assign('function_name',__FUNCTION__);
            return $this->fetch('import');
        }
    }


    function delete_all_from(){
        Db::query("TRUNCATE TABLE lotus_m_from");
        $this->success('VG目录站群：已清空');    
    }

    function delete_many_from(){
        $id = $this->request->post('id');
        $res =  Db::name('m_from')
        ->delete($id);
        if($res){
            $this->success('success');
        }else{
            $this->error('error');
        }
        
    }


    function delete_from($id){
        Db::name('m_from')->delete($id);
        $this->success('VG目录站群：删除成功');
    }


    //热词

    function  hotwords_list(){
        $list = Db::name('m_hotwords')
        ->order('id desc')
        ->paginate('20');
        $this->assign('list',$list);
        $this->assign('gongneng','hotwords');
        $this->assign('field','热词');
        return $this->fetch('list');
    }


    function add_hotwords(){
        $request = $this->request;
        if($request->isPost()){
            $post = $request->post();
            $validate  = validate('hotwords'); 
            $res = $validate->check($post);

             // Db::name('m_juzi')->insert($post);
             //    $this->success('增加成功');

            if($res!==true){
                $this->error($validate->getError());
            }else{
                Db::name('m_hotwords')->insert($post);
                $this->success('VG目录站群：增加成功');
            }
        }else{
            $this->assign('gongneng','hotwords');
            $this->assign('field','热词');
            return $this->fetch('add');
        }
    }


    function edit_hotwords($id=''){
        $request = $this->request;
        if($request->isPost()){
            $post = $request->post();
            $validate  = validate('hotwords'); 
            $res = $validate->check($post);
            if($res!==true){
                $this->error($validate->getError());
            }else{
                Db::name('m_hotwords')->where('id',$post['id'])->update(['m_hotwords'=>$post['m_hotwords'] ]);
                $this->success('VG目录站群：修改成功');
            }
        }else{
            $title = Db::name('m_hotwords')->find($id);
            $this->assign('gongneng','hotwords');
            $this->assign('field','热词');
            return $this->fetch('edit',['title'=>$title]);
        }
    }



    function import_hotwords(){
        $request = $this->request;
        if($file=request()->file('file')){
            if($file){
                $info = $file->move(ROOT_PATH . 'public' . DS . 'uploads');
                if($info){
                    // 输出 jpg
                    // echo $info->getExtension();
                    // 输出 20160820/42a79759f284b767dfcb2a0197904287.jpg
                    $save_name = ROOT_PATH . 'public' . DS . 'uploads'.DS.$info->getSaveName();
                    // 输出 42a79759f284b767dfcb2a0197904287.jpg
                    // echo $info->getFilename();
                    $this->import_txt($save_name,'m_hotwords');
                    $this->success('VG目录站群：导入成功');
                    // $data = [ 
                    //     'code'=>0,
                    //     'msg'=>'success',
                    //     'data'=>['src'=>$save_name]
                    // ];
                    // return json($data);
                }else{
                // 上传失败获取错误信息
                    $data = [ 
                        'code'=>-1,
                        'msg'=>'error',
                        'data'=>['src'=>'']
                    ];
                    return json($data);
                }
            }
            
        }else{
            $this->assign('function_name',__FUNCTION__);
            return $this->fetch('import');
        }
    }


    function delete_all_hotwords(){
        Db::query("TRUNCATE TABLE lotus_m_hotwords");
        $this->success('VG目录站群：已清空');    
    }

    function delete_many_hotwords(){
        $id = $this->request->post('id');
        $res =  Db::name('m_hotwords')
        ->delete($id);
        if($res){
            $this->success('success');
        }else{
            $this->error('error');
        }
        
    }

    function delete_hotwords($id){
        Db::name('m_hotwords')->delete($id);
        $this->success('VG目录站群：删除成功');
    }

    //人名库
      function  name_list(){
        $list = Db::name('m_name')
        ->order('id desc')
        ->paginate('20');
        $this->assign('list',$list);
        $this->assign('gongneng','name');
        $this->assign('field','名称');
        return $this->fetch('list');
    }


    function add_name(){
        $request = $this->request;
        if($request->isPost()){
            $post = $request->post();
            $validate  = validate('name'); 
            $res = $validate->check($post);

             // Db::name('m_juzi')->insert($post);
             //    $this->success('增加成功');

            if($res!==true){
                $this->error($validate->getError());
            }else{
                Db::name('m_name')->insert($post);
                $this->success('VG目录站群：增加成功');
            }
        }else{
            $this->assign('gongneng','name');
            $this->assign('field','名称');
            return $this->fetch('add');
        }
    }


    function edit_name($id=''){
        $request = $this->request;
        if($request->isPost()){
            $post = $request->post();
            $validate  = validate('name'); 
            $res = $validate->check($post);
            if($res!==true){
                $this->error($validate->getError());
            }else{
                Db::name('m_name')->where('id',$post['id'])->update(['m_name'=>$post['m_name'] ]);
                $this->success('VG目录站群：修改成功');
            }
        }else{
            $title = Db::name('m_name')->find($id);
            $this->assign('gongneng','name');
            $this->assign('field','名称');
            return $this->fetch('edit',['title'=>$title]);
        }
    }



    function import_name(){
        $request = $this->request;
        if($file=request()->file('file')){
            if($file){
                $info = $file->move(ROOT_PATH . 'public' . DS . 'uploads');
                if($info){
                    // 输出 jpg
                    // echo $info->getExtension();
                    // 输出 20160820/42a79759f284b767dfcb2a0197904287.jpg
                    $save_name = ROOT_PATH . 'public' . DS . 'uploads'.DS.$info->getSaveName();
                    // 输出 42a79759f284b767dfcb2a0197904287.jpg
                    // echo $info->getFilename();
                    $this->import_txt($save_name,'m_name');
                    $this->success('VG目录站群：导入成功');
                    // $data = [ 
                    //     'code'=>0,
                    //     'msg'=>'success',
                    //     'data'=>['src'=>$save_name]
                    // ];
                    // return json($data);
                }else{
                // 上传失败获取错误信息
                    $data = [ 
                        'code'=>-1,
                        'msg'=>'error',
                        'data'=>['src'=>'']
                    ];
                    return json($data);
                }
            }
            
        }else{
            $this->assign('function_name',__FUNCTION__);
            return $this->fetch('import');
        }
    }


    function delete_all_name(){
        Db::query("TRUNCATE TABLE lotus_m_name");
        $this->success('VG目录站群：已清空');    
    }

    function delete_many_name(){
        $id = $this->request->post('id');
        $res =  Db::name('m_name')
        ->delete($id);
        if($res){
            $this->success('success');
        }else{
            $this->error('error');
        }
        
    }

    function delete_name($id){
        Db::name('m_name')->delete($id);
        $this->success('VG目录站群：删除成功');
    }
    //城市库
      function  city_list(){
        $list = Db::name('m_city')
        ->order('id desc')
        ->paginate('20');
        $this->assign('list',$list);
        $this->assign('gongneng','city');
        $this->assign('field','城市库');
        return $this->fetch('list');
    }


    function add_city(){
        $request = $this->request;
        if($request->isPost()){
            $post = $request->post();
            $validate  = validate('city'); 
            $res = $validate->check($post);

             // Db::name('m_juzi')->insert($post);
             //    $this->success('增加成功');

            if($res!==true){
                $this->error($validate->getError());
            }else{
                Db::name('m_city')->insert($post);
                $this->success('VG目录站群：增加成功');
            }
        }else{
            $this->assign('gongneng','city');
            $this->assign('field','城市库');
            return $this->fetch('add');
        }
    }


    function edit_city($id=''){
        $request = $this->request;
        if($request->isPost()){
            $post = $request->post();
            $validate  = validate('city'); 
            $res = $validate->check($post);
            if($res!==true){
                $this->error($validate->getError());
            }else{
                Db::name('m_city')->where('id',$post['id'])->update(['m_city'=>$post['m_city'] ]);
                $this->success('VG目录站群：修改成功');
            }
        }else{
            $title = Db::name('m_city')->find($id);
            $this->assign('gongneng','city');
            $this->assign('field','城市库');
            return $this->fetch('edit',['title'=>$title]);
        }
    }



    function import_city(){
        $request = $this->request;
        if($file=request()->file('file')){
            if($file){
                $info = $file->move(ROOT_PATH . 'public' . DS . 'uploads');
                if($info){
                    // 输出 jpg
                    // echo $info->getExtension();
                    // 输出 20160820/42a79759f284b767dfcb2a0197904287.jpg
                    $save_name = ROOT_PATH . 'public' . DS . 'uploads'.DS.$info->getSaveName();
                    // 输出 42a79759f284b767dfcb2a0197904287.jpg
                    // echo $info->getFilename();
                    $this->import_txt($save_name,'m_city');
                    $this->success('VG目录站群：导入成功');
                    // $data = [ 
                    //     'code'=>0,
                    //     'msg'=>'success',
                    //     'data'=>['src'=>$save_name]
                    // ];
                    // return json($data);
                }else{
                // 上传失败获取错误信息
                    $data = [ 
                        'code'=>-1,
                        'msg'=>'error',
                        'data'=>['src'=>'']
                    ];
                    return json($data);
                }
            }
            
        }else{
            $this->assign('function_name',__FUNCTION__);
            return $this->fetch('import');
        }
    }


    function delete_all_city(){
        Db::query("TRUNCATE TABLE lotus_m_city");
        $this->success('VG目录站群：已清空');    
    }

    function delete_many_city(){
        $id = $this->request->post('id');
        $res =  Db::name('m_city')
        ->delete($id);
        if($res){
            $this->success('success');
        }else{
            $this->error('error');
        }
        
    }

    function delete_city($id){
        Db::name('m_city')->delete($id);
        $this->success('VG目录站群：删除成功');
    }

    //学校库
      function  school_list(){
        $list = Db::name('m_school')
        ->order('id desc')
        ->paginate('20');
        $this->assign('list',$list);
        $this->assign('gongneng','school');
        $this->assign('field','学校');
        return $this->fetch('list');
    }


    function add_school(){
        $request = $this->request;
        if($request->isPost()){
            $post = $request->post();
            $validate  = validate('school'); 
            $res = $validate->check($post);

             // Db::name('m_juzi')->insert($post);
             //    $this->success('增加成功');

            if($res!==true){
                $this->error($validate->getError());
            }else{
                Db::name('m_school')->insert($post);
                $this->success('VG目录站群：增加成功');
            }
        }else{
            $this->assign('gongneng','school');
            $this->assign('field','学校');
            return $this->fetch('add');
        }
    }


    function edit_school($id=''){
        $request = $this->request;
        if($request->isPost()){
            $post = $request->post();
            $validate  = validate('school'); 
            $res = $validate->check($post);
            if($res!==true){
                $this->error($validate->getError());
            }else{
                Db::name('m_school')->where('id',$post['id'])->update(['m_school'=>$post['m_school'] ]);
                $this->success('VG目录站群：修改成功');
            }
        }else{
            $title = Db::name('m_school')->find($id);
            $this->assign('gongneng','school');
            $this->assign('field','学校');
            return $this->fetch('edit',['title'=>$title]);
        }
    }



    function import_school(){
        $request = $this->request;
        if($file=request()->file('file')){
            if($file){
                $info = $file->move(ROOT_PATH . 'public' . DS . 'uploads');
                if($info){
                    // 输出 jpg
                    // echo $info->getExtension();
                    // 输出 20160820/42a79759f284b767dfcb2a0197904287.jpg
                    $save_name = ROOT_PATH . 'public' . DS . 'uploads'.DS.$info->getSaveName();
                    // 输出 42a79759f284b767dfcb2a0197904287.jpg
                    // echo $info->getFilename();
                    $this->import_txt($save_name,'m_school');
                    $this->success('VG目录站群：导入成功');
                    // $data = [ 
                    //     'code'=>0,
                    //     'msg'=>'success',
                    //     'data'=>['src'=>$save_name]
                    // ];
                    // return json($data);
                }else{
                // 上传失败获取错误信息
                    $data = [ 
                        'code'=>-1,
                        'msg'=>'error',
                        'data'=>['src'=>'']
                    ];
                    return json($data);
                }
            }
            
        }else{
            $this->assign('function_name',__FUNCTION__);
            return $this->fetch('import');
        }
    }


    function delete_all_school(){
        Db::query("TRUNCATE TABLE lotus_m_school");
        $this->success('已清空');    
    }

    function delete_many_school(){
        $id = $this->request->post('id');
        $res =  Db::name('m_school')
        ->delete($id);
        if($res){
            $this->success('success');
        }else{
            $this->error('error');
        }
        
    }

    function delete_school($id){
        Db::name('m_school')->delete($id);
        $this->success('VG目录站群：删除成功');
    }

    //爱好库
      function  hobby_list(){
        $list = Db::name('m_hobby')
        ->order('id desc')
        ->paginate('20');
        $this->assign('list',$list);
        $this->assign('gongneng','hobby');
        $this->assign('field','爱好');
        return $this->fetch('list');
    }


    function add_hobby(){
        $request = $this->request;
        if($request->isPost()){
            $post = $request->post();
            $validate  = validate('hobby'); 
            $res = $validate->check($post);

             // Db::name('m_juzi')->insert($post);
             //    $this->success('增加成功');

            if($res!==true){
                $this->error($validate->getError());
            }else{
                Db::name('m_hobby')->insert($post);
                $this->success('VG目录站群：增加成功');
            }
        }else{
            $this->assign('gongneng','hobby');
            $this->assign('field','爱好');
            return $this->fetch('add');
        }
    }


    function edit_hobby($id=''){
        $request = $this->request;
        if($request->isPost()){
            $post = $request->post();
            $validate  = validate('hobby'); 
            $res = $validate->check($post);
            if($res!==true){
                $this->error($validate->getError());
            }else{
                Db::name('m_hobby')->where('id',$post['id'])->update(['m_hobby'=>$post['m_hobby'] ]);
                $this->success('VG目录站群：修改成功');
            }
        }else{
            $title = Db::name('m_hobby')->find($id);
            $this->assign('gongneng','hobby');
            $this->assign('field','爱好');
            return $this->fetch('edit',['title'=>$title]);
        }
    }



    function import_hobby(){
        $request = $this->request;
        if($file=request()->file('file')){
            if($file){
                $info = $file->move(ROOT_PATH . 'public' . DS . 'uploads');
                if($info){
                    // 输出 jpg
                    // echo $info->getExtension();
                    // 输出 20160820/42a79759f284b767dfcb2a0197904287.jpg
                    $save_name = ROOT_PATH . 'public' . DS . 'uploads'.DS.$info->getSaveName();
                    // 输出 42a79759f284b767dfcb2a0197904287.jpg
                    // echo $info->getFilename();
                    $this->import_txt($save_name,'m_hobby');
                    $this->success('VG目录站群：导入成功');
                    // $data = [ 
                    //     'code'=>0,
                    //     'msg'=>'success',
                    //     'data'=>['src'=>$save_name]
                    // ];
                    // return json($data);
                }else{
                // 上传失败获取错误信息
                    $data = [ 
                        'code'=>-1,
                        'msg'=>'error',
                        'data'=>['src'=>'']
                    ];
                    return json($data);
                }
            }
            
        }else{
            $this->assign('function_name',__FUNCTION__);
            return $this->fetch('import');
        }
    }


    function delete_all_hobby(){
        Db::query("TRUNCATE TABLE lotus_m_hobby");
        $this->success('VG目录站群：已清空');    
    }

    function delete_many_hobby(){
        $id = $this->request->post('id');
        $res =  Db::name('m_hobby')
        ->delete($id);
        if($res){
            $this->success('success');
        }else{
            $this->error('error');
        }
        
    }

    function delete_hobby($id){
        Db::name('m_hobby')->delete($id);
        $this->success('VG目录站群：删除成功');
    }

    //书名库

      function  book_list(){
        $list = Db::name('m_book')
        ->order('id desc')
        ->paginate('20');
        $this->assign('list',$list);
        $this->assign('gongneng','book');
        $this->assign('field','书名');
        return $this->fetch('list');
    }


    function add_book(){
        $request = $this->request;
        if($request->isPost()){
            $post = $request->post();
            $validate  = validate('book'); 
            $res = $validate->check($post);

             // Db::name('m_juzi')->insert($post);
             //    $this->success('增加成功');

            if($res!==true){
                $this->error($validate->getError());
            }else{
                Db::name('m_book')->insert($post);
                $this->success('VG目录站群：增加成功');
            }
        }else{
            $this->assign('gongneng','book');
            $this->assign('field','书名');
            return $this->fetch('add');
        }
    }


    function edit_book($id=''){
        $request = $this->request;
        if($request->isPost()){
            $post = $request->post();
            $validate  = validate('book'); 
            $res = $validate->check($post);
            if($res!==true){
                $this->error($validate->getError());
            }else{
                Db::name('m_book')->where('id',$post['id'])->update(['m_book'=>$post['m_book'] ]);
                $this->success('VG目录站群：修改成功');
            }
        }else{
            $title = Db::name('m_book')->find($id);
            $this->assign('gongneng','book');
            $this->assign('field','书名');
            return $this->fetch('edit',['title'=>$title]);
        }
    }



    function import_book(){
        $request = $this->request;
        if($file=request()->file('file')){
            if($file){
                $info = $file->move(ROOT_PATH . 'public' . DS . 'uploads');
                if($info){
                    // 输出 jpg
                    // echo $info->getExtension();
                    // 输出 20160820/42a79759f284b767dfcb2a0197904287.jpg
                    $save_name = ROOT_PATH . 'public' . DS . 'uploads'.DS.$info->getSaveName();
                    // 输出 42a79759f284b767dfcb2a0197904287.jpg
                    // echo $info->getFilename();
                    $this->import_txt($save_name,'m_book');
                    $this->success('VG目录站群：导入成功');
                    // $data = [ 
                    //     'code'=>0,
                    //     'msg'=>'success',
                    //     'data'=>['src'=>$save_name]
                    // ];
                    // return json($data);
                }else{
                // 上传失败获取错误信息
                    $data = [ 
                        'code'=>-1,
                        'msg'=>'error',
                        'data'=>['src'=>'']
                    ];
                    return json($data);
                }
            }
            
        }else{
            $this->assign('function_name',__FUNCTION__);
            return $this->fetch('import');
        }
    }


    function delete_all_book(){
        Db::query("TRUNCATE TABLE lotus_m_book");
        $this->success('VG目录站群：已清空');    
    }

    function delete_many_book(){
        $id = $this->request->post('id');
        $res =  Db::name('m_book')
        ->delete($id);
        if($res){
            $this->success('success');
        }else{
            $this->error('error');
        }
        
    }

    function delete_book($id){
        Db::name('m_book')->delete($id);
        $this->success('VG目录站群：删除成功');
    }

    //栏目

      function  column_list(){
        $list = Db::name('m_column')
        ->order('id desc')
        ->paginate('20');
        $this->assign('list',$list);
        $this->assign('gongneng','column');
        $this->assign('field','栏目');
        return $this->fetch('list');
    }


    function add_column(){
        $request = $this->request;
        if($request->isPost()){
            $post = $request->post();
            $validate  = validate('column'); 
            $res = $validate->check($post);

             // Db::name('m_juzi')->insert($post);
             //    $this->success('增加成功');

            if($res!==true){
                $this->error($validate->getError());
            }else{
                Db::name('m_column')->insert($post);
                $this->success('VG目录站群：增加成功');
            }
        }else{
            $this->assign('gongneng','column');
            $this->assign('field','栏目');
            return $this->fetch('add');
        }
    }


    function edit_column($id=''){
        $request = $this->request;
        if($request->isPost()){
            $post = $request->post();
            $validate  = validate('column'); 
            $res = $validate->check($post);
            if($res!==true){
                $this->error($validate->getError());
            }else{
                Db::name('m_column')->where('id',$post['id'])->update(['m_column'=>$post['m_column'] ]);
                $this->success('VG目录站群：修改成功');
            }
        }else{
            $title = Db::name('m_column')->find($id);
            $this->assign('gongneng','column');
            $this->assign('field','栏目');
            return $this->fetch('edit',['title'=>$title]);
        }
    }



    function import_column(){
        $request = $this->request;
        if($file=request()->file('file')){
            if($file){
                $info = $file->move(ROOT_PATH . 'public' . DS . 'uploads');
                if($info){
                    // 输出 jpg
                    // echo $info->getExtension();
                    // 输出 20160820/42a79759f284b767dfcb2a0197904287.jpg
                    $save_name = ROOT_PATH . 'public' . DS . 'uploads'.DS.$info->getSaveName();
                    // 输出 42a79759f284b767dfcb2a0197904287.jpg
                    // echo $info->getFilename();
                    $this->import_txt($save_name,'m_column');
                    $this->success('VG目录站群：导入成功');
                    // $data = [ 
                    //     'code'=>0,
                    //     'msg'=>'success',
                    //     'data'=>['src'=>$save_name]
                    // ];
                    // return json($data);
                }else{
                // 上传失败获取错误信息
                    $data = [ 
                        'code'=>-1,
                        'msg'=>'error',
                        'data'=>['src'=>'']
                    ];
                    return json($data);
                }
            }
            
        }else{
            $this->assign('function_name',__FUNCTION__);
            return $this->fetch('import');
        }
    }


    function delete_all_column(){
        Db::query("TRUNCATE TABLE lotus_m_column");
        $this->success('VG目录站群：已清空');    
    }

    function delete_many_column(){
        $id = $this->request->post('id');
        $res =  Db::name('m_column')
        ->delete($id);
        if($res){
            $this->success('success');
        }else{
            $this->error('error');
        }
        
    }

    function delete_column($id){
        Db::name('m_column')->delete($id);
        $this->success('VG目录站群：删除成功');
    }

    //奖励库
      function  prize_list(){
        $list = Db::name('m_prize')
        ->order('id desc')
        ->paginate('20');
        $this->assign('list',$list);
        $this->assign('gongneng','prize');
        $this->assign('field','奖励');
        return $this->fetch('list');
    }


    function add_prize(){
        $request = $this->request;
        if($request->isPost()){
            $post = $request->post();
            $validate  = validate('prize'); 
            $res = $validate->check($post);

             // Db::name('m_juzi')->insert($post);
             //    $this->success('增加成功');

            if($res!==true){
                $this->error($validate->getError());
            }else{
                Db::name('m_prize')->insert($post);
                $this->success('VG目录站群：增加成功');
            }
        }else{
            $this->assign('gongneng','prize');
            $this->assign('field','奖励');
            return $this->fetch('add');
        }
    }


    function edit_prize($id=''){
        $request = $this->request;
        if($request->isPost()){
            $post = $request->post();
            $validate  = validate('prize'); 
            $res = $validate->check($post);
            if($res!==true){
                $this->error($validate->getError());
            }else{
                Db::name('m_prize')->where('id',$post['id'])->update(['m_prize'=>$post['m_prize'] ]);
                $this->success('VG目录站群：修改成功');
            }
        }else{
            $title = Db::name('m_prize')->find($id);
            $this->assign('gongneng','prize');
            $this->assign('field','奖励');
            return $this->fetch('edit',['title'=>$title]);
        }
    }



    function import_prize(){
        $request = $this->request;
        if($file=request()->file('file')){
            if($file){
                $info = $file->move(ROOT_PATH . 'public' . DS . 'uploads');
                if($info){
                    // 输出 jpg
                    // echo $info->getExtension();
                    // 输出 20160820/42a79759f284b767dfcb2a0197904287.jpg
                    $save_name = ROOT_PATH . 'public' . DS . 'uploads'.DS.$info->getSaveName();
                    // 输出 42a79759f284b767dfcb2a0197904287.jpg
                    // echo $info->getFilename();
                    $this->import_txt($save_name,'m_prize');
                    $this->success('VG目录站群：导入成功');
                    // $data = [ 
                    //     'code'=>0,
                    //     'msg'=>'success',
                    //     'data'=>['src'=>$save_name]
                    // ];
                    // return json($data);
                }else{
                // 上传失败获取错误信息
                    $data = [ 
                        'code'=>-1,
                        'msg'=>'error',
                        'data'=>['src'=>'']
                    ];
                    return json($data);
                }
            }
            
        }else{
            $this->assign('function_name',__FUNCTION__);
            return $this->fetch('import');
        }
    }


    function delete_all_prize(){
        Db::query("TRUNCATE TABLE lotus_m_prize");
        $this->success('VG目录站群：已清空');    
    }

    function delete_many_prize(){
        $id = $this->request->post('id');
        $res =  Db::name('m_prize')
        ->delete($id);
        if($res){
            $this->success('success');
        }else{
            $this->error('error');
        }
        
    }

    function delete_prize($id){
        Db::name('m_prize')->delete($id);
        $this->success('VG目录站群：删除成功');
    }

    function pic_list(){
        $list = Db::name('m_pic')
        ->order('id desc')
        ->paginate('20');
        $this->assign('list',$list);
        return $this->fetch('pic_list');
    }

	function add_pic(){
        $request = $this->request;
        if($file=request()->file('m_pic')){
            if($file){
                $info = $file->rule('uniqid')->move('./img');
                if($info){
                    // 输出 jpg
                    // echo $info->getExtension();
                    // 输出 20160820/42a79759f284b767dfcb2a0197904287.jpg
                    $save_name =  $info->getSaveName();
                    Db::name('m_pic')
                    ->insert(['m_pic'=>$save_name]);
                    // 输出 42a79759f284b767dfcb2a0197904287.jpg
                    // echo $info->getFilename();
                    $this->success('VG目录站群：上传成功');
                    // $data = [ 
                    //     'code'=>0,
                    //     'msg'=>'success',
                    //     'data'=>['src'=>$save_name]
                    // ];
                    // return json($data);
                }else{
                // 上传失败获取错误信息
                    $data = [ 
                        'code'=>-1,
                        'msg'=>'error',
                        'data'=>['src'=>'']
                    ];
                    return json($data);
                }
            }
            
        }else{
            $this->assign('function_name',__FUNCTION__);
            return $this->fetch('add_pic');
        }
    }

    function edit_pic($id){
        $request = $this->request;
        if($request->isPost()){
            $post = $request->post();
            $validate  = validate('prize'); 
            $res = $validate->check($post);
            if($res!==true){
                $this->error($validate->getError());
            }else{
                Db::name('m_prize')->where('id',$post['id'])->update(['m_prize'=>$post['m_prize'] ]);
                $this->success('VG目录站群：修改成功');
            }
        }else{
            $title = Db::name('m_prize')->find($id);
            $this->assign('gongneng','prize');
            $this->assign('field','奖励');
            return $this->fetch('edit',['title'=>$title]);
        }
    }

    function delete_all_pic(){
        Db::query("TRUNCATE TABLE lotus_m_pic");
        $this->success('VG目录站群：已清空');    
    }

    function delete_pic($id){
        Db::name('m_pic')->delete($id);
        $this->success('VG目录站群：删除成功');
    }


    function delete_many_pic(){
        $id = $this->request->post('id');
        $res =  Db::name('m_pic')
        ->delete($id);
        if($res){
            $this->success('success');
        }else{
            $this->error('error');
        }
        
    }



    //VG目录站群：关键词

        //VG目录站群：关键词

    function  keyword_list(){
        $list = Db::name('m_keyword')
        ->order('id desc')
        ->paginate('20');
        $this->assign('list',$list);
        $this->assign('gongneng','keyword');
        $this->assign('field','关键词');
        return $this->fetch('list');
    }


    function add_keyword(){
        $request = $this->request;
        if($request->isPost()){
            $post = $request->post();
            $validate  = validate('keyword'); 
            $res = $validate->check($post);

             // Db::name('m_juzi')->insert($post);
             //    $this->success('增加成功');

            if($res!==true){
                $this->error($validate->getError());
            }else{
                Db::name('m_keyword')->insert($post);
                $this->success('VG目录站群：增加成功');
            }
        }else{
            $this->assign('gongneng','keyword');
            $this->assign('field','关键词');
            return $this->fetch('add');
        }
    }


    function edit_keyword($id=''){
        $request = $this->request;
        if($request->isPost()){
            $post = $request->post();
            $validate  = validate('keyword'); 
            $res = $validate->check($post);
            if($res!==true){
                $this->error($validate->getError());
            }else{
                Db::name('m_keyword')->where('id',$post['id'])->update(['m_keyword'=>$post['m_keyword'] ]);
                $this->success('VG目录站群：修改成功');
            }
        }else{
            $title = Db::name('m_keyword')->find($id);
            $this->assign('gongneng','keyword');
            $this->assign('field','关键词');
            return $this->fetch('edit',['title'=>$title]);
        }
    }



    function import_keyword(){
        $request = $this->request;
        if($file=request()->file('file')){
            if($file){
                $info = $file->move(ROOT_PATH . 'public' . DS . 'uploads');
                if($info){
                    // 输出 jpg
                    // echo $info->getExtension();
                    // 输出 20160820/42a79759f284b767dfcb2a0197904287.jpg
                    $save_name = ROOT_PATH . 'public' . DS . 'uploads'.DS.$info->getSaveName();
                    // 输出 42a79759f284b767dfcb2a0197904287.jpg
                    // echo $info->getFilename();
                    $this->import_txt($save_name,'m_keyword');
                    $this->success('VG目录站群：导入成功');
                    // $data = [ 
                    //     'code'=>0,
                    //     'msg'=>'success',
                    //     'data'=>['src'=>$save_name]
                    // ];
                    // return json($data);
                }else{
                // 上传失败获取错误信息
                    $data = [ 
                        'code'=>-1,
                        'msg'=>'error',
                        'data'=>['src'=>'']
                    ];
                    return json($data);
                }
            }
            
        }else{
            $this->assign('function_name',__FUNCTION__);
            return $this->fetch('import');
        }
    }


    function delete_all_keyword(){
        Db::query("TRUNCATE TABLE lotus_m_keyword");
        $this->success('VG目录站群：已清空');    
    }

    function delete_many_keyword(){
        $id = $this->request->post('id');
        $res =  Db::name('m_keyword')
        ->delete($id);
        if($res){
            $this->success('success');
        }else{
            $this->error('error');
        }
        
    }

    function delete_keyword($id){
        Db::name('m_keyword')->delete($id);
        $this->success('VG目录站群：删除成功');
    }

    


}