<?php
namespace app\admin\controller;

use think\Db;

class Manage extends Main
{

    function user_list(){
        $list =  Db::name('member')
            ->select();
        $this->assign('list',$list);
        return $this->fetch();
    }
}
