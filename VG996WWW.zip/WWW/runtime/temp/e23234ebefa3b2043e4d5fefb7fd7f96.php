<?php if (!defined('THINK_PATH')) exit(); /*a:4:{s:52:"E:\phpstudy\WWW/application/install\view\\index.html";i:1558778270;s:57:"E:\phpstudy\WWW/application/install\view\public\head.html";i:1558778436;s:59:"E:\phpstudy\WWW/application/install\view\public\header.html";i:1558778497;s:59:"E:\phpstudy\WWW/application/install\view\public\footer.html";i:1558778362;}*/ ?>
<!doctype html>
<html>
<head>
<meta charset="utf-8" />
<title>VG目录站群程序安装-V5.25版本</title>
<link rel="stylesheet" href="__static__/install/simpleboot/themes/flat/theme.min.css" />
<link rel="stylesheet" href="__static__/install/css/install.css" />
<link rel="stylesheet" href="__static__/font-awesome/css/font-awesome.min.css" type="text/css">


</head>
<body>
	<div class="wrap">
		<div class="header">
	<h1 class="logo">VG目录站群程序 安装向导</h1>
	<div class="version">v 5.25</div>
</div>
		<div class="section">
			<div class="main">
				<pre class="agreement">VG目录站群泛目录软件使用协议

版权所有 ©2019-<?php echo date("Y"); ?>,VG目录站群团队

感谢您选择VG目录站群团队泛目录管理系统, 希望我们的产品能够让你的关键词收录更快，排名更好！


VG目录站群泛目录管理系统由VG目录站群团队发起并发布。

VG目录站群团队免责声明
  1、使用VG目录站群团队构建的网站的任何信息内容以及导致的任何版权纠纷和法律争议及后果，VG目录站群团队不承担任何责任。
  2、您一旦安装使用VG目录站群泛目录，即被视为完全理解并接受本协议的各项条款，在享有上述条款授予的权力的同时，受到相关的约束和限制。</pre>
			</div>
			<div class="bottom text-center">
				<a href="<?php echo url('index/step2'); ?>" class="btn btn-primary"><?php echo lang('ACCEPT'); ?></a>
			</div>
		</div>
	</div>
	<div class="footer">
	&copy; 2019-<?php echo date('Y'); ?> <a href="#" target="_blank">VG目录站群团队</a>
</div>
</body>
</html>