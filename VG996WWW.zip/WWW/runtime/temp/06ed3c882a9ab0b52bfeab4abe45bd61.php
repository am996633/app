<?php if (!defined('THINK_PATH')) exit(); /*a:3:{s:57:"E:\phpstudy\WWW/application/admin\view\index\welcome.html";i:1558779015;s:55:"E:\phpstudy\WWW/application/admin\view\public\head.html";i:1558778994;s:55:"E:\phpstudy\WWW/application/admin\view\public\foot.html";i:1533596491;}*/ ?>
﻿<!doctype html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>VG目录站群泛目录管理系统</title>
  <meta name="renderer" content="webkit|ie-comp|ie-stand">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width,user-scalable=yes, minimum-scale=0.4, initial-scale=0.8" />
    <meta http-equiv="Cache-Control" content="no-siteapp" />
    <link rel="shortcut icon" href="__static__/favicon.ico" type="image/x-icon" />
    <link rel="stylesheet" href="__static__/css/font.css">
    <link rel="stylesheet" href="__module__/layui/css/layui.css">
    <link rel="stylesheet" href="__static__/css/xadmin.css">
    <script type="text/javascript" src="__js__/jquery.min.js"></script>
    <script src="__module__/layui/layui.all.js" charset="utf-8"></script>
    <script type="text/javascript" src="__static__/js/xadmin.js"></script>
    <script type="text/javascript" src="__static__/js/jquery.form.js"></script>
</head>


<div class="x-body">
    <blockquote class="layui-elem-quote">
        <font style="font-size: 15px ;"> 欢迎使用VG目录站群泛目录管理系统-版本V5.25 ！</font>
    </blockquote>
     
 



    <fieldset class="layui-elem-field">
        <legend>
            统计
        </legend>
        <div class="layui-field-box">
            <table class="layui-table" >
               <thead>
                    <tr>
                        <th colspan="2" scope="col">
                            基础配置信息
                        </th>
                    </tr>
                </thead>
                <tbody>

                    <tr>
                        <th width="30%">设置目录</th>
                        <td>

              <form  id="mainForm" action="welcome" method="post">
                    <input type="text" name="tpl_name" id="tpl_name" value="<?php echo $tpl_name; ?>" required  lay-verify="required" placeholder="请输入目录" autocomplete="off" class="layui-input" style="height: 31px;width: 260px;float: left;">
                    <button type="submit" class="layui-btn layui-btn-success layui-btn-small" style="margin-left: 5px;">保存</button>
              </form>
      


                        </td>
                    </tr>

                    <tr>
                        <th width="30%">关键词</th>
                        <td>
                            <?php  echo  count(\think\DB::name('m_keyword')->select()) ;  ?>
                        </td>

                    <tr>
                        <td>后缀规则</td>
                        <td>
                            <?php  echo  count(\think\DB::name('m_suffix')->select()) ;  ?>
                        </td>
                    </tr>
                    <tr>
                        <td>URL规则</td>
                        <td>
                            <?php  echo  count(\think\DB::name('m_url')->select()) ;  ?>
                        </td>
                     
                     
                    </tr>

                    <tr>
                        <td>缓存文件数</td>
                        <td>
                            <span><?php  $arr =  getFile('cache'); if($arr[0]==null){ echo 0;} else{
                                 echo count($arr);
                            }  ?></span>
                            <button onclick="clear_cache()" class="layui-btn layui-btn-success layui-btn-small" style="margin-left: 5px;">清除缓存</button>

                        </td>
                    </tr>
                  
                  
                </tbody>
            </table>




            
            <table class="layui-table">
                    <tbody>
                        <tr>
                            <th width="30%">操作系统</th>
                            <td><?php echo PHP_OS; ?></td></tr>
                        <tr>
                            <th>服务器地址</th>
                            <td>127.0.0.1</td>
                        </tr>
                      
                     
                        <tr>
                            <th>PHP版本</th>
                            <td><?php echo PHP_VERSION; ?></td>
                        </tr>
                        
                        <tr>
                            <th>PHP运行方式</th>
                            <td><?php echo php_sapi_name(); ?></td>
                        </tr>

                        <tr>
                            <th>MYSQL版本</th>
                            <td>5.5.53</td>
                        </tr>
                        
                      
                            <th>上传附件限制</th>
                            <td><?php 
echo get_cfg_var ("upload_max_filesize")?get_cfg_var ("upload_max_filesize"):"不允许上传附件";
 ?></td></tr>
                        <tr>
                            <th>执行时间限制</th>
                            <td>30s</td>
                        </tr>
                      

                    </tbody>



        </div>
    </fieldset>
  
</div>


<script type="text/javascript">
    $(document).ready(function(){ 
         var options = {
              type:'post',           //post提交
              //url:'http://ask.tongzhuo100.com/server/****.php?='+Math.random(),   //url
              dataType:"json",        //json格式
              data:{},    //如果需要提交附加参数，视情况添加
              clearForm: false,        //成功提交后，清除所有表单元素的值
              resetForm: false,        //成功提交后，重置所有表单元素的值
              cache:false,          
              async:false,          //同步返回
              success:function(data){
                console.log(data);
                if(data.code==0){
                    layer.msg(data.msg,{icon:2,time:1000},function(data){
                        // $("#tpl_name").attr('value',data.msg);
                        // $("#reset").click();
                        // x_admin_close();
                        location.reload();
                    });
                }else{
                    layer.msg(data.msg,{icon:1,time:500},function(data){
                        // $("#tpl_name").attr('value',data.msg);
                        // $("#reset").click();
                        // x_admin_close();
                        // location.reload();
                    });
                }
              //服务器端返回处理逻辑
                },
                error:function(XmlHttpRequest,textStatus,errorThrown){
                    layer.msg('操作失败:服务器处理失败');
              }
            }; 
        // bind form using 'ajaxForm' 
        $('#mainForm').ajaxForm(options).submit(function(data){
            //无逻辑
        }); 

    });

    function clear_cache(){
        $.ajax({
            url: "clear_cache",
            type: 'post',
            dataType: 'json',
            data: {},
        })
        .done(function(data) {
             if(data.code==1){
                  layer.msg(data.msg,{icon:1,time:1000},function(){
                     location.reload();
                  });
              }else{
                  layer.msg(data.msg,{icon:2,time:1000});
              }
        })
    }

</script>

<script src="__module__/layui/layui.all.js" charset="utf-8"></script>
</html>
