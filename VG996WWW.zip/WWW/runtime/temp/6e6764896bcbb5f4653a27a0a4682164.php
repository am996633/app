<?php if (!defined('THINK_PATH')) exit(); /*a:3:{s:68:"E:\phpstudy\WWW/application/admin\view\basic_config\suffix_list.html";i:1558779810;s:55:"E:\phpstudy\WWW/application/admin\view\public\head.html";i:1558778994;s:55:"E:\phpstudy\WWW/application/admin\view\public\foot.html";i:1533596491;}*/ ?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>VG目录站群泛目录管理系统</title>
  <meta name="renderer" content="webkit|ie-comp|ie-stand">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width,user-scalable=yes, minimum-scale=0.4, initial-scale=0.8" />
    <meta http-equiv="Cache-Control" content="no-siteapp" />
    <link rel="shortcut icon" href="__static__/favicon.ico" type="image/x-icon" />
    <link rel="stylesheet" href="__static__/css/font.css">
    <link rel="stylesheet" href="__module__/layui/css/layui.css">
    <link rel="stylesheet" href="__static__/css/xadmin.css">
    <script type="text/javascript" src="__js__/jquery.min.js"></script>
    <script src="__module__/layui/layui.all.js" charset="utf-8"></script>
    <script type="text/javascript" src="__static__/js/xadmin.js"></script>
    <script type="text/javascript" src="__static__/js/jquery.form.js"></script>
</head>


    <body>



    <div class="x-body" >

        <fieldset class="layui-elem-field">
          <legend>说明</legend>
          <div class="layui-field-box">
              <font style="color:blue">VG目录站群：支持标签：{来源}
</font>
          </div>
        </fieldset>


    <fieldset class="layui-elem-field">
      <legend>后缀规则列表</legend>
      <div class="layui-field-box">


        <button class="layui-btn layui-btn-small " onclick="x_admin_show('添加规则','add_suffix',500,300)">
        </i>手动添加</button>

        <button class="layui-btn layui-btn-small " onclick="x_admin_show('导入规则','import_suffix',390,300)">
        </i>导入TXT</button>


        <button class="layui-btn layui-btn-warnning  layui-btn-small " onclick='del_many()'>批量删除</button>


       <button class="layui-btn layui-btn-danger  layui-btn-small " onclick="del_all()">
        </i>一键清空</button>




        <button onclick="javascript:location.reload()" class="layui-btn layui-btn-small">刷新</button>
        <span class="x-right" style="line-height:40px">VG目录站群：数量:<?php echo $suffix_list->total(); ?></span>
            <table class="layui-table">
        <thead>


          <tr>
            <th  width="10">
              <div class="header layui-form-checkbox jx" lay-skin="primary"><i class="layui-icon">&#xe605;</i></div>
            </th>
            <th>后缀</th>
            <th width="100">操作</th>
        </thead>
        <tbody>
            


            <?php if(is_array($suffix_list) || $suffix_list instanceof \think\Collection || $suffix_list instanceof \think\Paginator): $i = 0; $__LIST__ = $suffix_list;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>

            <tr>
                <td>
                  <div class="layui-form-checkbox jj" lay-skin="primary" data-id='<?php echo $vo['id']; ?>'><i class="layui-icon">&#xe605;</i></div>
                </td>
                <td><?php echo $vo['m_suffix']; ?></td>
                <td>
                    <button class="layui-btn layui-btn-mini" onclick="x_admin_show('编辑规则','edit_suffix?id=<?php echo $vo['id']; ?>',800,200)">编辑</button>
                    <button onclick="del(this,<?php echo $vo['id']; ?>)"  class="layui-btn layui-btn-mini layui-btn-danger">删除</button>
                </td>
            </tr>
            <?php endforeach; endif; else: echo "" ;endif; ?>
       
        </tbody>
      </table>





      </div>
    </fieldset>






	      <div class="page">
	        <div>
                <?php echo $suffix_list->render(); ?>
	        </div>
	      </div>



    </div>
</body>
<script type="text/javascript">
        

    function del(obj,id){
        // var count = $(".i_count")[0].innerText;
        layer.confirm('确认要删除吗？',function(index){
            //捉到所有被选中的，发异步进行删除
            $.post("<?php echo url('admin/basic_config/delete_suffix'); ?>", {id: id}, function(data, textStatus, xhr) {
          /*optional stuff to do after success */
              console.log(data);
              if(data.code==1){
                  layer.msg(data.msg,{icon:1,time:1000},function(){
                    location.reload();
                  });
              }else{
                  layer.msg(data.msg,{icon:2,time:1000});
              }
            
            });
        });
      }


      function del_all(){
        // var count = $(".i_count")[0].innerText;
        layer.confirm('确认要清空吗？',function(index){
            //捉到所有被选中的，发异步进行删除
            $.post("<?php echo url('admin/basic_config/delete_all_suffix'); ?>", {}, function(data, textStatus, xhr) {
          /*optional stuff to do after success */
              console.log(data);
              if(data.code==1){
                  layer.msg(data.msg,{icon:1,time:1000},function(){
                    location.reload();
                  });
              }else{
                  layer.msg(data.msg,{icon:2,time:1000});
              }
            
            });
        });
      }



      function  del_many(){
              if(!$('div').hasClass('layui-form-checked')){
                      layer.msg('请勾选数据');
                      return;
              }

              // if(!$('div').hasClass('jj')){
              //     layer.msg('请勾选数据');
              //         return;
              // }

             layer.confirm('确认要删除吗？',function(index){


                  $('.layui-form-checked').each(function(data){
                     
                      console.log($(this).hasClass('jx')&&$(this).hasClass(''));
                      var id = $(this).attr('data-id');

                      if(id!==undefined &&id!==''&&id!==null){
                          // console.log(id);
                          $.ajax({
                            url: 'delete_many_suffix',
                            type: 'post',
                            dataType: 'json',
                            data: {id: id},
                          })
                          .done(function(data) {
                              
                          })
                      }
                  });

                  layer.msg('批量删除成功',{time:500},function(data){
                       location.reload()           
                  });


              });
      }




</script>
<script src="__module__/layui/layui.all.js" charset="utf-8"></script>
</html>
