<?php if (!defined('THINK_PATH')) exit(); /*a:3:{s:71:"E:\phpstudy\WWW/application/admin\view\basic_config\import_keyword.html";i:1558779839;s:55:"E:\phpstudy\WWW/application/admin\view\public\head.html";i:1558778994;s:55:"E:\phpstudy\WWW/application/admin\view\public\foot.html";i:1533596491;}*/ ?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>VG目录站群泛目录管理系统</title>
  <meta name="renderer" content="webkit|ie-comp|ie-stand">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width,user-scalable=yes, minimum-scale=0.4, initial-scale=0.8" />
    <meta http-equiv="Cache-Control" content="no-siteapp" />
    <link rel="shortcut icon" href="__static__/favicon.ico" type="image/x-icon" />
    <link rel="stylesheet" href="__static__/css/font.css">
    <link rel="stylesheet" href="__module__/layui/css/layui.css">
    <link rel="stylesheet" href="__static__/css/xadmin.css">
    <script type="text/javascript" src="__js__/jquery.min.js"></script>
    <script src="__module__/layui/layui.all.js" charset="utf-8"></script>
    <script type="text/javascript" src="__static__/js/xadmin.js"></script>
    <script type="text/javascript" src="__static__/js/jquery.form.js"></script>
</head>


<body>
<style type="text/css" media="screen">
header {
    color: black;
}
</style>
<div class="x-body" >

      <blockquote class="layui-elem-quote">VG目录站群：导入编码utf-8的TXT文件,限制5M</blockquote>

   
       
      <div class="layui-upload-drag" id="test10">
        <i class="layui-icon"></i>
        <p>点击上传，或将文件拖拽到此处</p>
      </div>
</div>
</body>

<script type="text/javascript">
        var form = layui.form;
        var layer = layui.layer;
              //自定义验证规则
              form.verify({
                username: function(value){
                  if(value.length < 5){
                    return '用户名至少得5个字符啊';
                  }
                }
              });
        //监听提交
        form.on('submit(demo1)', function(data){
              layer.alert(JSON.stringify(data.field), {
              title: '最终的提交信息'
            })
            return false;
          });

     var upload = layui.upload;
      //拖拽上传
      upload.render({
        elem: '#test10'
        ,url: '<?php echo $function_name; ?>'
        ,exts:'txt'
        // ,accept: 'file' //允许上传的文件类型
        ,size: 1024*5 //最大允许上传的文件大小

        ,before: function(obj){ //obj参数包含的信息，跟 choose回调完全一致，可参见上文。
            layer.load(); //VG目录站群：上传loading
        }

        ,done: function(data){
          if(data.code==0){
                    layer.msg(data.msg);
                }else{
                    layer.msg(data.msg,{icon:1,time:500},function(){
                        $("#reset").click();
                        x_admin_close();
                        parent.location.reload();
                    });
                }
        }
      });


    $(document).ready(function(){ 
         var options = {
              type:'post',           //post提交
              // url:'',   //url
              dataType:"json",        //json格式
              data:{},    //如果需要提交附加参数，视情况添加
              clearForm: false,        //成功提交后，清除所有表单元素的值
              resetForm: false,        //成功提交后，重置所有表单元素的值
              cache:false,          
              async:false,          //同步返回
              success:function(data){
                console.log(data);
                if(data.code==0){
                    layer.msg(data.msg);
                }else{
                    layer.msg(data.msg,{icon:1,time:500},function(){
                        x_admin_close();
                        parent.location.reload();
                    });
                }
              //服务器端返回处理逻辑
                },
                error:function(XmlHttpRequest,textStatus,errorThrown){
                    layer.msg('操作失败:服务器处理失败');
              }
            }; 
        // bind form using 'ajaxForm' 
        $('#mainForm').ajaxForm(options).submit(function(data){
            //无逻辑
        }); 

    });
    
</script>
<script src="__module__/layui/layui.all.js" charset="utf-8"></script>
</html>
