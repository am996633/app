<?php if (!defined('THINK_PATH')) exit(); /*a:3:{s:52:"E:\phpstudy\WWW/application/install\view\\step5.html";i:1558778303;s:57:"E:\phpstudy\WWW/application/install\view\public\head.html";i:1558778436;s:59:"E:\phpstudy\WWW/application/install\view\public\footer.html";i:1558778362;}*/ ?>
<!doctype html>
<html>
<head>
	<meta charset="utf-8" />
<title>VG目录站群程序安装-V5.25版本</title>
<link rel="stylesheet" href="__static__/install/simpleboot/themes/flat/theme.min.css" />
<link rel="stylesheet" href="__static__/install/css/install.css" />
<link rel="stylesheet" href="__static__/font-awesome/css/font-awesome.min.css" type="text/css">


	<script src="__static__/js/jquery.js"></script>
</head>
<body>
	<div class="wrap">
		<include file="public/header" />
		<section class="section">
			<div style="padding: 40px 20px;">
				<div class="text-center">
					<a style="font-size: 18px;">恭喜您，VG目录站群泛目录程序最新版本V5.25安装完成！</a>
					<br>
					<br>
					<div class="alert alert-danger" style="width: 350px;display: inline-block;">
						VG目录站群提示：为了您站点的安全，安装完成后即可将网站application目录下的“install”文件夹删除!
						另请对data/conf/database.php文件做好备份，以防丢失！
					</div>
					<br>
					<a class="btn btn-success" href="<?php echo lotus_get_root(); ?>">进入后台</a>
				</div>
			</div>
		</section>
	</div>
	<div class="footer">
	&copy; 2019-<?php echo date('Y'); ?> <a href="#" target="_blank">VG目录站群团队</a>
</div>
</body>
</html>