﻿<?php
	//VG目录站群：设置目录名
	include 'database.php';
	function read_tpl(){
		$tpl_sz = array();
		foreach(glob('templates/*.html') as $tpl){
			$tpl_sz[] = basename($tpl);
		}
		$tpl = file_get_contents('templates/'.$tpl_sz[mt_rand(0,count($tpl_sz)-1)]);
		return $tpl;
	}

	function read_data($db_table){
		$_mysql = new DB();
		$_sel = $_mysql->_query("SELECT * FROM `$db_table` AS t1 JOIN (SELECT ROUND(RAND() * ((SELECT MAX(id) FROM `$db_table`)-(SELECT MIN(id) FROM `$db_table`))+(SELECT MIN(id) FROM `$db_table`)) AS id) AS t2 WHERE t1.id >= t2.id ORDER BY t1.id LIMIT 1");
		$mysql_sel = $_sel->fetch_row();
		return $mysql_sel['1'];
	}

	function read_mulu($db_table){
		$_mysql = new DB();
		$_sel = $_mysql->_query("SELECT value from ".$db_table);
		$mysql_sel = $_sel->fetch_row();
		return $mysql_sel['0'];
	}


	function zm_content($str){
		$content_sz = mb_str_split($str);
		foreach($content_sz as $content){
			$contents .= '&#'.base_convert(bin2hex(mb_convert_encoding($content, 'ucs-4', 'utf-8')), 16, 10).';';
		}
		return $contents;
	}

	function mb_str_split($str){  
   		return preg_split('/(?<!^)(?!$)/u', $str );  
	}

	function randCode($length, $type) {
    $arr = array(1 => "abcdefghijklmnopqrstuvwxyz", 2 => "ABCDEFGHIJKLMNOPQRSTUVWXYZ", 3 => "0123456789");
    	if($type == 0) {
        	array_pop($arr);
        	$string = implode("", $arr);
    	}elseif($type == "-1") {
        	$string = implode("", $arr);
    	}else{
        	$string = $arr[$type];
    	}
    	$count = strlen($string) - 1;
    	for($i = 0; $i < $length; $i++) {
        	$str[$i] = $string[rand(0, $count)];
        	$code .= $str[$i];
    	}
    	return $code;
	}

	function read_y(){
		$start = mktime(0,0,0,1,1,1974);
 		$end = mktime(23,59,59,1,1,2018);
 		$rand = rand($start,$end);
 		$year = date("Y",$rand);
 		return $year;
	}


	function clfh($content){
		
		$m_content = thfh($content);

		while(strstr($m_content,'{dh}')){
			$luanma = qu_luanma();
			$m_content = preg_replace('/{dh}/',$luanma .'，',$m_content,1);
		}

		while(strstr($m_content,'{jh}')){
			$luanma = qu_luanma();
			$m_content = preg_replace('/{jh}/',$luanma .'。',$m_content,1);
		}
		
		while(strstr($m_content,'{fh}')){
			$luanma = qu_luanma();
			$m_content = preg_replace('/{fh}/',$luanma .'；',$m_content,1);
		}

		while(strstr($m_content,'{duh}')){
			$luanma = qu_luanma();
			$m_content = preg_replace('/{duh}/',$luanma .'、',$m_content,1);
		}

		while(strstr($m_content,'{gth}')){
			$luanma = qu_luanma();
			$m_content = preg_replace('/{gth}/',$luanma .'！',$m_content,1);
		}

		while(strstr($m_content,'{mh}')){
			$luanma = qu_luanma();
			$m_content = preg_replace('/{mh}/',$luanma .'：',$m_content,1);
		}

		return $m_content;
	}

	function qu_luanma(){

		$luanma_array = array('','','','');
		$luanma = '';
		for($i=0;$i<mt_rand(2,5);$i++){
			$luanma .= $luanma_array[mt_rand(0,count($luanma_array)-1)];
		}
		return $luanma;
	}

	function thfh($content){

		$content = preg_replace('/，/','{dh}',$content);
		
		$content = preg_replace('/。/','{jh}',$content);
		
		$content = preg_replace('/；/','{fh}',$content);
		
		$content = preg_replace('/、/','{duh}',$content);
		
		$content = preg_replace('/！/','{gth}',$content);
		
		$content = preg_replace('/：/','{mh}',$content);
		return $content;
	}


?>