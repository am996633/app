﻿<?php
// + 官网：www.966seo.com
// +----------------------------------------------------------------------
// + VG目录站群团队最新力作，达到秒收录秒排名效果！
// +----------------------------------------------------------------------
// + VG目录站群泛目录适合各行业操作关键词快速排名！
// +----------------------------------------------------------------------
// + VG目录站群泛目录：为关键词秒收秒排快速排名而生！
// +----------------------------------------------------------------------
	error_reporting(E_ERROR);
	set_time_limit(0);
	date_default_timezone_set(PRC);
	header("content-Type: text/html; charset=utf-8");
	$cachefile = 'cache/'.sha1($_SERVER['HTTP_HOST'].$_SERVER["REQUEST_URI"]).'.cache';
	ob_start();
	if(file_exists($cachefile)){
		include($cachefile);
		ob_end_flush();
    	exit;
	}
	include 'function.php';
	$html = read_tpl();
	include 'Replace.php';
	echo $html;
	if(is_dir('cache')){
		$info = ob_get_contents();
		file_put_contents($cachefile,$info);
	}else{
		if(@mkdir('cache')){
			$info = ob_get_contents();
			file_put_contents($cachefile,$info);
		}
	}
?>