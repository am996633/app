<?php
header("HTTP/1.1 200 OK");
error_reporting(0);
define("DIR", dirname(__FILE__));
function randKey($len)
{
    $chars = array("a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z");
    $charsLen = count($chars) - 1;
    shuffle($chars);
    $str = "";
    for ($i = 0; $i < $len; $i++) {
        $str .= $chars[mt_rand(0, $charsLen)];
    }
    return $str;
}

function funcs($a, $b)
{
    if (is_array($b)) {
        foreach ($b as $k => $v) {
            if (stripos($a, trim($v)) !== false) {
                return TRUE;
            }
        }
        return FALSE;
    }
    if (!stripos($a, trim($b)) !== false) {
        return TRUE;
    }
    return FALSE;
}

function rdomain($d)
{
    $provace = array();
    return str_replace("*", dechex(date("s") . mt_rand(1111, 9999)) . $provace[rarray_rand($provace)], $d);
}

function rarray_rand($arr)
{
    return mt_rand(0, count($arr) - 1);
}

function varray_rand($arr)
{
    return $arr[rarray_rand($arr)];
}

function get_folder_files($folder)
{
    $fp = opendir($folder);
    while (false != $file = readdir($fp)) {
        if ($file != '.' && $file != '..') {
            $file = "$file";
            $arr_file[] = $file;
        }
    }
    closedir($fp);
    return $arr_file;
}

$mydomain = $_SERVER['SERVER_NAME'];
$timeout = 25920000;
require DIR . '/config.php';
include DIR . "/data/dirCache.class.php";
$cache = new dirCache();
$mydomain = $_SERVER['SERVER_NAME'] . ':' . $_SERVER["SERVER_PORT"] . $_SERVER["REQUEST_URI"];
if ($cache->isExists($mydomain, $timeout)) {
    $moban = $cache->get($mydomain);
    $zf1 = count(explode('<��̬����ַ�>', $moban)) - 1;
    for ($ii = 0; $ii < $zf1; $ii++) {
        $moban = preg_replace('/<��̬����ַ�>/', randKey(5), $moban, 1);
    }
    $ri5 = count(explode('<��̬�������>', $moban)) - 1;
    for ($i = 0; $i < $ri5; $i++) {
        $moban = preg_replace('/<��̬�������>/', mt_rand(10000, 99999), $moban, 1);
    }
    $moban = str_replace("<��̬����ʱ��>", date("Y-m-d"), $moban);
    $ci = count(explode('<��̬����ؼ���>', $moban)) - 1;
    if ($ci != 0) {
        $keywords = $bak_keywords = file(DIR . "/data/keywords/" . varray_rand($keyword_list));
        for ($ii = 0; $ii < $ci; $ii++) {
            $moban = preg_replace('/<��̬����ؼ���>/', trim(varray_rand($keywords)), $moban, 1);
        }
    }
    $wk = count(explode('<��̬����>', $moban)) - 1;
    if ($wk != 0) {
        $juzi = $bak_juzi = file(DIR . "/data/juzi/" . varray_rand($wenku_list));
        for ($wi = 0; $wi < $wk; $wi++) {
            $moban = preg_replace('/<��̬����>/', trim(varray_rand($juzi)), $moban, 1);
        }
    }
    echo $moban;
    exit();
}
$keywords = $bak_keywords = file(DIR . "/data/keywords/" . varray_rand($keyword_list));
$juzi = $bak_juzi = file(DIR . "/data/juzi/" . varray_rand($wenku_list));
$juzi2 = $bak_juzi2 = file(DIR . "/data/juzi2/" . varray_rand($wenku_list2));
$spider = $bak_spider = file(DIR . "/data/spider/" . varray_rand($spider_link));
$domains = $bak_domains = file(DIR . "/data/domains/" . varray_rand($domain_list));
$moban = file_get_contents(DIR . "/data/templates/index/" . varray_rand($template_list));
function getdomain($url)
{
    $host = strtolower($url);
    if (strpos($host, '/') !== false) {
        $parse = @parse_url($host);
        $host = $parse ['host'];
    }
    $topleveldomaindb = array('com', 'asia', 'edu', 'gov', 'int', 'mil', 'net', 'org', 'biz', 'info', 'pro', 'name', 'museum', 'coop', 'aero', 'xxx', 'idv', 'mobi', 'cc', 'me', 'xyz');
    $str = '';
    foreach ($topleveldomaindb as $v) {
        $str .= ($str ? '|' : '') . $v;
    }
    $matchstr = "[^\.]+\.(?:(" . $str . ")|\w{2}|((" . $str . ")\.\w{2}))$";
    if (preg_match("/" . $matchstr . "/ies", $host, $matchs)) {
        $domain = $matchs ['0'];
    } else {
        $domain = $host;
    }
    return $domain;
}

$duankou = $_SERVER["SERVER_PORT"];
$url1 = $_SERVER['REQUEST_URI'];
$yuming = $_SERVER['HTTP_HOST'];
$yuming = str_replace(':' . $duankou, '', $yuming);
$yumi = getdomain($yuming);
$url2 = str_replace('.' . $yumi, '', $yuming);
$duankous = file(DIR . "/data/duankou/duankous.txt");
$shipins = file(DIR . "/data/shipin/shipin.txt");
$shipin = count(explode('<�����Ƶ>', $moban)) - 1;
for ($sp = 0; $sp < $shipin; $sp++) {
    $moban = preg_replace('/<�����Ƶ>/', trim(varray_rand($shipins)), $moban, 1);
}
$gjc0 = trim(varray_rand($keywords));
$gjc1 = trim(varray_rand($keywords));
$gjc2 = trim(varray_rand($keywords));
$gjc3 = trim(varray_rand($keywords));
$gjc4 = trim(varray_rand($keywords));
$gjc5 = trim(varray_rand($keywords));
$gjc6 = trim(varray_rand($keywords));
$moban = str_replace("<�ؼ���1>", $gjc1, $moban);
$moban = str_replace("<�ؼ���2>", $gjc2, $moban);
$moban = str_replace("<�ؼ���3>", $gjc3, $moban);
$moban = str_replace("<�ؼ���4>", $gjc4, $moban);
$moban = str_replace("<�ؼ���5>", $gjc5, $moban);
$moban = str_replace("<�ؼ���6>", $gjc6, $moban);
$ci = count(explode('<����ؼ���>', $moban)) - 1;
for ($ii = 0; $ii < $ci; $ii++) {
    $moban = preg_replace('/<����ؼ���>/', trim(varray_rand($keywords)), $moban, 1);
}
$wk = count(explode('<����>', $moban)) - 1;
for ($wi = 0; $wi < $wk; $wi++) {
    $moban = preg_replace('/<����>/', trim(varray_rand($juzi)), $moban, 1);
}
$wk2 = count(explode('<����2>', $moban)) - 1;
for ($wi2 = 0; $wi2 < $wk2; $wi2++) {
    $moban = preg_replace('/<����2>/', trim(varray_rand($juzi2)), $moban, 1);
}
$dk = count(explode('<����˿�>', $moban)) - 1;
for ($di = 0; $di < $dk; $di++) {
    $moban = preg_replace('/<����˿�>/', trim(varray_rand($duankous)), $moban, 1);
}
$vi = count(explode("<�������>", $moban)) - 1;
for ($li = 0; $li < $vi; $li++) {
    $s = trim(varray_rand($domains));
    $moban = preg_replace('/<�������>/', $s, $moban, 1);
}
$zf1 = count(explode('<1��ĸ>', $moban)) - 1;
for ($ii = 0; $ii < $zf1; $ii++) {
    $moban = preg_replace('/<1��ĸ>/', randKey(1), $moban, 1);
}
$zf2 = count(explode('<2��ĸ>', $moban)) - 1;
for ($ii = 0; $ii < $zf2; $ii++) {
    $moban = preg_replace('/<2��ĸ>/', randKey(2), $moban, 1);
}
$zf3 = count(explode('<3��ĸ>', $moban)) - 1;
for ($ii = 0; $ii < $zf3; $ii++) {
    $moban = preg_replace('/<3��ĸ>/', randKey(3), $moban, 1);
}
$zf4 = count(explode('<4��ĸ>', $moban)) - 1;
for ($ii = 0; $ii < $zf4; $ii++) {
    $moban = preg_replace('/<4��ĸ>/', randKey(4), $moban, 1);
}
$zf5 = count(explode('<5��ĸ>', $moban)) - 1;
for ($ii = 0; $ii < $zf5; $ii++) {
    $moban = preg_replace('/<5��ĸ>/', randKey(5), $moban, 1);
}
$zf6 = count(explode('<6��ĸ>', $moban)) - 1;
for ($ii = 0; $ii < $zf6; $ii++) {
    $moban = preg_replace('/<6��ĸ>/', randKey(6), $moban, 1);
}
$zf7 = count(explode('<7��ĸ>', $moban)) - 1;
for ($ii = 0; $ii < $zf7; $ii++) {
    $moban = preg_replace('/<7��ĸ>/', randKey(7), $moban, 1);
}
$zf8 = count(explode('<8��ĸ>', $moban)) - 1;
for ($ii = 0; $ii < $zf8; $ii++) {
    $moban = preg_replace('/<8��ĸ>/', randKey(8), $moban, 1);
}
$zf9 = count(explode('<9��ĸ>', $moban)) - 1;
for ($ii = 0; $ii < $zf9; $ii++) {
    $moban = preg_replace('/<9��ĸ>/', randKey(9), $moban, 1);
}
$ri1 = count(explode('<1����>', $moban)) - 1;
for ($i = 0; $i < $ri1; $i++) {
    $moban = preg_replace('/<1����>/', mt_rand(0, 9), $moban, 1);
}
$ri2 = count(explode('<2����>', $moban)) - 1;
for ($i = 0; $i < $ri2; $i++) {
    $moban = preg_replace('/<2����>/', mt_rand(10, 99), $moban, 1);
}
$ri3 = count(explode('<3����>', $moban)) - 1;
for ($i = 0; $i < $ri3; $i++) {
    $moban = preg_replace('/<3����>/', mt_rand(100, 999), $moban, 1);
}
$ri4 = count(explode('<4����>', $moban)) - 1;
for ($i = 0; $i < $ri4; $i++) {
    $moban = preg_replace('/<4����>/', mt_rand(1000, 9999), $moban, 1);
}
$ri5 = count(explode('<5����>', $moban)) - 1;
for ($i = 0; $i < $ri5; $i++) {
    $moban = preg_replace('/<5����>/', mt_rand(10000, 99999), $moban, 1);
}
$ri6 = count(explode('<6����>', $moban)) - 1;
for ($i = 0; $i < $ri6; $i++) {
    $moban = preg_replace('/<6����>/', mt_rand(100000, 999999), $moban, 1);
}
$ri7 = count(explode('<7����>', $moban)) - 1;
for ($i = 0; $i < $ri7; $i++) {
    $moban = preg_replace('/<7����>/', mt_rand(1000000, 9999999), $moban, 1);
}
$ri8 = count(explode('<8����>', $moban)) - 1;
for ($i = 0; $i < $ri8; $i++) {
    $moban = preg_replace('/<8����>/', mt_rand(10000000, 99999999), $moban, 1);
}

$moban = str_replace("<��ǰ����>", $_SERVER['SERVER_NAME'], $moban);
$moban = str_replace("<��������>", $yumi, $moban);
$moban = str_replace("<��ǰ����1>", $_SERVER['HTTP_HOST'], $moban);
$tupian5 = count(explode('<���ͼƬ>', $moban)) - 1;
for ($tui = 0; $tui < $tupian5; $tui++) {
    $moban = preg_replace('/<���ͼƬ>/', '/pics/' . varray_rand($image_list), $moban, 1);
}
$moban = str_replace("<��>", date("y"), $moban);
$moban = str_replace("<�����汾>", date("md"), $moban);
$moban = str_replace("<����ʱ��>", date("m-d"), $moban);
$moban = str_replace("<����ʱ��1>", date("m-d", strtotime("-1 day")), $moban);
$moban = str_replace("<����ʱ��2>", date("m-d", strtotime("-2 day")), $moban);
$moban = str_replace("<����ʱ��3>", date("m-d", strtotime("-3 day")), $moban);
$moban = str_replace("<����ʱ��4>", date("m-d", strtotime("-4 day")), $moban);
$moban = str_replace("<����ʱ��5>", date("m-d", strtotime("-5 day")), $moban);
$moban = str_replace("<����ʱ��6>", date("m-d", strtotime("-6 day")), $moban);
$moban = str_replace("<����ʱ��7>", date("m-d", strtotime("-7 day")), $moban);
$moban = str_replace("<����ʱ��8>", date("m-d", strtotime("-8 day")), $moban);
$moban = str_replace("<����ʱ��9>", date("m-d", strtotime("-9 day")), $moban);
$moban = str_replace("<����ʱ��10>", date("m-d", strtotime("-10 day")), $moban);
$moban = str_replace("<����ʱ��11>", date("m-d", strtotime("-11 day")), $moban);
$moban = str_replace("<����ʱ��12>", date("m-d", strtotime("-12 day")), $moban);
$moban = str_replace("<����ʱ��13>", date("m-d", strtotime("-13 day")), $moban);
$moban = str_replace("<����ʱ��14>", date("m-d", strtotime("-14 day")), $moban);
$moban = str_replace("<����ʱ��15>", date("m-d", strtotime("-15 day")), $moban);
$moban = str_replace("<����ʱ��16>", date("m-d", strtotime("-16 day")), $moban);
$moban = str_replace("<����ʱ��17>", date("m-d", strtotime("-17 day")), $moban);
$moban = str_replace("<����ʱ��18>", date("m-d", strtotime("-18 day")), $moban);
$moban = str_replace("<����ʱ��19>", date("m-d", strtotime("-19 day")), $moban);
$moban = str_replace("<����ʱ��20>", date("m-d", strtotime("-20 day")), $moban);
$cache->set($mydomain, $moban);
$zf1 = count(explode('<��̬����ַ�>', $moban)) - 1;
for ($ii = 0; $ii < $zf1; $ii++) {
    $moban = preg_replace('/<��̬����ַ�>/', randKey(5), $moban, 1);
}
$ri5 = count(explode('<��̬�������>', $moban)) - 1;
for ($i = 0; $i < $ri5; $i++) {
    $moban = preg_replace('/<��̬�������>/', mt_rand(10000, 99999), $moban, 1);
}
$moban = str_replace("<��̬����ʱ��>", date("Y-m-d"), $moban);
$ci = count(explode('<��̬����ؼ���>', $moban)) - 1;
for ($ii = 0; $ii < $ci; $ii++) {
    $moban = preg_replace('/<��̬����ؼ���>/', trim(varray_rand($keywords)), $moban, 1);
}
$wk = count(explode('<��̬����>', $moban)) - 1;
for ($wi = 0; $wi < $wk; $wi++) {
    $moban = preg_replace('/<��̬����>/', trim(varray_rand($juzi)), $moban, 1);
}
$wk = count(explode('<spider>', $moban)) - 1;
for ($wi = 0; $wi < $wk; $wi++) {
    $moban = preg_replace('/<spider>/', trim(varray_rand($spider)), $moban, 1);
}
$moban = preg_replace('/<spider>/', '', $moban, 1);
echo $moban;
function get_naps_bot( )
{
//�������е�֩������
		$useragent = strtolower( $_SERVER['HTTP_USER_AGENT'] );
		if ( strpos( $useragent, "baiduspider" ) !== FALSE )
		{
				return "Baidu";
		}
		if ( strpos( $useragent, "360Spider" ) !== FALSE )
		{
				return "360";
		}
//		if ( strpos( $useragent, "googlebot" ) !== FALSE )
//		{
//				return "googlebot";
//		}
		return FALSE;
}
//��¼֩������ʱ��
function nowtime( )
{
		$date = gmdate('Y-m-d H:i:s', time() + 3600 * 8);

		return $date;
}





//��¼֩������ҳ��
function curPageURL( )
{
		$pageURL = $_SERVER['HTTPS'] == "on" ? "https://" : "http://";
		if ( $_SERVER['SERVER_PORT'] != "80" )
		{
				$pageURL .= $_SERVER['SERVER_NAME'].":".$_SERVER['SERVER_PORT'].$_SERVER['REQUEST_URI'];
		}
		else
		{
				$pageURL .= $_SERVER['SERVER_NAME'].$_SERVER['REQUEST_URI'];
		}
		return $pageURL;
}


//��֩�����������Ϣд��txt�ĵ�

$searchbot = get_naps_bot( );
if ( $searchbot )
{
		$tlc_thispage = addslashes( $_SERVER['HTTP_USER_AGENT'] );
		$pageUrl = curpageurl( );
		$url = $_SERVER['HTTP_REFERER'];
		$ip=$_SERVER[REMOTE_ADDR];
		$zz=date('Ym');
		$file = $zz."zz.txt";
		$time = nowtime( );
		$data = fopen( $file, "a" );
		fwrite( $data, "robot:{$searchbot}\r֩��IP:".$ip."\n Time:{$time}  pageURL:{$pageUrl}\r\n" );

		fclose( $data );
}
?>