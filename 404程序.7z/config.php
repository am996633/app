<?php
!defined('DIR') && die('Access denied');
$keyword_list = get_folder_files(DIR . '/data/keywords/');
$wenku_list = get_folder_files(DIR . '/data/juzi/');
$spider_link = get_folder_files(DIR . '/data/spider/');
$wenku_list2 = get_folder_files(DIR . '/data/juzi2/');
$domain_list = array('domains.txt',);
$template_list = get_folder_files(DIR . '/data/templates/index/');
$image_list = get_folder_files(DIR . '/pics/');
?>