<?php
return array (
  'name' => '���Բɼ��ڵ�2',
  'from_title' => '����Ӱ��',
  'from_url' => 'http://www.baofeng.com',
  'charset' => 'auto',
  'other_url' => '',
  'resdomain' => '',
  'img_delay_name' => '',
  'search_url' => '',
  'search_charset' => 'gb2312',
  'hidejserror' => '0',
  'no_siteapp' => '0',
  'licence' => '',
  'body_start' => '',
  'body_end' => '',
  'replacerules' => '/----------------�����滻�����и�ʽΪע��,�����ڷ���鿴,��ͬ��----------------/
##########
</head>******</head><div style="width:100%;height:50px;line-height:50px;text-align:center">��ʾ����ǰΪĬ�Ͻڵ㣬������ں�̨�޸�Ϊ����Ҫ��վ�㣡</div>
##########
/----------------ͼƬ�滻----------------/
##########
�������д�滻����
##########
/----------------����滻----------------/
##########
�������д�滻����
##########
/----------------�����滻----------------/
##########
�������д�滻����
##########',
  'siftrules' => '',
  'replace_before_on' => '0',
  'replacerules_before' => '',
  'siftrules_before' => '',
  'css' => '',
  'big52gbk' => '0',
  'replace' => '0',
  'rewrite' => 0,
  'tplfile' => '',
  'cookie' => '',
  'user_agent' => '',
  'referer' => '',
  'ip' => '',
  'ip_type' => '1',
  'zdy' => 
  array (
    0 => 
    array (
      'name' => '�б�',
      'ename' => 'newlist',
      'type' => '2',
      'body' => '',
      'regx' => '',
      'start' => '',
      'end' => '',
    ),
    2 => 
    array (
      'name' => '����',
      'ename' => 'body',
      'type' => '2',
      'body' => '',
      'regx' => '',
      'start' => '',
      'end' => '',
    ),
  ),
  'plus' => '',
  'siftags' => NULL,
  'time' => 1522262798,
  'domain_fan' => '0',
  'my_domain' => '',
  'from_domain' => '',
  'domain_rules' => '',
  'auto301' => '0',
  'charset_force' => '0',
  'theme_open' => '0',
  'theme_dir' => '',
  'theme_showotherurl' => '1',
  'urlrules_list' => '',
  'urlrules_listpage' => '',
  'urlrules_show' => '',
  'urlrules_showpage' => '',
  'rules_body' => '',
  'urlrules_other' => '',
  'theme_sifturl' => '',
  'auto_get_search' => '0',
  'source_replace' => '',
  'my_domain_auto' => '0',
  'from_domain_auto' => '0',
  'web_charset' => 'from',
  'web_debug' => 'off',
  'no_convert' => '0',
  'web_404_type' => 'display',
  'web_404_url' => '',
  'web_404_str' => '',
  'user_agent_mobile' => '',
  'user_agent_autochange' => 'auto',
  'ip_cachetime' => '600',
  'theme_dir_mobile' => '',
  'zdylist_open' => '0',
  'zdylist_rules' => '',
);
?>